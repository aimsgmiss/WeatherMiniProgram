//
//  SDKHelper.cpp
//  LearnOpenGLES
//
//  Created by xiang lin on 17/01/2018.
//  Copyright © 2018 . All rights reserved.
//

#import <mach-o/arch.h>
#import <assert.h>
#import <UIKit/UIKit.h>
#import <sys/utsname.h>
#import <sys/mount.h>
#import <stdlib.h>
#import <sys/socket.h> // Per msqr
#import <sys/sysctl.h>
#import <net/if.h>
#import <net/if_dl.h>
#import "SDKHelper.h"
#import "NetworkCollectPerformance.h"
//#import "TdrTypeUtil.h"
#import "ApmMetaInfoNetworkPack.h"
#import "SDKStructEnumDefine.h"
#include "GCloudPluginManager/Service/Report/IReportService.h"
#include "ReportTDM.h"
#import "GPMObserver.h"

#pragma  mark SDKWriteHelper

 SDKError::ErrorType SDKHelper::SDKWriteHelper:: writeFileAttribute(SDKWriteBuffer& writeBuffer,FileAttribute fileAttribute)
{
    SDKError::ErrorType          ret = SDKError::SDK_NO_ERROR;
    
    ret = writeBuffer.writeInt16(fileAttribute.hawkVersion);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return ret;
    }
    
    ret = writeBuffer.writeInt16(fileAttribute.randSeed);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return ret;
    }
    
    ret = writeBuffer.writeInt16(fileAttribute.networkType);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return ret;
    }
    
    ret = writeBuffer.writeInt32(fileAttribute.sceneQuality);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return ret;
    }
    
    ret = writeBuffer.writeInt32(fileAttribute.appInitTime);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return ret;
    }
    
    ret = writeBuffer.writeInt32(fileAttribute.tempSceneTime);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return ret;
    }
    
    
    /*ret = writeBuffer.writeInt16(fileAttribute.slientFlag);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return ret;
    }*/
  
    return ret;
    
}

SDKError::ErrorType SDKHelper::SDKWriteHelper::writeDeviceSpaceData(SDKWriteBuffer& writeBuffer,int32_t totalSpace,int32_t freeSpace)
{
    SDKError::ErrorType          ret = SDKError::SDK_NO_ERROR;

    ret = writeBuffer.writeInt32(totalSpace);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return ret;
    }
    
    ret = writeBuffer.writeInt32(freeSpace);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return ret;
    }
    
    return ret;
}


SDKError::ErrorType SDKHelper::SDKWriteHelper::writeSceneDataToBuffer(SDKWriteBuffer& writeBuffer,Scene scene)
{
    SDKError::ErrorType          ret = SDKError::SDK_NO_ERROR;
    
    ret = writeBuffer.writeChar(scene.flag);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeInt16(scene.sceneIndex);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeInt16(scene.sceneType);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeInt32(scene.timeStamp);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeInt16(scene.sceneStrLen);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeBytes(scene.sceneStrstr,scene.sceneStrLen);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    
    return ret;
}

 SDKError::ErrorType SDKHelper::SDKWriteHelper::writeFrameBuffer(SDKWriteBuffer& writeBuffer,Frame drawTriangleObj)
{
    SDKError::ErrorType         ret = SDKError::SDK_NO_ERROR;
    
    ret = writeBuffer.writeChar(drawTriangleObj.flag);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return ret;
    }
    
    ret = writeBuffer.writeInt32(drawTriangleObj.drawcall);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return ret;
    }
    
    ret = writeBuffer.writeInt32(drawTriangleObj.triangle);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return ret;
    }
    
    ret = writeBuffer.writeInt32(drawTriangleObj.timeInterval);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return ret;
    }
    
    ret = writeBuffer.writeInt32(drawTriangleObj.deltaSeconds);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return ret;
    }
    
    return ret;
}

SDKError::ErrorType SDKHelper::SDKWriteHelper::writeFrameState(SDKWriteBuffer& writeBuffer,FrameStateS frameState)
{
    SDKError::ErrorType         ret = SDKError::SDK_NO_ERROR;
    
    ret = writeBuffer.writeChar(frameState.flag);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return ret;
    }
    
    ret = writeBuffer.writeInt32(frameState.timeInterval);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return ret;
    }
    
    ret = writeBuffer.writeInt32(frameState.mX);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return ret;
    }
    
    ret = writeBuffer.writeInt32(frameState.mY);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return ret;
    }
    
    ret = writeBuffer.writeInt32(frameState.mZ);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return ret;
    }
    
    ret = writeBuffer.writeInt32(frameState.mPitch);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return ret;
    }
    
    ret = writeBuffer.writeInt32(frameState.mYaw);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return ret;
    }
    
    ret = writeBuffer.writeInt32(frameState.mRoll);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return ret;
    }
    
    return ret;
}

SDKError::ErrorType SDKHelper::SDKWriteHelper::writeDataPerSecToBuffer(SDKWriteBuffer& writeBuffer,DataPerSec dataPerSec)
{
    SDKError::ErrorType          ret = SDKError::SDK_NO_ERROR;
    
    ret = writeBuffer.writeChar(dataPerSec.flag);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeInt16(dataPerSec.fps);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeInt16(dataPerSec.appCpuUsage);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeInt32(dataPerSec.timeInterval);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeInt32(dataPerSec.appMemoryUsed);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    for (int index = 0; index < (sizeof(dataPerSec.reserved) / sizeof(int32_t)); index++)
    {
        ret = writeBuffer.writeInt32(dataPerSec.reserved[index]);
        
        if (ret != SDKError::SDK_NO_ERROR)
        {
            return  ret;
        }
    }
    
     ret = writeBuffer.writeInt32(dataPerSec.netSend);
     if (ret != SDKError::SDK_NO_ERROR)
     {
         return  ret;
     }
     
     ret = writeBuffer.writeInt32(dataPerSec.netRecv);
     if (ret != SDKError::SDK_NO_ERROR)
     {
         return  ret;
     }
    
     ret = writeBuffer.writeInt32(dataPerSec.reserved1);
     if (ret != SDKError::SDK_NO_ERROR)
     {
         return  ret;
     }
     
     ret = writeBuffer.writeInt32(dataPerSec.reserved2);
     if (ret != SDKError::SDK_NO_ERROR)
     {
         return  ret;
     }
    
   
    return ret;
}

SDKError::ErrorType SDKHelper::SDKWriteHelper::writeUserID(SDKWriteBuffer& writeBuffer,const char* userID)
{
    SDKError::ErrorType          ret = SDKError::SDK_NO_ERROR;
    uint16_t                     userIDLen;
    
    userIDLen = (uint16_t)strlen(userID);
    ret = writeBuffer.writeChar(kUserIDFlag);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeInt16(userIDLen);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeBytes(userID,userIDLen);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    return ret;
}

SDKError::ErrorType SDKHelper::SDKWriteHelper::writeLocal(SDKWriteBuffer& writeBuffer,const char* local)
{
    SDKError::ErrorType          ret = SDKError::SDK_NO_ERROR;
    uint16_t                     localLen;
    
    localLen = (uint16_t)strlen(local);
    ret = writeBuffer.writeChar(kLocalFlag);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeInt16(localLen);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeBytes(local,localLen);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    return ret;
}

SDKError::ErrorType SDKHelper::SDKWriteHelper::writeVersion(SDKWriteBuffer& writeBuffer,const char* version,uint16_t versionLen)
{
    SDKError::ErrorType          ret = SDKError::SDK_NO_ERROR;

    
    ret = writeBuffer.writeChar(kVersionFlag);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeInt16(versionLen);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeBytes(version,versionLen);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    return ret;
}

SDKError::ErrorType SDKHelper::SDKWriteHelper::writeIPCUUID(SDKWriteBuffer& writeBuffer,const char* iPCUUID,uint16_t len)
{
    SDKError::ErrorType          ret = SDKError::SDK_NO_ERROR;
    
    
    ret = writeBuffer.writeChar(kIPCUUIDFlag);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeInt16(len);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeBytes(iPCUUID,len);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    return ret;
}


SDKError::ErrorType SDKHelper::SDKWriteHelper::writeAppState(SDKWriteBuffer& writeBuffer,char flag,int32_t timeInterval)
{
    SDKError::ErrorType          ret = SDKError::SDK_NO_ERROR;
    
    
    ret = writeBuffer.writeChar(flag);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeInt32(timeInterval);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    
    return ret;
}


SDKError::ErrorType SDKHelper::SDKWriteHelper::writeQuality(SDKWriteBuffer& writeBuffer,int32_t quality)
{
    SDKError::ErrorType          ret = SDKError::SDK_NO_ERROR;
  
    ret = writeBuffer.writeChar(kSceneQualityFlag);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeInt32(quality);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }

    return ret;
}

SDKError::ErrorType SDKHelper::SDKWriteHelper::writeDeviceLevel(SDKWriteBuffer& writeBuffer,int32_t deviceLevel)
{
    SDKError::ErrorType          ret = SDKError::SDK_NO_ERROR;
    
    ret = writeBuffer.writeChar(kDeviceLevelFlag);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeInt32(deviceLevel);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    return ret;
}


SDKError::ErrorType SDKHelper::SDKWriteHelper::writeGameEvent(SDKWriteBuffer& writeBuffer,int32_t timeInterval,int32_t key,const char* info)
{
    SDKError::ErrorType          ret = SDKError::SDK_NO_ERROR;
    uint32_t                     infoLen;
    
    infoLen = (uint32_t)strlen(info);
    ret = writeBuffer.writeChar(kGameEventFlag);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeInt32(timeInterval);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeInt32(key);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeInt32(infoLen);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeBytes(info,infoLen);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    return ret;
}


SDKError::ErrorType SDKHelper::SDKWriteHelper::writeGameEventCached(SDKWriteBuffer& writeBuffer,int32_t key,const char* info)
{
    SDKError::ErrorType          ret = SDKError::SDK_NO_ERROR;
    uint32_t                     infoLen;
    
    infoLen = (uint32_t)strlen(info);
    ret = writeBuffer.writeChar(kGameEventCachedFlag);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }

    ret = writeBuffer.writeInt32(key);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeInt32(infoLen);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    ret = writeBuffer.writeBytes(info,infoLen);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    return ret;
}


SDKError::ErrorType SDKHelper::SDKWriteHelper::writeNetLatency(SDKWriteBuffer& writeBuffer,int32_t timeInterval,int16_t latency)
{
    SDKError::ErrorType          ret = SDKError::SDK_NO_ERROR;

    ret = writeBuffer.writeChar(kNetLatencyFlag);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeInt32(timeInterval);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeInt32(0);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeInt16(latency);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    return ret;
}

SDKError::ErrorType SDKHelper::SDKWriteHelper::writeNetworkStat(SDKWriteBuffer& writeBuffer,int8_t flag,int16_t netstat)
{
    SDKError::ErrorType          ret = SDKError::SDK_NO_ERROR;
   
    ret = writeBuffer.writeChar(flag);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeInt16(netstat);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    return ret;
}


SDKError::ErrorType SDKHelper::SDKWriteHelper::writeLagStatus(SDKWriteBuffer& writeBuffer,int32_t timeInterval,int32_t distance)
{
    SDKError::ErrorType          ret = SDKError::SDK_NO_ERROR;
  
    ret = writeBuffer.writeChar(kLagStatusFlag);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeInt32(timeInterval);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    ret = writeBuffer.writeInt32(distance);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    return ret;
}


SDKError::ErrorType SDKHelper::SDKWriteHelper::writeInt8(SDKWriteBuffer& writeBuffer,int8_t value)
{
    SDKError::ErrorType          ret = SDKError::SDK_NO_ERROR;
    
    ret = writeBuffer.writeInt8(value);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    return ret;
}

SDKError::ErrorType SDKHelper::SDKWriteHelper::writeInt16(SDKWriteBuffer& writeBuffer,int16_t value)
{
    SDKError::ErrorType          ret = SDKError::SDK_NO_ERROR;
    
    ret = writeBuffer.writeInt16(value);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    return ret;
}


SDKError::ErrorType SDKHelper::SDKWriteHelper::writeInt32(SDKWriteBuffer& writeBuffer,int32_t value)
{
    SDKError::ErrorType          ret = SDKError::SDK_NO_ERROR;
    
    ret = writeBuffer.writeInt32(value);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    return ret;
}

SDKError::ErrorType SDKHelper::SDKWriteHelper::writeBytes(SDKWriteBuffer& writeBuffer,const char* buffer,int len)
{
    SDKError::ErrorType          ret = SDKError::SDK_NO_ERROR;
    
    ret = writeBuffer.writeBytes(buffer,len);
    if (ret != SDKError::SDK_NO_ERROR)
    {
        return  ret;
    }
    
    return ret;
}


#pragma  mark SDKUtill


short      SDKHelper::SDKUtill::networkType = 1;
int        SDKHelper::SDKUtill::opts = 0;
NSString*  SDKHelper::SDKUtill::currVersionStr = @"9.0";
double     SDKHelper::SDKUtill::currVersionDoub = 9.0;
NSString*  SDKHelper::SDKUtill::sessionUUID = kDefaultUUID;
NSString*  SDKHelper::SDKUtill::uniqueSessionUUID = kDefaultUUID;
NSString*  SDKHelper::SDKUtill::linkSessionUUID = kDefaultUUID;

GPMObserver* SDKHelper::SDKUtill::gpmObserver = NULL;

SDKHelper::SDKUtill::SDKUtill()
{
    //mIphoneModelMutableDic = [NSMutableDictionary dictionary];
}

SDKHelper::SDKUtill::~SDKUtill()
{
    
}

uint32_t SDKHelper::SDKUtill::getCurrentTimeIntervalMillisecond()
{
    if (SDKUtill::currVersionDoub > 10.0)
    {
        struct timespec         time = {0, 0};
        clock_gettime(CLOCK_MONOTONIC, &time);
        
        return (uint32_t)(uint64_t(time.tv_sec) * 1000 + time.tv_nsec / 1000000);
    }
    else
    {
        // Fallback on earlier versions
        struct timeval      timeval;
        gettimeofday(&timeval,NULL);
        
        return (uint32_t) uint64_t(timeval.tv_sec * 1000 + timeval.tv_usec / 1000);
    }
}

uint64_t SDKHelper::SDKUtill::getCurrentTimeMicroseconds()
{
    if (SDKUtill::currVersionDoub > 10.0)
    {
        struct timespec         time = {0, 0};
        clock_gettime(CLOCK_MONOTONIC, &time);
        
        return time.tv_sec * 1000000 + time.tv_nsec / 1000;
    }
    else
    {
        // Fallback on earlier versions
        struct timeval      timeval;
        gettimeofday(&timeval,NULL);
        
        return  timeval.tv_sec * 1000000 + timeval.tv_usec;
    }
}

uint32_t SDKHelper::SDKUtill::getDeviceFreeSpace()
{
    struct statfs       buf;
    long long           freespace;
    
    freespace = 0;
    if(statfs("/private/var", &buf) >= 0) freespace = (long long)buf.f_bsize * buf.f_bfree;

    return uint32_t(freespace/kByteConvertMB);
}

uint32_t SDKHelper::SDKUtill::getTotalRAMCount()
{
    return uint32_t([NSProcessInfo processInfo].physicalMemory / kByteConvertMB);
}

NSUInteger SDKHelper::SDKUtill::getProccessorCount()
{
    NSUInteger              activeProcessorCount;
    
    activeProcessorCount = [NSProcessInfo processInfo].activeProcessorCount;
    
    return  activeProcessorCount > 0 ? activeProcessorCount : 0;
}

NSString* SDKHelper::SDKUtill::getCPUArchName(){
    
    const NXArchInfo * arch = NXGetLocalArchInfo();
    
    if (arch && arch -> name)
    {
        return [NSString stringWithCString:arch->name encoding:NSUTF8StringEncoding];
    }
    
    return @"unknown";
}

NSString* SDKHelper::SDKUtill::generateUuid()
{
    char destinationBuffer37Bytes[37];
    memset(destinationBuffer37Bytes, 0, sizeof(destinationBuffer37Bytes));
    destinationBuffer37Bytes[sizeof(destinationBuffer37Bytes) - 1] = '\0';
    uuid_t uuid;
    uuid_generate(uuid);
    sprintf(destinationBuffer37Bytes,
            "%02X%02X%02X%02X-%02X%02X-%02X%02X-%02X%02X-%02X%02X%02X%02X%02X%02X",
            (unsigned)uuid[0],
            (unsigned)uuid[1],
            (unsigned)uuid[2],
            (unsigned)uuid[3],
            (unsigned)uuid[4],
            (unsigned)uuid[5],
            (unsigned)uuid[6],
            (unsigned)uuid[7],
            (unsigned)uuid[8],
            (unsigned)uuid[9],
            (unsigned)uuid[10],
            (unsigned)uuid[11],
            (unsigned)uuid[12],
            (unsigned)uuid[13],
            (unsigned)uuid[14],
            (unsigned)uuid[15]
            );
    
    return  [NSString stringWithUTF8String:destinationBuffer37Bytes];
}

NSString* SDKHelper::SDKUtill::getCurrentFullTime()
{
    time_t timeInterval = [[NSDate date] timeIntervalSince1970];
    struct tm* plt = localtime(&timeInterval);
    
    if (plt)
    {
        return [NSString stringWithFormat:@"%d_%02d_%02d_%02d_%02d_%02d_%llu_%d_%d", plt -> tm_year + 1900, plt -> tm_mon + 1,plt -> tm_mday, plt -> tm_hour, plt -> tm_min, plt -> tm_sec,getCurrentTimeMicroseconds(),arc4random() % 65534,arc4random() % 65534];
    }
    
    return generateUuid();
}


NSString* SDKHelper::SDKUtill::getCurrentLogTime()
{
    time_t timeInterval = [[NSDate date] timeIntervalSince1970];
    struct tm* plt = localtime(&timeInterval);
    
    if (plt)
    {
        return [NSString stringWithFormat:@"%d-%02d-%02d %02d:%02d:%02d",plt -> tm_year + 1900, plt -> tm_mon + 1,plt -> tm_mday, plt -> tm_hour, plt -> tm_min, plt -> tm_sec];
    }
    
    return generateUuid();
}

NSString* SDKHelper::SDKUtill::getCurrentTimeIntervalSince1970()
{
    time_t timeInterval = [[NSDate date] timeIntervalSince1970];
    struct tm* plt = localtime(&timeInterval);
    
    if (plt)
    {
        return [NSString stringWithFormat:@"%ld_%d_%02d_%02d_%02d_%02d_%02d_",timeInterval,plt -> tm_year + 1900, plt -> tm_mon + 1,plt -> tm_mday, plt -> tm_hour, plt -> tm_min, plt -> tm_sec];
    }
    
    return generateUuid();
}


const char* SDKHelper::SDKUtill::getErrorMsg(int errorCode)
{
    switch ((GCloudErrorCode)errorCode)
    {
        case GCloudErrorCode_None:
        {
            return "no error";
        }
        case GCloudErrorCode_NULL:
        {
            return "pointer-type argument is NULL";
        }
        case GCloudErrorCode_BOOLFalse:
        {
            return "bool value is false";
        }
        case GCloudErrorCode_LenZero:
        {
            return "data len is zero";
        }
        case GCloudErrorCode_CreateSocketError:
        {
            return "failed to create socket";
        }
        case GCloudErrorCode_CreateFileError:
        {
            return "failed to create file";
        }
        case GCloudErrorCode_PackError:
        {
            return "failed to pack data";
        }
        case GCloudErrorCode_SendError:
        {
            return "failed to send data";
        }
        case GCloudErrorCode_UploadFailure:
        {
            return "failed to upload data";
        }
        case GCloudErrorCode_SceneLevelStateInvaild:
        {
            return "scene state level is invaild";
        }
        case GCloudErrorCode_CloseSwitch:
        {
            return "cdn switch is closed";
        }
        case GCloudErrorCode_ForbidDevice:
        {
            return "device is forbidded";
        }
        case GCloudErrorCode_AlreadyInit:
        {
            return "current context is already initialize";
        }
        case GCloudErrorCode_unInitalized:
        {
            return "current context is uninitialize";
        }
    }
    
    return "NA";
}

NSDictionary* SDKHelper::SDKUtill::getDeviceEasyReadModel(NSString* deviceIdent)
{

    NSDictionary* iOSHardInfos =
    @{
        //iPhone
        @"iPhone11,4" : @{@"filter-model":  @[@"iPhone XS Max", @"iPhone11,4"], @"filter-soc": @[@"A12"]},
        @"iPhone11,6" : @{@"filter-model":  @[@"iPhone XS Max", @"iPhone11,6"],  @"filter-soc": @[@"A12"]},
        @"iPhone11,2" : @{@"filter-model":  @[@"iPhone XS", @"iPhone11,2"],  @"filter-soc": @[@"A12"]},
        @"iPhone11,8" : @{@"filter-model":  @[@"iPhone XR", @"iPhone11,8"],  @"filter-soc": @[@"A12"]},
        
        @"iPhone10,3" : @{@"filter-model":  @[@"iPhone X", @"iPhone10,3"],  @"filter-soc": @[@"A11"]},
        @"iPhone10,6" : @{@"filter-model":  @[@"iPhone X", @"iPhone10,6"],  @"filter-soc": @[@"A11"]},
        @"iPhone10,2" : @{@"filter-model":  @[@"iPhone 8 Plus", @"iPhone10,2"],  @"filter-soc": @[@"A11"]},
        @"iPhone10,5" : @{@"filter-model":  @[@"iPhone 8 Plus", @"iPhone10,5"],  @"filter-soc": @[@"A11"]},
        @"iPhone10,4" : @{@"filter-model":  @[@"iPhone 8", @"iPhone10,4"],  @"filter-soc": @[@"A11"]},
        @"iPhone10,1" : @{@"filter-model":  @[@"iPhone 8", @"iPhone10,1"],  @"filter-soc": @[@"A11"]},
        
        @"iPhone9,4" : @{@"filter-model":  @[@"iPhone 7 Plus", @"iPhone9,4"],  @"filter-soc": @[@"A10"]},
        @"iPhone9,2" : @{@"filter-model":  @[@"iPhone 7 Plus", @"iPhone9,2"],  @"filter-soc": @[@"A10"]},
        
        @"iPhone9,1" : @{@"filter-model":  @[@"iPhone 7", @"iPhone9,1"],  @"filter-soc": @[@"A10"]},
        @"iPhone9,3" : @{@"filter-model":  @[@"iPhone 7", @"iPhone9,3"],  @"filter-soc": @[@"A10"]},
        @"iPhone8,4" : @{@"filter-model":  @[@"iPhone SE", @"iPhone8,4"],  @"filter-soc": @[@"A9"]},
        @"iPhone8,2" : @{@"filter-model":  @[@"iPhone 6S Plus", @"iPhone8,2"],  @"filter-soc": @[@"A9"]},
        @"iPhone8,1" : @{@"filter-model":  @[@"iPhone 6S", @"iPhone8,1"],  @"filter-soc": @[@"A9"]},
        @"iPhone7,1" : @{@"filter-model":  @[@"iPhone 6 Plus", @"iPhone7,1"],  @"filter-soc": @[@"A8"]},
        @"iPhone7,2" : @{@"filter-model":  @[@"iPhone 6", @"iPhone7,2"],  @"filter-soc": @[@"A8"]},
        @"iPhone6,1" : @{@"filter-model":  @[@"iPhone 5S", @"iPhone6,1"],  @"filter-soc": @[@"A7"]},
        @"iPhone6,2" : @{@"filter-model":  @[@"iPhone 5S", @"iPhone6,2"],  @"filter-soc": @[@"A7"]},
        
        @"iPhone5,4" : @{@"filter-model":  @[@"iPhone 5c", @"iPhone5,4"],  @"filter-soc": @[@"A6"]},
        @"iPhone5,3" : @{@"filter-model":  @[@"iPhone 5c", @"iPhone5,3"],  @"filter-soc": @[@"A6"]},
        
        @"iPhone5,2" : @{@"filter-model":  @[@"iPhone 5", @"iPhone5,2"],  @"filter-soc": @[@"A6"]},
        @"iPhone5,1" : @{@"filter-model":  @[@"iPhone 5", @"iPhone5,1"],  @"filter-soc": @[@"A6"]},
        
        @"iPhone4,1" : @{@"filter-model":  @[@"iPhone 4S", @"iPhone4,1"],  @"filter-soc": @[@"A5"]},
        @"iPhone3,1" : @{@"filter-model":  @[@"iPhone 4", @"iPhone3,1"],  @"filter-soc": @[@"A4"]},
        
        @"iPhone3,2" : @{@"filter-model":  @[@"iPhone 4", @"iPhone3,2"],  @"filter-soc": @[@"A4"]},
        @"iPhone3,3" : @{@"filter-model":  @[@"iPhone 4", @"iPhone3,3"],  @"filter-soc": @[@"A4"]},
        
        //iPad
        @"iPad11,4" : @{@"filter-model":  @[@"iPad Air (3rd generation)", @"iPad11,4"],  @"filter-soc": @[@"A12"]},
        @"iPad11,3" : @{@"filter-model":  @[@"@iPad Air (3rd generation)", @"iPad11,3"],  @"filter-soc": @[@"A12"]},
        
        @"iPad11,2" : @{@"filter-model":  @[@"iPad mini (5th generation)", @"iPad11,2"],  @"filter-soc": @[@"A12"]},
        @"iPad11,1" : @{@"filter-model":  @[@"iPad mini (5th generation)", @"iPad11,1"],  @"filter-soc": @[@"A12"]},
        
        @"iPad8,8" : @{@"filter-model":  @[@"iPad Pro (12.9-inch) (3rd generation)", @"iPad8,8"],  @"filter-soc": @[@"A12X"]},
        @"iPad8,7" : @{@"filter-model":  @[@"iPad Pro (12.9-inch) (3rd generation)", @"iPad8,7"],  @"filter-soc": @[@"A12X"]},
        @"iPad8,6" : @{@"filter-model":  @[@"iPad Pro (12.9-inch) (3rd generation)", @"iPad8,6"],  @"filter-soc": @[@"A12X"]},
        @"iPad8,5" : @{@"filter-model":  @[@"iPad Pro (12.9-inch) (3rd generation)", @"iPad8,5"],  @"filter-soc": @[@"A12X"]},
        
        @"iPad8,4" : @{@"filter-model":  @[@"iPad Pro (11-inch)", @"iPad8,4"],  @"filter-soc": @[@"A12X"]},
        @"iPad8,3" : @{@"filter-model":  @[@"iPad Pro (11-inch)", @"iPad8,3"],  @"filter-soc": @[@"A12X"]},
        @"iPad8,2" : @{@"filter-model":  @[@"iPad Pro (11-inch)", @"iPad8,2"],  @"filter-soc": @[@"A12X"]},
        @"iPad8,1" : @{@"filter-model":  @[@"iPad Pro (11-inch)", @"iPad8,1"],  @"filter-soc": @[@"A12X"]},
        
        @"iPad7,6" : @{@"filter-model":  @[@"iPad (6th generation)", @"iPad7,6"],  @"filter-soc": @[@"A10"]},
        @"iPad7,5" : @{@"filter-model":  @[@"iPad (6th generation)", @"iPad7,5"],  @"filter-soc": @[@"A10"]},
        
        @"iPad7,4" : @{@"filter-model":  @[@"iPad Pro (10.5-inch)", @"iPad7,4"],  @"filter-soc": @[@"A10X"]},
        @"iPad7,3" : @{@"filter-model":  @[@"iPad Pro (10.5-inch)", @"iPad7,3"],  @"filter-soc": @[@"A10X"]},
        
        @"iPad7,2" : @{@"filter-model":  @[@"iPad Pro (12.9-inch) (2nd generation)", @"iPad7,2"],  @"filter-soc": @[@"A10X"]},
        @"iPad7,1" : @{@"filter-model":  @[@"iPad Pro (12.9-inch) (2nd generation)", @"iPad7,1"],  @"filter-soc": @[@"A10X"]},
        
        @"iPad6,12" : @{@"filter-model":  @[@"iPad (5th generation)", @"iPad6,12"],  @"filter-soc": @[@"A9"]},
        @"iPad6,11" : @{@"filter-model":  @[@"iPad (5th generation)", @"iPad6,11"],  @"filter-soc": @[@"A9"]},
        
        @"iPad6,11" : @{@"filter-model":  @[@"iPad 2017", @"iPad6,11"],  @"filter-soc": @[@"A9"]},
        @"iPad6,12" : @{@"filter-model":  @[@"iPad 2017", @"iPad6,12"],  @"filter-soc": @[@"A9"]},
        
        @"iPad6,7" : @{@"filter-model":  @[@"iPad Pro-1st 12.9-inch", @"iPad6,7"],  @"filter-soc": @[@"A9X"]},
        @"iPad6,8" : @{@"filter-model":  @[@"iPad Pro-1st 12.9-inch", @"iPad6,8"],  @"filter-soc": @[@"A9X"]},
        @"iPad6,3" : @{@"filter-model":  @[@"iPad Pro 9.7-inch", @"iPad6,3"],  @"filter-soc": @[@"A9X"]},
        @"iPad6,4" : @{@"filter-model":  @[@"iPad Pro 9.7-inch", @"iPad6,4"],  @"filter-soc": @[@"A9X"]},
        @"iPad7,1" : @{@"filter-model":  @[@"iPad Pro-2nd 12.9-inch", @"iPad7,1"],  @"filter-soc": @[@"A10X"]},
        @"iPad7,2" : @{@"filter-model":  @[@"iPad Pro-2nd 12.9-inch", @"iPad7,2"],  @"filter-soc": @[@"A10X"]},
        @"iPad7,3" : @{@"filter-model":  @[@"iPad Pro 10.5-inch", @"iPad7,3"],  @"filter-soc": @[@"A10X"]},
        @"iPad7,4" : @{@"filter-model":  @[@"iPad Pro 10.5-inch", @"iPad7,4"],  @"filter-soc": @[@"A10X"]},
        
        @"iPad7,5" : @{@"filter-model":  @[@"iPad 2018", @"iPad7,5"],  @"filter-soc": @[@"A10"]},
        @"iPad7,6" : @{@"filter-model":  @[@"iPad 2018", @"iPad7,6"],  @"filter-soc": @[@"A10"]},
        
        @"iPad5,1" : @{@"filter-model":  @[@"iPad Mini 4", @"iPad5,1"],  @"filter-soc": @[@"A8"]},
        @"iPad5,2" : @{@"filter-model":  @[@"iPad Mini 4", @"iPad5,2"],  @"filter-soc": @[@"A8"]},
        @"iPad5,3" : @{@"filter-model":  @[@"iPad Air 2", @"iPad5,3"],  @"filter-soc": @[@"A8X"]},
        @"iPad5,4" : @{@"filter-model":  @[@"iPad Air 2", @"iPad5,4"],  @"filter-soc": @[@"A8X"]},
        
        @"iPad4,7" : @{@"filter-model":  @[@"iPad Mini 3", @"iPad4,7"],  @"filter-soc": @[@"A7"]},
        @"iPad4,8" : @{@"filter-model":  @[@"iPad Mini 3", @"iPad4,8"],  @"filter-soc": @[@"A7"]},
        @"iPad4,9" : @{@"filter-model":  @[@"iPad Mini 3", @"iPad4,9"],  @"filter-soc": @[@"A7"]},
        
        @"iPad4,4" : @{@"filter-model":  @[@"iPad Mini Retina", @"iPad4,4"],  @"filter-soc": @[@"A7"]},
        @"iPad4,5" : @{@"filter-model":  @[@"iPad Mini Retina", @"iPad4,5"],  @"filter-soc": @[@"A7"]},
        @"iPad4,6" : @{@"filter-model":  @[@"iPad Mini Retina", @"iPad4,6"],  @"filter-soc": @[@"A7"]},
    
        @"iPad4,1" : @{@"filter-model":  @[@"iPad Air", @"iPad4,1"],  @"filter-soc": @[@"A7"]},
        @"iPad4,2" : @{@"filter-model":  @[@"iPad Air", @"iPad4,2"],  @"filter-soc": @[@"A7"]},
        @"iPad4,3" : @{@"filter-model":  @[@"iPad Air", @"iPad4,3"],  @"filter-soc": @[@"A7"]},
        
        @"iPad3,6" : @{@"filter-model":  @[@"iPad (4th generation)", @"iPad3,6"],  @"filter-soc": @[@"A6X"]},
        @"iPad3,5" : @{@"filter-model":  @[@"iPad (4th generation)", @"iPad3,5"],  @"filter-soc": @[@"A6X"]},
        @"iPad3,4" : @{@"filter-model":  @[@"iPad (4th generation)", @"iPad3,4"],  @"filter-soc": @[@"A6X"]},
        @"iPad3,1" : @{@"filter-model":  @[@"iPad 3rd Gen", @"iPad3,1"],  @"filter-soc": @[@"A5X"]},
        @"iPad3,2" : @{@"filter-model":  @[@"iPad 3rd Gen", @"iPad3,2"],  @"filter-soc": @[@"A5X"]},
        @"iPad3,3" : @{@"filter-model":  @[@"iPad 3rd Gen", @"iPad3,3"],  @"filter-soc": @[@"A5X"]},
        @"iPad2,5" : @{@"filter-model":  @[@"iPad mini", @"iPad2,5"],  @"filter-soc": @[@"A5"]},
        @"iPad2,6" : @{@"filter-model":  @[@"iPad mini", @"iPad2,6"],  @"filter-soc": @[@"A5"]},
        @"iPad2,7" : @{@"filter-model":  @[@"iPad mini", @"iPad2,7"],  @"filter-soc": @[@"A5"]},
        @"iPad2,1" : @{@"filter-model":  @[@"iPad 2", @"iPad2,1"],  @"filter-soc": @[@"A5"]},
        @"iPad2,2" : @{@"filter-model":  @[@"iPad 2", @"iPad2,2"],  @"filter-soc": @[@"A5"]},
        @"iPad2,3" : @{@"filter-model":  @[@"iPad 2", @"iPad2,3"],  @"filter-soc": @[@"A5"]},
        @"iPad2,4" : @{@"filter-model":  @[@"iPad 2", @"iPad2,4"],  @"filter-soc": @[@"A5"]},
    };

    return iOSHardInfos[deviceIdent];
}

NSString* SDKHelper::SDKUtill::convertLowerCaseNoEmptyStr(NSString* sourceStr)
{
    if (!sourceStr) {
        return nil;
    }

    return [[sourceStr stringByReplacingOccurrencesOfString:@" " withString:@""] lowercaseString];
}
