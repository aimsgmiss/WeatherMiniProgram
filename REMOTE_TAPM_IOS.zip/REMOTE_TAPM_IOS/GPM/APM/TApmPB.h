//
//  TApmPB.h
//  LearnOpenGLES
//
//  Created by vincentwgao on 2019/4/9.
//  Copyright © 2019年 xianglin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "apmpb/protocolbuf/ApmProto.pbobjc.h"
#import "StreamEvent.h"

namespace TAPM_PB
{
    ApmCommonInfo* g_apm_pb_get_common_info();
    
    bool g_apm_pb_set_step_event_common_info(ApmCommonInfo* pCommonInfo,STREAM_EVENT& event,char* buffer, size_t maxSz,size_t& usedSz);
    
    const char* g_apm_pb_malloc_apm_data(const char* file_path,int& send_len);
    
    void g_apm_pb_safe_free(void* ptr);
    
    void g_apm_pb_safe_delete_common_info(ApmCommonInfo* pCommonInfo);
}

NS_ASSUME_NONNULL_BEGIN

@interface TApmPB : NSObject

@end

NS_ASSUME_NONNULL_END
