//
//  SDKStructEnumDefine.hpp
//  LearnOpenGLES
//
//  Created by xiang lin on 17/01/2018.
//  Copyright © 2018 . All rights reserved.
//

#ifndef SDKStructEnumDefine_h
#define SDKStructEnumDefine_h

#include <stdio.h>
#import <string.h>
#import <Foundation/Foundation.h>
#include <dispatch/dispatch.h>

//版本号每次都改
#define kHawkVersion                                    291
#define kBuglyVersion                                   @"3.0"

#define kDefaultUUID                                    @"00000000-0000-0000-0000-000000000000"
#define kGPU_OPT                                        1
#define kCPU_OPT                                        2
#define kFPS_OPT                                        4
#define kPSS_OPT                                        8
#define kDC_OPT                                         16
#define kFrameEndCompressedBatchFlag                    22
#define kFrameTimeAxisFlag                              23
#define kTRI_OPT                                        32
#define kTEX_Meta_OPT                                   64
#define kMONO_OPT                                       128
#define kNET_Traffic_OPT                                256
#define kGloabelBufferLen                               (1024 * 16)
#define kOSType                                          32/** unity 33  UE4 32*/
#define kSceneFlag                                       8
#define kFrameFlag                                       2
#define kDataPerSecFlag                                  3
#define kUserIDFlag                                      113
#define kSceneQualityFlag                                103
#define kDeviceLevelFlag                                 122
#define kNetLatencyFlag                                  16
#define kLagStatusFlag                                   108
//define  kNetworkTrafficFlag                              
#define kGameEventFlag                                   110
#define kGameEventCachedFlag                             115
#define kNetworkTypeFlag                                 112
#define kLocalFlag                                       107
#define kVersionFlag                                     111
#define kIPCUUIDFlag                                     113
#define kAppBkgroundFlag                                 125
#define kAppForegroundFlag                               124
#define kFrameStateFlag                                  116
#define kPrefixExtFlag                                   117
#define kExcludePrefixFlag                               118
#define kDetectTimeOutFlag                               119
#define kFPSFlag                                         120
#define kThermalStatePrefixFlag                          127
#define kMaxDictionaryCount                              1024

#define kMaxFrameDataDTCount                             120
#define kGlobalEventBufferCached                         1024
#define kInt16MaxValue                                   65534

#define kApmMetaInfoObj                                 [ApmMetaInfoNetworkPack sharedApmMetaInfoNetworkPack]
#define kSDKERROR                                       -1
#define kDiffDeltaTime                                   1
#define kInvalidIntValue                                -1
#define kInvalidInt8_tValue                             255
#define kCStrUnkown                                     "unkonow"
#define kStrUnkown                                      @"unkown"
#define kGameInfoDefaultCStr                            "NA"
#define kDefaultCStr                                    "NA"
#define kNotificationCenterDefaultCenter                [NSNotificationCenter defaultCenter]

#define kByteConvertKB                                  (1024)

#define kByteConvertMB                                  (1024 * 1024)
#define kFileManagerDefault                             [NSFileManager defaultManager]
#define kSDKUserDefault                                 [NSUserDefaults standardUserDefaults]
#define kLibraryCachePath                               NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES).lastObject
#define kCacheDirectoryName                             @"/APMSDKCache"
#define kszGpuVendor                                    @"kszGpuVendor"
#define kszGpuVersion                                   @"kszGpuVersion"
#define kszGpuRenderer                                  @"kszGpuRenderer"

#define kPrefixCacheFileName                            @"APMSDK_Uncompressed_"
#define kPrefixZipFileName                              @"APMSDK_Zip_"
#define kPrefixStreamEventFileName                      @"APMSDK_SE_"
#define kPrefixLogFileName                              @"APMSDK_Log_"

#define kStreamEventMarkFinish                          @"markFinish"
#define kStreamEventLinkSession                         @"linkSession"
#define kUniqueSessionUUID                              @"kUniqueSessionUUID"
#define kLinkSessionUUID                                @"kLinkSessionUUID"

//#define PRINT_D  if(false)  printf("\n"); if(false) printf
////#define PRINT_D  printf("\n"); printf
//#define PRINT_E printf("\n"); printf
//#define PRINT_W PRINT_E

//#define _DEBUG
//#define _DEBUG_UNIT_TEST

#ifdef _DEBUG
#define APMSDKLog(...)   APM_LOG(@"%@\n",[NSString stringWithFormat:__VA_ARGS__])
#define APMSDKAssert(condition,desc)  NSAssert(condition, desc)
//#define APMSDKLog(...) APM_LOG(@"函数：%s 第 %d 行 \n %@\n\n",__func__,__LINE__,[NSString stringWithFormat:__VA_ARGS__])
#else
#define APMSDKLog(...) {}
#define APMSDKAssert(condition,desc){}
#endif

#define APMSDKSafeFree(obj)\
if(obj != NULL)\
{\
    free((void*)obj);\
    obj = NULL;\
}\

#define APMSDKSafeDelete(obj)\
if(obj != NULL)\
{\
    delete obj;\
    obj = NULL;\
}\


#define kAPMSwitchDidChangedNotification @"kAPMSwitchDidChangedNotification"

#pragma pack(push) //保存对齐状态
#pragma pack(1)

typedef NS_ENUM(NSUInteger, LevelState)           // 场景状态
{
    LevelState_MarkLoadLevel,
    LevelState_MarkLoadLevelCompleted,
    LevelState_MarkLoadFin,
    LevelState_Unkown
};

typedef NS_ENUM(NSUInteger, TagState)             // 标记状态
{
    TagState_BeginTag,
    TagState_EndTag,
    TagState_Unkown
};

typedef NS_ENUM(NSUInteger, GamePerformanceDataType)
{
    GamePerformanceDataType_FPS,                 // 采集数据类型
    GamePerformanceDataType_CPU,
    GamePerformanceDataType_GPU,
    GamePerformanceDataType_Memory,
    GamePerformanceDataType_NetworkTraffic,
    GamePerformanceDataType_Battery,
    GamePerformanceDataType_Unkown
    
};

typedef NS_ENUM(NSUInteger, AppState)             // app状态
{
    AppState_Foreground,
    AppState_Background,
    AppState_Unkown
};

typedef NS_ENUM(NSUInteger, MsgQueueBodyType)     // 自定义数据类型
{
    MsgQueueBodyType_FileStartData,
    MsgQueueBodyType_UserID,
    MsgQueueBodyType_Quality,
    MsgQueueBodyType_DeviceLevel,
    MsgQueueBodyType_NetLatency,
    MsgQueueBodyType_LagStatus,
    MsgQueueBodyType_Info,
    MsgQueueBodyType_Global_Info,
    MsgQueueBodyType_Tag,
    MsgQueueBodyType_NetworkStatus,
    MsgQueueBodyType_Local,
    MsgQueueBodyType_Frame,
    MsgQueueBodyType_Version,
    MsgQueueBodyType_Appstate,
    MsgQueueBodyType_IPCUUID,
};

typedef NS_ENUM(NSUInteger, NumberOfBytes)
{
    NumberOfBytes_Int8,
    NumberOfBytes_Int16,
    NumberOfBytes_Int32,
    NumberOfBytes_Int64,
    NumberOfBytes_bytes
};

typedef NS_ENUM(NSInteger, GCloudErrorCode)     // GCloudErrorCode
{
    GCloudErrorCode_AlreadyInit = -1,
    GCloudErrorCode_None,
    GCloudErrorCode_NULL,
    GCloudErrorCode_BOOLFalse,
    GCloudErrorCode_LenZero,
    GCloudErrorCode_CreateSocketError,
    GCloudErrorCode_CreateFileError,
    GCloudErrorCode_PackError,
    GCloudErrorCode_SendError,
    GCloudErrorCode_UploadFailure,
    GCloudErrorCode_SceneLevelStateInvaild,
    GCloudErrorCode_CloseSwitch,
    GCloudErrorCode_ForbidDevice,
    GCloudErrorCode_unInitalized
};

typedef struct  _fileAttribute
{
    short               hawkVersion;        // 文件版本
    short               randSeed;
    short               networkType;        // 网络类型
    int32_t             sceneQuality;       // 游戏画质
    int32_t             appInitTime;
    int32_t             tempSceneTime;
    //short               slientFlag;       // flag
}FileAttribute;


#define kSceneWriteToBufferLen(scene)               (sizeof(char) + sizeof(short)*2 + sizeof(int32_t) + sizeof(short) + strlen(scene.sceneStrstr))

typedef struct _Scene
{
    char                flag;               // 填 8
    short               sceneIndex;         // 3000开始，通一个场景一个索引，其他场景依次累加 1
    short               sceneType;          // 填 1，2，3
    int32_t             timeStamp;          // 调用场景的时间
    short               sceneStrLen;        // 场景字符串长度
    const char*         sceneStrstr;        // 场景名字
    
}Scene,*PScene;

typedef struct
{
    char                flag;               // 填 2
    int32_t             drawcall;           // drawcall次数
    int32_t             triangle;           // 三角形个数
    int32_t             timeInterval;
    int32_t             deltaSeconds;       // tick 函数中的时间
    
}Frame;

#define  kSizeofFrame                    (sizeof(char)  + sizeof(int32_t) * 4)

typedef struct _DataPerSec
{
    char                flag;               // 填 3
    short               fps;
    short               appCpuUsage;        // 当前进程占用CPU使用率
    int32_t             timeInterval;
    int32_t             appMemoryUsed;      // 当前进程占用内存
    int32_t             reserved[4];
    int32_t             netSend;
    int32_t             netRecv;
    int32_t             reserved1;
    int32_t             reserved2;
    
}DataPerSec,*PDataPerSec;

#define kSizeofDataPerSec       (sizeof(char) + sizeof(int32_t) * 11)

typedef struct                              //wechat、QQ
{
    char                flag;               //填 113
    short               userIDLen;
    const char*         userID;
    
}UserIDS;

#define kSizeofUserIDSLen(userID)    (sizeof(char) + sizeof(short) + strlen(userID))

typedef struct                              //游戏画质
{
    char                flag;               //填 103
    int32_t             quality;
    
}SceneQualityS;

#define kSizeofSceneQualityS    (sizeof(char) + sizeof(int32_t))


typedef struct                              //
{
    char                flag;               //填 122
    int32_t             deviceLevel;
    
}DeviceLevelS;

#define kSizeofSceneDeviceLevelS    (sizeof(char) + sizeof(int32_t))


typedef struct                               // 网络延迟
{
    char                 flag;               // 填 16
    int32_t              timeInterval;
    int32_t              serverIP;
    int16_t              latency;           // 延迟
    
}NetLatency;

#define kSizeofNetLatency    (sizeof(char) + sizeof(int32_t) + sizeof(int32_t) + sizeof(int16_t))

typedef struct                               // 网络状态
{
    char                 flag;               // 填 112
    int16_t              netstat;            // 具体数据
    
}NetStatus;

#define kSizeofNetStats    (sizeof(char) + sizeof(int16_t))

typedef struct                              // 回扯信息
{
    char                flag;               // 填 108
    int32_t             timeInterval;
    int32_t             distance;           // 回扯距离
    
}LagStatus;

#define kSizeofLagStatus    (sizeof(char) + sizeof(int32_t) + sizeof(int32_t))

typedef struct                              // 游戏事件
{
    char                flag;               // 填 110
    int32_t             timeInterval;
    int32_t             key;                // 事件key
    int32_t             infoLen;            // info长度
    const char*         info;               // 事件value
    
}GameEvent;

#define kSizeofGameEvent(info)    (sizeof(char) + (sizeof(int32_t)*3) + strlen(info))

typedef struct                              // 游戏事件缓存(全局)
{
    char                flag;               // 填 115
    int32_t             key;                // 事件key
    int32_t             infoLen;            // info长度
    const char*         info;               // 事件value
    
}GameEventCached;

#define kSizeofGameEventCached(info)    (sizeof(char) + (sizeof(int32_t)*2) + strlen(info))

typedef struct                             // 本地
{
    char                flag;              // 107
    int16_t             localLen;
    const char*         local;
    
}Locale;

#define kSizeofLocal(local)     (sizeof(char) + sizeof(int16_t) + strlen(local))

typedef struct                             // 版本
{
    char                flag;              // 111
    int16_t             localLen;
    const char*         version;
    
}Version;

#define kSizeofVersion(version)         (sizeof(char) + sizeof(int16_t) + strlen(version))

typedef struct                             // app状态
{
    char                flag;              // 124,125
    int32_t             timeInterval;
}AppStateS;

#define kSizeofAppStateS         (sizeof(char) + sizeof(int32_t))

typedef struct                             // 版本
{
    char                flag;              // 123
    int16_t             len;
    const char*         iPCUUID;
}IPCUUID;

#define kSizeofIPCUUID(iPCUUID)       (sizeof(char) + sizeof(int16_t) + strlen(iPCUUID))

typedef struct
{
    char                flag;
    int32_t             timeInterval;
    int32_t             mX;
    int32_t             mY;
    int32_t             mZ;
    int32_t             mPitch;
    int32_t             mYaw;
    int32_t             mRoll;
    
}FrameStateS;

#define kSizeofFrameStateS         (sizeof(char) + sizeof(int32_t) * 7)

typedef struct{
    
    char                flag;
    short               connectServerDetailLen;
    const char*         connectServerDetail;    // 内容每个服务器用逗号隔开 www.qq.com_43,www.sohu.com_20,www.sina.com.cn_25   43,20,25 为tcp连接每个服务器时间单位毫秒
    int32_t             gateway[3];             // 连续ping3次路由器耗时单位毫秒
    short               networkTypeLen;
    const char*         networkType;
    
}DetectTimeOut;

#define kSizeofDetectTimeOut      (sizeof(char) + sizeof(int32_t) * 4 + strlen(connectServerDetail) + strlen(networkType))

typedef struct{
    char                flag;
    int32_t             avg;
    int32_t             max;
    int32_t             min;
    int32_t             total;
    int32_t             heavy;
    int32_t             flight;
    int32_t             fcntx0;
    int32_t             flfps1;
    int32_t             flfps2;
    int32_t             flfps3;
    int32_t             fdotsLen;
    const char*         fpsDots;
}FpsRecorder;

#define kSizeofFpsRecorder      (sizeof(char) + sizeof(int32_t) * 11 + strlen(fpsDots))

#pragma pack (pop)

#endif /* SDKStructEnumDefine_hpp */





