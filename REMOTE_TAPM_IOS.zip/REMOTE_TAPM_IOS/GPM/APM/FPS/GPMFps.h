//
//  GPMFps.h
//  APM
//
//  Created by xiang lin on 2020/3/9.
//  Copyright © 2020 xianglin. All rights reserved.
//


#import <Foundation/Foundation.h>
#import "GPMFpsRecorder.h"
#import "GPMFpsInfo.h"

NS_ASSUME_NONNULL_BEGIN

@interface GPMFps : NSObject

+ (instancetype)sharedInstance;

- (void)startInterval:(float)interval cusTs:(int)cusTs lTs1:(int)lTs1 lTs2:(int)lTs2 lTs3:(int)lTs3 dotFreq:(int)dotFreq;

- (void)end:(void (^)(GPMFpsInfo*))fpsInfo;

- (void)addFps:(int)fps;

@end

NS_ASSUME_NONNULL_END
