//
//  GPMFpsInfo.m
//  APM
//
//  Created by xiang lin on 2020/3/9.
//  Copyright © 2020 xianglin. All rights reserved.
//

#import "GPMFpsInfo.h"

@implementation GPMFpsInfo

-(NSString *)toString{
    return [NSString stringWithFormat:@"均值:%@,最大值:%d,最小值:%d,统计次数:%d,严重抖动次数:%d,轻微抖动次数:%d,轻微抖动次数1:%d,轻微抖动次数2:%d,轻微抖动次数3:%d,自定义抖动次数:%d",@(_avg),_max,_min,_totalTimes,_heavyTimes,_lightTimes,_lightTimes1,_lightTimes2,_lightTimes3,_cusTimes];
}
@end
