//
//  GPMFps.m
//  APM
//
//  Created by xiang lin on 2020/3/9.
//  Copyright © 2020 xianglin. All rights reserved.
//
#import "SDKHelper.h"
#import "GPMFps.h"
#import "APMCCStrategy.h"

@interface GPMFps()

@property(nonatomic,strong) GPMFpsRecorder* mRecorder;

@property(nonatomic,assign) float mInterval;

@property(nonatomic,assign) float minInterval;

@end

@implementation GPMFps

+ (instancetype)sharedInstance{
    
    static GPMFps*singleInstance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        singleInstance = [[GPMFps alloc] init];
    });
    
    return singleInstance;
}

- (instancetype)init{
    if (self = [super init]) {
        _minInterval = 10;
    }
    return self;
}

- (void)startInterval:(float)interval cusTs:(int)cusTs lTs1:(int)lTs1 lTs2:(int)lTs2 lTs3:(int)lTs3 dotFreq:(int)dotFreq{
    if ([[APMCCStrategy sharedInstance] isFeatureEnabled:FEATURE_LOCAL_SETTLE]) {
        _mInterval = interval > _minInterval ? interval : _minInterval;
        _mRecorder = [[GPMFpsRecorder alloc] initInterval:_mInterval cusTs:cusTs lTs1:lTs1 lTs2:lTs2 lTs3:lTs3 dotFreq:dotFreq];
    }
}

- (void)end:(void (^)(GPMFpsInfo*))fpsInfo{
    if (_mRecorder && [[APMCCStrategy sharedInstance] isFeatureEnabled:FEATURE_LOCAL_SETTLE]) {
        [_mRecorder end:fpsInfo];
    }
}

- (void)addFps:(int)fps{
    if (_mRecorder && [[APMCCStrategy sharedInstance] isFeatureEnabled:FEATURE_LOCAL_SETTLE]) {
       [_mRecorder addFps:fps];
    }
}

@end
