//
//  GPMFpsRecorder.m
//  APM
//
//  Created by xiang lin on 2020/3/9.
//  Copyright © 2020 xianglin. All rights reserved.
//


#import "SDKHelper.h"
#import "GPMFpsRecorder.h"
#import "TApm_Mutex.h"
#import "TApm_AutoLock.h"

@interface GPMFpsRecorder()
{
    int                     _hTs;       // 严重抖动阈值
    int                     _llTs;      // 轻微抖动左阈值
    int                     _lrTs;      // 轻微抖动右阈值
    int                     _lTs1;      // 轻微抖动阈值1
    int                     _lTs2;      // 轻微抖动阈值2
    int                     _lTs3;      // 轻微抖动阈值3
    int                     _cusTs;     // 自定义抖动右阈值
    float                   _dotFreq;   // 采集频率
    uint32_t                _lastDotTime;
    NSMutableArray*         _fpsArrs;
    NSMutableArray*         _fpsDotsArrs;
    int                     _lastFps;
    int                     _hTimes;    // 严重抖动次数
    int                     _lTimes;    // 轻微抖动次数
    int                     _lTimes1;   // 轻微抖动次数1
    int                     _lTimes2;   // 轻微抖动次数2
    int                     _lTimes3;   // 轻微抖动次数3
    int                     _cusTimes;  // 自定义次数
    float                   _interval;  // 每次fps统计时长
}

@end

static TApmMutex fpsExtMutex;

@implementation GPMFpsRecorder

- (instancetype)initInterval:(float)interval cusTs:(int)cusTs lTs1:(int)lTs1 lTs2:(int)lTs2 lTs3:(int)lTs3 dotFreq:(int)dotFreq{
    
    if (self = [super init]) {
        [self reset];
        _interval = interval;
        _cusTs = cusTs;
        _lTs1 = lTs1;
        _lTs2 = lTs2;
        _lTs3 = lTs3;
        _dotFreq = dotFreq;
        //_dotFreq = dotFreq / 1000.0f;
        _lastDotTime = SDKHelper::SDKUtill::getCurrentTimeIntervalMillisecond();
        _fpsArrs = [NSMutableArray array];
        _fpsDotsArrs = [NSMutableArray array];
    }
    
    return self;
}

- (void)reset{
    
    _hTs = -10;
    _llTs = -10;
    _lrTs = -4;
    _lTs1 = -1;
    _lTs2 = -2;
    _lTs3 = -3;
    _cusTs = 0;
    _dotFreq = 1.0;
    _lastDotTime = 0;
    _lastFps = -1;
    _hTimes = 0;
    _lTimes = 0;
    _cusTimes = 0;
    _interval = 0.0;
    
    if (_lTs1 <= 0) {
        _lTimes1 = -1;
    }
    if (_lTs2 <= 0) {
        _lTimes2 = -1;
    }
    if (_lTs3 <= 0) {
        _lTimes3 = -1;
    }
}

- (void)end:(void (^)(GPMFpsInfo*))fpsInfo{
  
    TApm_AutoLock autoLock(fpsExtMutex);
    if (_fpsArrs.count <= 0) {
        return;
    }
    
    __block int sum = 0;
    __block int min = [_fpsArrs[0] intValue];
    __block int max = min;
    
    [_fpsArrs enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        int value = [obj intValue];
        sum += value;
        if(value > max)
            max = value;
        if(value < min)
            min = value;
    }];
    
    float avg = (float)sum / _fpsArrs.count;
    //avg = (float)Math.Round(avg, 1); ??
    avg = round(avg * 10) / 10;
    GPMFpsInfo* info = [[GPMFpsInfo alloc] init];
    info.avg = avg;
    info.max = max;
    info.min = min;
    
    info.totalTimes = (int)_fpsArrs.count;
    info.heavyTimes = _hTimes;
    info.cusTimes = _cusTimes;
    info.lightTimes = _lTimes;
    info.lightTimes1 = _lTimes1;
    info.lightTimes2 = _lTimes2;
    info.lightTimes3 = _lTimes3;
    info.fpsdots = [self getFpsDotsStr];
    if (fpsInfo) {
        fpsInfo(info);
    }
    [_fpsArrs removeAllObjects];
    [_fpsDotsArrs removeAllObjects];
}

 - (NSString*)getFpsDotsStr {
     
     __block NSString* fpsDotsStr = [NSString string];
     [_fpsDotsArrs enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
         fpsDotsStr = [fpsDotsStr stringByAppendingFormat:@"%@,",obj];
     }];

    return fpsDotsStr;
}

- (void)addFps:(int)fps{
    
    TApm_AutoLock autoLock(fpsExtMutex);
    // 验证合理性
    if(fps < 0)
        return;
    
    id fpsObj = @(fps);
    if (fpsObj) {
        [_fpsArrs addObject:fpsObj];
    }
    // 如果不是第一次记录：
    if(_lastFps > 0) {
        int dif = fps - _lastFps;
        if(dif < _hTs)
            _hTimes++;
        else if(dif >= _llTs && dif < _lrTs)
            _lTimes++;
        if(dif <= _cusTs)
            _cusTimes++;
    }
    
    _lastFps = fps;
    uint32_t curTime = SDKHelper::SDKUtill::getCurrentTimeIntervalMillisecond();

    if(_dotFreq > 0 && _lastDotTime + _dotFreq <= curTime) {
        if (fpsObj) {
             [_fpsDotsArrs addObject:fpsObj];
        }
       
        _lastDotTime = curTime;
        if (fps >= 0 && fps < _lTs1) {
            _lTimes1++;
        } else if(fps >= _lTs1 && fps < _lTs2){
            _lTimes2++;
        } else if (fps >= _lTs2 && fps < _lTs3) {
            _lTimes3++;
        }
    }
}

- (int)getFps {
    return _lastFps;
}

- (NSArray*)getFpsDots{
    TApm_AutoLock autoLock(fpsExtMutex);
    return [NSMutableArray arrayWithArray:_fpsDotsArrs];
}

@end
