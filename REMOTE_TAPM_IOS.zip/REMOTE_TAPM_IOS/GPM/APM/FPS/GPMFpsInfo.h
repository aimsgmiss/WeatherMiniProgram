//
//  GPMFpsInfo.h
//  APM
//
//  Created by xiang lin on 2020/3/9.
//  Copyright © 2020 xianglin. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface GPMFpsInfo : NSObject

- (NSString*)toString;

@property(nonatomic,assign)  float avg; // fps平均值，保留一位小数点

@property(nonatomic,assign)  int max; // fps最大值

@property(nonatomic,assign)  int min; // fps最小值

@property(nonatomic,assign)  int totalTimes; // 总共统计的次数

@property(nonatomic,assign)  int heavyTimes; // 严重抖动次数

@property(nonatomic,assign)  int lightTimes; // 轻微抖动次数

@property(nonatomic,assign)  int lightTimes1; // 轻微抖动次数1

@property(nonatomic,assign)  int lightTimes2; // 轻微抖动次数2

@property(nonatomic,assign)  int lightTimes3; // 轻微抖动次数3

@property(nonatomic,assign)  int cusTimes; // 自定义抖动次数

@property(nonatomic,copy) NSString* fpsdots; // FPS统计结果数组


@end

NS_ASSUME_NONNULL_END
