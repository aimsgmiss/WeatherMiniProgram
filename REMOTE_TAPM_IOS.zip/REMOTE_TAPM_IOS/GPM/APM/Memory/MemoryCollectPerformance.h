//
//  MemoryCollectPerformance.h
//  LearnOpenGLESWithGPUImage
//
//  Created by xiang lin on 13/12/2017.
//  Copyright © 2017 xiang All rights reserved.
//

#import "TApmCollectPerformance.h"

@interface MemoryCollectPerformance : TApmCollectPerformance
{
    int32_t            _pss;
    int32_t            _reservedPss;
}

@property (nonatomic,assign) BOOL isLowLevelDevice;

- (void)getCurrentAppResidentMemory;

@end
