//
//  MemoryCollectPerformance.m
//  LearnOpenGLESWithGPUImage
//
//  Created by xiang lin on 13/12/2017.
//  Copyright © 2017 xiang All rights reserved.
//

#import <mach/task_info.h>
#import <Foundation/NSProcessInfo.h>
#import <mach/task.h>
#import <CoreGraphics/CoreGraphics.h>
#import <sys/sysctl.h>
#import <mach/mach_host.h>
#import "MemoryCollectPerformance.h"
#import "MessageQueue.h"
#import "SDKHeader.h"
#import "CPUCollectPerformance.h"
#import "SDKHelper.h"
#import "DeviceInfoHelper.h"
using namespace SDKHelper;
@interface MemoryCollectPerformance()

@end

@implementation MemoryCollectPerformance

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        NSString* deviceModel = DeviceInfo::DeviceInfoHelper::getDeviceModel();
        NSArray* lowLevelDeviceModels = @[@"iPhone7,1",@"iPhone7,2",@"iPhone6,1",@"iPhone6,2"];
        _isLowLevelDevice = NO;
        if (deviceModel && lowLevelDeviceModels && [lowLevelDeviceModels containsObject:deviceModel]) _isLowLevelDevice = YES;
    }
    return self;
}

-(void)startMonitor
{
    [super startMonitor];
}

-(void)collectionDatas
{
    DataPerSec          dataPerSec;
    
    if (!self.isCollectionData) return;
    [super collectionDatas];
    _pss = 0;
    _reservedPss = 0;
    if (kPSS_OPT & SDKUtill::opts)
    {
        _pss = 0;
        _reservedPss = 0;
    }
    else
    {
        [self getCurrentAppResidentMemory];
    }
    memset(&dataPerSec, 0, sizeof(dataPerSec));
    dataPerSec.appMemoryUsed = _pss;
    dataPerSec.reserved1 = _reservedPss;
    
    [[MessageQueue sharedInstance] pushMessageToGloabelBufferQueue:GamePerformanceDataType_Memory DataPerSec:dataPerSec isWriteToBuffer:NO];
    
}

// 当前进程占用内存
- (void)getCurrentAppResidentMemory
{
    
    mach_msg_type_number_t info_count = TASK_VM_INFO_COUNT;
    task_vm_info_data_t vm_info;
    if(task_info(mach_task_self(), TASK_VM_INFO, (task_info_t)&vm_info, &info_count) == KERN_SUCCESS)
    {
        if (_isLowLevelDevice || SDKUtill::currVersionDoub >= 12.0)
        {
            _pss = (int32_t) vm_info.phys_footprint / (kByteConvertMB);
            _reservedPss = _pss;
            APMSDKLog(@"Memory in use (in M) phys_footprint: %d", _pss);
        }
        
        if (SDKUtill::currVersionDoub < 12.0)
        {
            _reservedPss = int32_t (vm_info.internal + vm_info.compressed - vm_info.purgeable_volatile_pmap) / (kByteConvertMB);
            APMSDKLog(@"Memory in use (in M) phys_footprint: %d", _reservedPss);
        }
    }
    else
    {
        _pss = 0;
        _reservedPss = 0;
    }
    
    struct mach_task_basic_info info;
    mach_msg_type_number_t      count = MACH_TASK_BASIC_INFO_COUNT;
    if (!_isLowLevelDevice && task_info(mach_task_self(), MACH_TASK_BASIC_INFO, (task_info_t)& info, &count) == KERN_SUCCESS)
    {
        _pss = (int32_t)info.resident_size / kByteConvertMB;
        APMSDKLog(@"Memory in use (in M) resident_size: %d", _pss);
    }
    

}

-(void)stopMonitor
{
    [super stopMonitor];
}


@end
