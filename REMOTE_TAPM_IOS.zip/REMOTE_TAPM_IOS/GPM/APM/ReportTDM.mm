#include "ReportTDM.h"
#import "SDKStructEnumDefine.h"
#import "TApmLog.h"
#import "GCloudCoreGPM.h"
namespace GCloud {
    namespace APM {

        static GCloud::Plugin::IReportService* g_report_service_inf = NULL;
        void
        ReportInitContext(bool success, int errorCode, int sessionId) {
            PluginGPM pluginTri;
            GCloud::Plugin::IEvent *pEvent =
            CREATE_GCLOUDCORE_REPORT_EVENT(
                    PluginGPM,    // 插件实现类
                    GCLOUDCORE_REPORT_ENV_TEST | GCLOUDCORE_REPORT_ENV_RELEASE,
                    2005,
                    "monitor");

            if (!pEvent) {
                return;
            } else {
                // 上报key-value数据
                pEvent->Add(GCloud::Plugin::KStrKeyComponentName, PLUGIN_NAME_APM,
                            strlen(PLUGIN_NAME_APM));
                pEvent->Add(GCloud::Plugin::KStrKeyComponentVersion, pluginTri.GetVersion(),
                            strlen(pluginTri.GetVersion()));
                pEvent->Add(GCloud::Plugin::KStrKeyMethodName, "InitContext",
                            strlen("InitContext"));
                pEvent->Add(GCloud::Plugin::kIntKeyResultCode, success);
                pEvent->Add(GCloud::Plugin::kIntKeyErrorCode, errorCode);
                pEvent->Add(GCloud::Plugin::KIntKeyMethodType, 1);
                pEvent->Add(GCloud::Plugin::KIntKeySessionID, 1);
                pEvent->Report();

                DESTROY_GCLOUDCORE_REPORT_EVENT(PluginGPM, &pEvent);
                return;
            }
        }

        void
        ReportMarkLevelLoad(const std::string &levelName, bool success, int errorCode) {
            PluginGPM pluginTri;
            GCloud::Plugin::IEvent *pEvent =
            CREATE_GCLOUDCORE_REPORT_EVENT(
                    PluginGPM,    // 插件实现类
                    GCLOUDCORE_REPORT_ENV_TEST | GCLOUDCORE_REPORT_ENV_RELEASE,
                    2005,
                    "monitor");

            if (!pEvent) {
                return;
            } else {
                // 上报key-value数据
                pEvent->Add(GCloud::Plugin::KStrKeyComponentName, PLUGIN_NAME_APM,
                            strlen(PLUGIN_NAME_APM));
                pEvent->Add(GCloud::Plugin::KStrKeyComponentVersion, pluginTri.GetVersion(),
                            strlen(pluginTri.GetVersion()));
                pEvent->Add(GCloud::Plugin::KStrKeyMethodName, "MarkLevelLoad",
                            strlen("MarkLevelLoad"));
                char levelNameJson[256];
                sprintf(levelNameJson, "{\"levelName\":%s}", levelName.c_str());
                pEvent->Add(GCloud::Plugin::KStrKeyMethodParams, levelNameJson,
                            strlen(levelNameJson));
                pEvent->Add(GCloud::Plugin::kIntKeyResultCode, success);
                pEvent->Add(GCloud::Plugin::kIntKeyErrorCode, errorCode);
                pEvent->Add(GCloud::Plugin::KIntKeyMethodType, 1);
                pEvent->Add(GCloud::Plugin::KIntKeySessionID, 1);
                pEvent->Report();

                DESTROY_GCLOUDCORE_REPORT_EVENT(PluginGPM, &pEvent);
                return;
            }
        }

        void
        ReportPostStatus(bool success, int errorCode, int duration, int size) {
            PluginGPM pluginAPM;
            GCloud::Plugin::IEvent *pEvent =
            CREATE_GCLOUDCORE_REPORT_EVENT(
                    PluginGPM,    // 插件实现类
                    GCLOUDCORE_REPORT_ENV_TEST | GCLOUDCORE_REPORT_ENV_RELEASE,
                    2005,
                    "monitor");

            if (!pEvent) {
                return;
            } else {
                // 上报key-value数据
                pEvent->Add(GCloud::Plugin::KStrKeyComponentName, PLUGIN_NAME_APM,
                            strlen(PLUGIN_NAME_APM));
                pEvent->Add(GCloud::Plugin::KStrKeyComponentVersion, pluginAPM.GetVersion(),
                            strlen(pluginAPM.GetVersion()));
                pEvent->Add(GCloud::Plugin::KStrKeyMethodName, "PostData", strlen("PostData"));
                pEvent->Add(GCloud::Plugin::kIntKeyResultCode, success);
                pEvent->Add(GCloud::Plugin::kIntKeyErrorCode, errorCode);
                pEvent->Add(GCloud::Plugin::KIntKeyMethodType, 1);
                pEvent->Add(GCloud::Plugin::KIntKeyDuration, duration);
                pEvent->Add(GCloud::Plugin::KIntKeySessionID, 1);
                pEvent->Report();

                DESTROY_GCLOUDCORE_REPORT_EVENT(PluginGPM, &pEvent);
                return;
            }
        }

        void
        ReportDeviceClassStatus(bool success, int errorCode, int duration, const char *domain) {
            if (domain == NULL) return;
            PluginGPM pluginAPM;
            GCloud::Plugin::IEvent *pEvent =
            CREATE_GCLOUDCORE_REPORT_EVENT(
                    PluginGPM,    // 插件实现类
                    GCLOUDCORE_REPORT_ENV_TEST | GCLOUDCORE_REPORT_ENV_RELEASE,
                    2005,
                    "monitor");

            if (!pEvent) {
                return;
            } else {
                // 上报key-value数据
                pEvent->Add(GCloud::Plugin::KStrKeyComponentName, PLUGIN_NAME_APM,
                            strlen(PLUGIN_NAME_APM));
                pEvent->Add(GCloud::Plugin::KStrKeyComponentVersion, pluginAPM.GetVersion(),
                            strlen(pluginAPM.GetVersion()));
                char levelNameJson[256];
                sprintf(levelNameJson, "{\"domainName\":%s}", domain);

                pEvent->Add(GCloud::Plugin::KStrKeyMethodName, "GetDeviceClass",
                            strlen("GetDeviceClass"));
                pEvent->Add(GCloud::Plugin::KStrKeyMethodParams, levelNameJson,
                            strlen(levelNameJson));
                pEvent->Add(GCloud::Plugin::kIntKeyResultCode, success);
                pEvent->Add(GCloud::Plugin::kIntKeyErrorCode, errorCode);
                pEvent->Add(GCloud::Plugin::KIntKeyMethodType, 1);
                pEvent->Add(GCloud::Plugin::KIntKeyDuration, duration);
                pEvent->Add(GCloud::Plugin::KIntKeySessionID, 1);
                pEvent->Report();

                DESTROY_GCLOUDCORE_REPORT_EVENT(PluginGPM, &pEvent);
            }
        }

        /*GCloud::Plugin::IReportService* GetReportService(){
            
            if(g_report_service_inf == NULL){
                GCloud::Plugin::PluginBase*  pluginBase = PluginGPM::GetInstance();
                if(NULL==pluginBase){
                    APM_LOG_DEBUG(@"ReportBinaryByTDM init PluginBase error");
                    return NULL;
                }
                GCloud::Plugin::IPluginManager* pluginManager = pluginBase->GetPluginManager();
                if(NULL==pluginManager){
                    APM_LOG_DEBUG(@"ReportBinaryByTDM init IPluginManager error");
                    return NULL;
                }
                GCloud::Plugin::IPlugin* plugin = (GCloud::Plugin::IPlugin*)pluginManager->GetPluginByName(PLUGIN_NAME_TDM);
                if(NULL==plugin){
                    APM_LOG_DEBUG(@"ReportBinaryByTDM init IPlugin error");
                    return NULL;
                }
                g_report_service_inf = (GCloud::Plugin::IReportService*)plugin->GetServiceByName(PLUGIN_SERVICE_NAME_REPORT);
                if(NULL==g_report_service_inf){
                    APM_LOG_DEBUG(@"ReportBinaryByTDM init IReportService error");
                    return NULL;
                }
            }
            
            return g_report_service_inf;
        }*/
        
        void ReportBinaryByTDM(int srcID, const char * eventName, const char* data, int len){
        
            g_report_service_inf = GCloud::GPM::GetReportService();
            if(g_report_service_inf != NULL){
                g_report_service_inf->ReportBinary(srcID, eventName, data, len);
                APM_LOG_DEBUG(@"ReportBinaryByTDM len:%d",len);
            }
        }

        const char* GetTDMUID(){
            
            g_report_service_inf = GCloud::GPM::GetReportService();

            if(g_report_service_inf != NULL){
                return g_report_service_inf->GetTDMUID();
            }else{
                return "ERROR";
            }
        }

    }
}
