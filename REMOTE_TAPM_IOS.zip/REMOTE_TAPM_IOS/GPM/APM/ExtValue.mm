
#ifdef ANDROID
#include "jni.h"
#endif

//#include "prototype.h"
#include "MsgQueue.h"
#include "TApm_Mutex.h"
#include "TApm_AutoLock.h"
#include "zigzag.h"
#include <Foundation/Foundation.h>
#import "MessageQueue.h"
#import "SDKHelper.h"
#import "APMCCStrategy.h"
#import "TApmLog.h"

#define JNIEXPORT
#define JNICALL
using namespace SDKHelper;

#define EXT_STR_MAX_LEN 64

struct ExtPacket
{
    uint32_t timestamp;
    uint32_t sceneIdx;
    int type;//1,2,3,4,5,6,7
    union
    {
        int ivalue[3];
        float fvalue[3];
        char svalue[EXT_STR_MAX_LEN];
    };
    
    int categoryIdx;
    char categoryName[EXT_STR_MAX_LEN];
    
    int keyIdx;
    char keyName[EXT_STR_MAX_LEN];
    
    ExtPacket()
    {
        memset(this, 0, sizeof(ExtPacket));
    }
};

static GPM::MsgQueue<ExtPacket> gExtQueue(4096, false,"gExtQueue");

static ExtPacket sgTempPacket;

static TApmMutex sgExtMutex;

#define PARAM_TYPE_INT 1
#define PARAM_TYPE_INT_INT 2
#define PARAM_TYPE_INT_INT_INT 3

#define PARAM_TYPE_FLOAT 4
#define PARAM_TYPE_FLOAT_FLOAT 5
#define PARAM_TYPE_FLOAT_FLOAT_FLOAT 6

#define PARAM_TYPE_STR 7

#define PARAM_TYPE_TUPLE_WRAP 8

#define PREFIX_EXT_AXIS_TIMESTAMP 24

#define REAL_TYPE_BITS 0xFF
//#define INDEX_KEY_INDICATOR 100
#define INDEX_KEY_SEPARATOR 0x100
#define INDEX_CAT_SEPARATOR 0x10000

#define EMPTY_STR_SEPERATOR 100

#define MAX_CACHED_INDEX 1024

#define PARAM_TYPE_TUPLE_WRAP_END (EMPTY_STR_SEPERATOR+1)
//#define PARAM_TYPE_BEGINJOINTKEY 1111
//#define PARAM_TYPE_ENDJOINTKEY 1112

//static struct timespec sExtTmSpec;

extern unsigned int    g_apmSenceIndex;

extern void            g_apm_write_zigzag_int32(int32_t value);
// 保留3为小数
extern "C" JNIEXPORT void JNICALL tapmNativePostV3F(const char* category, const char* key, float a, float b, float c)
{
   
    if (![[APMCCStrategy sharedInstance] validCheck:@"tapmNativePostV3F" tag:FEATURE_POST_VALUE_XX]) {
        return;
    }
    
    if(!category || !key)
    {
        APM_LOG_DEBUG(@"category or key is NULL");
        return;
    }
      
    TApm_AutoLock autoLock(sgExtMutex);
    
    sgTempPacket.timestamp = SDKUtill::getCurrentTimeIntervalMillisecond();
    sgTempPacket.sceneIdx = g_apmSenceIndex;
    
    sgTempPacket.type = PARAM_TYPE_FLOAT_FLOAT_FLOAT;
    sgTempPacket.fvalue[0] = a;
    sgTempPacket.fvalue[1] = b;
    sgTempPacket.fvalue[2] = c;
    memset(sgTempPacket.keyName, 0, EXT_STR_MAX_LEN);
    strncpy(sgTempPacket.keyName, key, EXT_STR_MAX_LEN - 1);
    
    memset(sgTempPacket.categoryName, 0, EXT_STR_MAX_LEN);
    strncpy(sgTempPacket.categoryName, category, EXT_STR_MAX_LEN - 1);
    gExtQueue.postMsg(sgTempPacket);
}

extern "C" JNIEXPORT void JNICALL tapmNativePostV2F(const char* category, const char* key, float a, float b)
{
    if (![[APMCCStrategy sharedInstance] validCheck:@"tapmNativePostV2F" tag:FEATURE_POST_VALUE_XX]) {
        return;
    }
       
    if(!category || !key)
    {
       APM_LOG_DEBUG(@"category or key is NULL");
       return;
    }
    
    TApm_AutoLock autoLock(sgExtMutex);

    sgTempPacket.timestamp = SDKUtill::getCurrentTimeIntervalMillisecond();
    sgTempPacket.sceneIdx = g_apmSenceIndex;
    
    sgTempPacket.type = PARAM_TYPE_FLOAT_FLOAT;
    sgTempPacket.fvalue[0] = a;
    sgTempPacket.fvalue[1] = b;
    memset(sgTempPacket.keyName, 0, EXT_STR_MAX_LEN);
    strncpy(sgTempPacket.keyName, key, EXT_STR_MAX_LEN - 1);
    
    memset(sgTempPacket.categoryName, 0, EXT_STR_MAX_LEN);
    strncpy(sgTempPacket.categoryName, category, EXT_STR_MAX_LEN - 1);
    gExtQueue.postMsg(sgTempPacket);
}

extern "C" JNIEXPORT void JNICALL tapmNativePostV1F(const char* category, const char* key, float a)
{
    if (![[APMCCStrategy sharedInstance] validCheck:@"tapmNativePostV1F" tag:FEATURE_POST_VALUE_XX]) {
        return;
    }
       
    if(!category || !key)
    {
       APM_LOG_DEBUG(@"category or key is NULL");
       return;
    }
    
    TApm_AutoLock autoLock(sgExtMutex);

    sgTempPacket.timestamp = SDKUtill::getCurrentTimeIntervalMillisecond();
    sgTempPacket.sceneIdx = g_apmSenceIndex;
    
    sgTempPacket.type = PARAM_TYPE_FLOAT;
    sgTempPacket.fvalue[0] = a;
    memset(sgTempPacket.keyName, 0, EXT_STR_MAX_LEN);
    strncpy(sgTempPacket.keyName, key, EXT_STR_MAX_LEN - 1);
    
    memset(sgTempPacket.categoryName, 0, EXT_STR_MAX_LEN);
    strncpy(sgTempPacket.categoryName, category, EXT_STR_MAX_LEN - 1);
    gExtQueue.postMsg(sgTempPacket);
}

extern "C" JNIEXPORT void JNICALL tapmNativePostV3I(const char* category, const char* key, int a, int b, int c)
{
    if (![[APMCCStrategy sharedInstance] validCheck:@"tapmNativePostV3I" tag:FEATURE_POST_VALUE_XX]) {
        return;
    }
       
    if(!category || !key)
    {
       APM_LOG_DEBUG(@"category or key is NULL");
       return;
    }
    
    TApm_AutoLock autoLock(sgExtMutex);

    sgTempPacket.timestamp = SDKUtill::getCurrentTimeIntervalMillisecond();
    sgTempPacket.sceneIdx = g_apmSenceIndex;
    
    sgTempPacket.type = PARAM_TYPE_INT_INT_INT;
    sgTempPacket.ivalue[0] = a;
    sgTempPacket.ivalue[1] = b;
    sgTempPacket.ivalue[2] = c;
    memset(sgTempPacket.keyName, 0, EXT_STR_MAX_LEN);
    strncpy(sgTempPacket.keyName, key, EXT_STR_MAX_LEN - 1);
    
    memset(sgTempPacket.categoryName, 0, EXT_STR_MAX_LEN);
    strncpy(sgTempPacket.categoryName, category, EXT_STR_MAX_LEN - 1);
    gExtQueue.postMsg(sgTempPacket);
}

extern "C" JNIEXPORT void JNICALL tapmNativePostV2I(const char* category, const char* key, int a, int b)
{
    if (![[APMCCStrategy sharedInstance] validCheck:@"tapmNativePostV2I" tag:FEATURE_POST_VALUE_XX]) {
        return;
    }
       
    if(!category || !key)
    {
       APM_LOG_DEBUG(@"category or key is NULL");
       return;
    }
    
    TApm_AutoLock autoLock(sgExtMutex);
    
    sgTempPacket.timestamp = SDKUtill::getCurrentTimeIntervalMillisecond();
    sgTempPacket.sceneIdx = g_apmSenceIndex;
    
    sgTempPacket.type = PARAM_TYPE_INT_INT;
    sgTempPacket.ivalue[0] = a;
    sgTempPacket.ivalue[1] = b;
    memset(sgTempPacket.keyName, 0, EXT_STR_MAX_LEN);
    strncpy(sgTempPacket.keyName, key, EXT_STR_MAX_LEN - 1);
    
    memset(sgTempPacket.categoryName, 0, EXT_STR_MAX_LEN);
    strncpy(sgTempPacket.categoryName, category, EXT_STR_MAX_LEN - 1);
    gExtQueue.postMsg(sgTempPacket);
}

extern "C" JNIEXPORT void JNICALL tapmNativePostV1I(const char* category, const char* key, int a)
{
    if (![[APMCCStrategy sharedInstance] validCheck:@"tapmNativePostV1I" tag:FEATURE_POST_VALUE_XX]) {
        return;
    }
       
    if(!category || !key)
    {
       APM_LOG_DEBUG(@"category or key is NULL");
       return;
    }

    TApm_AutoLock autoLock(sgExtMutex);
    
    sgTempPacket.timestamp = SDKUtill::getCurrentTimeIntervalMillisecond();;
    sgTempPacket.sceneIdx = g_apmSenceIndex;
    
    sgTempPacket.type = PARAM_TYPE_INT;
    sgTempPacket.ivalue[0] = a;
    
    memset(sgTempPacket.keyName, 0, EXT_STR_MAX_LEN);
    strncpy(sgTempPacket.keyName, key, EXT_STR_MAX_LEN - 1);
    
    memset(sgTempPacket.categoryName, 0, EXT_STR_MAX_LEN);
    strncpy(sgTempPacket.categoryName, category, EXT_STR_MAX_LEN - 1);
    gExtQueue.postMsg(sgTempPacket);
    
}

extern "C" JNIEXPORT void JNICALL tapmNativePostV1S(const char* category, const char* key, const char* value)
{
    if (![[APMCCStrategy sharedInstance] validCheck:@"tapmNativePostV1S" tag:FEATURE_POST_VALUE_XX]) {
        return;
    }
       
    if(!category || !key || !value)
    {
       APM_LOG_DEBUG(@"category or key or value is NULL");
       return;
    }
    
    TApm_AutoLock autoLock(sgExtMutex);
    
    sgTempPacket.timestamp = SDKUtill::getCurrentTimeIntervalMillisecond();
    sgTempPacket.sceneIdx = g_apmSenceIndex;
    
    sgTempPacket.type = PARAM_TYPE_STR;
    
    memset(sgTempPacket.keyName, 0, EXT_STR_MAX_LEN);
    strncpy(sgTempPacket.keyName, key, EXT_STR_MAX_LEN - 1);
    
    memset(sgTempPacket.categoryName, 0, EXT_STR_MAX_LEN);
    strncpy(sgTempPacket.categoryName, category, EXT_STR_MAX_LEN - 1);
    
    memset(sgTempPacket.svalue, 0, EXT_STR_MAX_LEN);
    strncpy(sgTempPacket.svalue, value, EXT_STR_MAX_LEN - 1);
    
    gExtQueue.postMsg(sgTempPacket);
}

extern "C" JNIEXPORT void JNICALL tapmNativeBeginTupleWrap(const char* key)
{
    if (![[APMCCStrategy sharedInstance] validCheck:@"tapmNativeBeginTupleWrap" tag:FEATURE_POST_VALUE_XX]) {
        return;
    }
       
    if(!key)
    {
       APM_LOG_DEBUG(@"key is NULL");
       return;
    }
    
    TApm_AutoLock autoLock(sgExtMutex);
    sgTempPacket.timestamp = SDKUtill::getCurrentTimeIntervalMillisecond();
    sgTempPacket.sceneIdx = g_apmSenceIndex;
    
    sgTempPacket.type = PARAM_TYPE_TUPLE_WRAP;
    
    memset(sgTempPacket.keyName, 0, EXT_STR_MAX_LEN);
    strncpy(sgTempPacket.keyName, key, EXT_STR_MAX_LEN - 1);
    
    gExtQueue.postMsg(sgTempPacket);
}

extern "C" JNIEXPORT void JNICALL tapmNativeEndTupleWrap()
{
    if (![[APMCCStrategy sharedInstance] validCheck:@"tapmNativeEndTupleWrap" tag:FEATURE_POST_VALUE_XX]) {
        return;
    }
       
    TApm_AutoLock autoLock(sgExtMutex);
    
    sgTempPacket.timestamp = SDKUtill::getCurrentTimeIntervalMillisecond();
    sgTempPacket.sceneIdx = g_apmSenceIndex;
    
    sgTempPacket.type = PARAM_TYPE_TUPLE_WRAP_END;
    
    gExtQueue.postMsg(sgTempPacket);
}

namespace TAPM
{
    NSMutableDictionary*   sgIndexMap = nil;
    static int sgIndexMapCounter = 1;
    static bool isTimestampAxisWritten = false;
    static uint32_t extLastTimestamp = 0;
    
    NSMutableDictionary* getSgIndexMap()
    {
        if (nil == sgIndexMap) sgIndexMap = [[NSMutableDictionary alloc] init];
        
        return sgIndexMap;
    }

    void serlizeExtToFile(FILE* file, uint8_t eventPrefix, unsigned targetSceneIdx)// 将timefence之前的全部写入
    {
    
        if (![[APMCCStrategy sharedInstance] validCheck:@"serlizeExtToFile" tag:FEATURE_POST_VALUE_XX]) {
            return;
        }

        sgIndexMap = getSgIndexMap();
        if (!sgIndexMap) return;
        
        int eventGap = gExtQueue.getHeadIdx() - gExtQueue.getTailIdx() - 1;
        //int eventLen = std::min(eventGap, gExtQueue.getBufferSz() - 1);
        int eventLen = MIN(eventGap,gExtQueue.getBufferSz() - 1);
        if (eventLen <= 0)
            return;
        
        unsigned tailIdx = gExtQueue.getTailIdx();
        while (eventLen--)
        {
            ExtPacket* packetPtr = &gExtQueue.get(tailIdx+1); //peek
            if(packetPtr->sceneIdx > targetSceneIdx)
            {
                PRINT_I("POSTEXT TARGET SCENEIDX NOT MATCH %u %u, break\n", packetPtr->sceneIdx, targetSceneIdx);
                break;
            }
            
            tailIdx++;
            
            FWRITE_1(eventPrefix, file);
            
            if (packetPtr->type < EMPTY_STR_SEPERATOR)
            {
                {
                    if (sgIndexMap.count < MAX_CACHED_INDEX)
                    {
                        const char* keyValue = packetPtr->keyName;
                        NSString* key = [NSString stringWithFormat:@"%s",keyValue];
                        if (!key) return;
                        
                        int targetIdx = 0;
                        id value = [sgIndexMap objectForKey:key];
                        if (value)
                        {
                            targetIdx = [value intValue];
                        }
                        else
                        {
                            targetIdx = sgIndexMapCounter++;
                            [sgIndexMap setValue:@(targetIdx) forKey:key];
                            packetPtr->type |= INDEX_KEY_SEPARATOR;// new key
                        }
                        packetPtr->keyIdx = targetIdx;
                    }
                    else
                    {// avoid flush attack
                        
                        packetPtr->keyIdx = MAX_CACHED_INDEX;
                        packetPtr->type |= INDEX_KEY_SEPARATOR;
                        PRINT_I("AVOID FLUSH ATTACK, KEY: %s", packetPtr->keyName);
                    }
                    
                }
                
                if ((packetPtr->type & 0xFF) != PARAM_TYPE_TUPLE_WRAP)//category
                {
                    if (sgIndexMap.count < MAX_CACHED_INDEX)
                    {
                        const char* categoryValue = packetPtr->categoryName;
                        NSString* key = [NSString stringWithFormat:@"%s",categoryValue];
                        if (!key) return;
                        
                        int targetIdx = 0;
                        id value = [sgIndexMap objectForKey:key];
                        if (value)
                        {
                            targetIdx = [value intValue];
                        }
                        else
                        {
                            targetIdx = sgIndexMapCounter++;
                            [sgIndexMap setValue:@(targetIdx) forKey:key];
                            packetPtr->type |= INDEX_CAT_SEPARATOR;// new key
                        }
                        packetPtr->categoryIdx = targetIdx;
                    }
                    else
                    {
                        packetPtr->categoryIdx = MAX_CACHED_INDEX;
                        packetPtr->type |= INDEX_CAT_SEPARATOR;
                        PRINT_I("AVOID FLUSH ATTACK,CAT: %s", packetPtr->categoryName);
                    }
                    
                }
            }
            
            FWRITE_4(packetPtr->timestamp, file);
            FWRITE_4(packetPtr->type, file);
            
            switch (packetPtr->type & 0xFF)
            {
                case PARAM_TYPE_INT:
                {
                    FWRITE_4(packetPtr->ivalue[0], file);
                    break;
                }
                    
                case PARAM_TYPE_INT_INT:
                {
                    FWRITE_4(packetPtr->ivalue[0], file);
                    FWRITE_4(packetPtr->ivalue[1], file);
                    break;
                }
                    
                case PARAM_TYPE_INT_INT_INT:
                {
                    FWRITE_4(packetPtr->ivalue[0], file);
                    FWRITE_4(packetPtr->ivalue[1], file);
                    FWRITE_4(packetPtr->ivalue[2], file);
                    break;
                }
                    
                case PARAM_TYPE_FLOAT:
                {
                    float temp1 = packetPtr->fvalue[0];
                    int* itemp1Ptr = reinterpret_cast<int*> (&temp1);
                    FWRITE_4(*itemp1Ptr, file);
                    break;
                }
                    
                case PARAM_TYPE_FLOAT_FLOAT:
                {
                    float temp1 = packetPtr->fvalue[0];
                    float temp2 = packetPtr->fvalue[1];
                    
                    int* itemp1Ptr = reinterpret_cast<int*> (&temp1);
                    FWRITE_4(*itemp1Ptr, file);
                    
                    int* itemp2Ptr = reinterpret_cast<int*> (&temp2);
                    FWRITE_4(*itemp2Ptr, file);
                    break;
                }
                    
                case PARAM_TYPE_FLOAT_FLOAT_FLOAT:
                {
                    float temp1 = packetPtr->fvalue[0];
                    float temp2 = packetPtr->fvalue[1];
                    float temp3 = packetPtr->fvalue[2];
                    int* itemp1Ptr = reinterpret_cast<int*> (&temp1);
                    FWRITE_4(*itemp1Ptr, file);
                    
                    int* itemp2Ptr = reinterpret_cast<int*> (&temp2);
                    FWRITE_4(*itemp2Ptr, file);
                    
                    int* itemp3Ptr = reinterpret_cast<int*> (&temp3);
                    FWRITE_4(*itemp3Ptr, file);
                    break;
                }
                case PARAM_TYPE_STR:
                {
                    packetPtr->svalue[EXT_STR_MAX_LEN - 1] = '\0';
                    int16_t valueLen = strlen(packetPtr->svalue);
                    FWRITE_2(valueLen, sizeof(int16_t), 1, file);
                    if (valueLen > 0 && valueLen < EXT_STR_MAX_LEN)
                    {
                        FWRITE_Bytes(packetPtr->svalue, valueLen, 1, file);
                    }
                }
            }
            
            if ((packetPtr->type & REAL_TYPE_BITS) < EMPTY_STR_SEPERATOR)
            {
                {
                    FWRITE_4(packetPtr->keyIdx, file);
                    if (packetPtr->type & INDEX_KEY_SEPARATOR)//first memtioned
                    {
                        int16_t keyNameLen = strlen(packetPtr->keyName);
                        FWRITE_2(keyNameLen, sizeof(int16_t), 1, file);
                        if (keyNameLen > 0 && keyNameLen < EXT_STR_MAX_LEN)
                        {
                            FWRITE_Bytes(packetPtr->keyName, keyNameLen, 1, file);
                        }
                    }
                }
                
                if ((packetPtr->type & REAL_TYPE_BITS) != PARAM_TYPE_TUPLE_WRAP)
                {
                    FWRITE_4(packetPtr->categoryIdx, file);
                    if (packetPtr->type & INDEX_CAT_SEPARATOR)//first memtioned
                    {
                        int16_t categoryNameLen = strlen(packetPtr->categoryName);
                        FWRITE_2(categoryNameLen, sizeof(int16_t), 1, file);
                        if (categoryNameLen > 0 && categoryNameLen < EXT_STR_MAX_LEN)
                        {
                            FWRITE_Bytes(packetPtr->categoryName, categoryNameLen, 1, file);
                        }
                    }
                }
            }
            
        }
        
        gExtQueue.resetTailPos(tailIdx);
    }
    
    void clearIndexMap()
    {
        if (![[APMCCStrategy sharedInstance] validCheck:@"clearIndexMap" tag:FEATURE_POST_VALUE_XX]) {
            return;
        }
        
        [sgIndexMap removeAllObjects];
        sgIndexMapCounter = 1;
        isTimestampAxisWritten = false;
        extLastTimestamp = 0;
    }
    
    void serlizeExtToFileCompress(FILE* file, uint8_t eventPrefix, unsigned targetSceneIdx)// 将timefence之前的全部写入
    {
        if (![[APMCCStrategy sharedInstance] isFeatureEnabled:FEATURE_POST_VALUE_XX]) {
            return;
        }
        sgIndexMap = getSgIndexMap();
        if (!sgIndexMap) return;
        
        int eventGap = gExtQueue.getHeadIdx() - gExtQueue.getTailIdx() - 1;
        int eventLen = MIN(eventGap, gExtQueue.getBufferSz() - 1);
        if (eventLen <= 0)
            return;
        
        unsigned tailIdx = gExtQueue.getTailIdx();
        while (eventLen--)
        {
            ExtPacket* packetPtr = &gExtQueue.get(tailIdx + 1); //peek
            if (packetPtr->sceneIdx > targetSceneIdx)
            {
                PRINT_I("POSTEXT TARGET SCENEIDX NOT MATCH %u %u, break", packetPtr->sceneIdx, targetSceneIdx);
                break;
            }
            
            tailIdx++;
            
            //process axis timestamp
            if (!isTimestampAxisWritten)
            {
                isTimestampAxisWritten = true;
                extLastTimestamp = packetPtr->timestamp;
                uint8_t axisPrefix = PREFIX_EXT_AXIS_TIMESTAMP;
                FWRITE_1(axisPrefix, file);
                FWRITE_4(extLastTimestamp, file);
            }
            //end
            FWRITE_1(eventPrefix, file);
            
            if (packetPtr->type < EMPTY_STR_SEPERATOR)
            {
                {
                    if (sgIndexMap.count < MAX_CACHED_INDEX)
                    {
                        const char* keyValue = packetPtr->keyName;
                        NSString* key = [NSString stringWithFormat:@"%s",keyValue];
                        if (!key) return;
                        
                        int targetIdx = 0;
                        id value = [sgIndexMap objectForKey:key];
                        if (value)
                        {
                            targetIdx = [value intValue];
                        }
                        else
                        {
                            targetIdx = sgIndexMapCounter++;
                            [sgIndexMap setValue:@(targetIdx) forKey:key];
                            packetPtr->type |= INDEX_KEY_SEPARATOR;// new key
                        }
                        packetPtr->keyIdx = targetIdx;
                    }
                    else
                    {// avoid flush attack
                        
                        packetPtr->keyIdx = MAX_CACHED_INDEX;
                        packetPtr->type |= INDEX_KEY_SEPARATOR;
                        PRINT_I("AVOID FLUSH ATTACK, KEY: %s", packetPtr->keyName);
                    }
                    
                }
                
                if ((packetPtr->type & 0xFF) != PARAM_TYPE_TUPLE_WRAP)//category
                {
                    if (sgIndexMap.count < MAX_CACHED_INDEX)
                    {
                        const char* categoryValue = packetPtr->categoryName;
                        NSString* key = [NSString stringWithFormat:@"%s",categoryValue];
                        if (!key) return;
                        
                        int targetIdx = 0;
                        id value = [sgIndexMap objectForKey:key];
                        if (value)
                        {
                            targetIdx = [value intValue];
                        }
                        else
                        {
                            targetIdx = sgIndexMapCounter++;
                            [sgIndexMap setValue:@(targetIdx) forKey:key];
                            packetPtr->type |= INDEX_CAT_SEPARATOR;// new key
                        }
                        packetPtr->categoryIdx = targetIdx;
                    }
                    else
                    {
                        packetPtr->categoryIdx = MAX_CACHED_INDEX;
                        packetPtr->type |= INDEX_CAT_SEPARATOR;
                        PRINT_I("AVOID FLUSH ATTACK,CAT: %s", packetPtr->categoryName);
                    }
                    
                }
            }
            
            uint32_t diffTime = packetPtr->timestamp - extLastTimestamp;
            //diffTime is a small positive int value, encode & write zigzag
            extLastTimestamp = packetPtr->timestamp;
        
            g_apm_write_zigzag_int32(diffTime);
            
            g_apm_write_zigzag_int32(packetPtr->type);
            
            switch (packetPtr->type & 0xFF)
            {
                case PARAM_TYPE_INT:
                {
                    
                    g_apm_write_zigzag_int32(packetPtr->ivalue[0]);
                    
                    break;
                }
                    
                case PARAM_TYPE_INT_INT:
                {
                    g_apm_write_zigzag_int32(packetPtr->ivalue[0]);
                    
                    g_apm_write_zigzag_int32(packetPtr->ivalue[1]);
                    
                    break;
                }
                    
                case PARAM_TYPE_INT_INT_INT:
                {
                    g_apm_write_zigzag_int32(packetPtr->ivalue[0]);
                    
                    g_apm_write_zigzag_int32(packetPtr->ivalue[1]);
                    
                    g_apm_write_zigzag_int32(packetPtr->ivalue[2]);
                    break;
                }
                    
                case PARAM_TYPE_FLOAT:
                {
                    float temp1 = packetPtr->fvalue[0];
                    int* itemp1Ptr = reinterpret_cast<int*> (&temp1);
                    FWRITE_4(*itemp1Ptr, file);
                    break;
                }
                    
                case PARAM_TYPE_FLOAT_FLOAT:
                {
                    float temp1 = packetPtr->fvalue[0];
                    float temp2 = packetPtr->fvalue[1];
                    
                    int* itemp1Ptr = reinterpret_cast<int*> (&temp1);
                    FWRITE_4(*itemp1Ptr, file);
                    
                    int* itemp2Ptr = reinterpret_cast<int*> (&temp2);
                    FWRITE_4(*itemp2Ptr, file);
                    break;
                }
                    
                case PARAM_TYPE_FLOAT_FLOAT_FLOAT:
                {
                    float temp1 = packetPtr->fvalue[0];
                    float temp2 = packetPtr->fvalue[1];
                    float temp3 = packetPtr->fvalue[2];
                    int* itemp1Ptr = reinterpret_cast<int*> (&temp1);
                    FWRITE_4(*itemp1Ptr, file);
                    
                    int* itemp2Ptr = reinterpret_cast<int*> (&temp2);
                    FWRITE_4(*itemp2Ptr, file);
                    
                    int* itemp3Ptr = reinterpret_cast<int*> (&temp3);
                    FWRITE_4(*itemp3Ptr, file);
                    break;
                }
                case PARAM_TYPE_STR:
                {
                    packetPtr->svalue[EXT_STR_MAX_LEN - 1] = '\0';
                    int16_t valueLen = strlen(packetPtr->svalue);
                    
                    FWRITE_2(valueLen, NULL,NULL,NULL);
                    if (valueLen > 0 && valueLen < EXT_STR_MAX_LEN)
                    {
                        FWRITE_Bytes(packetPtr->svalue,valueLen,NULL,NULL);
                    }
                }
                    
            }
            
            if ((packetPtr->type & REAL_TYPE_BITS) < EMPTY_STR_SEPERATOR)
            {
                {
                    FWRITE_4(packetPtr->keyIdx, file);
                    if (packetPtr->type & INDEX_KEY_SEPARATOR)//first memtioned
                    {
                        int16_t keyNameLen = strlen(packetPtr->keyName);
                        
                        FWRITE_2(keyNameLen, sizeof(int16_t), 1, file);
                        if (keyNameLen > 0 && keyNameLen < EXT_STR_MAX_LEN)
                        {
                            FWRITE_Bytes(packetPtr->keyName, keyNameLen, 1, file);
                        }
                    }
                }
                
                if ((packetPtr->type & REAL_TYPE_BITS) != PARAM_TYPE_TUPLE_WRAP)
                {
                    FWRITE_4(packetPtr->categoryIdx, file);
                    if (packetPtr->type & INDEX_CAT_SEPARATOR)//first memtioned
                    {
                        int16_t categoryNameLen = strlen(packetPtr->categoryName);
                        FWRITE_2(categoryNameLen, sizeof(int16_t), 1, file);
                        if (categoryNameLen > 0 && categoryNameLen < EXT_STR_MAX_LEN)
                        {
                            FWRITE_Bytes(packetPtr->categoryName, categoryNameLen, 1, file);
                        }
                    }
                }
            }
            
        }
        
        gExtQueue.resetTailPos(tailIdx);
    }
    
}

