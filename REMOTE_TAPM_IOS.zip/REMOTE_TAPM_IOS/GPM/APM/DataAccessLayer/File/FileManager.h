//
//  FileManager.h
//  LearnOpenGLESWithGPUImage
//
//  Created by xiang lin on 15/12/2017.
//  Copyright © 2017 xiang All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FileManager : NSObject

@property (nonatomic,copy) NSString* cacheFileName;

@property (nonatomic,copy) NSString* cacheDirectoryPath;

+ (FileManager*)sharedFileManager;

- (BOOL)flushBufferToFile:(const char*)srcBuffer bufferLen:(NSUInteger)bufferLen;

- (NSString*)constructCachePath:(NSString*)fileName;

- (BOOL)createCacheFileName:(NSString*)cacheFileName;

- (NSArray*)showAllUnUploadCachedFile;

- (BOOL)uploadToServer:(NSString*)cacheFileName;

- (void)removeFilePath:(NSString *)filePath;

- (void)closeFilePtr;

@end
