//
//  FileManager.m
//  LearnOpenGLESWithGPUImage
//
//  Created by xiang lin on 15/12/2017.
//  Copyright © 2017 xiang All rights reserved.
//
//#import <TDataMaster/ITDataMaster.h>
//#import <TDataMaster/TDataMasterApplication.h>
#include <zlib.h>
#import <pthread.h>
#import "SDKHeader.h"
#import "SDKBuf.h"
#import "SDKHelper.h"
#import "TApmPB.h"
#import "ReportTDM.h"
#import "TApmLog.h"

#define MIN_CACHE_FILE_LEN       10
#define MAX_BUFFER_SZ            (64 * 1024)
#define MAX_UPLOAD_ZIP_LEN       (2 * 1024 * 1024)
#define MAX_CACHE_FILE_LEN       (20 * 1024 * 1024)

using namespace TAPMIOS_SDKBuf;
using namespace SDKHelper;

@interface FileManager()
{
    BOOL            _isCreateDirectory;
    BOOL            _isCreateCacheFile;
    BOOL            _isCreateZipFile;
    FILE*           _dstFilePtr;
}


@end

static FileManager* singleInstance = nil;

@implementation FileManager

+ (FileManager*)sharedFileManager
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        singleInstance = [[[self class] alloc] init];
        
    });
    
    return singleInstance;
}

- (instancetype)init
{
    if (self = [super init])
    {
         NSError*    error;
        
        _isCreateDirectory = NO;
        _isCreateCacheFile = NO;
        _isCreateZipFile = NO;
        _dstFilePtr = NULL;
        _cacheDirectoryPath = [kLibraryCachePath stringByAppendingString:kCacheDirectoryName];
        if (_cacheDirectoryPath && ![kFileManagerDefault fileExistsAtPath:_cacheDirectoryPath])
        {
            _isCreateDirectory = [kFileManagerDefault createDirectoryAtPath:_cacheDirectoryPath withIntermediateDirectories:YES attributes:nil error:&error];
        }
        else if([kFileManagerDefault fileExistsAtPath:_cacheDirectoryPath])
        {
            _isCreateDirectory = YES;
        }
        
        [self clearAllZipFile];
    }

    return self;
}

- (NSString*)constructCachePath:(NSString*)fileName
{
    APMSDKAssert(fileName != nil, @"fileName is empty");
    if (fileName == nil || _cacheDirectoryPath == nil || !_isCreateDirectory) return nil;
    return  [self.cacheDirectoryPath stringByAppendingString:[NSString stringWithFormat:@"/%@",fileName]];
}

- (NSArray*)showAllUnUploadCachedFile
{
    NSArray*                    localCacheFiles;
    NSError*                    error;
    
    localCacheFiles = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:self.cacheDirectoryPath error:&error];
    APMSDKAssert(error == NULL, @"contentsOfDirectoryAtPath error");
    
    return localCacheFiles;
}


- (BOOL)flushBufferToFile:(const char*)srcBuffer bufferLen:(NSUInteger)bufferLen
{
    if (bufferLen > 0 && _dstFilePtr != NULL)
    {
        fseek(_dstFilePtr, 0, SEEK_END);
        try
        {
            fwrite(srcBuffer, 1, bufferLen, _dstFilePtr);
        }
        catch (NSException* e)
        {
            APMSDKAssert(NO, @"write to file error");
            return NO;
        }
        
        return YES;
    }
  
    return NO;
}

- (BOOL)createCacheFileName:(NSString*)cacheFileName
{
    NSString*                cacheFilePath;
    
    if (cacheFileName)
    {
        cacheFilePath = [self constructCachePath:cacheFileName];
        if(cacheFilePath && ![kFileManagerDefault fileExistsAtPath:cacheFilePath])
        {
           return [kFileManagerDefault createFileAtPath:cacheFilePath contents:nil attributes:nil];
        }
    }
    
    return NO;
}

- (BOOL)uploadToServer:(NSString*)cacheFileName
{

    NSString*                 cacheFilePath;
    unsigned long long        fileSize;
    NSError*                  error;
    const char*               srcCPath = NULL;
    const char*               destCPath = NULL;
    NSString*                 destPath;
    //FILE*                     destZipFile;
    uint64_t                  zipFileSize;
    
    if (cacheFileName)
    {
        cacheFilePath = [self constructCachePath:cacheFileName];
        if (cacheFilePath == nil) return NO;
        if ([kFileManagerDefault fileExistsAtPath:cacheFilePath])
        {
            fileSize = [[kFileManagerDefault attributesOfItemAtPath:cacheFilePath error:&error] fileSize];
            APMSDKAssert(error == nil, @"fileSize attributesOfItemAtPath error");
            if (fileSize > MIN_CACHE_FILE_LEN && fileSize < MAX_CACHE_FILE_LEN)
            {
                srcCPath = [cacheFilePath UTF8String];
                if (srcCPath != NULL)
                {
                    NSString* zipFile = [NSString stringWithFormat:@"%@%@.data",kPrefixZipFileName,SDKUtill::getCurrentFullTime()];
                    destPath = [self constructCachePath:zipFile];
                    BOOL ret = [self createCacheFileName:zipFile];
                    if (ret)
                    {
                        if(destPath != nil) destCPath = [destPath UTF8String];
                        if ([self segmentZip:srcCPath desPath:destCPath])
                        {
                            zipFileSize = [[kFileManagerDefault attributesOfItemAtPath:destPath error:&error] fileSize];
                            if (zipFileSize == 0) return NO;
                            //APM_LOG_DEBUG(@"compressed success,压缩前：%@,压缩后：%@",@(fileSize),@(zipFileSize));
                            if (zipFileSize > MAX_UPLOAD_ZIP_LEN)
                            {
                                [self removeFilePath:cacheFilePath];
                                [self removeFilePath:destPath];
                                return NO;
                            }
                            else
                            {
                                int sendLen = 0;
                                char* sendBuffer = (char*)TAPM_PB::g_apm_pb_malloc_apm_data(destCPath,sendLen);
                                //test
                               /*{
                                    NSData* testData = [NSData dataWithBytes:sendBuffer length:sendLen];
                                    [testData writeToFile:[self createZipFile:[NSString stringWithFormat:@"%@%@_test.data",kPrefixZipFileName,@(count++)]] atomically:YES];
                                }*/
                                if (sendBuffer)
                                {
                                    //TDM::ITDataMaster::GetInstance() -> SetLogLevel(TDM::kLogWarning);
                                    //TDM::ITDataMaster::GetInstance() -> ReportBinary(10008, "APM_SDK_PERF", sendBuffer,sendLen);
                                    GCloud::APM::ReportBinaryByTDM(10008, "APM_SDK_PERF", sendBuffer, sendLen);
                                    APM_LOG_EVENT(@"file send successfully");
                                }
                                TAPM_PB::g_apm_pb_safe_free(sendBuffer);
                                [self removeFilePath:cacheFilePath];
                                [self removeFilePath:destPath];
                                
                                return YES;
                            }
                        }
                        else
                        {
                            APM_LOG_DEBUG(@"compress failture");
                        }
                        
                    }
                }
            }
            else
            {
                [self removeFilePath:cacheFilePath];
            }
        }
    }
    
    return NO;
}

-(BOOL)segmentZip:(const char*)srcPath desPath:(const char*)dstPath
{
    if(dstPath == NULL || srcPath == NULL) return false;
    FILE* dstFile = fopen(dstPath, "wb+");
    if(dstFile == NULL)
    {
        APMSDKLog(@"cannot open dstpath :%@",[NSString stringWithUTF8String:dstPath]);
        return false;
    }
    
    FILE* srcFile = fopen(srcPath, "rb");
    if(srcFile == NULL)
    {
        APMSDKLog(@"cannot open srcpath :%@",[NSString stringWithUTF8String:srcPath]);
        fclose(dstFile);
        return false;
    }
    
    fseek(srcFile, 0 ,SEEK_END);
    long fileSz = ftell(srcFile);
    fseek(srcFile, 0 ,SEEK_SET);
    
    long consumed = 0;
    char* buffer = new char[MAX_BUFFER_SZ];
    char* zipOut = new char[MAX_BUFFER_SZ + 128];
    if (buffer == NULL || zipOut == NULL) return NO;
    do{
        memset(buffer, 0, MAX_BUFFER_SZ);
        memset(zipOut, 0, MAX_BUFFER_SZ + 128);
        size_t tmpSz = fread(buffer, 1, MAX_BUFFER_SZ - 1, srcFile);
        size_t outSz = MAX_BUFFER_SZ + 128;
        if(ABase::compress2((Bytef*)zipOut, &outSz, (const Bytef*)buffer, tmpSz, Z_DEFAULT_COMPRESSION) != Z_OK)
        {
            APMSDKAssert(false, @"zip compress error!");
            delete [] buffer;
            delete [] zipOut;
            fflush(dstFile);
            fclose(dstFile);
            fclose(srcFile);
            return NO;
        }
        fwrite(&outSz, 4, 1, dstFile);
        fwrite(zipOut, 1, outSz, dstFile);
        consumed += tmpSz;
    }while(consumed < fileSz);
    
    delete [] buffer;
    delete [] zipOut;
    
    fflush(dstFile);
    fclose(dstFile);
    fclose(srcFile);
    
    return true;
}

- (void)setCacheFileName:(NSString *)cacheFileName
{
    NSString*                 cacheFilePath;
    
    if (cacheFileName)
    {
        cacheFilePath = [self constructCachePath:cacheFileName];
        if (cacheFilePath == nil) return;
        if (![kFileManagerDefault fileExistsAtPath:cacheFilePath])
        {
            _isCreateCacheFile = [kFileManagerDefault createFileAtPath:cacheFilePath contents:nil attributes:nil];
            if (!_isCreateCacheFile) return;
            APM_LOG_DEBUG(@"create cacheFile:%@",cacheFilePath);
        }
        _dstFilePtr = fopen([cacheFilePath UTF8String], "wb+");
        if (_dstFilePtr == NULL)
        {
            APM_LOG_DEBUG(@"cannot open cacheFilePath :%@",cacheFilePath);
        }
        
    }
}

#pragma mark setter getter


- (void)removeFilePath:(NSString *)filePath
{
    NSError*            error;

    if (filePath)
    {
        if ([kFileManagerDefault fileExistsAtPath:filePath])
        {
            BOOL ret = [kFileManagerDefault removeItemAtPath:filePath error:&error];
            if (ret)
            {
                //APM_LOG_DEBUG(@" remove file success:%@",filePath);
            }
        }
    }
}

-(void)clearAllZipFile
{
    NSArray*            localCacheFiles;
    NSString*           zipFilePath;
    NSString*           cacheFileName;
    
    localCacheFiles = [self showAllUnUploadCachedFile];
    if (localCacheFiles && localCacheFiles.count > 0)
    {
        for (cacheFileName in localCacheFiles)
        {
            if (cacheFileName && [cacheFileName hasPrefix:kPrefixZipFileName])
            {
                zipFilePath = [self constructCachePath:cacheFileName];
                if (zipFilePath) [self removeFilePath:zipFilePath];
            }
        }
    }
}

- (void)closeFilePtr
{
    if (_dstFilePtr != NULL)
    {
        fclose(_dstFilePtr);
        _dstFilePtr = NULL;
    }
}




@end





