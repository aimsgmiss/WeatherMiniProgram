//
//  TApmGCloud.cpp
//  APM
//
//  Created by xiang lin on 2019/10/15.
//  Copyright © 2019 xianglin. All rights reserved.
//

#include "TApmGCloud.h"

#import "SDKStructEnumDefine.h"
#import "TApmLog.h"

namespace GCloud {
    namespace APM {
        
        static GCloud::IRemoteConfig* g_remote_config = NULL;
        
        IRemoteConfig* GetIRemoteConfig(){
            
            if (g_remote_config == NULL) {
                
                GCloud::Plugin::PluginBase*  pluginBase = PluginAPM::GetInstance();
                if(NULL==pluginBase){
                    APM_LOG_RELEASE(@"TApm GCloud init PluginBase error");
                    return NULL;
                }
                GCloud::Plugin::IPluginManager* pluginManager = pluginBase->GetPluginManager();
                if(NULL==pluginManager){
                    APM_LOG_RELEASE(@"TApm GCloud init IPluginManager error");
                    return NULL;
                }
                GCloud::Plugin::IPlugin* plugin = (GCloud::Plugin::IPlugin*)pluginManager->GetPluginByName(PLUGIN_NAME_GCLOUDCORE);
                if(NULL==plugin){
                    APM_LOG_RELEASE(@"TApm GCloud init IPlugin error");
                    return NULL;
                }
                
                GCloud::Plugin::IRemoteConfigService* remote_config_service = (GCloud::Plugin::IRemoteConfigService*)plugin->GetServiceByName(PLUGIN_SERVICE_NAME_REMOTECONFIG);
                if(NULL==remote_config_service){
                    APM_LOG_RELEASE(@"TApm GCloud init IReportService error");
                    return NULL;
                }
                
                g_remote_config = remote_config_service -> GetRemoteConfig(pluginBase);
                
                APM_LOG_RELEASE(@"TApm GCloud get remote config success");
            }
            
            return g_remote_config;
            
        }
    }
}
