//
//  GPMLifecycle.m
//  APM
//
//  Created by vincentwgao on 2018/9/12.
//  Copyright © 2018年 xianglin. All rights reserved.
//

#import "GPMLifecycle.h"
#import "PluginGPM.h"
#import "TApmLog.h"
@implementation GPMLifecycle
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    REGISTER_GCLOUD_PLUGIN(PluginGPM);
    APM_LOG_EVENT(@"GPMLifecycle didFinishLaunchingWithOptions");
    return YES;
}

- (BOOL)handleOpenURL:(NSURL *)url
{
    APM_LOG_DEBUG(@"GPMLifecycle handleOpenURL");
    return YES;
}

- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options
{
    APM_LOG_DEBUG(@"GPMLifecycle openURL");
    return YES;
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    APM_LOG_DEBUG(@"GPMLifecycle applicationDidEnterBackground");
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    APM_LOG_DEBUG(@"GPMLifecycle applicationWillEnterForeground");
}

- (void)applicationDidBecomeActive:(UIApplication*)application
{
    APM_LOG_DEBUG(@"GPMLifecycle applicationDidBecomeActive");
}

- (void)applicationWillResignActive:(UIApplication*)application
{
    APM_LOG_DEBUG(@"GPMLifecycle applicationWillResignActive");
}

- (void)applicationWillTerminate:(UIApplication*)application
{
    APM_LOG_DEBUG(@"GPMLifecycle applicationWillTerminate");
}

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application
{
    APM_LOG_DEBUG(@"GPMLifecycle applicationDidReceiveMemoryWarning");
}

- (void) application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    APM_LOG_DEBUG(@"GPMLifecycle didRegisterForRemoteNotificationsWithDeviceToken");
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error
{
    APM_LOG_DEBUG(@"GPMLifecycle didFailToRegisterForRemoteNotificationsWithError");
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler
{
    APM_LOG_DEBUG(@"GPMLifecycle didReceiveRemoteNotification");
}
@end
