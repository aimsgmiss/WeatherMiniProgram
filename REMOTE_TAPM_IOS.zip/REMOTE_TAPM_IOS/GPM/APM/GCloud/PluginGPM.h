//
//  PluginGPM.hpp
//  APM
//
//  Created by 雍鹏亮 on 2019/10/24.
//  Copyright © 2019 xianglin. All rights reserved.
//

#ifndef PluginGPM_hpp
#define PluginGPM_hpp


#include "PluginBase/PluginBase.h"


#ifdef ANDROID
#include <android/log.h>
#include "GPMLogger.h"
#endif

class PluginGPM: public GCloud::Plugin::Singleton<PluginGPM>, public GCloud::Plugin::PluginBase
{
public:
    
    virtual const char* GetName() const
    {
        return "GPMSDK";
    }
    
    virtual const char* GetVersion() const
    {
        return "GPM.x.x.x.x";
    }
    
    
public:
    virtual void OnStartup(GCloud::Plugin::IServiceRegister* serviceRegister)
    {
        
#ifdef ANDROID
        PRINT_E("PluginGPM OnStartup");
#endif
        
#ifdef __APPLE__
        NSLog(@"PluginGPM OnStartup");
#endif
        
        if (serviceRegister)
        {
            serviceRegister->Register("Frame");
            serviceRegister->Register("PhoneState");
        }
        else
        {
#ifdef ANDROID
            PRINT_E("GPMFrameService Registered failed");
#endif
            
#ifdef __APPLE__
            NSLog(@"GPMFrameService Registered failed");
#endif
        }
    }
    ;
    virtual void OnPostStartup()
    {
#ifdef ANDROID
        PRINT_E("PluginGPM OnPostStartup");
#endif
        
#ifdef __APPLE__
        NSLog(@"PluginGPM OnPostStartup");
#endif
    }
    ;
    
    virtual void OnPreShutdown()
    {
    }
    ;
    virtual void OnShutdown()
    {
    }
    ;
    
public:
    virtual GCloud::Plugin::IPluginService* GetServiceByName(const char* serviceName);
};


#endif /* PluginGPM_hpp */
