
//
//  PluginGPM.jni.cpp
//  APM
//
//  Created by 雍鹏亮 on 2019/10/24.
//  Copyright © 2019 xianglin. All rights reserved.
//

#ifdef ANDROID

#include <jni.h>
#include <android/log.h>

#include "PluginBase/PluginBase.h"
#include "PluginGPM.h"
#include "GPMLogger.h"

extern "C"
{
    jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) {
        
        PRINT_D("Enter JNI LOAD");
        JNIEnv* env = NULL;
        
        if (vm->GetEnv((void**) &env, JNI_VERSION_1_4) != JNI_OK) {
            return -1;
        }
        
        REGISTER_GCLOUD_PLUGIN(vm, PluginGPM);
        PRINT_D("REGISTER APM SERVICE");
        return JNI_VERSION_1_4;
    }
}

#endif
