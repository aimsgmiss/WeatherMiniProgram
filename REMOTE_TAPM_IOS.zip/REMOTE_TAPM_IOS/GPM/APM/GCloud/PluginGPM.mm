//
//  PluginGPM.m
//  APM
//
//  Created by 雍鹏亮 on 2019/10/24.
//  Copyright © 2019 xianglin. All rights reserved.
//

#include "PluginGPM.h"
#include "PluginBase/PluginBase.h"

#include <string.h>

GCloud::Plugin::IPluginService* PluginGPM::GetServiceByName(const char* serviceName)
{
    return NULL;
}
