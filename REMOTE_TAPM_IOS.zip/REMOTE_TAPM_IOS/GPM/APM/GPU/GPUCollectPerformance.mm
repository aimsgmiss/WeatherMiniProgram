//
//  GPUCollectPerformance.m
//  LearnOpenGLESWithGPUImage
//
//  Created by xiang lin on 25/12/2017.
//  Copyright © 2017 xiang. All rights reserved.
//

#import "GPUCollectPerformance.h"
#import "MessageQueue.h"
#import "SDKHeader.h"
#import "SDKHelper.h"

using namespace SDKHelper;

@implementation GPUCollectPerformance

-(void)startMonitor
{
    [super startMonitor];
}

-(void)collectionDatas
{
    DataPerSec          dataPerSec;
    
    if (!self.isCollectionData) return;
    [super collectionDatas];
    memset(&dataPerSec, 0, sizeof(DataPerSec));
    //dataPerSec.gpu1 = 0;
    //dataPerSec.gpu2 = 0;
    APMSDKLog(@"GPU pushMessageToGloabelBufferQueue");
    [[MessageQueue sharedInstance] pushMessageToGloabelBufferQueue:GamePerformanceDataType_GPU DataPerSec:dataPerSec isWriteToBuffer:YES];
}

-(void)stopMonitor
{
    [super stopMonitor];
}

@end
