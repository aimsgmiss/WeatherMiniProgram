
//#import "TdrTLV.h"
//#import "TdrError.h"
//#import "TdrTypeUtil.h"
#import "ReportTDM.h"
#import "StreamEvent.h"
#import "TApm_Mutex.h"
#import "TApmStreamEventCommitter.h"
#import "TApmStreamEventHandler.h"
#import "SDKStructEnumDefine.h"
#import "SDKHelper.h"
#import "FileManager.h"
#import "TApmLog.h"

#define kPreStepTimeKey     @"kPreStepTimeKey"

//using tsf4g_tdr::TdrTLVUtil;
//using tsf4g_tdr::TdrError;

#define CP_STR_SF(target,src,maxlen)            \
if((src) != NULL) \
{\
    strncpy( target, src, maxlen-2 );\
    target[ maxlen-1 ] = '\0';\
}


//extern dispatch_semaphore_t g_stream_event_commiter_semaphore;
extern NSMutableDictionary* g_streamEventCategoryMaps;

static void* streamEventProcessor(void* param);
static void* streamEventTimerThread(void* param);

TApmStreamEventHandler::TApmStreamEventHandler()
{
    mStreamEventQueuePtr = new GPM::MsgQueue<STREAM_EVENT>(256,false,"streamEventQueue");
    mThreadStatusQueuePtr = new GPM::MsgQueue<STREAM_EVENT_THREAD_STATUS>(8,false,"streamEventThreadExitQueue");
    mStepMap = [NSMutableDictionary dictionary];
    mSemState = dispatch_semaphore_create(0);
    
    pthread_t   stream_handler;
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    pthread_create(&stream_handler, &attr, &streamEventProcessor, (void*)this);
    
    //pthread_t   timer_handler;
    //pthread_create(&timer_handler, &attr, &streamEventTimerThread, (void*)this);
    
    mEnablePostMsg = true;
    //mEnableTimer = true;
    mPcommonInfo = TAPM_PB::g_apm_pb_get_common_info();
    
}

bool TApmStreamEventHandler::mStartUploadLocalStepEvent()
{
    
    NSArray* cacheFiles = [[FileManager sharedFileManager] showAllUnUploadCachedFile];
    if (cacheFiles && cacheFiles.count > 0)
    {
        for (NSString* cacheFileName in cacheFiles)
        {
            if (cacheFileName && [cacheFileName hasPrefix:kPrefixStreamEventFileName])
            {
                NSString* streamEventPath = [[FileManager sharedFileManager] constructCachePath:cacheFileName];
                NSData* data = [NSData dataWithContentsOfFile:streamEventPath];
                
                int sendLen = [data length];
                char* sendBuffer = (char*)[data bytes];
                if (sendLen > 0 && sendBuffer)
                {
                    APM_LOG_DEBUG(@"TApm_ios begin to report local step event binary from tdm len:%d",sendLen);
                    GCloud::APM::ReportBinaryByTDM(10008, "APM_SDK_STEP", sendBuffer, sendLen);
                }
                
                [[FileManager sharedFileManager] removeFilePath:streamEventPath];
            }
        }
    }
    
    return YES;
}


TApmStreamEventHandler::~TApmStreamEventHandler()
{
    TAPM_PB::g_apm_pb_safe_delete_common_info(mPcommonInfo);
    APMSDKSafeDelete(mStreamEventQueuePtr);
    APMSDKSafeDelete(mThreadStatusQueuePtr);
}

void TApmStreamEventHandler::mPostMsg(const char* eventCategory,int stepId, int status, int code, int networkType,const char* msg,const char* extDefinedKey)
{
    
    if (mStreamEventQueuePtr == NULL)
    {
        APM_LOG_DEBUG(@"TApm_ios step event msg queue is NULL");
        return;
    }
    
    APM_LOG_DEBUG(@"TApm_ios postStreamEvent stepId:%d status:%d code:%d msg:%s",stepId,status,code,msg);
    STREAM_EVENT se;
    
    if (!eventCategory)
    {
        eventCategory = kDefaultCStr;
    }
    se.eventCategory = strdup(eventCategory);
    
    se.stepCode = code;
    se.stepStatus = status;
    se.stepId = stepId;
    se.stepTime = time(NULL);
    se.networkType = networkType;
    se.stepRandom = rand() & 65535;
    
    if (!msg)
    {
        msg = kDefaultCStr;
    }
    se.stepMsg = strdup(msg);
    
    const char* sessionUUID = [SDKHelper::SDKUtill::sessionUUID UTF8String];
    if (!sessionUUID)
    {
        sessionUUID = kDefaultCStr;
    }
    se.sessionId = strdup(sessionUUID);
    
    const char* uniqueSessionUUID = [SDKHelper::SDKUtill::uniqueSessionUUID UTF8String];
    if (!uniqueSessionUUID)
    {
        uniqueSessionUUID = kDefaultCStr;
    }
    se.uniqueSessionId = strdup(uniqueSessionUUID);
    
    NSString* eventCategoryKey = [NSString stringWithUTF8String:eventCategory];
    if (!eventCategoryKey)
    {
        se.clear();
        APM_LOG_DEBUG(@"TApm_ios postMsg step event category key is nil");
        return;
    }
    
    NSDictionary* eventMaps = [g_streamEventCategoryMaps objectForKey:eventCategoryKey];
    if (!eventMaps)
    {
        se.clear();
        APM_LOG_DEBUG(@"TApm_ios postMsg step event category dictionary is nil");
        return;
    }
    
    NSMutableDictionary* eventMapsM = [NSMutableDictionary dictionaryWithDictionary:eventMaps];
    if(eventMapsM)
    {
        id preStepTime = [eventMapsM objectForKey:kPreStepTimeKey];
        if (preStepTime)
        {
            time_t previousStepTime = [preStepTime integerValue];
            id stepTime = @(SDKHelper::SDKUtill::getCurrentTimeIntervalMillisecond());
            if (stepTime)
            {
                [eventMapsM setValue:stepTime forKey:kPreStepTimeKey];
                se.stepSpanTime = (int)([stepTime integerValue] - previousStepTime);
            }
            else
            {
                se.stepSpanTime = 0;
            }
        }
        else
        {
            id stepTime = @(SDKHelper::SDKUtill::getCurrentTimeIntervalMillisecond());
            if (stepTime)
            {
                [eventMapsM setValue:stepTime forKey:kPreStepTimeKey];
            }
            se.stepSpanTime = 0;
        }
        
        [g_streamEventCategoryMaps setObject:eventMapsM forKey:eventCategoryKey];
    }
    
    id linkSessionBool = [eventMapsM objectForKey:kStreamEventLinkSession];
    if (linkSessionBool && [linkSessionBool boolValue])
    {
        const char* preSessionIdCstr = NULL;
        if (SDKHelper::SDKUtill::linkSessionUUID)
        {
            preSessionIdCstr = [SDKHelper::SDKUtill::linkSessionUUID UTF8String];
        }
        else
        {
            preSessionIdCstr = sessionUUID;
        }
        
        if (preSessionIdCstr)
        {
            se.linkSessionId = strdup(preSessionIdCstr);
        }
    }
    else
    {
        se.linkSessionId = NULL;
    }
    
    if (!extDefinedKey)
    {
        extDefinedKey = kDefaultCStr;
    }
    se.extDefinedKey = strdup(extDefinedKey);
    
    mStreamEventQueuePtr -> postMsg(se);
    
    dispatch_semaphore_signal(mSemState);
}

void TApmStreamEventHandler::mNotifyAllStreamEventThreadExitProgram()
{
    if (mThreadStatusQueuePtr && mEnablePostMsg)
    {
        APM_LOG_DEBUG(@"TApm_ios step event all thread will exit program");
        STREAM_EVENT_THREAD_STATUS threadStatus;
        threadStatus.isThreadExit = true;
        mEnablePostMsg = false;
        mThreadStatusQueuePtr -> postMsg(threadStatus);
    }
    
    dispatch_semaphore_signal(mSemState);
}

bool TApmStreamEventHandler::mPackMsg(STREAM_EVENT& event, char* buffer, size_t maxSz,size_t& usedSz)
{
    if (!mPcommonInfo)
    {
        APM_LOG_DEBUG(@"TApm_ios mCommmon info is NULL");
        return false;
    }
    
    if(TAPM_PB::g_apm_pb_set_step_event_common_info(mPcommonInfo, event, buffer, maxSz, usedSz))
    {
        return true;
    }
    
    return false;
}

// ticker
//static void* streamEventTimerThread(void* param)
//{
//    TApmStreamEventHandler* seHandler = (TApmStreamEventHandler*) param;
//    if (!seHandler)
//    {
//        APM_LOG_DEBUG(@"TApm_ios timerThread step event handler is NULL");
//        return NULL;
//    }
//
//    while (YES)
//    {
//        @autoreleasepool
//        {
//            sleep(3);
//            dispatch_semaphore_signal(g_stream_event_commiter_semaphore);
//            if (!seHandler -> mEnableTimer)
//            {
//                APM_LOG_DEBUG(@"TApm_ios timer thread will exit program");
//                return NULL;
//            }
//        }
//    }
//}

static void streamEventConsumeAllMsg(TApmStreamEventHandler* seHandler)
{
    STREAM_EVENT se;
    
    while (seHandler -> mStreamEventQueuePtr -> consumeMsgOnce(se))
    {
        char tmpBuffer[2048];
        memset(tmpBuffer, 0, 2048);
        size_t usedSz = 0;
        
        bool packRet = seHandler -> mPackMsg(se, tmpBuffer, sizeof(tmpBuffer), usedSz);
        if (!packRet)
        {
            APM_LOG_DEBUG(@"TApm_ios pb pack step event msg error");
            se.clear();
            continue;
        }
        
        NSData* data = [NSData dataWithBytes:tmpBuffer length:usedSz];
        if (!data)
        {
            APM_LOG_DEBUG(@"TApm_ios pack NSdata data with bytes error");
            se.clear();
            continue;
        }
        
        NSString* streamEventFile = [NSString stringWithFormat:@"%@%@",kPrefixStreamEventFileName,SDKHelper::SDKUtill::getCurrentFullTime()];
        NSString* streamEventFilePath = [[FileManager sharedFileManager] constructCachePath:streamEventFile];
        
        int tryCount = 5;
        do{
            BOOL ret = [data writeToFile:streamEventFilePath atomically:YES];
            if (ret)
            {
                APM_LOG_DEBUG(@"TApm_ios step event write success:%@",streamEventFile);
                break;
            }
            else
            {
                APM_LOG_DEBUG(@"TApm_ios write step event to file path failture:%@ will rewrite again",streamEventFilePath);
            }
            sleep(2);
        } while (tryCount-- > 0);
        
        if (streamEventFilePath && data)
        {
            APM_LOG_DEBUG(@"TApm_ios begin to report step event binary from tdm len:%zu",usedSz);
         
            GCloud::APM::ReportBinaryByTDM(10008, "APM_SDK_STEP", (char*)data.bytes, usedSz);
            //remove local step event file
            [[FileManager sharedFileManager] removeFilePath:streamEventFilePath];
            
        }
        
        // free previously malloc memmory
        se.clear();
    }
    
    se.clear();
}

static void* streamEventProcessor(void* param)
{
    sleep(5);
    
    TApmStreamEventHandler* seHandler = (TApmStreamEventHandler*) param;
    if (!seHandler)
    {
        APM_LOG_DEBUG(@"TApm_ios streamEventProcessor step event handler is NULL");
        return NULL;
    }
    
    seHandler -> mStartUploadLocalStepEvent();
    while (true)
    {
        @autoreleasepool
        {
            dispatch_semaphore_wait(seHandler -> mSemState, DISPATCH_TIME_FOREVER);
            
            streamEventConsumeAllMsg(seHandler);
            
            STREAM_EVENT_THREAD_STATUS threadStatus;
            // notify close all step event thread
            while (seHandler -> mThreadStatusQueuePtr -> consumeMsgOnce(threadStatus))
            {
                if (threadStatus.isThreadExit)
                {
                    // clear all queue msg data
                    streamEventConsumeAllMsg(seHandler);
                    
                    APM_LOG_DEBUG(@"TApm_ios step event handler thread will exit program");
                    return NULL;
                    
                }
            }
        }
    }
    
    return NULL;
}
