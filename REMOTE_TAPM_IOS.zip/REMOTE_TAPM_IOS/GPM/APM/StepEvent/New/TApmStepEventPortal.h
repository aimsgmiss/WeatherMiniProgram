//
//  TApmStepEventPortal.h
//  APM
//
//  Created by 雍鹏亮 on 2019/12/30.
//  Copyright © 2019 xianglin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TApmSessionState.h"

NS_ASSUME_NONNULL_BEGIN

@interface TApmStepEventPortal : NSObject

- (instancetype)initWithSessionState:(TApmSessionState *)sessionState;

- (void)postStepEventWithEventCategory:(NSString *)eventCategory stepId:(NSInteger)stepId status:(NSInteger)status code:(NSInteger)code
                                   msg:(NSString *)msg extDefinedKey:(NSString *)extDefinedKey;

- (void)linkSessionWithCategory:(NSString *)category;


- (void)asynSendStartStepEvent;

@end

NS_ASSUME_NONNULL_END



