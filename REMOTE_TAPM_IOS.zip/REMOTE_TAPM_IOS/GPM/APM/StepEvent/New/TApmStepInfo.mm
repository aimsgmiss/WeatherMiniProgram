//
//  TApmStepInfo.m
//  APM
//
//  Created by 雍鹏亮 on 2019/12/30.
//  Copyright © 2019 xianglin. All rights reserved.
//

#import "TApmStepInfo.h"

@implementation TApmStepInfo

- (instancetype)init{
    if (self = [super init]) {
        [self reset];
    }
    return self;
}

- (void)reset{
    self.isFinishedEvent = NO;
    self.isLinked = NO;
    
    self.eventCategory = @"_DEFAULT_";
    self.stepId = 0;
    self.stepStatus = 0;
    self.stepCode = 0;
    self.stepMsg = @"";
    self.networkType = 0;
    self.stepTime = 0;
    self.stepSpanTime = 0;
    self.stepRandom = 0;
    self.sessionId = @"";
    self.uniqueSessionId = @"";
    self.extDefinedKey = @"";
    self.linkedSessionId = @"";
}

- (STREAM_EVENT)translateToSTREAM_EVENT{
    
      STREAM_EVENT se;
      const char* eventCategory = self.eventCategory.UTF8String;
      if (eventCategory) {
          se.eventCategory = strdup(eventCategory);
      }
     
      se.stepId = (int)self.stepId;
      se.stepStatus = (int)self.stepStatus;
      se.stepCode = (int)self.stepCode;
      const char* stepMsg = self.stepMsg.UTF8String;
      if (stepMsg) {
         se.stepMsg = strdup(stepMsg);
      }
      se.networkType = (int)self.networkType;
      se.stepTime = self.stepTime;
      se.stepRandom = (int)self.stepRandom;
      
      const char* sessionId = self.stepMsg.UTF8String;
      if (sessionId) {
          se.sessionId = strdup(sessionId);
      }
      const char* uniqueSessionId = self.uniqueSessionId.UTF8String;
      if (uniqueSessionId) {
          se.uniqueSessionId = strdup(uniqueSessionId);
      }

      const char* linkSessionId = self.linkedSessionId.UTF8String;
      if (linkSessionId) {
          se.linkSessionId = strdup(linkSessionId);
      }
      
      const char* extDefinedKey = self.extDefinedKey.UTF8String;
      if (extDefinedKey) {
          se.extDefinedKey = strdup(extDefinedKey);
      }
     
      se.stepSpanTime = self.stepSpanTime;
      
      return se;
}

@end
