//
//  TApmStepEventProcessor.h
//  APM
//
//  Created by 雍鹏亮 on 2019/12/30.
//  Copyright © 2019 xianglin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TApmStepInfoQueue.h"
#import "TApmSessionState.h"

NS_ASSUME_NONNULL_BEGIN

@interface TApmStepEventProcessor : NSObject


- (instancetype)initWithStepInfoQueue:(TApmStepInfoQueue *)stepInfoQueue processSemaphore:(dispatch_semaphore_t)processSemaphore
                         sessionState:(TApmSessionState *)sessionState;

- (void)startProcess;

+ (void)packetAndSendByTDM:(TApmStepInfo *)stepInfo;

@end

NS_ASSUME_NONNULL_END
