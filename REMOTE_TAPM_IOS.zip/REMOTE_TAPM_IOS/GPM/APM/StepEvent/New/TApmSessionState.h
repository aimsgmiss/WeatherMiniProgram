//
//  TApmSessionState.h
//  APM
//
//  Created by 雍鹏亮 on 2019/12/30.
//  Copyright © 2019 xianglin. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TApmSessionState : NSObject

@property(readonly, strong, nonatomic)NSString *sessionId;
@property(readonly, strong, nonatomic)NSString *uniqueSessionId;
@property(readonly, strong, nonatomic)NSString *linkedSessionId;

@end

NS_ASSUME_NONNULL_END
