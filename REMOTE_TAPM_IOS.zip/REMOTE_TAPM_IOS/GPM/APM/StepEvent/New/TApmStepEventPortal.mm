//
//  TApmStepEventPortal.m
//  APM
//
//  Created by 雍鹏亮 on 2019/12/30.
//  Copyright © 2019 xianglin. All rights reserved.
//

#import "TApmStepEventPortal.h"
#import "TApmStepInfoQueue.h"
#import "TApmStepEventProcessor.h"
#import "TApmLog.h"
#import "NetworkCollectPerformance.h"
#import <sys/time.h>
#import <SDKHelper.h>

@interface TApmStepEventPortal()

@property(nonatomic, strong)TApmStepInfoQueue *bufferedEventQueue;
@property(nonatomic, strong)dispatch_semaphore_t processSemaphore;
@property(nonatomic, strong)TApmStepEventProcessor *streamEventProcessor;
@property(nonatomic, strong)NSMutableDictionary<NSString *, NSNumber *> *stepSpanTimeDic;
@property(nonatomic, strong)TApmSessionState *sessionState;

@end

@implementation TApmStepEventPortal

- (instancetype)initWithSessionState:(TApmSessionState *)sessionState{
    if (self = [self init]) {
        self.bufferedEventQueue = [[TApmStepInfoQueue alloc] init];
        self.processSemaphore = dispatch_semaphore_create(0);
        self.streamEventProcessor = nil;
        self.stepSpanTimeDic = [NSMutableDictionary dictionary];
        self.sessionState = sessionState;
    }
    return self;
}

- (void)postStepEventWithEventCategory:(NSString *)eventCategory stepId:(NSInteger)stepId status:(NSInteger)status code:(NSInteger)code
                                   msg:(NSString *)msg extDefinedKey:(NSString *)extDefinedKey{
    if (!self.streamEventProcessor) {
        self.streamEventProcessor = [[TApmStepEventProcessor alloc] initWithStepInfoQueue:self.bufferedEventQueue processSemaphore:self.processSemaphore sessionState:self.sessionState];
        [self.streamEventProcessor startProcess];
    }
    
    if (!eventCategory) {
        APM_LOG_DEBUG(@"EventCategory is nil");
        return;
    }
    
    if (!msg || !msg.length) {
        msg = @"NA";
    }
    
    if (!extDefinedKey || !extDefinedKey.length) {
        extDefinedKey = @"NA";
    }
    
    TApmStepInfo *tempStepEvent = [[TApmStepInfo alloc] init];
    tempStepEvent.eventCategory = eventCategory;
    tempStepEvent.stepId = stepId;
    tempStepEvent.stepStatus = status;
    tempStepEvent.stepCode = code;
    tempStepEvent.stepMsg = msg;
    tempStepEvent.extDefinedKey = extDefinedKey;
    tempStepEvent.stepTime = (int64_t)([[NSDate date] timeIntervalSince1970] * 1000);//timeIntervalSince1970 获取的是一个double类型的以秒为单位的时间戳
    {
        NSNumber *lastStepTimeNum = self.stepSpanTimeDic[eventCategory]; //mStepSpanTimeMap.get(eventCategory);
        if (lastStepTimeNum) {
            tempStepEvent.stepSpanTime = (int32_t)(tempStepEvent.stepTime - lastStepTimeNum.longLongValue);
        }else{
            tempStepEvent.stepSpanTime = 0;
        }
        self.stepSpanTimeDic[eventCategory] = @(tempStepEvent.stepTime);
    }
    
    tempStepEvent.stepRandom = rand() & 65535;
    [self.bufferedEventQueue pushStepInfo:tempStepEvent];
    dispatch_semaphore_signal(self.processSemaphore);
}

- (void)linkSessionWithCategory:(NSString *)category{
    TApmStepInfo *tempStepEvent = [[TApmStepInfo alloc] init];
    tempStepEvent.isLinked = YES;
    tempStepEvent.eventCategory = category;
    [self.bufferedEventQueue pushStepInfo:tempStepEvent];
    dispatch_semaphore_signal(self.processSemaphore);
}


- (void)asynSendStartStepEvent{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        TApmStepInfo *sdkStartStepInfo = [[TApmStepInfo alloc] init];
        
        sdkStartStepInfo.isLinked = NO;
        sdkStartStepInfo.isFinishedEvent = NO;
        sdkStartStepInfo.eventCategory = @"apm_startup";
        sdkStartStepInfo.stepId = 0;
        sdkStartStepInfo.stepStatus = 0;
        sdkStartStepInfo.stepCode = 0;
        sdkStartStepInfo.stepMsg = @"NA";
        sdkStartStepInfo.extDefinedKey = @"NA";
        sdkStartStepInfo.networkType = [[NetworkCollectPerformance sharedInstance] getNetworkType];
        sdkStartStepInfo.stepTime = (int64_t)([[NSDate date] timeIntervalSince1970] * 1000);//timeIntervalSince1970 获取的是一个double类型的以秒为单位的时间戳
        sdkStartStepInfo.stepSpanTime = 0;
        sdkStartStepInfo.stepRandom =  rand() & 65535;
        sdkStartStepInfo.sessionId = self.sessionState.sessionId;
        sdkStartStepInfo.uniqueSessionId = self.sessionState.uniqueSessionId;
        sdkStartStepInfo.linkedSessionId = self.sessionState.linkedSessionId;
        
        [TApmStepEventProcessor packetAndSendByTDM:sdkStartStepInfo];
    });
}

@end
