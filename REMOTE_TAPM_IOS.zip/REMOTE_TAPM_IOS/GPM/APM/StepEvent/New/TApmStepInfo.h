//
//  TApmStepInfo.h
//  APM
//
//  Created by 雍鹏亮 on 2019/12/30.
//  Copyright © 2019 xianglin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "StreamEvent.h"

NS_ASSUME_NONNULL_BEGIN

@interface TApmStepInfo : NSObject

@property(assign, nonatomic)BOOL isFinishedEvent;
@property(strong, nonatomic)NSString *eventCategory;
@property(assign, nonatomic)NSInteger stepId;
@property(assign, nonatomic)NSInteger stepStatus;
@property(assign, nonatomic)NSInteger stepCode;
@property(strong, nonatomic)NSString *stepMsg;
@property(assign, nonatomic)NSInteger networkType;
@property(assign, nonatomic)int64_t stepTime;
@property(assign, nonatomic)int32_t stepSpanTime;
@property(assign, nonatomic)NSInteger stepRandom;
@property(strong, nonatomic)NSString *sessionId;
@property(strong, nonatomic)NSString *linkedSessionId;
@property(strong, nonatomic)NSString *uniqueSessionId;
@property(strong, nonatomic)NSString *extDefinedKey;
@property(assign, nonatomic)BOOL isLinked;

- (void)reset;

- (STREAM_EVENT)translateToSTREAM_EVENT;

@end

NS_ASSUME_NONNULL_END
