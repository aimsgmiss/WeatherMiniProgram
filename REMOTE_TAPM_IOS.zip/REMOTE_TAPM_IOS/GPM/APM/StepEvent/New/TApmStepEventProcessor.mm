//
//  TApmStepEventProcessor.m
//  APM
//
//  Created by 雍鹏亮 on 2019/12/30.
//  Copyright © 2019 xianglin. All rights reserved.
//

#import "TApmStepEventProcessor.h"
#import "TApmStepInfoQueue.h"
#import "TApmSessionState.h"
#import "SDKHelper.h"
#import "TApmLog.h"
#import "StreamEvent.h"
#import "TApmPB.h"
#import "apmpb/protocolbuf/ApmProto.pbobjc.h"
#import "ReportTDM.h"

using namespace SDKHelper;

@interface TApmStepEventProcessor()

@property(nonatomic, strong)dispatch_semaphore_t processSemaphore;
@property(nonatomic, strong)TApmStepInfoQueue * stepEventQueue;
@property(nonatomic, strong)NSMutableDictionary<NSString *, NSNumber *> *linkSessionMap;
@property(nonatomic, strong)TApmSessionState *sessionState;

@end

@implementation TApmStepEventProcessor

- (instancetype)initWithStepInfoQueue:(TApmStepInfoQueue *)stepInfoQueue processSemaphore:(dispatch_semaphore_t)processSemaphore
                         sessionState:(TApmSessionState *)sessionState{
    if (self = [self init]) {
        self.processSemaphore = processSemaphore;
        self.stepEventQueue = stepInfoQueue;
        self.sessionState = sessionState;
        self.linkSessionMap = [NSMutableDictionary dictionary];
    }
    return self;
}

- (void)startProcess{
    NSThread *thread = [[NSThread alloc] initWithTarget:self selector:@selector(run) object:nil];
    [thread setName:@"StepEvent Processing Thread"];
    [thread start];
}

- (void)run{
    while (true) {
        @autoreleasepool {
            dispatch_semaphore_wait(self.processSemaphore, DISPATCH_TIME_FOREVER);
            
            TApmStepInfo *tempEvent = [self.stepEventQueue consumeStepEvent];
            if (!tempEvent){
                 continue;
            }

            if (tempEvent.isLinked) {
                APM_LOG_DEBUG(@"Link session: %@", tempEvent.eventCategory);
                if(tempEvent.eventCategory != nil && ![self.linkSessionMap.allKeys containsObject:tempEvent.eventCategory]){
                    self.linkSessionMap[tempEvent.eventCategory] = @(YES);
                }
                continue;
            }
            
            [self fillStepEvent:tempEvent isLinked:[self.linkSessionMap.allKeys containsObject:tempEvent.eventCategory]];
            [TApmStepEventProcessor packetAndSendByTDM:tempEvent];
        }
    }
}

- (void)fillStepEvent:(TApmStepInfo *)stepEvent isLinked:(BOOL)isLinked{
    stepEvent.networkType = SDKUtill::networkType;
    stepEvent.sessionId = self.sessionState.sessionId;
    stepEvent.uniqueSessionId = self.sessionState.uniqueSessionId;
    
    if (isLinked) {
        APM_LOG_DEBUG(@"Linked Session");
        stepEvent.linkedSessionId = self.sessionState.linkedSessionId;
        stepEvent.isLinked = YES;
    }
}

+ (void)packetAndSendByTDM:(TApmStepInfo *)stepInfo{
    static ApmCommonInfo* commonInfo = NULL;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        commonInfo = TAPM_PB::g_apm_pb_get_common_info();
    });
    
    STREAM_EVENT event = [stepInfo translateToSTREAM_EVENT];
    char tmpBuffer[2048];
    memset(tmpBuffer, 0, 2048);
    size_t usedSz = 0;
    bool setCommonInfoResult  = TAPM_PB::g_apm_pb_set_step_event_common_info(commonInfo, event, tmpBuffer, sizeof(tmpBuffer), usedSz);
    if (!setCommonInfoResult) {
        APM_LOG_DEBUG(@"TApm_ios pb pack step event msg error");
        event.clear();
        return;
    }
    
    NSData* data = [NSData dataWithBytes:tmpBuffer length:usedSz];
    if (!data){
        APM_LOG_DEBUG(@"TApm_ios pack NSdata data with bytes error");
        event.clear();
        return;
    }
    
    GCloud::APM::ReportBinaryByTDM(10008, "APM_SDK_STEP", (char*)data.bytes, (int)usedSz);
    event.clear();
}

@end
