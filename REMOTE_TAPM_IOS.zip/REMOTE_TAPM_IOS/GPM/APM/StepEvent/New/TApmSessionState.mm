//
//  TApmSessionState.m
//  APM
//
//  Created by 雍鹏亮 on 2019/12/30.
//  Copyright © 2019 xianglin. All rights reserved.
//

#import "TApmSessionState.h"
#import "SDKHelper.h"

@implementation TApmSessionState

- (NSString *)sessionId{
    return SDKHelper::SDKUtill::sessionUUID;
}

- (NSString *)uniqueSessionId{
    return SDKHelper::SDKUtill::uniqueSessionUUID;
}

- (NSString *)linkedSessionId{
    return SDKHelper::SDKUtill::linkSessionUUID;
}

@end
