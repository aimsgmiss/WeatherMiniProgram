//
//  StepInfoQueue.m
//  APM
//
//  Created by 雍鹏亮 on 2019/12/30.
//  Copyright © 2019 xianglin. All rights reserved.
//

#import "TApmStepInfoQueue.h"
#import "TApmLog.h"

@interface TApmStepInfoQueue()

@property(nonatomic, strong)NSMutableArray<TApmStepInfo *> *stepInfoArray;
@property(nonatomic, strong)NSLock *lock;

@end

@implementation TApmStepInfoQueue

- (instancetype)init{
    if (self = [super init]) {
        self.stepInfoArray = [NSMutableArray array];
        self.lock = [[NSLock alloc] init];
    }
    return self;
}

- (BOOL)pushStepInfo:(TApmStepInfo *)stepInfo{
    if (!stepInfo) {
        APM_LOG_DEBUG(@"Push TApmStepInfo is nil");
        return NO;
    }
    [self.lock lock];
    [self.stepInfoArray addObject:stepInfo];
    [self.lock unlock];
    return YES;
}

- (TApmStepInfo *)consumeStepEvent{
    if (self.isQueueEmpty) {
        return nil;
    }
    
    [self.lock lock];
    TApmStepInfo *first = [self.stepInfoArray firstObject];
    [self.stepInfoArray removeObject:first];
    [self.lock unlock];
    return first;
}

- (BOOL)isQueueEmpty{
    [self.lock lock];
    BOOL isEmpty = self.stepInfoArray.count == 0;
    [self.lock unlock];
    return isEmpty;
}

@end
