//
//  StepInfoQueue.h
//  APM
//
//  Created by 雍鹏亮 on 2019/12/30.
//  Copyright © 2019 xianglin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TApmStepInfo.h"

NS_ASSUME_NONNULL_BEGIN

@interface TApmStepInfoQueue : NSObject

- (BOOL)pushStepInfo:(TApmStepInfo *)stepInfo;
- (nullable TApmStepInfo *)consumeStepEvent;
- (BOOL)isQueueEmpty;

@end

NS_ASSUME_NONNULL_END
