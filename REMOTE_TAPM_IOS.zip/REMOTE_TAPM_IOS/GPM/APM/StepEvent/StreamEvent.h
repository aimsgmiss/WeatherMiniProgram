
#ifndef STREAMEVENT_H_
#define STREAMEVENT_H_

#import <time.h>
#import <string.h>
#import "SDKStructEnumDefine.h"

struct STREAM_EVENT
{
    char*   eventCategory;
	int     stepId;
	int     stepStatus;
	int     stepCode;
    char*   stepMsg;
	int     networkType;
    int64_t  stepTime;
    int     stepRandom;
    char*   sessionId;
    char*   uniqueSessionId;
    char*   linkSessionId;
    char*   extDefinedKey;
    int     stepSpanTime;

	STREAM_EVENT()
	{
        memset(this, 0, sizeof(STREAM_EVENT));
	}
    
    void clear()
    {
        APMSDKSafeFree(this -> eventCategory);
        APMSDKSafeFree(this -> stepMsg);
        APMSDKSafeFree(this -> sessionId);
        APMSDKSafeFree(this -> uniqueSessionId);
        APMSDKSafeFree(this -> linkSessionId);
        APMSDKSafeFree(this -> extDefinedKey);
        memset(this, 0, sizeof(STREAM_EVENT));
    }
};

struct STREAM_EVENT_THREAD_STATUS
{
    bool    isThreadExit;
    
    STREAM_EVENT_THREAD_STATUS()
    {
        isThreadExit = false;
    }
};


//struct STREAM_EVENT_COMMITTER
//{
//    const char* filePath;
//    void*       data;
//    size_t      len;
//
//    STREAM_EVENT_COMMITTER()
//    {
//        memset(this, 0, sizeof(STREAM_EVENT_COMMITTER));
//    }
//
//    void clear()
//    {
//        APMSDKSafeFree(this -> filePath);
//        APMSDKSafeFree(this -> data);
//        memset(this, 0, sizeof(STREAM_EVENT_COMMITTER));
//    }
//
//};
#endif /* STREAMEVENT_H_ */
