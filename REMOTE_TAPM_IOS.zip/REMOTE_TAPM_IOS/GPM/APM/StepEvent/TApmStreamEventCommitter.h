//
//  TApmStreamEventCommiter.h
//  LearnOpenGLES
//
//  Created by vincentwgao on 2019/5/22.
//  Copyright © 2019年 xianglin. All rights reserved.
//

//#import <Foundation/Foundation.h>
//#import "MsgQueue.h"
//#import "StreamEvent.h"
//
//NS_ASSUME_NONNULL_BEGIN
//
//@interface TApmStreamEventCommitter : NSObject
//{
//    @public
//    // post a data to queue when thread exit program
//    //MsgQueue<STREAM_EVENT_THREAD_STATUS>* _threadStatusQueuePtr;
//    // data queue
//    MsgQueue<STREAM_EVENT_COMMITTER>* _committerMsgQueuePtr;
//    
//}
//
//+ (TApmStreamEventCommitter*)sharedInstance;
//
//- (void)startUploadStepEvent;
//@end
//
//NS_ASSUME_NONNULL_END
