
#ifndef STREAMEVENTPROCESSOR_H_
#define STREAMEVENTPROCESSOR_H_

#import "MsgQueue.h"
#import "StreamEvent.h"
#import "TApm_Mutex.h"
#import "SDKStructEnumDefine.h"
#import "TApmPB.h"
#import "apmpb/protocolbuf/ApmProto.pbobjc.h"

class TApmStreamEventHandler
{
    
public:
    
    dispatch_semaphore_t    mSemState;
    
    //bool                    mEnableTimer;
    
    bool                    mEnablePostMsg;
    
    GPM::MsgQueue<STREAM_EVENT>* mStreamEventQueuePtr;
    
    GPM::MsgQueue<STREAM_EVENT_THREAD_STATUS>* mThreadStatusQueuePtr;
    
    NSMutableDictionary*    mStepMap;
    
    ApmCommonInfo*          mPcommonInfo;
public:

    TApmStreamEventHandler();
    
    ~TApmStreamEventHandler();

public:
	
    bool mStartUploadLocalStepEvent();
    
    void mNotifyAllStreamEventThreadExitProgram();
    
    void mPostMsg(const char* eventCategory,int stepId, int status, int code, int networkType,const char* msg,const char* extDefinedKey);

	bool mPackMsg(STREAM_EVENT& event, char* buffer, size_t maxSz,size_t& usedSz);

};

#endif
