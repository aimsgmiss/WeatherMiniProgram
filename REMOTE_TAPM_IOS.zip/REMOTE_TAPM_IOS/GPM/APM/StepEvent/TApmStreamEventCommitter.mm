//
//  TApmStreamEventCommiter.m
//  LearnOpenGLES
//
//  Created by vincentwgao on 2019/5/22.
//  Copyright © 2019年 xianglin. All rights reserved.
//
//
////#import <TDataMaster/ITDataMaster.h>
//#import "TDataMasterApplication.h"
//#import <pthread.h>
//#import "TApmStreamEventCommitter.h"
////#import "UploadTaskSocket.h"
//#import "FileManager.h"
//#import "SDKStructEnumDefine.h"
//#import "SDKHelper.h"
////#import "ReportTDM.h"
////#import "TApmLog.h"
//@implementation TApmStreamEventCommitter
//
//static TApmStreamEventCommitter* sigleInstance = nil;
//
////extern dispatch_semaphore_t      g_stream_event_commiter_semaphore;
//
//-(instancetype)init
//{
//    if ((self = [super init]))
//    {
//
//        //[self performSelectorInBackground:@selector(startStreamEventCommitterThread) withObject:nil];
//
//        //_threadStatusQueuePtr = new MsgQueue<STREAM_EVENT_THREAD_STATUS>(8,false,"threadStatusQueueCommitter");
//
//        _committerMsgQueuePtr = new MsgQueue<STREAM_EVENT_COMMITTER>(256,false,"_committerMsgQueuePtr");
//
//       [self startUploadLocalStepEvent];
//    }
//
//    return self;
//}
//
//+ (TApmStreamEventCommitter*)sharedInstance
//{
//    static dispatch_once_t onceToken;
//    dispatch_once(&onceToken, ^{
//        sigleInstance = [[TApmStreamEventCommitter alloc] init];
//    });
//
//    return sigleInstance;
//}
//
// - (void)consumeQueueAllMsg
//{
//    STREAM_EVENT_COMMITTER sec;
//
//    if(!_committerMsgQueuePtr) return;
//
//    if (!_committerMsgQueuePtr -> hasMsg())
//    {
//        return;
//    }
//
//    while (_committerMsgQueuePtr -> consumeMsgOnce(sec))
//    {
//
//        if (sec.data && sec.len > 0)
//        {
//            NSLog(@"TApm_ios begin to report step event binary from tdm len:%zu",sec.len);
//            //GCloud::APM::ReportBinaryByTDM(10008, "APM_SDK_STEP", (char*)sec.data, sec.len);
//            //TDM::ITDataMaster::GetInstance() -> ReportBinary(10008, "APM_SDK_STEP", (char*)sec.data,sec.len);
//            [[TDataMasterApplication sharedInstance] reportBinaryWithSrcID:10008 eventName:"APM_SDK_STEP" data:(char*)sec.data andLen:sec.len];
//        }
//
//        if (sec.filePath)
//        {
//            //remove local step event file
//            [[FileManager sharedFileManager] removeFilePath:[NSString stringWithUTF8String:sec.filePath]];
//        }
//        sec.clear();
//    }
//
//    sec.clear();
//}
//
//- (void)startUploadStepEvent
//{
//    [self consumeQueueAllMsg];
//}
//
//
//- (BOOL)startUploadLocalStepEvent
//{
//
//    NSArray* cacheFiles = [[FileManager sharedFileManager] showAllUnUploadCachedFile];
//    if (cacheFiles && cacheFiles.count > 0)
//    {
//        for (NSString* cacheFileName in cacheFiles)
//        {
//            if (cacheFileName && [cacheFileName hasPrefix:kPrefixStreamEventFileName])
//            {
//                NSString* streamEventPath = [[FileManager sharedFileManager] constructCachePath:cacheFileName];
//                NSData* data = [NSData dataWithContentsOfFile:streamEventPath];
//
//                int sendLen = [data length];
//                char* sendBuffer = (char*)[data bytes];
//                if (sendLen > 0 && sendBuffer)
//                {
//                    NSLog(@"TApm_ios begin to report local step event binary from tdm len:%d",sendLen);
//
//                    [[TDataMasterApplication sharedInstance] reportBinaryWithSrcID:10008 eventName:"APM_SDK_STEP" data:sendBuffer andLen:sendLen];
//                    //TDM::ITDataMaster::GetInstance() -> ReportBinary(10008, "APM_SDK_STEP", sendBuffer,sendLen);
//                    //GCloud::APM::ReportBinaryByTDM(10008, "APM_SDK_STEP",sendBuffer,sendLen);
//                }
//
//                [[FileManager sharedFileManager] removeFilePath:streamEventPath];
//            }
//        }
//    }
//
//    return YES;
//}
//
//
//@end
