//
//  GPMThermalState.h
//  APM
//
//  Created by xiang lin on 2020/3/31.
//  Copyright © 2020 xianglin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MsgQueue.h"
#import "SDKStructEnumDefine.h"
NS_ASSUME_NONNULL_BEGIN

#pragma pack(push)
#pragma pack(1)

typedef struct _APMProcessInfoThermalState
{
    char        flag;
    int16_t     vlaue;
}APMProcessInfoThermalState;

#pragma pack (pop)

@interface APMThermalState : NSObject
{
    @public
    GPM::MsgQueue<APMProcessInfoThermalState>*      _msgQueuePtr;
}

@end

NS_ASSUME_NONNULL_END
