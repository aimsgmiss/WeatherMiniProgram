//
//  GPMThermalState.m
//  APM
//
//  Created by xiang lin on 2020/3/31.
//  Copyright © 2020 xianglin. All rights reserved.
//

#import "APMThermalState.h"
#import "TApmLog.h"
#import "SDKHelper.h"

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunguarded-availability-new"
@interface APMThermalState()

@end

@implementation APMThermalState

- (instancetype)init{
    if (self = [super init]) {
        _msgQueuePtr = new GPM::MsgQueue<APMProcessInfoThermalState> (32, false,"sThermalSateQueuePtr");
        if (SDKHelper::SDKUtill::currVersionDoub > 11.0) {
        APM_LOG_DEBUG(@"start thermal state monitor");
        #pragma clang diagnostic push
        #pragma clang diagnostic ignored "-Wunused-variable"
        NSProcessInfoThermalState state = [NSProcessInfo processInfo].thermalState;
        #pragma clang diagnostic pop
        [[NSNotificationCenter defaultCenter] addObserverForName:NSProcessInfoThermalStateDidChangeNotification object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
            
            APMProcessInfoThermalState      thermalState;
            thermalState.flag = kThermalStatePrefixFlag;

            NSProcessInfoThermalState state = [[NSProcessInfo processInfo] thermalState];
            if (state == NSProcessInfoThermalStateNominal) {
              thermalState.vlaue = NSProcessInfoThermalStateNominal;
            }else if (state == NSProcessInfoThermalStateFair) {
            // Thermals are fair. Consider taking proactive measures to prevent higher thermals.
              thermalState.vlaue = NSProcessInfoThermalStateFair;
            } else if (state == NSProcessInfoThermalStateSerious) {
            // Thermals are highly elevated. Help the system by taking corrective action.
              thermalState.vlaue = NSProcessInfoThermalStateSerious;
            } else if (state == NSProcessInfoThermalStateCritical) {
            // Thermals are seriously elevated. Help the system by taking immediate corrective action.
              thermalState.vlaue = NSProcessInfoThermalStateCritical;
            } else {
              thermalState.vlaue = -1;
            // Thermals are okay. Go about your business.
            }
            if (_msgQueuePtr) {
              APM_LOG_DEBUG(@"thermal state did change value is :%d",thermalState.vlaue);
              _msgQueuePtr -> postMsg(thermalState);
            }
        }];
      }
    }
    return self;
}

-(void)dealloc{
    if (SDKHelper::SDKUtill::currVersionDoub > 11.0) {
        [[NSNotificationCenter defaultCenter] removeObserver:self];
    }
    APMSDKSafeDelete(_msgQueuePtr);
}
@end
#pragma clang diagnostic pop
