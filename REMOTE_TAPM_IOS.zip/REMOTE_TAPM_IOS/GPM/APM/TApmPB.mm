//
//  TApmPB.m
//  LearnOpenGLES
//
//  Created by vincentwgao on 2019/4/9.
//  Copyright © 2019年 xianglin. All rights reserved.
//
//#import <TDataMaster/ITDataMaster.h>
#import "TApmPB.h"
#import "SDKStructEnumDefine.h"
#import "ApmMetaInfoNetworkPack.h"
#import "ReportTDM.h"
#import "TApmLog.h"

namespace TAPM_PB
{
    ApmCommonInfo* g_apm_pb_get_common_info()
    {
        ApmCommonInfo*     pCommonInfo;
        
        pCommonInfo = [[ApmCommonInfo alloc] init];
        if (!pCommonInfo)
        {
            APM_LOG_DEBUG(@" pCommonInfo is NULL");
            return NULL;
        }
        
        if (kApmMetaInfoObj.szAppID)
        {
            [pCommonInfo setAppId:kApmMetaInfoObj.szAppID];
        }
        
        if (kApmMetaInfoObj.szUserID)
        {
            [pCommonInfo setUserId:kApmMetaInfoObj.szUserID];
        }
        
        if (kApmMetaInfoObj.szAppVersion)
        {
            [pCommonInfo setAppVsStr:kApmMetaInfoObj.szAppVersion];
        }
        
        if (kApmMetaInfoObj.szBuildVersion)
        {
            [pCommonInfo setAppVsCode:kApmMetaInfoObj.szBuildVersion];
           
        }
        
        if (kApmMetaInfoObj.szSystemVersion)
        {
            [pCommonInfo setOsLevel:kApmMetaInfoObj.szSystemVersion];
         
        }
        
        if (kApmMetaInfoObj.szCpuArch)
        {
            [pCommonInfo setCpuArch:kApmMetaInfoObj.szCpuArch];
            
        }
        
        if (kApmMetaInfoObj.szVendorUUID)
        {
            [pCommonInfo setVenderUuid:kApmMetaInfoObj.szVendorUUID];
         
        }
        
        NSString* gpu_version_str = [kSDKUserDefault objectForKey:kszGpuVersion];
        if (gpu_version_str)
        {
            [pCommonInfo setGpuVersion:gpu_version_str];
        }
        
        NSString* gpu_render_str = [kSDKUserDefault objectForKey:kszGpuRenderer];
        if (gpu_render_str)
        {
            [pCommonInfo setGpuRenderer:gpu_render_str];
        }
        
        if (kApmMetaInfoObj.szManu)
        {
            [pCommonInfo setManu:kApmMetaInfoObj.szManu];
        }
        
        if (kApmMetaInfoObj.szModel)
        {
            [pCommonInfo setModel:kApmMetaInfoObj.szModel];
        }
        
        [pCommonInfo setRandomSeed:kApmMetaInfoObj.randomSeed];
        
        [pCommonInfo setMac:kApmMetaInfoObj.ullMac];

        [pCommonInfo setImei:kApmMetaInfoObj.ullImei];
   
        [pCommonInfo setOsType:kApmMetaInfoObj.wOsType];
       
        [pCommonInfo setLaunchTime:kApmMetaInfoObj.tLaunchTime];
        
        [pCommonInfo setMem:kApmMetaInfoObj.dwMem];
      
        [pCommonInfo setCpuCore:kApmMetaInfoObj.dwCpuCore];
    
        [pCommonInfo setCpuFreq:0];
     
        [pCommonInfo setWFlashSize:kApmMetaInfoObj.wFlash_size];
   
        [pCommonInfo setWFlashSizeFree:kApmMetaInfoObj.wFlash_size_free];
        
        const char* tdmUidStr = GCloud::APM::GetTDMUID();
        if (tdmUidStr != NULL)
        {
            NSString* nsTdmUid = [NSString stringWithUTF8String:tdmUidStr];
            if (nsTdmUid) {
                APM_LOG_DEBUG(@"get tdm uid:%@",nsTdmUid);
                [pCommonInfo setSzAndroidId:nsTdmUid];
            }
        }
        
        return pCommonInfo;
    }

    bool g_apm_pb_set_step_event_common_info(ApmCommonInfo* pCommonInfo,STREAM_EVENT& event,char* buffer, size_t maxSz,size_t& usedSz)
    {
        if (!pCommonInfo)
        {
            APM_LOG_DEBUG(@"pb common info pCommonInfo is NULL");
            return false;
        }
   
        if (event.stepMsg)
        {
            NSString* stepMsg = [NSString stringWithUTF8String:event.stepMsg];
            if (stepMsg)
            {
                [pCommonInfo setSzStepInfo:stepMsg];
            }
        }
        
        if (event.eventCategory)
        {
            NSString* eventCategory = [NSString stringWithUTF8String:event.eventCategory];
            if (eventCategory)
            {
                [pCommonInfo setSzEventCategory:eventCategory];
            }
        }
        
        if (event.sessionId)
        {
            NSString* sessionId = [NSString stringWithUTF8String:event.sessionId];
            if (sessionId)
            {
                [pCommonInfo setSzSessionId:sessionId];
            }
        }
        
        if (event.uniqueSessionId)
        {
            NSString* uniqueSessionId = [NSString stringWithUTF8String:event.uniqueSessionId];
            if (uniqueSessionId)
            {
                [pCommonInfo setSzUniqueSessionId:uniqueSessionId];
            }
        }
        
        if (event.linkSessionId)
        {
            NSString* linkSessionId = [NSString stringWithUTF8String:event.linkSessionId];
            if (linkSessionId)
            {
                [pCommonInfo setSzLinkSessionId:linkSessionId];
            }
        }
        
        if (event.extDefinedKey)
        {
            NSString* extDefinedKey = [NSString stringWithUTF8String:event.extDefinedKey];
            if (extDefinedKey)
            {
                [pCommonInfo setSzExtDefinedKey:extDefinedKey];
            }

        }
        
        [pCommonInfo setIStepStatus:event.stepStatus];
        
        [pCommonInfo setDwStepId:event.stepId];
      
        [pCommonInfo setWNetworkType:event.networkType];
  
        [pCommonInfo setIStepCode:event.stepCode];
       
        [pCommonInfo setTStepTime:event.stepTime];
     
        [pCommonInfo setIStepSpanTime:event.stepSpanTime];
        
        [pCommonInfo setIStepRand:event.stepRandom];
        
        NSData* data = [pCommonInfo data];
        usedSz = [data length];
        if (usedSz > maxSz)
        {
            APM_LOG_DEBUG(@"common info buffer is too small");
            return false;
        }
        
        memcpy(buffer,(const char*)[data bytes] , usedSz);
       
        return true;
    }

    const char* g_apm_pb_malloc_apm_data(const char* file_path,int& send_len)
    {
       
        ApmCommonInfo*  pCommonInfo;
        ApmDataPb*      pApmDataPb;
        
        send_len = 0;
        if (!file_path)
        {
            APM_LOG_DEBUG(@"file_path is NULL");
            return NULL;
        }
        pApmDataPb = [[ApmDataPb alloc] init];
        
        if (!pApmDataPb)
        {
            APM_LOG_DEBUG(@"pApmDataPb is NULL");
            return NULL;
        }
        
        pCommonInfo = g_apm_pb_get_common_info();
        if (!pCommonInfo)
        {
            APM_LOG_DEBUG(@"pCommonInfo is NULL");
            return NULL;
        }
        
        [pApmDataPb  setInfo:pCommonInfo];
        
        NSData *contentData = [NSData dataWithContentsOfFile:[NSString stringWithUTF8String:file_path]];
        if (!contentData)
        {
            APM_LOG_DEBUG(@"contentData is nil");
            return NULL;
        }
        
        [pApmDataPb setBuff:contentData];
        
        NSData* apmData = [pApmDataPb data];
        send_len = apmData.length;
        
        char* send_buffer = (char*)malloc(send_len);
        if (!send_buffer)
        {
            APM_LOG_DEBUG(@"malloc send_buffer error");
            return NULL;
        }
        
        memcpy(send_buffer, (const char*)apmData.bytes,send_len);
    
        return send_buffer;
    }

    void g_apm_pb_safe_free(void* ptr)
    {
        if (ptr)
        {
            free(ptr);
            ptr = NULL;
        }
    }

    void g_apm_pb_safe_delete_common_info(ApmCommonInfo* pCommonInfo)
    {
        if (pCommonInfo)
        {
    
        }
    }
}

@implementation TApmPB

@end
