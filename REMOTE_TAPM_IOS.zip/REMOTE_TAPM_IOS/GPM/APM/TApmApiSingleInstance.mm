//
//  TApmApiInterClass.m
//  LearnOpenGLES
//
//  Created by vincentwgao on 2018/6/29.
//  Copyright © 2018年 . All rights reserved.
//

#import "TApmApiSingleInstance.h"
#import <pthread.h>
#import <UIKit/UIKit.h>
#import <sys/utsname.h>
#import <objc/runtime.h>
#import <sys/mount.h>
#import <time.h>
#import "SDKHeader.h"
#import "SDKStructEnumDefine.h"
#import "FileManager.h"
#import "SDKMsgQueue.h"
#import "SDKHelper.h"
#import <malloc/malloc.h>
//#import "StreamEventAuditMgr.h"
#import "TApmStreamEventCommitter.h"
#import "TApmStreamEventHandler.h"
//#import "TdrTypeUtil.h"
#import "SDKHttpRequest.h"
#import "FrameState.h"
#import "SDKStack.h"
#import "SDKIPC.h"
#import "MsgQueue.h"
#import "ExtValue.h"
#import "ReportTDM.h"
//using namespace APM_SPEC;
#import "zigzag.h"
//#import "TApmSwitch.h"
#import "TApmLog.h"
#import "DeviceInfoHelper.h"
#import "TApmStepEventPortal.h"
#import "TApmStepEventProcessor.h"
#import "APMCCStrategy.h"
//#import "GCloudCoreGPM.h"
#import "SDKMMapWriterBuffer.h"
#import "APMThermalState.h"

#define kRandomDataUrlStr           @"https://cdn.wetest.qq.com/cube/com/apmcc/TAPM_IOS_"
#define kDeviceLevelUrlStr          @"https://cdn.wetest.qq.com/cube/com/apmcc/QCC_IOS_"

#define kUserID                     @"kUserID"
#define kLocal                      @"kLocal"
#define kVersion                    @"kVersion"
#define kModelGearInfo              @"kModelGearInfo"
#define kModelGearFileName          @"deviceLevel"
#define kModelGearFileType          @"geojson"

#define kPostEventErrorKey          1109
#define kUserIDMaxLen               32
#define kLocalMaxLen                32
#define kAppIDMaxLen                32
#define kVersionMaxLen              32


#define kSceneTypeBeginTag          11
#define kSceneTypeEndTag            13
#define kSceneTypeMarkLevel         1
#define kSceneTypeMarkComplete      2
#define kSceneTypeMarkFin           3


#define kDeviceLevelNetworkTryCount 10

unsigned int                        g_apmSenceIndex = 29999;
char*                               g_sCachedBuffer[kGlobalEventBufferCached];
int                                 g_sCachedBufferIdx[kGlobalEventBufferCached];
uint16_t                            g_apmRandom_seed;
time_t                              g_apmAppInitTime;
time_t                              g_apmTempSceneTime;

typedef struct _tagElement
{
    TagState    tagState;
    const char* tagName;
    
}TagElement;

typedef struct _excludeInfo
{
    uint32_t mTimeStamp;
    uint32_t mType;
    
}ExcludeInfo;

NSMutableDictionary*                            g_streamEventCategoryMaps = nil;
//dispatch_semaphore_t                            g_stream_event_commiter_semaphore;

using namespace SDKHelper;
using namespace SDKMsgQueue;
@interface TApmApiSingleInstance()
{
    BOOL                    _isInitContext;                          // 是否已经初始化上下文
    BOOL                    _isInitContextSuccess;                   // 上下文是否初始化成功
    BOOL                    _isInitSetpEventContext;                 // 开发者是否已调用initStepEventContext
    BOOL                    _isInitSetpEventContextSuccess;                 // stepEventContext初始化成功
    const char*             _userID;                                 // 用户ID
    LevelState              _currenLevelState;                       // 当前场景状态
    TagState                _currentTagState;                        // 当前标记状态
    char*                   _sceneName;                              // 场景名字
    SDKMsgQueue::MsgQueue*  _distanceMsgQueue;                       // 回扯地址队列
    SDKMsgQueue::MsgQueue*  _latencyMsgQueue;                        // 网络延迟队列
    SDKMsgQueue::MsgQueue*  _eventMsgQueue;                          // 游戏事件队列
    SDKMsgQueue::MsgQueue*  _networkStatMsgQueue;                    // 网络状态载数据队列
    SDKMsgQueue::MsgQueue*  _levelMsgQueue;                          // 场景数据队列
    SDKMsgQueue::MsgQueue*  _frameMsgQueue;                          // 帧数据队列
    SDKMsgQueue::MsgQueue*  _uploadCacheFileMsgQueue;                // 上传缓存文件名字队列
    SDKMsgQueue::MsgQueue*  _cacheFileMsgQueue;                      // 缓存文件名字队列
    SDKMsgQueue::MsgQueue*  _appStateMsgQueue;                       // 帧数据队列
    SDKMsgQueue::MsgQueue*  _qualityMsgQueue;                        // 画质数据据队列
    SDKMsgQueue::MsgQueue*  _deviceLevelMsgQueue;
    BOOL                    _isWriteUserIDToCache;                   // 判断是否将UserID写入到缓存
    BOOL                    _isWriteVersionToCache;                  // 判断是否将Version写入到缓存
    BOOL                    _isWriteLocalToCache;                    // 判断是否将local写入到缓存
    BOOL                    _isWriteIPCUUID;                         // 判断是否将IPCUUID写入到缓存
    dispatch_semaphore_t    _markLevelsemaphore;                     // 场景开始信号
    dispatch_semaphore_t    _beginUploadSemaphore;                   // 开始上传信号
    id                      _enterBkgroundObserver;                  // 进入后台观察者
    id                      _enterForegroundObserver;                // 进入前台观察者
    AppState                _appState;                               // 当前app状态
    int32_t                 _currentQuality;                         // 当前画质
    int32_t                 _currentDeviceLevel;
    BOOL                    _isSetQuality;                           // 是否写入画质
    BOOL                    _isSetDeviceLevel;
    TApmStreamEventHandler* _sStreamEventHandlerPtr;
    time_t                  _tLauchTime;                             // 启动时间
    int                     _stepId;
    FrameStateJudger*       _sFrameStateJudgerPtr;
    SDKStack<TagElement>*   _tagStack;                               // tag stack
    MsgQueueBody            _frameQueueBody;                         // 帧消息体
    GPM::MsgQueue<ExcludeInfo>*  _sExcludeRequestQueuePtr;                //
    BOOL                    _isStreamEventComp;
    uint32_t                _lastFrameTimeStamp;                     // 一个场景最后一次调用postFrame时间戳
    uint32_t                _markLoadLevelFinTimeStamp;              // 场景结束时间戳
    uint32_t                _totalLevelFrames;                       // 每一个场景总帧数
    GPM::MsgQueue<DetectTimeOut>* _detectTimeOutQueuePtr;                 // TCP网络探测
    //MsgQueue<FpsRecorder>*  _fpsRecorderQueuePtr;
    APMThermalState*        _thermalState;
}

/** 采集对象集合*/
@property (nonatomic,strong) NSMutableArray* collectionObjs;

@property (nonatomic,copy) NSString* appid;

@property (nonatomic,copy) NSString* tagName;

@property (nonatomic,assign) uint32_t frequency;

@property (nonatomic,copy) NSString* ipcUUID;

//@property (nonatomic,strong) TApmStreamEventCommitter* streamEventCommitter;

@property (nonatomic,assign) BOOL isTimeThreadExit;

@property (nonatomic,strong) NSMutableDictionary* sceneMeanFps;

@property (nonatomic, strong) TApmStepEventPortal *stepEventPortal;

@end

static TApmApiSingleInstance*  singleInstance = nil;

@implementation TApmApiSingleInstance


+ (instancetype)sharedInstance
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        singleInstance = [[TApmApiSingleInstance alloc] init];
    });
    
    return singleInstance;
}

- (instancetype)init
{
    UIDevice*           currentDevice;
    NSString*           systemVersion;
    
    if (self = [super init])
    {
        _isInitContext = NO;
        _isInitContextSuccess = NO;
        _isInitSetpEventContext = NO;
        _isInitSetpEventContextSuccess = NO;
        _userID = NULL;
        _sceneName = NULL;
        _currenLevelState = LevelState_Unkown;
        _currentTagState = TagState_Unkown;
        _distanceMsgQueue = NULL;
        _latencyMsgQueue = NULL;
        _eventMsgQueue = NULL;
        _networkStatMsgQueue = NULL;
        _levelMsgQueue = NULL;
        _uploadCacheFileMsgQueue = NULL;
        _cacheFileMsgQueue = NULL;
        _appStateMsgQueue = NULL;
        _qualityMsgQueue = NULL;
        _deviceLevelMsgQueue = NULL;
        _frameMsgQueue = NULL;
        _sExcludeRequestQueuePtr = NULL;
        _detectTimeOutQueuePtr = NULL;
        _isWriteUserIDToCache = NO;
        _isWriteLocalToCache = NO;
        _isWriteIPCUUID = NO;
        _isWriteVersionToCache = NO;
        g_apmRandom_seed = arc4random() % kInt16MaxValue;
        _enterForegroundObserver = nil;
        _enterBkgroundObserver = nil;
        _appState = AppState_Foreground;
        _currentQuality = 0;
        _currentDeviceLevel = 0;
        _isSetQuality = NO;
        _isSetDeviceLevel = NO;
//        _sStreamEventHandlerPtr = NULL;
        _ipcUUID = nil;
        _stepId = -1;
        _isTimeThreadExit = NO;
//        _isStreamEventComp = NO;
        _lastFrameTimeStamp = 0;
        _totalLevelFrames = 0;
        _markLoadLevelTimeStamp = 0;
        _markLoadLevelFinTimeStamp = 0;
        _stepEventPortal = nil;
        //_fpsRecorderQueuePtr = NULL;
        SDKUtill::currVersionStr = DeviceInfo::DeviceInfoHelper::getSysVersion();
        if (SDKUtill::currVersionStr) {
             SDKUtill::currVersionDoub = [SDKUtill::currVersionStr doubleValue];
        }
    
        _tLauchTime = time(NULL);
        
        SDKUtill::sessionUUID = SDKUtill::generateUuid();
    
        SDKUtill::linkSessionUUID = [kSDKUserDefault objectForKey:kLinkSessionUUID];
        if (SDKUtill::sessionUUID)
        {
            [kSDKUserDefault setObject: SDKUtill::sessionUUID forKey:kLinkSessionUUID];
        }
        
        NSString* uniqueSessionUUID = [kSDKUserDefault objectForKey:kUniqueSessionUUID];
        if (!uniqueSessionUUID)
        {
            uniqueSessionUUID = SDKUtill::generateUuid();
            [kSDKUserDefault setObject:uniqueSessionUUID forKey:kUniqueSessionUUID];
        }
        
        SDKUtill::uniqueSessionUUID = uniqueSessionUUID;
        
    }
    // 获取当前网络类型
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        SDKUtill::networkType = [[[NetworkCollectPerformance alloc]init] getNetworkType];
        kApmMetaInfoObj.wNetwork_type = SDKUtill::networkType;
    });
    
    return self;
}

- (int)initContext:(NSString*)appid
{
    NSString*           currentIphoneModel;
    NSArray*            forbiddenList;
    
    if (![[APMCCStrategy sharedInstance] isFeatureEnabled:FEATURE_INIT])
    {
       APM_LOG_DEBUG(@"initContext error switch disable");
       return GCloudErrorCode_CloseSwitch;
    }
    
    if (!appid)
    {
        GCloud::APM::ReportInitContext(false, GCloudErrorCode_NULL, 0);
        [APMCCStrategy sharedInstance].mEnabledModule = NO;
        return GCloudErrorCode_NULL;
    }
    currentIphoneModel = DeviceInfo::DeviceInfoHelper::getDeviceModel();
    //forbiddenList = @[@"iPhone5,1",@"iPhone5,2",@"iPhone5,3",@"iPhone5,4",@"iPhone6,1",@"iPhone6,2"];
    forbiddenList = @[@"iPhone5,1",@"iPhone5,2",@"iPhone5,3",@"iPhone5,4",@"iPhone6,1"];
    for (NSString* obj in forbiddenList)
    {
        if ([currentIphoneModel isEqualToString:obj])
        {
            APM_LOG_DEBUG(@" %@ is forbidden",obj);
            [APMCCStrategy sharedInstance].mEnabledModule = NO;
            return GCloudErrorCode_ForbidDevice;
        }
    }
    
    if(_isInitContext) return GCloudErrorCode_AlreadyInit;
    _isInitContext = YES;

    [self setAPPID:appid];
    [self invokeBuggly];
    [self getRandFromCDNServer];
    [self setupWhenIsCDNEnable];
    [self setupStepEventPortal];
    [self reportStartupEvent];
    APM_LOG_EVENT(@"GPM init finished");
    
    return GCloudErrorCode_None;
}

- (void)setupStepEventPortal{
    if ([[APMCCStrategy sharedInstance] isFeatureEnabled:FEATURE_POST_STEP_EVENT] && !self.stepEventPortal) {
        self.stepEventPortal = [[TApmStepEventPortal alloc] initWithSessionState:[[TApmSessionState alloc] init]];
    }
}

- (void)reportStartupEvent{
    if ([[APMCCStrategy sharedInstance] isFeatureEnabled:FEATURE_LANUCH_MSG]) {
        if (!self.stepEventPortal) {
            self.stepEventPortal = [[TApmStepEventPortal alloc] initWithSessionState:[[TApmSessionState alloc] init]];
        }
        [self.stepEventPortal asynSendStartStepEvent];
    }
}

- (void)setupWhenIsCDNEnable{
    [self getCurrentAppInfo];
    [self initData];
    [self enableTrackState];
    [self dealLocalCacheFile];
    [self createWorkThread];
    //[self postStreamEvent:0 status:0 code:0 msg:"auto" extDefineKey:"extDefinekey"];
    APM_LOG_DEBUG(@"initContext");
    GCloud::APM::ReportInitContext(true, GCloudErrorCode_None, 0);
    _isInitContextSuccess = YES;
    /*if ([[APMCCStrategy sharedInstance] validCheck:NSStringFromSelector(_cmd) tag:FEATURE_SET_OPENID]) {
        //open id
          char* openID = GCloud::GPM::getOpenID();
          if (openID) {
              [self setUserID:openID];
              APMSDKSafeFree(openID);
          }else{
              APM_LOG_DEBUG(@"open id is NULL, set open id error");
          }
    }*/
  
}

- (void)initData
{
    _distanceMsgQueue = new SDKMsgQueue::MsgQueue(8,true,"_distanceMsgQueue");
    _latencyMsgQueue = new SDKMsgQueue::MsgQueue(128,true,"_latencyMsgQueue");
    _eventMsgQueue = new SDKMsgQueue::MsgQueue(256,true,"_eventMsgQueue");
    _networkStatMsgQueue = new SDKMsgQueue::MsgQueue(8,true,"_networkStatMsgQueue");
    _levelMsgQueue = new SDKMsgQueue::MsgQueue(64,true,"_levelMsgQueue");
    _uploadCacheFileMsgQueue = new SDKMsgQueue::MsgQueue(8,true,true,"_uploadCacheFileMsgQueue");
    _cacheFileMsgQueue = new SDKMsgQueue::MsgQueue(8,false,"_cacheFileMsgQueue");
    _frameMsgQueue = new SDKMsgQueue::MsgQueue(1024,false,"_frameMsgQueue");
    _appStateMsgQueue = new SDKMsgQueue::MsgQueue(8,false,"_appStateMsgQueue");
    _qualityMsgQueue = new SDKMsgQueue::MsgQueue(8,false,"_qualityMsgQueue");
    _deviceLevelMsgQueue = new SDKMsgQueue::MsgQueue(8,false,"_deviceLevelMsgQueue");
    //_fpsRecorderQueuePtr = new MsgQueue<FpsRecorder>(8,true,"_fpsRecorderQueuePtr");
    _markLevelsemaphore = dispatch_semaphore_create(0);
    _beginUploadSemaphore = dispatch_semaphore_create(0);
    for (int i = 0; i < kGlobalEventBufferCached; i++)
    {
        g_sCachedBuffer[i] = NULL;
        g_sCachedBufferIdx[i] = 0;
    }
    
    __weak typeof(self) weakSelf = self;
    _enterBkgroundObserver = [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationWillResignActiveNotification object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        
        __strong typeof(weakSelf) strongSelf = weakSelf;
//        if (strongSelf -> _sStreamEventHandlerPtr && strongSelf.streamEventCommitter)
//        {
//            //APM_LOG_DEBUG(@"will enter background send step event semaphore");
//            //dispatch_semaphore_signal(g_stream_event_commiter_semaphore);
//             //[[TApmStreamEventCommitter sharedInstance] startUploadStepEvent];
//        }
      
        dispatch_async(dispatch_get_main_queue(), ^{
            if (strongSelf -> _appState == AppState_Foreground)
            {
                [strongSelf postAppState:AppState_Background];
                strongSelf -> _appState = AppState_Background;
            }
        });
        
    }];
    
    _enterForegroundObserver = [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidBecomeActiveNotification object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        // IPC Thread
        //[self performSelectorInBackground:@selector(ipcThread) withObject:nil];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            if (strongSelf -> _appState == AppState_Background)
            {
                [strongSelf postAppState:AppState_Foreground];
                strongSelf -> _appState = AppState_Foreground;
            }
        });
        
    }];
    
    _tagStack = new SDKStack<TagElement>(16);
    constructMsgQueueBody(_frameQueueBody);
    _frameQueueBody.flag = kFrameFlag;
    _frameQueueBody.drawcall = 0;
    _frameQueueBody.triangle = 0;
    
    g_apmAppInitTime = time(NULL);
    _sceneMeanFps = [NSMutableDictionary dictionary];
   
    if ([[APMCCStrategy sharedInstance] isFeatureEnabled:FEATURE_THERMALSTATE]){
           //APM_LOG_DEBUG(@"thermal state enable");
            _thermalState = [[APMThermalState alloc] init];
       }else{
           APM_LOG_DEBUG(@"thermal state disable");
       }
}

- (void)initStepEventContext
 {

 }

- (void)releaseStepEventContext
{
  
}

- (void)invokeBuggly
{
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSString * componentId = @"c416ba13ca";
        NSString * version = kBuglyVersion;
        
        if (componentId && version)
        {
            NSMutableDictionary * dictionary = [NSMutableDictionary dictionary];
            // 读取已有信息并记录
            NSDictionary * dict = [[NSUserDefaults standardUserDefaults] dictionaryForKey:@"BuglySDKInfos"];
            if (dict)
            {
                [dictionary addEntriesFromDictionary:dict];
            }
            // 添加当前组件的唯一标识和版本
            [dictionary setValue:version forKey:componentId];
            
            // 写入更新的信息
            [[NSUserDefaults standardUserDefaults] setObject:[NSDictionary dictionaryWithDictionary:dictionary] forKey:@"BuglySDKInfos"];
        }
    });
    
}

- (void)enableTrackState
{
    _sFrameStateJudgerPtr = new FrameStateJudger(1024);
}

- (void)postErrorStr:(NSString*)errorStr
{
    [self postErrorStr:errorStr errorDes:nil];
}

- (void)postErrorStr:(NSString*)errorStr errorDes:(NSString*)errorDes
{
    if (!errorStr) return;
    
    if (errorDes) errorStr = [NSString stringWithFormat:@"%@:%@",errorStr,errorDes];
    APM_LOG_DEBUG(@"postErrorStr:%@", errorStr);
    [self postEvent:kPostEventErrorKey info:[errorStr UTF8String]];
}

- (int)getDeviceLevelAbsPath:(NSString*)absolutePath configLevel:(NSString*)configLevel
{
    if (!absolutePath || !configLevel)
    {
        APM_LOG_DEBUG(@"asyn device level absolutePath or configLevel is nil");
        return 0;
    }
    
    NSDictionary *localModelGearDic = [self localModelGearDicWithabsolutePath:absolutePath];
    if (!localModelGearDic) {
        return 0;
    }
    return [self getDeviceLevel:localModelGearDic configLevel:configLevel syncFromServer:NO];
}


- (int)ayncGetDeviceLevelWithAbsPath:(NSString*)absolutePath configLevel:(NSString*)configLevel
{
    if (!absolutePath || !configLevel)
    {
        APM_LOG_DEBUG(@"sync device level absolutePath or configLevel is nil");
        return 0;
    }
    
    NSDictionary *localModelGearDic = [self userConfigModelGearDicWithabsolutePath:absolutePath];
    if (!localModelGearDic) {
        return 0;
    }
    
    return [self getDeviceLevel:localModelGearDic configLevel:configLevel syncFromServer:YES];
}


- (NSDictionary *)userConfigModelGearDicWithabsolutePath:(NSString *)absolutePath{
    if ([absolutePath hasSuffix:@"/"]) {
        absolutePath = [NSString stringWithFormat:@"%@tapm_qcc_ios_default",absolutePath];
    }else{
        absolutePath = [NSString stringWithFormat:@"%@/tapm_qcc_ios_default",absolutePath];
    }
    
    NSError *error = nil;
    NSData* data = [NSData dataWithContentsOfFile:absolutePath options:NSDataReadingUncached error:&error];
    if (error || !data)
    {
        APM_LOG_DEBUG(@"read device level config file:%@ error:%@", absolutePath, error.description);
        return nil;
    }
    
    NSDictionary * localModelGearDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
    if (error || !localModelGearDic)
    {
        APM_LOG_DEBUG(@"device level json convert error:%@", error.description);
        return nil;
    }
    
    return localModelGearDic;
    
}

- (NSDictionary *)localModelGearDicWithabsolutePath:(NSString *)absolutePath{
    if ([absolutePath hasSuffix:@"/"]) {
        absolutePath = [NSString stringWithFormat:@"%@tapm_qcc_ios_default",absolutePath];
    }else{
        absolutePath = [NSString stringWithFormat:@"%@/tapm_qcc_ios_default",absolutePath];
    }
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if (![fileManager fileExistsAtPath:absolutePath]) {
        APM_LOG_DEBUG(@"device level file:%@ not exist", absolutePath);
        return nil;
    }
    NSDictionary* localModelGearDic = [kSDKUserDefault objectForKey:kModelGearInfo];
    if (!localModelGearDic)
    {
        APM_LOG_DEBUG(@"device level file:%@", absolutePath);
        NSData* data = [NSData dataWithContentsOfFile:absolutePath];
        if (!data)
        {
            APM_LOG_DEBUG(@"device level data convert error");
            return nil;
        }
        
        NSError* error;
        localModelGearDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
        if (error)
        {
            APM_LOG_DEBUG(@"device level json convert error:%@",error.description);
            return nil;
        }
        
        if (!localModelGearDic) return nil;
        
        [kSDKUserDefault setObject:localModelGearDic forKey:kModelGearInfo];
        [kSDKUserDefault synchronize];
        
    }
    return localModelGearDic;
}


- (NSDictionary *)syncDeviceLevelDataFromServer:(NSURL *)url{
    NSDictionary *resultDic = nil;
    NSError *networkError = nil;
    NSError *jsonSerializationError = nil;
    for (int i = 0; i < kDeviceLevelNetworkTryCount; i++) {
        networkError = nil;
        jsonSerializationError = nil;
        NSData *data = [NSData dataWithContentsOfURL:url options:NSDataReadingUncached error:&networkError];
        if (networkError || !data) {
            continue;
        }
        
        resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&jsonSerializationError];
        if (jsonSerializationError || !resultDic) {
            continue;
        }
        break;
    }
    if (!resultDic) {
        if (networkError) {
            [self postErrorStr:@"device level connect server error" errorDes:networkError.description];
        }
        
        if (jsonSerializationError) {
            [self postErrorStr:@"device level json serialization error from server" errorDes:jsonSerializationError.description];
        }
        return nil;
    }
    return resultDic;
}

- (int)getDeviceLevel:(NSDictionary*)modelGearJson configLevel:(NSString* )configLevel syncFromServer:(BOOL)syncFromServer
{
    int currentLevel = 0;
    if (!modelGearJson || !configLevel) return 0;

    NSString* version = modelGearJson[@"version"];
    if (!version || [version isKindOfClass:[NSNull class]])
    {
        [self postErrorStr:@"read local device level version error"];
        return 0;
    }
    
    version = [version description];

    if (!_appid)
    {
        [self postErrorStr:@"appid is null"];
        return 0;
    }
    

    if (syncFromServer) {
        NSDictionary *networkDic = nil;
        NSString *curVerson = version;
        NSString *remoteVersion = nil;
        BOOL validValid = NO;
        do{
            NSURL *url = [NSURL URLWithString: [kDeviceLevelUrlStr stringByAppendingString:[NSString stringWithFormat:@"%@_%@",_appid,curVerson]]];
            if (!url) {
                [self postErrorStr:@"device level url not exist"];
                return 0;
            }
            networkDic = [self syncDeviceLevelDataFromServer:url];
            if (!networkDic) {//网络失败或json格式解析失败
                return 0;
            }
            remoteVersion = networkDic[@"version"];
            if (!remoteVersion  || [remoteVersion isKindOfClass:[NSNull class]]) {//远程未配置version字段
                return 0;
            }
            remoteVersion = [remoteVersion description];
            validValid =  [curVerson isEqualToString:remoteVersion];
            curVerson = remoteVersion;
        }while(!validValid);
        modelGearJson = networkDic;
    }else{
        NSURL* url = [NSURL URLWithString: [kDeviceLevelUrlStr stringByAppendingString:[NSString stringWithFormat:@"%@_%@",_appid,version]]];
        if (!url)
        {
            [self postErrorStr:@" device level url not exist"];
            return 0;
        }
        SDKHttpRequest* sdkHttpRequest = [[SDKHttpRequest alloc] init];
        if (!sdkHttpRequest)
        {
            [self postErrorStr:@" device level sdkHttpRequest init error"];
            return 0;
        }
        
        [sdkHttpRequest requestURL:url completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
            if (!error && data)
            {
                NSDictionary* resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
                if (!error)
                {
                    if (!resultDic) return ;
                    [kSDKUserDefault setObject:resultDic forKey:kModelGearInfo];
                    [kSDKUserDefault synchronize];
                }
                else [self postErrorStr:@"device level json serialization error from server"];
            }
            else [self postErrorStr:@"device level connect server error" errorDes:error.description];
        }];
    }

    NSArray* configureList = modelGearJson[@"configureList"];
    if (!configureList)
    {
        [self postErrorStr:@"device level configureList error"];
        return 0;
    }
    
    SDKUtill utill;
    NSString* identifier = DeviceInfo::DeviceInfoHelper::getDeviceModel();
    NSDictionary* filterDic = utill.getDeviceEasyReadModel(identifier);
    if (!filterDic)
    {
        [self postErrorStr:@"identifier does not match"];
        return 0;
    }
    
    NSDictionary* configDic = modelGearJson[configLevel];
    if (!configDic)
    {
        [self postErrorStr:@"device level configLevel not exist"];
        return 0;
    }
    
    BOOL useRegex = NO;
    id regexConfigValue = configDic[@"regex"];
    if (regexConfigValue) {
        if ([regexConfigValue isKindOfClass:[NSString class]] || [regexConfigValue isKindOfClass:[NSNumber class]]) {
            useRegex = [regexConfigValue integerValue] == 1;
        }
    }
   
    NSNumber* classLevelNum = configDic[@"classLevelNum"];
    if (!classLevelNum)
    {
        [self postErrorStr:@"device level classLevelNum not exist"];
        return 0;
    }
    
    NSArray* classLevelValues = configDic[@"classLevelValues"];
    if (!classLevelValues)
    {
        [self postErrorStr:@"device level classLevelValues not exist"];
        return 0;
    }
    
    if ([classLevelNum intValue] != [classLevelValues count])
    {
        [self postErrorStr:@"device level classLevelValues not equal classLevelNum"];
        return 0;
    }
    
    NSNumber* defaultLevel = configDic[@"defLevel"];
    if (defaultLevel) currentLevel = [defaultLevel intValue];
    
    NSArray* filters = @[@"filter-model",@"filter-soc"];
    
    for (NSString* filterName in filters) {
        
        NSDictionary* filterModel = configDic[filterName];
       
        NSString* identifierLowerNoempty = utill.convertLowerCaseNoEmptyStr(identifier);
        for (NSString* gear in filterModel.allKeys)
        {
            int gearInt = [gear intValue];
            NSNumber* gearNumber = [NSNumber numberWithInt:gearInt];
            if (!gearNumber) continue;
            if (![classLevelValues containsObject:gearNumber]) continue;
            
            NSArray* modelWhitelist = filterModel[gear];
            if (!modelWhitelist || [modelWhitelist isKindOfClass:[NSNull class]]) continue;
            
            NSString* modelWhite;
            
            for (modelWhite in modelWhitelist)
            {
                if (!modelWhite) continue;
             
                if (useRegex) {//正则匹配
                    NSArray *filterItems= filterDic[filterName];
                    for (NSString *filterItem in filterItems) {
                        BOOL matchResult = [self matchSrc:filterItem regex:modelWhite];
                        if (matchResult) {
                            currentLevel = [gear intValue];
                            APM_LOG_DEBUG(@" current device level is :%d,configLevel:%@",currentLevel,configLevel);
                            return currentLevel;
                        }
                    }
                    
                }else{
                    
                    modelWhite = utill.convertLowerCaseNoEmptyStr(modelWhite);
                    NSArray* vec = filterDic[filterName];
                    for (NSString* obj in vec) {
                        NSString* str = utill.convertLowerCaseNoEmptyStr(obj);
                        if ([modelWhite isEqualToString:identifierLowerNoempty] || [str isEqualToString:modelWhite] ||
                            [self faultTolerantForModel:str modelWhite:modelWhite])
                        {
                            currentLevel = [gear intValue];
                            APM_LOG_DEBUG(@"current device level is :%d,configLevel:%@",currentLevel,configLevel);
                            return currentLevel;
                        }
                    }
                }
            }
        }
    }
    
    
    [self postErrorStr:@"device level does not match end"];
    
    return currentLevel;
}

- (BOOL)faultTolerantForModel:(NSString*)currentRasyReadModel modelWhite:(NSString*)modelWhite
{
 
    if (!currentRasyReadModel || !modelWhite) return NO;
    
    if (![currentRasyReadModel hasPrefix:@"ipad"] || ![modelWhite hasPrefix:@"ipad"]) return NO;
    
    NSString* iPadPro_1st_12_9_1st = @"1st";
    NSString* iPadPro_1st_12_9_12_9 = @"12.9";
    if ([currentRasyReadModel containsString:iPadPro_1st_12_9_1st] && [currentRasyReadModel containsString:iPadPro_1st_12_9_12_9] &&
        [modelWhite containsString:iPadPro_1st_12_9_1st] && [modelWhite containsString:iPadPro_1st_12_9_12_9])
    {
            return YES;
    }

    NSString* iPadPro_2nd_12_9_2nd = @"2nd";
    NSString* iPadPro_2nd_12_9_12_9 = @"12.9";
    if ([currentRasyReadModel containsString:iPadPro_2nd_12_9_2nd] && [currentRasyReadModel containsString:iPadPro_2nd_12_9_12_9] &&
        [modelWhite containsString:iPadPro_2nd_12_9_2nd] && [modelWhite containsString:iPadPro_2nd_12_9_12_9])
    {
        return YES;
    }
    
    NSString* iPad_9_7 = @"9.7";
    if ([currentRasyReadModel containsString:iPad_9_7] && [modelWhite containsString:iPad_9_7]) return YES;

    NSString* iPad_10_5 = @"10.5";
    if ([currentRasyReadModel containsString:iPad_10_5] && [modelWhite containsString:iPad_10_5]) return YES;
    
    NSString* iPad_2017 = @"2017";
    if ([currentRasyReadModel containsString:iPad_2017] && [modelWhite containsString:iPad_2017]) return YES;
    
    NSString* iPad_2018 = @"2018";
    if ([currentRasyReadModel containsString:iPad_2018] && [modelWhite containsString:iPad_2018]) return YES;

    return NO;
}


- (void)getRandFromCDNServer
{
    SDKUtill::opts = 0;
    self.frequency = [APMCCStrategy sharedInstance].mPssIntervals;
}

- (void)dealLocalCacheFile
{
    
    NSArray*             localCacheFiles;
    MsgQueueBody         msgQueueBody;
    bool                 isExitCacheFile = NO;
    
    localCacheFiles = [[FileManager sharedFileManager] showAllUnUploadCachedFile];
    if (localCacheFiles && localCacheFiles.count > 0)
    {
        for (NSString* cacheFileName in localCacheFiles)
        {
            if (cacheFileName && [cacheFileName hasPrefix:kPrefixCacheFileName]  && ![cacheFileName hasSuffix:kSDKMMapWriterBufferFileSuffix])
            {
                constructMsgQueueBody(msgQueueBody);
                msgQueueBody.charValue = [cacheFileName UTF8String];
                if(msgQueueBody.charValue != NULL) _uploadCacheFileMsgQueue -> postMsg(msgQueueBody);
                isExitCacheFile = YES;
            }
        }
        if (isExitCacheFile)
        {
            dispatch_semaphore_signal(_beginUploadSemaphore);
        }
    }
    
    
    
    //如果当前开启了mmap检查本地文件中是否存在mmap的.part文件
    if ([[APMCCStrategy sharedInstance] isFeatureEnabled:FEATURE_MMAP]){
        NSArray<NSDictionary *> * lastRunPartfiles = SDKMMapWriterBuffer::checkLastRunPartFile();
        if (lastRunPartfiles.count > 0) {
            //代表存在.part文件, 在子线程中合并发送
            static dispatch_queue_t queue;
            static dispatch_once_t onceToken;
            dispatch_once(&onceToken, ^{
                queue = dispatch_queue_create("apm_startup_upload_mmap_file_queue", DISPATCH_QUEUE_SERIAL);
            });
            dispatch_async(queue, ^{
                BOOL hasPartFileAndMargeSuccess = NO;
                for (NSDictionary *lastRunPartfile in lastRunPartfiles) {
                    NSString *fileName = lastRunPartfile[kSDKMMapWriterBufferFileName];
                    if (!fileName) {
                        continue;
                    }
                    BOOL oncePartFileAndMargeSuccess = SDKMMapWriterBuffer::margeFileWithFileNameAndMaxIndex(fileName, [lastRunPartfile[kSDKMMapWriterBufferFileMaxIndex] intValue]);
                    MsgQueueBody         msg;
                    constructMsgQueueBody(msg);
                    msg.charValue = [fileName UTF8String];
                    if (msg.charValue) {
                        _uploadCacheFileMsgQueue -> postMsg(msg);
                        hasPartFileAndMargeSuccess = oncePartFileAndMargeSuccess ?: hasPartFileAndMargeSuccess;
                    }
                }
                if (hasPartFileAndMargeSuccess) {
                   dispatch_semaphore_signal(_beginUploadSemaphore);
                }
            });
        }
    }
}



- (void)createWorkThread
{
    // 创建一个后台线程
    [self performSelectorInBackground:@selector(startWorkThread) withObject:nil];
    // 创建网络上传线程
    [self performSelectorInBackground:@selector(startUploadThread) withObject:nil];
    
}

- (void)beginExclude
{
    ExcludeInfo         temp;
    
    if (![APMCCStrategy sharedInstance].mEnabledModule)
    {
        APM_LOG_DEBUG(@"beginExclude error switch disable");
        return;
    }
    
    if (![self isCurrentLevelDataValid]) return;
    
    if (!_isInitContext)
    {
        return;
    }
    
    if (_sExcludeRequestQueuePtr == NULL)
    {
        _sExcludeRequestQueuePtr = new GPM::MsgQueue<ExcludeInfo> (128, false,"sExcludeRequestQueuePtr");
    }
    
    if (_sExcludeRequestQueuePtr == NULL)
    {
        APM_LOG_DEBUG(@"ExcludeRequestQueue is NULL");
        return;
    }

    //nsecs_t timeStamp;
    //timespec tempspec;
    //systemTimeMacro(tempspec, timeStamp);
    //temp.mTimeStamp = timeStamp / NS_TO_MS;
    temp.mTimeStamp = SDKUtill::getCurrentTimeIntervalMillisecond();
    temp.mType = 1;
    
    _sExcludeRequestQueuePtr->postMsg(temp);
}

- (void)postDetectTimeOut:(NSDictionary*)detectTimeOutDic
{
    if (![[APMCCStrategy sharedInstance] validCheck:NSStringFromSelector(_cmd) tag:FEATURE_POST_DETECT_TIMEOUT]) {
        return;
    }
    
    if (!detectTimeOutDic) {
        return;
    }
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _detectTimeOutQueuePtr = new GPM::MsgQueue<DetectTimeOut>(8,true,"detectTimeOutQueuePtr");
    });
    
    if (!_detectTimeOutQueuePtr) {
        APM_LOG_DEBUG(@"_detectTimeOutQueuePtr is NULL");
        return;
    }
    
    __block DetectTimeOut   detectTimeout;
    __block NSMutableString* serverDetailInfo = [NSMutableString string];
    [detectTimeOutDic enumerateKeysAndObjectsUsingBlock:^(NSString*  _Nonnull key, NSString* obj, BOOL * _Nonnull stop) {
        
        if ([key hasPrefix:@"d"]) {
            [serverDetailInfo appendFormat:@"%@,",obj];
        }
        
        if ([key isEqualToString:@"gateway"]) {
            NSArray* gateway = [obj componentsSeparatedByString:@","];
            [gateway enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                if (idx <= 2 && obj) {
                    detectTimeout.gateway[idx] = (int32_t)[obj integerValue];
                    if (idx == 2) {
                        *stop = YES;
                    }
                }
            }];
        }
        
        if ([key isEqualToString:@"xg"]) {

            const char* networkType = obj.UTF8String;
            if (networkType) {
                detectTimeout.networkType = strdup(networkType);
                detectTimeout.networkTypeLen = strlen(networkType);
            }
        }
    }];
  
    const char* serverDetailInfoUTF8 = [serverDetailInfo UTF8String];
    if (serverDetailInfoUTF8) {
        detectTimeout.connectServerDetailLen = strlen(serverDetailInfoUTF8);
        detectTimeout.connectServerDetail = strdup(serverDetailInfoUTF8);
    }
 
    _detectTimeOutQueuePtr -> postMsg(detectTimeout);
    
}

- (void)endExclude
{
    ExcludeInfo         temp;
    
    if (![APMCCStrategy sharedInstance].mEnabledModule)
    {
        APM_LOG_DEBUG(@"endExclude error switch disable");
        return;
    }
    if (![self isCurrentLevelDataValid]) return;
    if (!_isInitContext)
    {
        return;
    }
    
    if (_sExcludeRequestQueuePtr == NULL)
    {
        APM_LOG_DEBUG(@"ExcludeRequestQueue is NULL");
        return;
    }
    //nsecs_t timeStamp;
    //timespec tempspec;
    //systemTimeMacro(tempspec, timeStamp);
    //temp.mTimeStamp = timeStamp / NS_TO_MS;
    temp.mTimeStamp = SDKUtill::getCurrentTimeIntervalMillisecond();
    temp.mType = 2;
    
    _sExcludeRequestQueuePtr->postMsg(temp);
    
}

- (float)getInstantFps
{
   
    if (![[APMCCStrategy sharedInstance] validCheck:NSStringFromSelector(_cmd) tag:FEATURE_FPS]) {
        return 0.0;
    }
    
    if (![self isCurrentLevelDataValid]) return 0.0;
    if (!_isInitContext)
    {
        return 0.0;
    }
    
    uint32_t currentFrameTimeStamp = SDKUtill::getCurrentTimeIntervalMillisecond();
    uint32_t diff = currentFrameTimeStamp - _lastFrameTimeStamp;
    if (diff != 0)
    {
        return 1.0 / diff;
    }
    
    APM_LOG_DEBUG(@"get instant fps error");
    
    return 0.0;
}

- (float)calculateMeanFps:(NSString*)sceneName start:(uint32_t)startTimeStamp end:(uint32_t)endTimeStamp
{
    if(!_sceneMeanFps)
    {
        APM_LOG_DEBUG(@"calculate mean fps map is nil");
        return 0.0;
    }
    
    if (!sceneName)
    {
        APM_LOG_DEBUG(@"calculate mean fps scene name is nil");
        return 0.0;
    }
    
    if (endTimeStamp < startTimeStamp)
    {
        APM_LOG_DEBUG(@"calculate mean fps end time stamp less than start time stamp");
        return 0.0;
    }
    
    float meanFps = _totalLevelFrames / ((endTimeStamp - startTimeStamp) / 1000.0f);
    
    if (_sceneMeanFps.count > kMaxDictionaryCount)
    {
        APM_LOG_DEBUG(@"mean fps maps cache data too large,cache failure");
        return meanFps;
    }
    
     _sceneMeanFps[sceneName] = @(meanFps);
    
    return meanFps;
}

- (float)getSceneMeanFps:(NSString*)sceneName
{
    if (![[APMCCStrategy sharedInstance] validCheck:NSStringFromSelector(_cmd) tag:FEATURE_FPS]) {
           return 0.0;
    }
    
    if (![self isCurrentLevelDataValid]) return 0.0;
    if (!_isInitContext)
    {
        return 0.0;
    }
    if (!sceneName)
    {
        APM_LOG_DEBUG(@" get scene mean fps scene name is nil");
        return 0.0;
    }
    
    const char* cSceneName = [sceneName UTF8String];
    if (cSceneName)
    {
        if(strcmp(cSceneName, _sceneName) == 0)
        {
            uint32_t currentTimeStamp =  SDKUtill::getCurrentTimeIntervalMillisecond();
            return [self calculateMeanFps:sceneName start:_markLoadLevelTimeStamp end:currentTimeStamp];
        }
    }
   
    NSNumber* floatMeanFps = [_sceneMeanFps objectForKey:sceneName];
    if (floatMeanFps)
    {
        return [floatMeanFps floatValue];
    }
    
    return 0.0;
}

- (int)getSceneMaxPss //MB
{
    if (![[APMCCStrategy sharedInstance] validCheck:NSStringFromSelector(_cmd) tag:FEATURE_FPS]) {
        return 0;
    }
    
    if (![self isCurrentLevelDataValid]) return 0;
    if (!_isInitContext)
    {
        return 0;
    }
    
    return [MessageQueue sharedInstance].maxPss;
}

- (int)getSceneTotalTime
{
    if (![[APMCCStrategy sharedInstance] validCheck:NSStringFromSelector(_cmd) tag:FEATURE_FPS]) {
        return 0;
    }
    
    if (![self isCurrentLevelDataValid]) return 0;
    if (!_isInitContext)
    {
        return 0;
    }
    
    return SDKUtill::getCurrentTimeIntervalMillisecond() - _markLoadLevelTimeStamp;
}

- (int)getSceneTotalFrames
{
    if (![[APMCCStrategy sharedInstance] validCheck:NSStringFromSelector(_cmd) tag:FEATURE_FPS]) {
        return 0;
    }
    
    if (![self isCurrentLevelDataValid]) return 0;
    if (!_isInitContext)
    {
        return 0;
    }
    
    return _totalLevelFrames;
}

- (void)setQuality:(int32_t)quality
{
    MsgQueueBody        msgQueueBody;
    
    if (![APMCCStrategy sharedInstance].mEnabledModule)
    {
        APM_LOG_DEBUG(@"setQuality error switch disable");
        return;
    }
    if (!_isInitContext)
    {
        return;
    }
    if (_currentQuality != quality || !_isSetQuality)
    {
        constructMsgQueueBody(msgQueueBody);
        msgQueueBody.int32Value = quality;
        msgQueueBody.sceneIndex = g_apmSenceIndex;
        _qualityMsgQueue -> postMsg(msgQueueBody);
        _currentQuality = quality;
        _isSetQuality = YES;
        APM_LOG_DEBUG(@"setQuality:%d",quality);
    }
    
}

- (void)setDeviceLevel:(int32_t)deviceLevel
{
    MsgQueueBody        msgQueueBody;
    
    if (!_isInitContext)
    {
        return;
    }
    if (_currentDeviceLevel != deviceLevel || !_isSetDeviceLevel)
    {
        constructMsgQueueBody(msgQueueBody);
        msgQueueBody.int32Value = deviceLevel;
        msgQueueBody.sceneIndex = g_apmSenceIndex;
        _deviceLevelMsgQueue -> postMsg(msgQueueBody);
        _currentDeviceLevel = deviceLevel;
        _isSetDeviceLevel = YES;
        APM_LOG_DEBUG(@"set device level:%d",deviceLevel);
    }
}

- (void)setUserID:(const char*)userID
{
    NSString*               userIDStr;
    
    if (!userID)  return;
    
    userIDStr = [NSString stringWithUTF8String:userID];
    if(userIDStr != nil && [userIDStr length] > kUserIDMaxLen) userIDStr = [userIDStr substringWithRange:NSMakeRange(0, kUserIDMaxLen)];
    APM_LOG_DEBUG(@"setOpenId:%@",userIDStr);
    kApmMetaInfoObj.szUserID = userIDStr;
    [kSDKUserDefault setObject:userIDStr forKey:kUserID];
    [kSDKUserDefault synchronize];
}

- (void)setLocal:(NSString*)local
{
    if (![APMCCStrategy sharedInstance].mEnabledModule)
    {
        APM_LOG_DEBUG(@"setLocal error switch disable");
        return;
    }
    
    if (!_isInitContext)
    {
        return;
    }
    
    if (!local)  return;
    
    if([local length] > kLocalMaxLen) local = [local substringWithRange:NSMakeRange(0, kLocalMaxLen)];
    
    [kSDKUserDefault setObject:local forKey:kLocal];
    
    APM_LOG_DEBUG(@"setLocal:%@",local);
}


- (void)setAPPID:(NSString*)appid
{
    if (appid)
    {
        if ([appid length] > kAppIDMaxLen) appid = [appid substringWithRange:NSMakeRange(0, kAppIDMaxLen)];
        _appid = [appid copy];
        APM_LOG_DEBUG(@"setAPPID:%@",appid);
    }
}

- (void)setVersionIden:(NSString*)version
{
   
    if (![[APMCCStrategy sharedInstance] validCheck:NSStringFromSelector(_cmd) tag:FEATURE_SET_VERSION_IDEN]) {
        return ;
    }
    if (version)
    {
        if ([version length] > kVersionMaxLen) version = [version substringWithRange:NSMakeRange(0, kVersionMaxLen)];
        [kSDKUserDefault setObject:version forKey:kVersion];
        [kSDKUserDefault synchronize];
        APM_LOG_DEBUG(@"setVersionIden:%@",version);
    }
}


// 根据当前场景的状态，判断传入的数据是否有效
- (BOOL)isCurrentLevelDataValid
{
    return (_currenLevelState == LevelState_MarkLoadLevel || _currenLevelState == LevelState_MarkLoadLevelCompleted);
}

- (void)postEvent:(uint32_t)key info:(const char*)info
{
    MsgQueueBody        msgQueueBody;
    
    if (![[APMCCStrategy sharedInstance] validCheck:NSStringFromSelector(_cmd) tag:FEATURE_POST_EVENT]) {
        return ;
    }
   
    if (!_isInitContext)
    {
        return;
    }
    
    constructMsgQueueBody(msgQueueBody);
    
    msgQueueBody.int32Value = key;
    msgQueueBody.charValue = info;
    msgQueueBody.timeInterval = SDKUtill::getCurrentTimeIntervalMillisecond();
    msgQueueBody.sceneIndex = g_apmSenceIndex;
    if(msgQueueBody.charValue != NULL)
    {
        _eventMsgQueue -> postMsg(msgQueueBody);
        APM_LOG_DEBUG(@"postEvent key:%d,info:%s",key,info);
    }
}

- (void)postNTL:(int32_t)latency
{
    
    MsgQueueBody        msgQueueBody;
    
    if (![APMCCStrategy sharedInstance].mEnabledModule)
    {
        APM_LOG_DEBUG(@"post NTL error switch disable");
        return;
    }
    if (!_isInitContext)
    {
        return;
    }
    
    if ([self isCurrentLevelDataValid])
    {
        constructMsgQueueBody(msgQueueBody);
        msgQueueBody.int32Value = latency;
        msgQueueBody.timeInterval = SDKUtill::getCurrentTimeIntervalMillisecond();
        msgQueueBody.sceneIndex = g_apmSenceIndex;
        _latencyMsgQueue -> postMsg(msgQueueBody);
    }
}

- (void)postLagStatus:(int32_t)distance
{
    
    MsgQueueBody        msgQueueBody;
    
    if (![APMCCStrategy sharedInstance].mEnabledModule)
    {
       APM_LOG_DEBUG(@"post postLagStatus error switch disable");
       return;
    }
    if (!_isInitContext)
    {
        return;
    }
    
    if ([self isCurrentLevelDataValid])
    {
        constructMsgQueueBody(msgQueueBody);
        msgQueueBody.timeInterval = SDKUtill::getCurrentTimeIntervalMillisecond();
        msgQueueBody.int32Value = distance;
        msgQueueBody.sceneIndex = g_apmSenceIndex;
        _distanceMsgQueue -> postMsg(msgQueueBody);
    }
}

- (void)postFrame:(float)deltaSeconds
{
    
    if (![APMCCStrategy sharedInstance].mEnabledModule) return;
    if (!_isInitContext)
    {
        return;
    }
    if (kFPS_OPT & SDKUtill::opts) return;
    if ([self isCurrentLevelDataValid])
    {
        _frameQueueBody.timeInterval = SDKUtill::getCurrentTimeIntervalMillisecond();
        _frameQueueBody.deltaSeconds = deltaSeconds * 100;
        _frameQueueBody.sceneIndex = g_apmSenceIndex;
        _frameMsgQueue -> postMsg(_frameQueueBody);
        _totalLevelFrames++;
        _lastFrameTimeStamp = _frameQueueBody.timeInterval;
    }
}

- (void)postAppState:(AppState)appState
{
    MsgQueueBody          msgQueueBody;
    
    if (![[APMCCStrategy sharedInstance] validCheck:NSStringFromSelector(_cmd) tag:FEATURE_APP_STATE]) {
        return ;
    }
        
    if (!_isInitContext)
    {
        return;
    }
    if ([self isCurrentLevelDataValid])
    {
        constructMsgQueueBody(msgQueueBody);
        if(appState == AppState_Foreground) msgQueueBody.flag = kAppForegroundFlag;
        else  msgQueueBody.flag = kAppBkgroundFlag;
        msgQueueBody.sceneIndex = g_apmSenceIndex;
        msgQueueBody.timeInterval = SDKUtill::getCurrentTimeIntervalMillisecond();
        _appStateMsgQueue -> postMsg(msgQueueBody);
        APM_LOG_DEBUG(@"app state:%u,timeInterval:%u",(unsigned int)appState,msgQueueBody.timeInterval);
    }
}

- (void)linkStreamEventSession:(NSString *)eventName
{
   
    if (![[APMCCStrategy sharedInstance] validCheck:NSStringFromSelector(_cmd) tag:FEATURE_POST_STEP_EVENT]) {
        return ;
    }
    
     [self.stepEventPortal linkSessionWithCategory:eventName];
}

- (void)postStepEvent:(const char*)eventName stepId:(int)stepId status:(int)status code:(int)code msg:(const char*)msg extDefineKey:(const char*)extDefineKey
{
   
    if (![[APMCCStrategy sharedInstance] validCheck:NSStringFromSelector(_cmd) tag:FEATURE_POST_STEP_EVENT]) {
        return ;
    }
      
    [self.stepEventPortal postStepEventWithEventCategory:eventName?@(eventName):nil stepId:stepId
                                                      status:status code:code msg:msg?@(msg):nil extDefinedKey:extDefineKey?@(extDefineKey):nil];
}

// 1s处理一次
// 低帧
// 陡降
// 帧时间
// 考虑不同的目标帧率
- (void)postCoordinate:(int)x y:(int)y z:(int)z pitch:(int)pitch yaw:(int)yaw roll:(int)roll
{
    
    if (![[APMCCStrategy sharedInstance] validCheck:NSStringFromSelector(_cmd) tag:FEATURE_POST_TRACK_STATE]) {
        return ;
    }
    if (!_isInitContext)
    {
        return;
    }
    
    if (_sFrameStateJudgerPtr == NULL)
    {
        APM_LOG_DEBUG(@"FrameStateJudger is NULL");
        return;
    }

    SnapshotState ssstate;
    ssstate.mTimeStamp = SDKUtill::getCurrentTimeIntervalMillisecond();
    
    ssstate.mCoordinate.mX = x;
    ssstate.mCoordinate.mY = y;
    ssstate.mCoordinate.mZ = z;
    
    ssstate.mRotator.mPitch = pitch;
    ssstate.mRotator.mYaw = yaw;
    ssstate.mRotator.mRoll = roll;
    
    _sFrameStateJudgerPtr->postSnapshotState(ssstate);
}


- (void)beginTag:(NSString*)tagName
{
    MsgQueueBody        msgQueueBody;
    
    if (![APMCCStrategy sharedInstance].mEnabledModule)
    {
        APM_LOG_DEBUG(@"beginTag error switch disable");
        return;
    }
    if (!_isInitContext)
    {
        return;
    }
    
    if ([self isCurrentLevelDataValid])
    {
        const char* tempName = [tagName cStringUsingEncoding:NSUTF8StringEncoding];
        if (tempName == NULL) return;
        
        char* tagCName = (char*)malloc(strlen(tempName) + 1);
        if (tagCName == NULL) return;
        strcpy(tagCName, tempName);
        
        TagElement tagElement;
        tagElement.tagState = TagState_BeginTag;
        tagElement.tagName = tagCName;
        
        if (!_tagStack)
        {
            APMSDKSafeFree(tagCName);
            return;
        }
        bool ret = _tagStack -> push(tagElement);
        if (!ret) {
            APMSDKSafeFree(tagCName);
            return;
        }
        
        constructMsgQueueBody(msgQueueBody);
        msgQueueBody.charValue = tagCName;
        msgQueueBody.sceneType = kSceneTypeBeginTag;
        msgQueueBody.sceneIndex = g_apmSenceIndex;
        msgQueueBody.timeInterval = SDKUtill::getCurrentTimeIntervalMillisecond();
        if(msgQueueBody.charValue != NULL)
        {
            APM_LOG_DEBUG(@"beginTag:%s",tagCName);
            _levelMsgQueue -> postMsg(msgQueueBody);
        }
    }
    else
    {
        APM_LOG_DEBUG(@"current tag :%@ not location scene level,operation invalid",tagName);
    }
}

- (void)endTag
{
    MsgQueueBody        msgQueueBody;
    
    if (![APMCCStrategy sharedInstance].mEnabledModule)
    {
        APM_LOG_DEBUG(@"endTag error switch disable");
        return;
    }
    
    if (!_isInitContext)
    {
        return;
    }
    
    if ([self isCurrentLevelDataValid])
    {
        if (!_tagStack) return;
        TagElement tagElement;
        bool ret = _tagStack -> pop(tagElement);
        APMSDKLog(@"_tagStack->tagName:%s",tagElement.tagName);
        if (!ret)
        {
            APM_LOG_DEBUG(@"end tag invoke error because of begin tag not exist");
            return;
        }
        const char* tagCName = tagElement.tagName;
        if (tagCName == NULL) return;
        
        constructMsgQueueBody(msgQueueBody);
        msgQueueBody.charValue = tagCName;
        msgQueueBody.sceneType = kSceneTypeEndTag;
        msgQueueBody.sceneIndex = g_apmSenceIndex;
        msgQueueBody.timeInterval = SDKUtill::getCurrentTimeIntervalMillisecond();
        if(msgQueueBody.charValue != NULL) _levelMsgQueue -> postMsg(msgQueueBody);
        APMSDKSafeFree(tagCName);
        APM_LOG_DEBUG(@"endTag");
    }
    else
    {
        APM_LOG_DEBUG(@"no BeginTag，operation invalid");
    }
}

- (void)postNetworkStatusFlag:(int8_t)flag status:(int16_t)status
{
    
    MsgQueueBody        msgQueueBody;
    
    if (![APMCCStrategy sharedInstance].mEnabledModule)
    {
        APM_LOG_DEBUG(@"postNetworkStatusFlag error switch disable");
        return;
    }
    if (!_isInitContext)
    {
        return;
    }
    
    if ([self isCurrentLevelDataValid])
    {
        constructMsgQueueBody(msgQueueBody);
        msgQueueBody.flag = flag;
        msgQueueBody.int16Value = status;
        msgQueueBody.sceneIndex = g_apmSenceIndex;
        _networkStatMsgQueue -> postMsg(msgQueueBody);
    }
}

- (PScene)createSceneFlag:(char)flag sceneIndex:(short)sceneIndex sceneType:(short)sceneType
{
    PScene                  scenePtr;
    size_t                  sceneNameLen;
    
    scenePtr = (PScene)malloc(sizeof(Scene));
    APMSDKAssert(scenePtr != NULL, @"PScene malloc memory error");
    if (NULL == scenePtr) return NULL;
    scenePtr -> flag = flag;
    scenePtr -> sceneIndex = g_apmSenceIndex;
    scenePtr -> sceneType = sceneType;
    scenePtr -> timeStamp = SDKHelper::SDKUtill::getCurrentTimeIntervalMillisecond();
    if (_sceneName)
    {
        sceneNameLen = strlen(_sceneName) + 1;
        scenePtr -> sceneStrLen = sceneNameLen;
        scenePtr -> sceneStrstr = (char*)malloc(sceneNameLen);
        APMSDKAssert(scenePtr -> sceneStrstr != NULL, @"scenePtr -> sceneStrstr malloc memory error");
        if (NULL == scenePtr -> sceneStrstr) return scenePtr;
        memset((void*)scenePtr -> sceneStrstr, 0, sceneNameLen);
        strcpy((char*)scenePtr -> sceneStrstr, _sceneName);
    }
    
    return scenePtr;
}

- (void)pushMessageToGloabelBufferQueueAndSafeFree:(PScene)pScene forceWriteToFile:(BOOL)isForce
{
    if (NULL == pScene)
    {
        return;
    }
    [[MessageQueue sharedInstance] pushMessageToGloabelBufferQueue:*pScene forceWriteToFile:isForce];
    [self safeFreeScene:pScene];
}

- (void)safeFreeScene:(PScene)pScene
{
    if (pScene != NULL)
    {
        if (pScene -> sceneStrstr)
        {
            free((void*)pScene -> sceneStrstr);
            pScene -> sceneStrstr = NULL;
        }
        APMSDKSafeFree(pScene);
    }
}

- (void)startWorkThread
{
    
    MsgQueueBody         msgQueueBody;
    PScene               scenePtr;
    NSString*            userID;
    NSString*            local;
    NSString*            version;
    NSString*            cacheFileName = nil;
    int16_t              sceneIndex = 0;
    MsgQueueBody         cacheFileMsg;
    uint64_t             frequencyTotal = 0;
    
    @autoreleasepool
    {
        [[NSThread currentThread] setName:@"APM_IOS_WorkThread"];
    }
    
    dispatch_semaphore_wait(_markLevelsemaphore, DISPATCH_TIME_FOREVER);
    while (YES)
    {
        @autoreleasepool
        {
            while (_levelMsgQueue -> consumeMsgOnce(msgQueueBody))
            {
                if (msgQueueBody.sceneType == kSceneTypeMarkLevel)
                {
                    if (_cacheFileMsgQueue -> consumeMsgOnce(cacheFileMsg))
                    {
                        cacheFileName = [NSString stringWithUTF8String:cacheFileMsg.charValue];
                        
                        APMSDKAssert(cacheFileName != nil, @"cCacheFileName is empty");
                        if (cacheFileName)
                        {
                            if ([[APMCCStrategy sharedInstance] isFeatureEnabled:FEATURE_MMAP])
                            {
                                [[MessageQueue sharedInstance] setCacheFileName:cacheFileName];
                            }
                            else
                            {
                                [[FileManager sharedFileManager] setCacheFileName:cacheFileName];
                            }
                        }
                        _cacheFileMsgQueue -> safeFree(cacheFileMsg);
                    }
                    
                    //reset
                    [[MessageQueue sharedInstance] reset];
                    
                    [self performCollectionElement:@selector(startMonitor)];
                    // 写入文件开始的数据
                    [[MessageQueue sharedInstance] pushMessageToGloabelBufferCustomData:msgQueueBody type:MsgQueueBodyType_FileStartData];
                    TAPM::clearIndexMap();
                    scenePtr = (PScene)msgQueueBody.voidPtr;
                    if (scenePtr)
                    {
                        sceneIndex = scenePtr -> sceneIndex;
                        APMSDKLog(@"upload:_sceneLoadLevel sceneIndex:%d",scenePtr -> sceneIndex);
                        [self pushMessageToGloabelBufferQueueAndSafeFree:scenePtr forceWriteToFile:NO];
                    }
                    
                    _levelMsgQueue -> safeFree(msgQueueBody);
                    
                    break;
                }
                else if (msgQueueBody.sceneType == kSceneTypeMarkComplete)
                {
                    scenePtr = (PScene)msgQueueBody.voidPtr;
                    if (scenePtr)
                    {
                        APMSDKLog(@"upload:_sceneloadLevelComp sceneIndex:%d",scenePtr -> sceneIndex);
                        [self pushMessageToGloabelBufferQueueAndSafeFree:scenePtr forceWriteToFile:NO];
                    }
                }
                else if (msgQueueBody.sceneType == kSceneTypeMarkFin)
                {
                    
                    [self performCollectionElement:@selector(stopMonitor)];
                    
                    //清空所有队列中的信息
                    [self iterateFromeQueue:sceneIndex];
                    scenePtr = (PScene)msgQueueBody.voidPtr;
                    if (scenePtr)
                    {
                        APMSDKLog(@"upload:_sceneloadLevelFin:%d",scenePtr -> sceneIndex);
                        [self pushMessageToGloabelBufferQueueAndSafeFree:scenePtr forceWriteToFile:YES];
                    }
                    
                    constructMsgQueueBody(cacheFileMsg);
                    if(cacheFileName != nil) cacheFileMsg.charValue = [cacheFileName cStringUsingEncoding:NSUTF8StringEncoding];
                    if (cacheFileMsg.charValue != NULL)
                    {
                        _uploadCacheFileMsgQueue -> postMsg(cacheFileMsg);
                        // 上传缓存文件到server
                        dispatch_semaphore_signal(_beginUploadSemaphore);
                    }
                    
                    
                    dispatch_semaphore_wait(_markLevelsemaphore, DISPATCH_TIME_FOREVER);
                }
                else if (msgQueueBody.sceneType == kSceneTypeBeginTag || msgQueueBody.sceneType == kSceneTypeEndTag)
                {
                    
                    [[MessageQueue sharedInstance] pushMessageToGloabelBufferCustomData:msgQueueBody type:MsgQueueBodyType_Tag];
                }
                
                _levelMsgQueue -> safeFree(msgQueueBody);
            }
            
            [self iterateFromeQueue:sceneIndex];
            
            //每frequency秒获取cpu,pss,电量等数据
            if (frequencyTotal++ % _frequency == 0) [self performCollectionElement:@selector(collectionDatas)];
            
            // 用户ID
            if (!_isWriteUserIDToCache)
            {
                userID = [kSDKUserDefault objectForKey:kUserID];
                if (userID)
                {
                    constructMsgQueueBody(msgQueueBody);
                    msgQueueBody.charValue = [userID cStringUsingEncoding:NSUTF8StringEncoding];
                    [[MessageQueue sharedInstance] pushMessageToGloabelBufferCustomData:msgQueueBody type:MsgQueueBodyType_UserID];
                }
                _isWriteUserIDToCache = YES;
            }
            
            // local
            if (!_isWriteLocalToCache)
            {
                local = [kSDKUserDefault objectForKey:kLocal];
                if (local)
                {
                    constructMsgQueueBody(msgQueueBody);
                    msgQueueBody.charValue = [local cStringUsingEncoding:NSUTF8StringEncoding];
                    [[MessageQueue sharedInstance] pushMessageToGloabelBufferCustomData:msgQueueBody type:MsgQueueBodyType_Local];
                }
                _isWriteLocalToCache = YES;
            }
            
            // version
            if (!_isWriteVersionToCache)
            {
                version = [kSDKUserDefault objectForKey:kVersion];
                if (version)
                {
                    constructMsgQueueBody(msgQueueBody);
                    msgQueueBody.charValue = [version cStringUsingEncoding:NSUTF8StringEncoding];
                    [[MessageQueue sharedInstance] pushMessageToGloabelBufferCustomData:msgQueueBody type:MsgQueueBodyType_Version];
                }
                _isWriteVersionToCache = YES;
            }
            
            //ipcUUID
            
            if (_ipcUUID && !_isWriteIPCUUID)
            {
                constructMsgQueueBody(msgQueueBody);
                msgQueueBody.charValue = [_ipcUUID cStringUsingEncoding:NSUTF8StringEncoding];
                [[MessageQueue sharedInstance] pushMessageToGloabelBufferCustomData:msgQueueBody type:MsgQueueBodyType_IPCUUID];
                _isWriteIPCUUID = YES;
            }
            
            sleep(1);
        }
    }
    
}

- (void)startUploadThread
{
    @autoreleasepool
    {
        [[NSThread currentThread] setName:@"APM_IOS_UploadThread"];
    }
  
    while (YES)
    {
        @autoreleasepool
        {
            dispatch_semaphore_wait(_beginUploadSemaphore, DISPATCH_TIME_FOREVER);
            
            MsgQueueBody         msgQueueBody;
            NSString*            fileCacheName;
            
            while (_uploadCacheFileMsgQueue -> consumeMsgOnce(msgQueueBody))
            {
                kApmMetaInfoObj.szUserID = [kSDKUserDefault objectForKey:kUserID];
                fileCacheName = [NSString stringWithUTF8String:msgQueueBody.charValue];
                // 准备上传数据到服务器
                if(fileCacheName != nil) [[FileManager sharedFileManager] uploadToServer:fileCacheName];
                _uploadCacheFileMsgQueue -> safeFree(msgQueueBody);
            }
        }
    }
}

/*- (void)ipcThread
{
    
    [[NSThread currentThread] setName:@"APM_IOS_IPCThread"];
    @autoreleasepool
    {
        SDKIPC*             sdkIPC;
        NSString*           tempICPUUID;
        
        sdkIPC = [[SDKIPC alloc] init];
        if (!sdkIPC) return;
        tempICPUUID = [sdkIPC uuidStr];
        if (tempICPUUID)
        {
            self.ipcUUID = tempICPUUID;
        }
    }
}*/



- (void)iterateFromeQueue:(int16_t)sceneIndex
{
    MsgQueueBody    msgQueueBody;
    ExcludeInfo     ei;
    DetectTimeOut   detectTimeOut;
    //FpsRecorder     fpsValue;
    
    APMSDKAssert(sceneIndex <= g_apmSenceIndex, @"sceneIndex < g_apmSenceIndex is error");
    
    //游戏画质
    while (_qualityMsgQueue -> consumeMsgOnce(msgQueueBody))
    {
        if (msgQueueBody.sceneIndex <= sceneIndex)
        {
            [[MessageQueue sharedInstance] pushMessageToGloabelBufferCustomData:msgQueueBody type:MsgQueueBodyType_Quality];
            _qualityMsgQueue -> safeFree(msgQueueBody);
        }
        else
        {
            break;
        }
    }
    
    while (_deviceLevelMsgQueue -> consumeMsgOnce(msgQueueBody))
    {
        if (msgQueueBody.sceneIndex <= sceneIndex)
        {
            [[MessageQueue sharedInstance] pushMessageToGloabelBufferCustomData:msgQueueBody type:MsgQueueBodyType_DeviceLevel];
            _deviceLevelMsgQueue -> safeFree(msgQueueBody);
        }
        else
        {
            break;
        }
    }
    
    
    // 帧秒数据
    if ([[APMCCStrategy sharedInstance] isFeatureEnabled:FEATURE_ZIGZAG])
    {
         [[MessageQueue sharedInstance] consumeFramesWithCompress:_frameMsgQueue];
    }
   else
    {
        while (_frameMsgQueue -> consumeMsgOnce(msgQueueBody))
        {
            if (msgQueueBody.sceneIndex <= sceneIndex)
            {
                
                [[MessageQueue sharedInstance] pushMessageToGloabelBufferCustomData:msgQueueBody type:MsgQueueBodyType_Frame];
                _frameMsgQueue -> safeFree(msgQueueBody);
            }
            else
            {
                break;
            }
        }
    }


    while (_eventMsgQueue -> consumeMsgOnce(msgQueueBody))
    {
        int32_t             key;
        char*               pChar;
        
        if (msgQueueBody.sceneIndex <= sceneIndex)
        {
            key = msgQueueBody.int32Value;
            if (key >= 302 && key < kGlobalEventBufferCached && msgQueueBody.charValue != NULL)   //全局事件
            {
                
                if (g_sCachedBuffer[key] == NULL)
                {
                    g_sCachedBuffer[key] = (char*)malloc(128);
                    APMSDKAssert(g_sCachedBuffer[key] != NULL, @"g_sCachedBuffer[key] alloc error");
                    if(g_sCachedBuffer[key] != NULL)
                    {
                        memset(g_sCachedBuffer[key], 0, 128);
                        pChar = strcpy(g_sCachedBuffer[key], msgQueueBody.charValue);
                        if (pChar != NULL)
                        {
                            g_sCachedBufferIdx[key] = 1;
                        }
                    }
                }
                else
                {
                    pChar = strcpy(g_sCachedBuffer[key], msgQueueBody.charValue);
                    if (pChar != NULL)
                    {
                        g_sCachedBufferIdx[key] = 1;
                    }
                    else
                    {
                        g_sCachedBufferIdx[key] = 0;
                    }
                }
            }
            
            [[MessageQueue sharedInstance] pushMessageToGloabelBufferCustomData:msgQueueBody type:MsgQueueBodyType_Info];
            
            _eventMsgQueue -> safeFree(msgQueueBody);
        }
        else
        {
            break;
        }
    }
    //网络延迟
    
    while (_latencyMsgQueue -> consumeMsgOnce(msgQueueBody))
    {
        if (msgQueueBody.sceneIndex <= sceneIndex)
        {
            [[MessageQueue sharedInstance] pushMessageToGloabelBufferCustomData:msgQueueBody type:MsgQueueBodyType_NetLatency];
            _latencyMsgQueue -> safeFree(msgQueueBody);
        }
        else
        {
            break;
        }
    }
    
    //回扯地址
    
    while (_distanceMsgQueue -> consumeMsgOnce(msgQueueBody))
    {
        if (msgQueueBody.sceneIndex <= sceneIndex)
        {
            [[MessageQueue sharedInstance] pushMessageToGloabelBufferCustomData:msgQueueBody type:MsgQueueBodyType_LagStatus];
            _distanceMsgQueue -> safeFree(msgQueueBody);
        }
        else
        {
            break;
        }
    }
    
    // 处理网络状态
    
    while (_networkStatMsgQueue -> consumeMsgOnce(msgQueueBody))
    {
        if (msgQueueBody.sceneIndex <= sceneIndex)
        {
            [[MessageQueue sharedInstance] pushMessageToGloabelBufferCustomData:msgQueueBody type:MsgQueueBodyType_NetworkStatus];
            _networkStatMsgQueue -> safeFree(msgQueueBody);
        }
        else
        {
            break;
        }
    }
    
    // 处理app状态
    while (_appStateMsgQueue -> consumeMsgOnce(msgQueueBody))
    {
        if (msgQueueBody.sceneIndex <= sceneIndex)
        {
            [[MessageQueue sharedInstance] pushMessageToGloabelBufferCustomData:msgQueueBody type:MsgQueueBodyType_Appstate];
            _appStateMsgQueue -> safeFree(msgQueueBody);
        }
        else
        {
            break;
        }
    }
    
    // frame state
    if (_sFrameStateJudgerPtr && _sFrameStateJudgerPtr->mSnapshotsStatePtr)
    {
        int eventGap = _sFrameStateJudgerPtr->mSnapshotsStatePtr->getHeadIdx() - _sFrameStateJudgerPtr->mSnapshotsStatePtr->getTailIdx() - 1;//NOTE: 0-1 will never happens
        int eventLen = MIN(eventGap, _sFrameStateJudgerPtr->mSnapshotsStatePtr->getBufferSz() - 1);
        //int queueSz = _sFrameStateJudgerPtr->mSnapshotsStatePtr->getBufferSz();
        if (eventLen > 0)
        {
            unsigned tailIdx = _sFrameStateJudgerPtr->mSnapshotsStatePtr->getTailIdx();
            while (eventLen--)
            {
                tailIdx++;
                SnapshotState* packetPtr = &_sFrameStateJudgerPtr->mSnapshotsStatePtr->get(tailIdx);
                FrameStateS frameState;
                frameState.flag = kFrameStateFlag;
                frameState.timeInterval = packetPtr->mTimeStamp;
                frameState.mX = packetPtr->mCoordinate.mX;
                frameState.mY = packetPtr->mCoordinate.mY;
                frameState.mZ = packetPtr->mCoordinate.mZ;
                
                frameState.mPitch = packetPtr->mRotator.mPitch;
                frameState.mYaw = packetPtr->mRotator.mYaw;
                frameState.mRoll = packetPtr->mRotator.mRoll;
                
                [[MessageQueue sharedInstance] pushMessageToGloabelBufferQueue:frameState];
            }
            
            _sFrameStateJudgerPtr->mSnapshotsStatePtr->resetTailPos(tailIdx);
        }
    }
    
    // exclude
    if (_sExcludeRequestQueuePtr)
    {
        while(_sExcludeRequestQueuePtr->consumeMsgOnce(ei))
        {
            FWRITE_1(kExcludePrefixFlag, NULL);
            FWRITE_4(ei.mTimeStamp,NULL);
            FWRITE_4(ei.mType,NULL);
        }
    }
    
    if ([[APMCCStrategy sharedInstance] isFeatureEnabled:FEATURE_ZIGZAG])
    {
        TAPM::serlizeExtToFileCompress(NULL, kPrefixExtFlag,(unsigned int)sceneIndex);
    }
    else
    {
        TAPM::serlizeExtToFile(NULL, kPrefixExtFlag, (unsigned int)sceneIndex);
    }
    
    //detecttimeout
    if (_detectTimeOutQueuePtr) {
        while (_detectTimeOutQueuePtr -> consumeMsgOnce(detectTimeOut)) {
            
            //char                flag;
            //short               connectServerDetailLen;
            //const char*         connectServerDetail;    // 内容每个服务器用逗号隔开 www.qq.com_43,www.sohu.com_20,www.sina.com.cn_25   43,20,25 为tcp连接每个服务器时间单位毫秒
            //int32_t             gateway[3];             // 连续ping3次路由器耗时单位毫秒
            //short               networkTypeLen;
            //const char*         networkType;
            FWRITE_1(kDetectTimeOutFlag, NULL);
            FWRITE_2(detectTimeOut.connectServerDetailLen, NULL,NULL,NULL);
            FWRITE_Bytes((const char*)detectTimeOut.connectServerDetail,detectTimeOut.connectServerDetailLen,NULL,NULL);
            FWRITE_4(detectTimeOut.gateway[0], NULL);
            FWRITE_4(detectTimeOut.gateway[1], NULL);
            FWRITE_4(detectTimeOut.gateway[2], NULL);
            FWRITE_2(detectTimeOut.networkTypeLen, NULL,NULL,NULL);
            FWRITE_Bytes((const char*)detectTimeOut.networkType,detectTimeOut.networkTypeLen,NULL,NULL);
            
            APMSDKSafeFree(detectTimeOut.connectServerDetail);
            APMSDKSafeFree(detectTimeOut.networkType);
        }
    }
    
    //FPS
    /*if (_fpsRecorderQueuePtr) {
        while (_fpsRecorderQueuePtr -> consumeMsgOnce(fpsValue)) {
            FWRITE_1(kFPSFlag,NULL);
            FWRITE_4(fpsValue.avg,NULL);
            FWRITE_4(fpsValue.max,NULL);
            FWRITE_4(fpsValue.min,NULL);
            FWRITE_4(fpsValue.total,NULL);
            FWRITE_4(fpsValue.heavy,NULL);
            FWRITE_4(fpsValue.flight,NULL);
            FWRITE_4(fpsValue.fcntx0,NULL);
            FWRITE_4(fpsValue.flfps1,NULL);
            FWRITE_4(fpsValue.flfps2,NULL);
            FWRITE_4(fpsValue.flfps3,NULL);
            FWRITE_4(fpsValue.fdotsLen,NULL);
            FWRITE_Bytes(fpsValue.fpsDots, fpsValue.fdotsLen, NULL, NULL);
            APMSDKSafeFree(fpsValue.fpsDots);
        }
    }*/
    
    APMProcessInfoThermalState value;
    if (_thermalState && _thermalState ->_msgQueuePtr) {
      while(_thermalState -> _msgQueuePtr -> consumeMsgOnce(value)) {
          FWRITE_1(value.flag, NULL);
          FWRITE_2(value.vlaue, NULL, NULL, NULL);
      }
    }
}

- (int)markLoadlevel:(const char* )sceneName
{
  
    size_t          sceneNameLen;
    PScene          scenePtr;
    MsgQueueBody    msgQueueBody;
    NSString*       cacheFileName;
    BOOL            result;
    
    [self checkAndInitContext];
    
    if (!sceneName)
    {
        APM_LOG_DEBUG(@"mark load level scene name is NULL");
        sceneName = "NA";
        GCloud::APM::ReportMarkLevelLoad(sceneName, false, GCloudErrorCode_NULL);
        
        return GCloudErrorCode_NULL;
    }
    
    if (![[APMCCStrategy sharedInstance] validCheck:NSStringFromSelector(_cmd) tag:FEATURE_MARK_LEVEL_LOAD]) {
        GCloud::APM::ReportMarkLevelLoad(sceneName, false, GCloudErrorCode_BOOLFalse);
        return GCloudErrorCode_CloseSwitch;
    }
    
    if (!_isInitContext)
    {
        return GCloudErrorCode_unInitalized;
    }
    
    // 手动标记场景结束
    if (_currenLevelState == LevelState_MarkLoadLevel)
    {
        [self markLevelFin];
    }
    if (_currenLevelState == LevelState_MarkLoadLevelCompleted)
    {
        [self markLevelFin];
    }
    // 创建本地文件
    cacheFileName = [kPrefixCacheFileName stringByAppendingFormat:@"%@",SDKUtill::getCurrentFullTime()];
    if (cacheFileName)
    {
        result = [[FileManager sharedFileManager] createCacheFileName:cacheFileName];
        APMSDKAssert(result,@"create cache file error");
        if (!result)
        {
            GCloud::APM::ReportMarkLevelLoad(sceneName, false, GCloudErrorCode_CreateFileError);
            
            return GCloudErrorCode_CreateFileError;
        }
        constructMsgQueueBody(msgQueueBody);
        msgQueueBody.charValue = [cacheFileName UTF8String];
        if(msgQueueBody.charValue != NULL) _cacheFileMsgQueue -> postMsg(msgQueueBody);
    }
    
    g_apmTempSceneTime = time(NULL);
    
    g_apmSenceIndex++;
    if (sceneName)
    {
        sceneNameLen = strlen(sceneName) + 1;
        APMSDKSafeFree(_sceneName);
        // 将场景名称保存
        _sceneName = (char*)malloc(sceneNameLen);
        APMSDKAssert(_sceneName != NULL, @"_sceneName malloc memory error");
        if(NULL != _sceneName)
        {
            memset((void*)_sceneName, 0, sceneNameLen);
            strcpy((char*)_sceneName, sceneName);
        }
    }
    // 获取当前网络类型
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        SDKUtill::networkType = [[[NetworkCollectPerformance alloc]init] getNetworkType];
        kApmMetaInfoObj.wNetwork_type = SDKUtill::networkType;
    });
    
    scenePtr = [self createSceneFlag:kSceneFlag sceneIndex:g_apmSenceIndex sceneType:kSceneTypeMarkLevel];
    if (scenePtr)
    {
        constructMsgQueueBody(msgQueueBody);
        msgQueueBody.voidPtr = scenePtr;
        msgQueueBody.sceneIndex = g_apmSenceIndex;
        msgQueueBody.sceneType = kSceneTypeMarkLevel;
        // 当前画质
        msgQueueBody.int32Value = _currentQuality;
        msgQueueBody.int64Value = _currentDeviceLevel;
        _levelMsgQueue -> postMsg(msgQueueBody);
    }
    
    _isWriteUserIDToCache = NO;
    _isWriteLocalToCache = NO;
    _isWriteVersionToCache = NO;
    _isWriteIPCUUID = NO;
    _lastFrameTimeStamp = 0;
    _markLoadLevelTimeStamp = SDKUtill::getCurrentTimeIntervalMillisecond();
    dispatch_semaphore_signal(_markLevelsemaphore);
    _currenLevelState = LevelState_MarkLoadLevel;
    APM_LOG_EVENT(@"markloadLevel:%s",sceneName);
    GCloud::APM::ReportMarkLevelLoad(sceneName, true, GCloudErrorCode_None);
    
    return GCloudErrorCode_None;
}

/*- (void)saveFps:(float)favg FMax:(int)fmax FMin:(int)fmin Ftotal:(int)ftotal Fheavy:(int)fheavy Flight:(int)flight Fcntx0:(int)fcntx0 Flfps1:(int)flfps1 Flfps2:(int)flfps2 Flfps3:(int)flfps3 Fpsdots:(NSString *)fpsdots{
    /*if (_fpsRecorderQueuePtr) {
        FpsRecorder fpsValue;
        fpsValue.avg = favg * 100;
        fpsValue.max = fmax;
        fpsValue.min = fmin;
        fpsValue.total = ftotal;
        fpsValue.heavy = fheavy;
        fpsValue.flight = flight;
        fpsValue.fcntx0 = fcntx0;
        fpsValue.flfps1 = flfps1;
        fpsValue.flfps2 = flfps2;
        fpsValue.flfps3 = flfps3;
       
        const char* fpsdotsCstr = fpsdots.UTF8String;
        if (fpsdotsCstr) {
            fpsValue.fdotsLen = (int32_t)strlen(fpsdotsCstr);
            fpsValue.fpsDots = strdup(fpsdotsCstr);
        }
        _fpsRecorderQueuePtr -> postMsg(fpsValue);
    }else{
         APM_LOG_DEBUG(@"fpsRecorderQueuePtr is NULL,save fps error");
    }
}*/

- (int)markLoadlevelCompleted
{
    MsgQueueBody         msgQueueBody;
    PScene               scenePtr;
    
    if (![[APMCCStrategy sharedInstance] validCheck:NSStringFromSelector(_cmd) tag:FEATURE_MARK_LEVEL_LOAD_COMPLETED]) {
        return GCloudErrorCode_CloseSwitch;
    }
    
    if (!_isInitContext)
    {
        return GCloudErrorCode_unInitalized;
    }
    
    if (_currenLevelState != LevelState_MarkLoadLevel)
    {
        APM_LOG_DEBUG(@"scene invoke order(markLoadlevelCompleted) error");
        return GCloudErrorCode_SceneLevelStateInvaild;
    }
    _currenLevelState = LevelState_MarkLoadLevelCompleted;
    scenePtr = [self createSceneFlag:kSceneFlag sceneIndex:g_apmSenceIndex sceneType:kSceneTypeMarkComplete];
    if (scenePtr)
    {
        constructMsgQueueBody(msgQueueBody);
        msgQueueBody.voidPtr = scenePtr;
        msgQueueBody.sceneIndex = g_apmSenceIndex;
        msgQueueBody.sceneType = kSceneTypeMarkComplete;
        _levelMsgQueue -> postMsg(msgQueueBody);
    }
    
    APM_LOG_DEBUG(@"markLoadlevelCompleted");
    
    return GCloudErrorCode_None;
}

- (int)markLevelFin
{
    MsgQueueBody          msgQueueBody;
    PScene                scenePtr;

    if (![[APMCCStrategy sharedInstance] validCheck:NSStringFromSelector(_cmd) tag:FEATURE_MARK_LEVEL_FIN]) {
        return GCloudErrorCode_CloseSwitch;
    }
    
    if (!_isInitContext)
    {
        return GCloudErrorCode_unInitalized;
    }
    
    if (_currenLevelState == LevelState_MarkLoadFin || _currenLevelState == LevelState_Unkown)
    {
        APM_LOG_DEBUG(@"scene invoke order(markLevelFin) error");
        return GCloudErrorCode_SceneLevelStateInvaild;
    }
 
    // 场景中使用标签，没有结束标签，手动结束
    while (_tagStack -> getIdex() > 0) [self endTag];
  
    constructMsgQueueBody(msgQueueBody);
    msgQueueBody.sceneIndex = g_apmSenceIndex;
    msgQueueBody.flag = kNetworkTypeFlag;
    msgQueueBody.int16Value = SDKUtill::networkType;
    _networkStatMsgQueue -> postMsg(msgQueueBody);
    
    scenePtr  = [self createSceneFlag:kSceneFlag sceneIndex:g_apmSenceIndex sceneType:kSceneTypeMarkFin];
    if (scenePtr)
    {
        constructMsgQueueBody(msgQueueBody);
        msgQueueBody.voidPtr = scenePtr;
        msgQueueBody.sceneIndex = g_apmSenceIndex;
        msgQueueBody.sceneType = kSceneTypeMarkFin;
        _levelMsgQueue -> postMsg(msgQueueBody);
    }
    
    _currenLevelState = LevelState_MarkLoadFin;
    _isSetQuality = NO;
    _isSetDeviceLevel = NO;
    _markLoadLevelFinTimeStamp = SDKUtill::getCurrentTimeIntervalMillisecond();
    if (_sceneName)
    {
        [self calculateMeanFps:@(_sceneName) start:_markLoadLevelTimeStamp end:_markLoadLevelFinTimeStamp];
    }
    

    _totalLevelFrames = 0;
    APM_LOG_DEBUG(@"markLevelFin");
    
    return GCloudErrorCode_None;
    
}

- (void)performCollectionElement:(SEL)selector
{
    __block TApmCollectPerformance*     gameObj;
    __block IMP                         imp;
    
    [self.collectionObjs enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop){
        
        @autoreleasepool
        {
            gameObj = (TApmCollectPerformance*)obj;
            if (gameObj != nil) {
                imp = [obj methodForSelector:selector];
                ((void(*)(id,SEL))imp)(gameObj,selector);
            }
            
        }
    }];
    
}

- (void)removeAllResouceAndOjbects
{
    
    [self.collectionObjs removeAllObjects];
    _collectionObjs = Nil;
}

- (NSMutableArray* )collectionObjs
{
    NSArray*            objs;
    __block id          gameObj;
    
    // fishhook 以后使用暂时关闭
    //cHook();
    if (!_collectionObjs)
    {
        
        objs = @[
                 [CPUCollectPerformance class],
                 [GPUCollectPerformance class],
                 [MemoryCollectPerformance class],
                 //[DrawcallCollectPerformance class],
                 //[BatteryCollectPerformance class],
                 //[TemperatureCollectPerformance class],
                 [NetworkCollectPerformance class]
                 ];
        _collectionObjs = [[NSMutableArray alloc]initWithCapacity:objs.count];
        __weak typeof(self) weakSelf = self;
        [objs enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            
            gameObj = [[[(Class)obj class] alloc] init];
            __strong typeof(weakSelf) strongSelf = weakSelf;
            [strongSelf -> _collectionObjs addObject:gameObj];
        }];
    }
    
    return _collectionObjs;
}

//获取当前当前设备基本信息
- (void)getCurrentAppInfo
{
    NSDictionary*           infoDictionary;
    //NSString*               appCurVersion;
    NSString*               appCurBuildVersion;
    
    infoDictionary = [[NSBundle mainBundle] infoDictionary];
    //appCurVersion = [infoDictionary objectForKey:@"CFBundleShortVersionString"];
    appCurBuildVersion = [infoDictionary objectForKey:@"CFBundleVersion"];
    
    kApmMetaInfoObj.szAppVersion = DeviceInfo::DeviceInfoHelper::getAppVersion();
    kApmMetaInfoObj.szBuildVersion = appCurBuildVersion;
    kApmMetaInfoObj.wOsType = kOSType;
    kApmMetaInfoObj.randomSeed = g_apmRandom_seed;
    kApmMetaInfoObj.szAppID = _appid;
    kApmMetaInfoObj.szManu = DeviceInfo::DeviceInfoHelper::getBrand();    // e.g. @"iPhone", @"iPod touch"
    kApmMetaInfoObj.szModel = DeviceInfo::DeviceInfoHelper::getDeviceModel();       // e.g. @"iPhone X"
    kApmMetaInfoObj.szCpuArch = SDKUtill::getCPUArchName();
    kApmMetaInfoObj.szVendorUUID = [[UIDevice currentDevice].identifierForVendor UUIDString];
    kApmMetaInfoObj.szUserID = [kSDKUserDefault objectForKey:kUserID];
    kApmMetaInfoObj.dwMem = DeviceInfo::DeviceInfoHelper::getTotalRAMCount();
    kApmMetaInfoObj.dwCpuCore = (int32_t)DeviceInfo::DeviceInfoHelper::getProccessorCount();
    kApmMetaInfoObj.szSystemVersion = SDKUtill::currVersionStr;
    kApmMetaInfoObj.tLaunchTime = _tLauchTime;
    kApmMetaInfoObj.wFlash_size = DeviceInfo::DeviceInfoHelper::getDeviceTotalSpace();
    kApmMetaInfoObj.wFlash_size_free = SDKUtill::getDeviceFreeSpace();
}


- (char*)getCurrentSceneName
{
    const char* tempSceneName = _sceneName;
    if (!tempSceneName)
    {
        tempSceneName = "NA";
    }
    
    return strdup(tempSceneName);
}

- (char*)getErrorMsg:(int)errorCode
{
    const char* errorMsg = SDKHelper::SDKUtill::getErrorMsg(errorCode);
    if (!errorMsg)
    {
        errorMsg = "NA";
    }
    
    return strdup(errorMsg);
}

- (void)dealloc
{
    APMSDKSafeDelete(_eventMsgQueue);
    APMSDKSafeDelete(_latencyMsgQueue);
    APMSDKSafeDelete(_distanceMsgQueue);
    APMSDKSafeDelete(_levelMsgQueue);
    APMSDKSafeDelete(_networkStatMsgQueue);
    APMSDKSafeDelete(_frameMsgQueue);
    APMSDKSafeDelete(_cacheFileMsgQueue);
    APMSDKSafeDelete(_uploadCacheFileMsgQueue);
    APMSDKSafeDelete(_appStateMsgQueue);
    APMSDKSafeDelete(_qualityMsgQueue);
    APMSDKSafeDelete(_deviceLevelMsgQueue);
    APMSDKSafeDelete(_sStreamEventHandlerPtr);
    APMSDKSafeDelete(_sFrameStateJudgerPtr);
    //APMSDKSafeDelete(_fpsRecorderQueuePtr);
    APMSDKSafeDelete(_tagStack);
    APMSDKSafeFree(_sceneName);
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
    if (_enterForegroundObserver) [[NSNotificationCenter defaultCenter] removeObserver:_enterForegroundObserver];
    if (_enterBkgroundObserver) [[NSNotificationCenter defaultCenter] removeObserver:_enterBkgroundObserver];
}

- (void)checkAndInitContext{
    if (!_isInitContext || _isInitContextSuccess) {
        return;
    }
    
    if (!_isInitContextSuccess && [APMCCStrategy sharedInstance].mEnabledModule) {
        [self setupWhenIsCDNEnable];
    }
}

- (BOOL)matchSrc:(NSString *)src regex:(NSString *)regex{
    NSRegularExpression *pattern = [NSRegularExpression regularExpressionWithPattern:regex options:NSRegularExpressionCaseInsensitive error:NULL];
    if (!pattern) return NO;
    return ([pattern numberOfMatchesInString:src options:0 range:NSMakeRange(0, src.length)] > 0);
}

- (const char*)getSceneUniqueId{
    
    const char* uniqueId = [[NSString stringWithFormat:@"%@-%d", SDKUtill::sessionUUID,g_apmSenceIndex] UTF8String];
    if (!uniqueId)
    {
        uniqueId = "NA";
    }
    
    return strdup(uniqueId);
}

@end
