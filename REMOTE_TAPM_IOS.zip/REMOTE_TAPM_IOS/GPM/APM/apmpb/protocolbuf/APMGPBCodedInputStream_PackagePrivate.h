// Protocol Buffers - Google's data interchange format
// Copyright 2008 Google Inc.  All rights reserved.
// https://developers.google.com/protocol-buffers/
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

// This header is private to the ProtobolBuffers library and must NOT be
// included by any sources outside this library. The contents of this file are
// subject to change at any time without notice.

#import "APMGPBCodedInputStream.h"

@class APMGPBUnknownFieldSet;
@class APMGPBFieldDescriptor;

typedef struct APMGPBCodedInputStreamState {
  const uint8_t *bytes;
  size_t bufferSize;
  size_t bufferPos;

  // For parsing subsections of an input stream you can put a hard limit on
  // how much should be read. Normally the limit is the end of the stream,
  // but you can adjust it to anywhere, and if you hit it you will be at the
  // end of the stream, until you adjust the limit.
  size_t currentLimit;
  int32_t lastTag;
  NSUInteger recursionDepth;
} APMGPBCodedInputStreamState;

@interface APMGPBCodedInputStream () {
 @package
  struct APMGPBCodedInputStreamState state_;
  NSData *buffer_;
}

// Group support is deprecated, so we hide this interface from users, but
// support for older data.
- (void)readGroup:(int32_t)fieldNumber
              message:(APMGPBMessage *)message
    extensionRegistry:(APMGPBExtensionRegistry *)extensionRegistry;

// Reads a group field value from the stream and merges it into the given
// UnknownFieldSet.
- (void)readUnknownGroup:(int32_t)fieldNumber
                 message:(APMGPBUnknownFieldSet *)message;

// Reads a map entry.
- (void)readMapEntry:(id)mapDictionary
    extensionRegistry:(APMGPBExtensionRegistry *)extensionRegistry
                field:(APMGPBFieldDescriptor *)field
        parentMessage:(APMGPBMessage *)parentMessage;
@end

CF_EXTERN_C_BEGIN

int32_t APMGPBCodedInputStreamReadTag(APMGPBCodedInputStreamState *state);

double APMGPBCodedInputStreamReadDouble(APMGPBCodedInputStreamState *state);
float APMGPBCodedInputStreamReadFloat(APMGPBCodedInputStreamState *state);
uint64_t APMGPBCodedInputStreamReadUInt64(APMGPBCodedInputStreamState *state);
uint32_t APMGPBCodedInputStreamReadUInt32(APMGPBCodedInputStreamState *state);
int64_t APMGPBCodedInputStreamReadInt64(APMGPBCodedInputStreamState *state);
int32_t APMGPBCodedInputStreamReadInt32(APMGPBCodedInputStreamState *state);
uint64_t APMGPBCodedInputStreamReadFixed64(APMGPBCodedInputStreamState *state);
uint32_t APMGPBCodedInputStreamReadFixed32(APMGPBCodedInputStreamState *state);
int32_t APMGPBCodedInputStreamReadEnum(APMGPBCodedInputStreamState *state);
int32_t APMGPBCodedInputStreamReadSFixed32(APMGPBCodedInputStreamState *state);
int64_t APMGPBCodedInputStreamReadSFixed64(APMGPBCodedInputStreamState *state);
int32_t APMGPBCodedInputStreamReadSInt32(APMGPBCodedInputStreamState *state);
int64_t APMGPBCodedInputStreamReadSInt64(APMGPBCodedInputStreamState *state);
BOOL APMGPBCodedInputStreamReadBool(APMGPBCodedInputStreamState *state);
NSString *APMGPBCodedInputStreamReadRetainedString(APMGPBCodedInputStreamState *state)
    __attribute((ns_returns_retained));
NSData *APMGPBCodedInputStreamReadRetainedBytes(APMGPBCodedInputStreamState *state)
    __attribute((ns_returns_retained));
NSData *APMGPBCodedInputStreamReadRetainedBytesNoCopy(
    APMGPBCodedInputStreamState *state) __attribute((ns_returns_retained));

size_t APMGPBCodedInputStreamPushLimit(APMGPBCodedInputStreamState *state,
                                    size_t byteLimit);
void APMGPBCodedInputStreamPopLimit(APMGPBCodedInputStreamState *state,
                                 size_t oldLimit);
size_t APMGPBCodedInputStreamBytesUntilLimit(APMGPBCodedInputStreamState *state);
BOOL APMGPBCodedInputStreamIsAtEnd(APMGPBCodedInputStreamState *state);
void APMGPBCodedInputStreamCheckLastTagWas(APMGPBCodedInputStreamState *state,
                                        int32_t value);

CF_EXTERN_C_END
