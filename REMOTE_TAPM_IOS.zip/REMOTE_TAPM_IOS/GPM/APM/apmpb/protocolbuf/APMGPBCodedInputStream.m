// Protocol Buffers - Google's data interchange format
// Copyright 2008 Google Inc.  All rights reserved.
// https://developers.google.com/protocol-buffers/
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#import "APMGPBCodedInputStream_PackagePrivate.h"

#import "APMGPBDictionary_PackagePrivate.h"
#import "APMGPBMessage_PackagePrivate.h"
#import "APMGPBUnknownFieldSet_PackagePrivate.h"
#import "APMGPBUtilities_PackagePrivate.h"
#import "APMGPBWireFormat.h"

NSString *const APMGPBCodedInputStreamException =
    APMGPBNSStringifySymbol(APMGPBCodedInputStreamException);

NSString *const APMGPBCodedInputStreamUnderlyingErrorKey =
    APMGPBNSStringifySymbol(APMGPBCodedInputStreamUnderlyingErrorKey);

NSString *const APMGPBCodedInputStreamErrorDomain =
    APMGPBNSStringifySymbol(APMGPBCodedInputStreamErrorDomain);

// Matching:
// https://github.com/protocolbuffers/protobuf/blob/master/java/core/src/main/java/com/google/protobuf/CodedInputStream.java#L62
//  private static final int DEFAULT_RECURSION_LIMIT = 100;
// https://github.com/protocolbuffers/protobuf/blob/master/src/google/protobuf/io/coded_stream.cc#L86
//  int CodedInputStream::default_recursion_limit_ = 100;
static const NSUInteger kDefaultRecursionLimit = 100;

static void RaiseException(NSInteger code, NSString *reason) {
  NSDictionary *errorInfo = nil;
  if ([reason length]) {
    errorInfo = @{ APMGPBErrorReasonKey: reason };
  }
  NSError *error = [NSError errorWithDomain:APMGPBCodedInputStreamErrorDomain
                                       code:code
                                   userInfo:errorInfo];

  NSDictionary *exceptionInfo =
      @{ APMGPBCodedInputStreamUnderlyingErrorKey: error };
  [[NSException exceptionWithName:APMGPBCodedInputStreamException
                           reason:reason
                         userInfo:exceptionInfo] raise];
}

static void CheckRecursionLimit(APMGPBCodedInputStreamState *state) {
  if (state->recursionDepth >= kDefaultRecursionLimit) {
    RaiseException(APMGPBCodedInputStreamErrorRecursionDepthExceeded, nil);
  }
}

static void CheckSize(APMGPBCodedInputStreamState *state, size_t size) {
  size_t newSize = state->bufferPos + size;
  if (newSize > state->bufferSize) {
    RaiseException(APMGPBCodedInputStreamErrorInvalidSize, nil);
  }
  if (newSize > state->currentLimit) {
    // Fast forward to end of currentLimit;
    state->bufferPos = state->currentLimit;
    RaiseException(APMGPBCodedInputStreamErrorSubsectionLimitReached, nil);
  }
}

static int8_t ReadRawByte(APMGPBCodedInputStreamState *state) {
  CheckSize(state, sizeof(int8_t));
  return ((int8_t *)state->bytes)[state->bufferPos++];
}

static int32_t ReadRawLittleEndian32(APMGPBCodedInputStreamState *state) {
  CheckSize(state, sizeof(int32_t));
  int32_t value = OSReadLittleInt32(state->bytes, state->bufferPos);
  state->bufferPos += sizeof(int32_t);
  return value;
}

static int64_t ReadRawLittleEndian64(APMGPBCodedInputStreamState *state) {
  CheckSize(state, sizeof(int64_t));
  int64_t value = OSReadLittleInt64(state->bytes, state->bufferPos);
  state->bufferPos += sizeof(int64_t);
  return value;
}

static int64_t ReadRawVarint64(APMGPBCodedInputStreamState *state) {
  int32_t shift = 0;
  int64_t result = 0;
  while (shift < 64) {
    int8_t b = ReadRawByte(state);
    result |= (int64_t)((uint64_t)(b & 0x7F) << shift);
    if ((b & 0x80) == 0) {
      return result;
    }
    shift += 7;
  }
  RaiseException(APMGPBCodedInputStreamErrorInvalidVarInt, @"Invalid VarInt64");
  return 0;
}

static int32_t ReadRawVarint32(APMGPBCodedInputStreamState *state) {
  return (int32_t)ReadRawVarint64(state);
}

static void SkipRawData(APMGPBCodedInputStreamState *state, size_t size) {
  CheckSize(state, size);
  state->bufferPos += size;
}

double APMGPBCodedInputStreamReadDouble(APMGPBCodedInputStreamState *state) {
  int64_t value = ReadRawLittleEndian64(state);
  return APMGPBConvertInt64ToDouble(value);
}

float APMGPBCodedInputStreamReadFloat(APMGPBCodedInputStreamState *state) {
  int32_t value = ReadRawLittleEndian32(state);
  return APMGPBConvertInt32ToFloat(value);
}

uint64_t APMGPBCodedInputStreamReadUInt64(APMGPBCodedInputStreamState *state) {
  uint64_t value = ReadRawVarint64(state);
  return value;
}

uint32_t APMGPBCodedInputStreamReadUInt32(APMGPBCodedInputStreamState *state) {
  uint32_t value = ReadRawVarint32(state);
  return value;
}

int64_t APMGPBCodedInputStreamReadInt64(APMGPBCodedInputStreamState *state) {
  int64_t value = ReadRawVarint64(state);
  return value;
}

int32_t APMGPBCodedInputStreamReadInt32(APMGPBCodedInputStreamState *state) {
  int32_t value = ReadRawVarint32(state);
  return value;
}

uint64_t APMGPBCodedInputStreamReadFixed64(APMGPBCodedInputStreamState *state) {
  uint64_t value = ReadRawLittleEndian64(state);
  return value;
}

uint32_t APMGPBCodedInputStreamReadFixed32(APMGPBCodedInputStreamState *state) {
  uint32_t value = ReadRawLittleEndian32(state);
  return value;
}

int32_t APMGPBCodedInputStreamReadEnum(APMGPBCodedInputStreamState *state) {
  int32_t value = ReadRawVarint32(state);
  return value;
}

int32_t APMGPBCodedInputStreamReadSFixed32(APMGPBCodedInputStreamState *state) {
  int32_t value = ReadRawLittleEndian32(state);
  return value;
}

int64_t APMGPBCodedInputStreamReadSFixed64(APMGPBCodedInputStreamState *state) {
  int64_t value = ReadRawLittleEndian64(state);
  return value;
}

int32_t APMGPBCodedInputStreamReadSInt32(APMGPBCodedInputStreamState *state) {
  int32_t value = APMGPBDecodeZigZag32(ReadRawVarint32(state));
  return value;
}

int64_t APMGPBCodedInputStreamReadSInt64(APMGPBCodedInputStreamState *state) {
  int64_t value = APMGPBDecodeZigZag64(ReadRawVarint64(state));
  return value;
}

BOOL APMGPBCodedInputStreamReadBool(APMGPBCodedInputStreamState *state) {
  return ReadRawVarint32(state) != 0;
}

int32_t APMGPBCodedInputStreamReadTag(APMGPBCodedInputStreamState *state) {
  if (APMGPBCodedInputStreamIsAtEnd(state)) {
    state->lastTag = 0;
    return 0;
  }

  state->lastTag = ReadRawVarint32(state);
  // Tags have to include a valid wireformat.
  if (!APMGPBWireFormatIsValidTag(state->lastTag)) {
    RaiseException(APMGPBCodedInputStreamErrorInvalidTag,
                   @"Invalid wireformat in tag.");
  }
  // Zero is not a valid field number.
  if (APMGPBWireFormatGetTagFieldNumber(state->lastTag) == 0) {
    RaiseException(APMGPBCodedInputStreamErrorInvalidTag,
                   @"A zero field number on the wire is invalid.");
  }
  return state->lastTag;
}

NSString *APMGPBCodedInputStreamReadRetainedString(
    APMGPBCodedInputStreamState *state) {
  int32_t size = ReadRawVarint32(state);
  NSString *result;
  if (size == 0) {
    result = @"";
  } else {
    CheckSize(state, size);
    result = [[NSString alloc] initWithBytes:&state->bytes[state->bufferPos]
                                      length:size
                                    encoding:NSUTF8StringEncoding];
    state->bufferPos += size;
    if (!result) {
#ifdef DEBUG
      // https://developers.google.com/protocol-buffers/docs/proto#scalar
      NSLog(@"UTF-8 failure, is some field type 'string' when it should be "
            @"'bytes'?");
#endif
      RaiseException(APMGPBCodedInputStreamErrorInvalidUTF8, nil);
    }
  }
  return result;
}

NSData *APMGPBCodedInputStreamReadRetainedBytes(APMGPBCodedInputStreamState *state) {
  int32_t size = ReadRawVarint32(state);
  if (size < 0) return nil;
  CheckSize(state, size);
  NSData *result = [[NSData alloc] initWithBytes:state->bytes + state->bufferPos
                                          length:size];
  state->bufferPos += size;
  return result;
}

NSData *APMGPBCodedInputStreamReadRetainedBytesNoCopy(
    APMGPBCodedInputStreamState *state) {
  int32_t size = ReadRawVarint32(state);
  if (size < 0) return nil;
  CheckSize(state, size);
  // Cast is safe because freeWhenDone is NO.
  NSData *result = [[NSData alloc]
      initWithBytesNoCopy:(void *)(state->bytes + state->bufferPos)
                   length:size
             freeWhenDone:NO];
  state->bufferPos += size;
  return result;
}

size_t APMGPBCodedInputStreamPushLimit(APMGPBCodedInputStreamState *state,
                                    size_t byteLimit) {
  byteLimit += state->bufferPos;
  size_t oldLimit = state->currentLimit;
  if (byteLimit > oldLimit) {
    RaiseException(APMGPBCodedInputStreamErrorInvalidSubsectionLimit, nil);
  }
  state->currentLimit = byteLimit;
  return oldLimit;
}

void APMGPBCodedInputStreamPopLimit(APMGPBCodedInputStreamState *state,
                                 size_t oldLimit) {
  state->currentLimit = oldLimit;
}

size_t APMGPBCodedInputStreamBytesUntilLimit(APMGPBCodedInputStreamState *state) {
  return state->currentLimit - state->bufferPos;
}

BOOL APMGPBCodedInputStreamIsAtEnd(APMGPBCodedInputStreamState *state) {
  return (state->bufferPos == state->bufferSize) ||
         (state->bufferPos == state->currentLimit);
}

void APMGPBCodedInputStreamCheckLastTagWas(APMGPBCodedInputStreamState *state,
                                        int32_t value) {
  if (state->lastTag != value) {
    RaiseException(APMGPBCodedInputStreamErrorInvalidTag, @"Unexpected tag read");
  }
}

@implementation APMGPBCodedInputStream

+ (instancetype)streamWithData:(NSData *)data {
  return [[[self alloc] initWithData:data] autorelease];
}

- (instancetype)initWithData:(NSData *)data {
  if ((self = [super init])) {
#ifdef DEBUG
    NSCAssert([self class] == [APMGPBCodedInputStream class],
              @"Subclassing of APMGPBCodedInputStream is not allowed.");
#endif
    buffer_ = [data retain];
    state_.bytes = (const uint8_t *)[data bytes];
    state_.bufferSize = [data length];
    state_.currentLimit = state_.bufferSize;
  }
  return self;
}

- (void)dealloc {
  [buffer_ release];
  [super dealloc];
}

// Direct access is use for speed, to avoid even internally declaring things
// read/write, etc. The warning is enabled in the project to ensure code calling
// protos can turn on -Wdirect-ivar-access without issues.
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdirect-ivar-access"

- (int32_t)readTag {
  return APMGPBCodedInputStreamReadTag(&state_);
}

- (void)checkLastTagWas:(int32_t)value {
  APMGPBCodedInputStreamCheckLastTagWas(&state_, value);
}

- (BOOL)skipField:(int32_t)tag {
  NSAssert(APMGPBWireFormatIsValidTag(tag), @"Invalid tag");
  switch (APMGPBWireFormatGetTagWireType(tag)) {
    case APMGPBWireFormatVarint:
      APMGPBCodedInputStreamReadInt32(&state_);
      return YES;
    case APMGPBWireFormatFixed64:
      SkipRawData(&state_, sizeof(int64_t));
      return YES;
    case APMGPBWireFormatLengthDelimited:
      SkipRawData(&state_, ReadRawVarint32(&state_));
      return YES;
    case APMGPBWireFormatStartGroup:
      [self skipMessage];
      APMGPBCodedInputStreamCheckLastTagWas(
          &state_, APMGPBWireFormatMakeTag(APMGPBWireFormatGetTagFieldNumber(tag),
                                        APMGPBWireFormatEndGroup));
      return YES;
    case APMGPBWireFormatEndGroup:
      return NO;
    case APMGPBWireFormatFixed32:
      SkipRawData(&state_, sizeof(int32_t));
      return YES;
  }
}

- (void)skipMessage {
  while (YES) {
    int32_t tag = APMGPBCodedInputStreamReadTag(&state_);
    if (tag == 0 || ![self skipField:tag]) {
      return;
    }
  }
}

- (BOOL)isAtEnd {
  return APMGPBCodedInputStreamIsAtEnd(&state_);
}

- (size_t)position {
  return state_.bufferPos;
}

- (size_t)pushLimit:(size_t)byteLimit {
  return APMGPBCodedInputStreamPushLimit(&state_, byteLimit);
}

- (void)popLimit:(size_t)oldLimit {
  APMGPBCodedInputStreamPopLimit(&state_, oldLimit);
}

- (double)readDouble {
  return APMGPBCodedInputStreamReadDouble(&state_);
}

- (float)readFloat {
  return APMGPBCodedInputStreamReadFloat(&state_);
}

- (uint64_t)readUInt64 {
  return APMGPBCodedInputStreamReadUInt64(&state_);
}

- (int64_t)readInt64 {
  return APMGPBCodedInputStreamReadInt64(&state_);
}

- (int32_t)readInt32 {
  return APMGPBCodedInputStreamReadInt32(&state_);
}

- (uint64_t)readFixed64 {
  return APMGPBCodedInputStreamReadFixed64(&state_);
}

- (uint32_t)readFixed32 {
  return APMGPBCodedInputStreamReadFixed32(&state_);
}

- (BOOL)readBool {
  return APMGPBCodedInputStreamReadBool(&state_);
}

- (NSString *)readString {
  return [APMGPBCodedInputStreamReadRetainedString(&state_) autorelease];
}

- (void)readGroup:(int32_t)fieldNumber
              message:(APMGPBMessage *)message
    extensionRegistry:(APMGPBExtensionRegistry *)extensionRegistry {
  CheckRecursionLimit(&state_);
  ++state_.recursionDepth;
  [message mergeFromCodedInputStream:self extensionRegistry:extensionRegistry];
  APMGPBCodedInputStreamCheckLastTagWas(
      &state_, APMGPBWireFormatMakeTag(fieldNumber, APMGPBWireFormatEndGroup));
  --state_.recursionDepth;
}

- (void)readUnknownGroup:(int32_t)fieldNumber
                 message:(APMGPBUnknownFieldSet *)message {
  CheckRecursionLimit(&state_);
  ++state_.recursionDepth;
  [message mergeFromCodedInputStream:self];
  APMGPBCodedInputStreamCheckLastTagWas(
      &state_, APMGPBWireFormatMakeTag(fieldNumber, APMGPBWireFormatEndGroup));
  --state_.recursionDepth;
}

- (void)readMessage:(APMGPBMessage *)message
    extensionRegistry:(APMGPBExtensionRegistry *)extensionRegistry {
  CheckRecursionLimit(&state_);
  int32_t length = ReadRawVarint32(&state_);
  size_t oldLimit = APMGPBCodedInputStreamPushLimit(&state_, length);
  ++state_.recursionDepth;
  [message mergeFromCodedInputStream:self extensionRegistry:extensionRegistry];
  APMGPBCodedInputStreamCheckLastTagWas(&state_, 0);
  --state_.recursionDepth;
  APMGPBCodedInputStreamPopLimit(&state_, oldLimit);
}

- (void)readMapEntry:(id)mapDictionary
    extensionRegistry:(APMGPBExtensionRegistry *)extensionRegistry
                field:(APMGPBFieldDescriptor *)field
        parentMessage:(APMGPBMessage *)parentMessage {
  CheckRecursionLimit(&state_);
  int32_t length = ReadRawVarint32(&state_);
  size_t oldLimit = APMGPBCodedInputStreamPushLimit(&state_, length);
  ++state_.recursionDepth;
  APMGPBDictionaryReadEntry(mapDictionary, self, extensionRegistry, field,
                         parentMessage);
  APMGPBCodedInputStreamCheckLastTagWas(&state_, 0);
  --state_.recursionDepth;
  APMGPBCodedInputStreamPopLimit(&state_, oldLimit);
}

- (NSData *)readBytes {
  return [APMGPBCodedInputStreamReadRetainedBytes(&state_) autorelease];
}

- (uint32_t)readUInt32 {
  return APMGPBCodedInputStreamReadUInt32(&state_);
}

- (int32_t)readEnum {
  return APMGPBCodedInputStreamReadEnum(&state_);
}

- (int32_t)readSFixed32 {
  return APMGPBCodedInputStreamReadSFixed32(&state_);
}

- (int64_t)readSFixed64 {
  return APMGPBCodedInputStreamReadSFixed64(&state_);
}

- (int32_t)readSInt32 {
  return APMGPBCodedInputStreamReadSInt32(&state_);
}

- (int64_t)readSInt64 {
  return APMGPBCodedInputStreamReadSInt64(&state_);
}

#pragma clang diagnostic pop

@end
