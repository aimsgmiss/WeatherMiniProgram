// Protocol Buffers - Google's data interchange format
// Copyright 2016 Google Inc.  All rights reserved.
// https://developers.google.com/protocol-buffers/
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#import "APMGPBCodedOutputStream.h"

NS_ASSUME_NONNULL_BEGIN

CF_EXTERN_C_BEGIN

size_t APMGPBComputeDoubleSize(int32_t fieldNumber, double value)
    __attribute__((const));
size_t APMGPBComputeFloatSize(int32_t fieldNumber, float value)
    __attribute__((const));
size_t APMGPBComputeUInt64Size(int32_t fieldNumber, uint64_t value)
    __attribute__((const));
size_t APMGPBComputeInt64Size(int32_t fieldNumber, int64_t value)
    __attribute__((const));
size_t APMGPBComputeInt32Size(int32_t fieldNumber, int32_t value)
    __attribute__((const));
size_t APMGPBComputeFixed64Size(int32_t fieldNumber, uint64_t value)
    __attribute__((const));
size_t APMGPBComputeFixed32Size(int32_t fieldNumber, uint32_t value)
    __attribute__((const));
size_t APMGPBComputeBoolSize(int32_t fieldNumber, BOOL value)
    __attribute__((const));
size_t APMGPBComputeStringSize(int32_t fieldNumber, NSString *value)
    __attribute__((const));
size_t APMGPBComputeGroupSize(int32_t fieldNumber, APMGPBMessage *value)
    __attribute__((const));
size_t APMGPBComputeUnknownGroupSize(int32_t fieldNumber,
                                  APMGPBUnknownFieldSet *value)
    __attribute__((const));
size_t APMGPBComputeMessageSize(int32_t fieldNumber, APMGPBMessage *value)
    __attribute__((const));
size_t APMGPBComputeBytesSize(int32_t fieldNumber, NSData *value)
    __attribute__((const));
size_t APMGPBComputeUInt32Size(int32_t fieldNumber, uint32_t value)
    __attribute__((const));
size_t APMGPBComputeSFixed32Size(int32_t fieldNumber, int32_t value)
    __attribute__((const));
size_t APMGPBComputeSFixed64Size(int32_t fieldNumber, int64_t value)
    __attribute__((const));
size_t APMGPBComputeSInt32Size(int32_t fieldNumber, int32_t value)
    __attribute__((const));
size_t APMGPBComputeSInt64Size(int32_t fieldNumber, int64_t value)
    __attribute__((const));
size_t APMGPBComputeTagSize(int32_t fieldNumber) __attribute__((const));
size_t APMGPBComputeWireFormatTagSize(int field_number, APMGPBDataType dataType)
    __attribute__((const));

size_t APMGPBComputeDoubleSizeNoTag(double value) __attribute__((const));
size_t APMGPBComputeFloatSizeNoTag(float value) __attribute__((const));
size_t APMGPBComputeUInt64SizeNoTag(uint64_t value) __attribute__((const));
size_t APMGPBComputeInt64SizeNoTag(int64_t value) __attribute__((const));
size_t APMGPBComputeInt32SizeNoTag(int32_t value) __attribute__((const));
size_t APMGPBComputeFixed64SizeNoTag(uint64_t value) __attribute__((const));
size_t APMGPBComputeFixed32SizeNoTag(uint32_t value) __attribute__((const));
size_t APMGPBComputeBoolSizeNoTag(BOOL value) __attribute__((const));
size_t APMGPBComputeStringSizeNoTag(NSString *value) __attribute__((const));
size_t APMGPBComputeGroupSizeNoTag(APMGPBMessage *value) __attribute__((const));
size_t APMGPBComputeUnknownGroupSizeNoTag(APMGPBUnknownFieldSet *value)
    __attribute__((const));
size_t APMGPBComputeMessageSizeNoTag(APMGPBMessage *value) __attribute__((const));
size_t APMGPBComputeBytesSizeNoTag(NSData *value) __attribute__((const));
size_t APMGPBComputeUInt32SizeNoTag(int32_t value) __attribute__((const));
size_t APMGPBComputeEnumSizeNoTag(int32_t value) __attribute__((const));
size_t APMGPBComputeSFixed32SizeNoTag(int32_t value) __attribute__((const));
size_t APMGPBComputeSFixed64SizeNoTag(int64_t value) __attribute__((const));
size_t APMGPBComputeSInt32SizeNoTag(int32_t value) __attribute__((const));
size_t APMGPBComputeSInt64SizeNoTag(int64_t value) __attribute__((const));

// Note that this will calculate the size of 64 bit values truncated to 32.
size_t APMGPBComputeSizeTSizeAsInt32NoTag(size_t value) __attribute__((const));

size_t APMGPBComputeRawVarint32Size(int32_t value) __attribute__((const));
size_t APMGPBComputeRawVarint64Size(int64_t value) __attribute__((const));

// Note that this will calculate the size of 64 bit values truncated to 32.
size_t APMGPBComputeRawVarint32SizeForInteger(NSInteger value)
    __attribute__((const));

// Compute the number of bytes that would be needed to encode a
// MessageSet extension to the stream.  For historical reasons,
// the wire format differs from normal fields.
size_t APMGPBComputeMessageSetExtensionSize(int32_t fieldNumber, APMGPBMessage *value)
    __attribute__((const));

// Compute the number of bytes that would be needed to encode an
// unparsed MessageSet extension field to the stream.  For
// historical reasons, the wire format differs from normal fields.
size_t APMGPBComputeRawMessageSetExtensionSize(int32_t fieldNumber, NSData *value)
    __attribute__((const));

size_t APMGPBComputeEnumSize(int32_t fieldNumber, int32_t value)
    __attribute__((const));

CF_EXTERN_C_END

NS_ASSUME_NONNULL_END
