//
//  TApmApiInterfaceObject.m
//  SDK
//  Created by xiang lin on 11/12/2017.
//  Copyright © 2017 xiang lin. All rights reserved.
//

#import "TApmApiSingleInstance.h"
#import "TApmLog.h"
#if defined(__cplusplus)
extern "C"
{
#endif
    
    int g_InitContext(const char* appid)
    {
        NSString*       appidStr;
        
        if (!appid)
        {
            APM_LOG_DEBUG(@"appid empty,operation invalid");
            appidStr = @"NA";
        }
        else appidStr = [NSString stringWithUTF8String:appid];
        
        return [[TApmApiSingleInstance sharedInstance] initContext:appidStr];
    }
    
    int g_MarkLoadlevel(const char* sceneName,int quality)
    {
        return [[TApmApiSingleInstance sharedInstance] markLoadlevel:sceneName];
    }
    
    int g_MarkLoadlevelCompleted(void)
    {
        return [[TApmApiSingleInstance sharedInstance] markLoadlevelCompleted];
    }
    
    int g_MarkLevelFin()
    {
        return [[TApmApiSingleInstance sharedInstance] markLevelFin];
    }
    
    void g_PostFrame(float deltaSeconds)
    {
        [[TApmApiSingleInstance sharedInstance] postFrame:deltaSeconds];
    }
    
     void g_SetQuality(int32_t quality)
    {
        
        [[TApmApiSingleInstance sharedInstance] setQuality:quality];
    }
    
    void g_SetDeviceLevel(int32_t deviceLevel)
    {
        [[TApmApiSingleInstance sharedInstance] setDeviceLevel:deviceLevel];
    }
    
    void g_SetUserID(const char* userID)
    {
        if (!userID)
        {
            APM_LOG_DEBUG(@" UserID empty,operation invalid");
            return;
        }
        
        [[TApmApiSingleInstance sharedInstance] setUserID:userID];
    }
    
    void g_SetLocal(const char* cLocal)
    {
    
        if (!cLocal)
        {
            APM_LOG_DEBUG(@" Local empty,operation invalid");
            return;
        }
        
        [[TApmApiSingleInstance sharedInstance] setLocal:[NSString stringWithUTF8String:cLocal]];
    }
    
    void g_BeginTag(const char* tagName)
    {
        
        if (!tagName)
        {
            APM_LOG_DEBUG(@"tagName empty,operation invalid");
            return;
        }
        [[TApmApiSingleInstance sharedInstance] beginTag:[NSString stringWithUTF8String:tagName]];
    }

    void g_EndTag(void)
    {
    
        [[TApmApiSingleInstance sharedInstance] endTag];
    }
    
    void g_PostNTL(int32_t latency)
    {
      
        [[TApmApiSingleInstance sharedInstance] postNTL:latency];
    }
   
    void g_PostLagStatus(int32_t distance)
    {
      
        [[TApmApiSingleInstance sharedInstance] postLagStatus:distance];
    }
    
    void g_PostEvent(int32_t key,const char* info)
    {
      
        if (key < 0)
        {
            APM_LOG_DEBUG(@"event key less than 0,operation invalid");
            return;
        }
        if (!info) return;
        
        [[TApmApiSingleInstance sharedInstance] postEvent:key info:info];
    }
    
    void g_SetVersionIden(const char* version)
    {
        
        if (!version)
        {
            APM_LOG_DEBUG(@"version empty,operation invalid");
            return;
        }
        
        [[TApmApiSingleInstance sharedInstance] setVersionIden:[NSString stringWithUTF8String:version]];
    }
    
   
   void g_LinkSession(const char* eventName)
    {
        if (!eventName)
        {
            APM_LOG_DEBUG(@"step event link session name is NULL");
            return;
        }
        
        [[TApmApiSingleInstance sharedInstance] linkStreamEventSession:[NSString stringWithUTF8String:eventName]];
    }
    
    void g_InitStepEventContext()
    {
        [[TApmApiSingleInstance sharedInstance] initStepEventContext];
    }

    
    void g_ReleaseStepEventContext()
    {
        [[TApmApiSingleInstance sharedInstance] releaseStepEventContext];
    }
    
    void g_PostStepEvent(const char* eventName,int stepId,int status,int code,const char* msg,const char* extDefinekey)
    {
        if (eventName == NULL)
        {
            eventName = "NA";
            APM_LOG_DEBUG(@"step event event name is NULL");
        }
        
        if (msg == NULL)
        {
            msg = "NA";
            APM_LOG_DEBUG(@"step event msg is NULL");
        }
        
        if (extDefinekey == NULL)
        {
            extDefinekey = "NA";
            APM_LOG_DEBUG(@"step event extDefinekey is NULL");
        }
        
        [[TApmApiSingleInstance sharedInstance] postStepEvent:eventName stepId:stepId status:status code:code msg:msg extDefineKey:extDefinekey];
    }
    
    void g_PostStreamEvent(int stepId, int code, int status, const char* msg)
    {
        //deprecated
    }
    
    int g_GetDeviceLevel(const char* absolutePath,const char* configLevel)
    {
        if (configLevel == NULL)
        {
            APM_LOG_DEBUG(@"device level configLevel name is NULL");
            return 0;
        }
        
        if (absolutePath == NULL)
        {
            APM_LOG_DEBUG(@"device level absolutePath is NULL");
            return 0;
        }
        
        APM_LOG_DEBUG(@"begin get device level async absolutePath:%@,config level:%@",@(absolutePath),@(configLevel));
        return [[TApmApiSingleInstance sharedInstance] getDeviceLevelAbsPath:@(absolutePath) configLevel:@(configLevel)];
    }
    
    
    int g_GetDeviceLevelSyncFromServer(const char* absolutePath, const char* configLevel){
        @autoreleasepool {
            if (configLevel == NULL)
            {
                APM_LOG_DEBUG(@"device level configLevel name is NULL");
                return 0;
            }
            
            if (absolutePath == NULL)
            {
                APM_LOG_DEBUG(@"device level absolutePath is NULL");
                return 0;
            }
            APM_LOG_DEBUG(@"begin get device level sync absolutePath:%@,config level:%@",@(absolutePath),@(configLevel));
            return [[TApmApiSingleInstance sharedInstance] ayncGetDeviceLevelWithAbsPath:@(absolutePath) configLevel:@(configLevel)];
        }
    }
    
    void g_PostCoordinate(int x, int y, int z, int pitch, int yaw, int roll)
    {
        [[TApmApiSingleInstance sharedInstance] postCoordinate:x y:y z:z pitch:pitch yaw:yaw roll:roll];
    }
    
    void g_BeginExclude()
    {
        [[TApmApiSingleInstance sharedInstance] beginExclude];
    }
   
    void g_EndExclude()
    {
        [[TApmApiSingleInstance sharedInstance] endExclude];
    }
    
    float g_GetInstantFps()
    {
        return [[TApmApiSingleInstance sharedInstance] getInstantFps];
    }
    
    float g_GetSceneMeanFps(const char* sceneName)
    {
        if (!sceneName)
        {
            APM_LOG_DEBUG(@"get scene meap fps name is NULL");
            return 0.0;
        }
        
        return [[TApmApiSingleInstance sharedInstance] getSceneMeanFps:[NSString stringWithUTF8String:sceneName]];
    }
    
    int g_GetSceneMaxPss() //MB
    {
        return [[TApmApiSingleInstance sharedInstance] getSceneMaxPss];
    }
    
    int g_GetSceneTotalTime()
    {
        return [[TApmApiSingleInstance sharedInstance] getSceneTotalTime];
    }
    
    int g_GetSceneTotalFrames()
    {
        return [[TApmApiSingleInstance sharedInstance] getSceneTotalFrames];
    }
    
     char* g_GetCurrentSceneName()
    {
        return [[TApmApiSingleInstance sharedInstance] getCurrentSceneName];
    }
    
    char* g_GetErrorMsg(int errorCode)
    {
        return [[TApmApiSingleInstance sharedInstance] getErrorMsg:errorCode];
    }
    
    int g_GetSceneLoadedTime()
    {
        return [[TApmApiSingleInstance sharedInstance] markLoadLevelTimeStamp];
    }
    
#if defined(__cplusplus)
}
#endif





