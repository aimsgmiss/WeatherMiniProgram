//
//  SDKMMapWriterBuffer.hpp
//  LearnOpenGLES
//
//  Created by yongpengliang on 2019/6/13.
//  Copyright © 2019 xianglin. All rights reserved.
//

#ifndef SDKMMapWriterBuffer_hpp
#define SDKMMapWriterBuffer_hpp

#import "SDKBuf.h"
#import "TApmLog.h"


namespace TAPMIOS_SDKBuf
{

#define kSDKMMapWriterBufferFileName @"fileName"
#define kSDKMMapWriterBufferFileMaxIndex @"maxIndex"
#define  kSDKMMapWriterBufferFileSuffix @".part"

using namespace mmapfw;

class SDKMMapWriterBuffer : public SDKWriteBuffer{
    
private:
    MmapFileWriter *m_writer;
    int     m_mmapSize;
    char    *m_fileName;
    int     m_fileIndex;
    
    void openNewFileWithFileNameIndexIncrease(){
        m_fileIndex++;
        set(m_fileName,0);
    }

    
public:
    SDKMMapWriterBuffer(){
        m_writer = NULL;
        m_mmapSize = getpagesize() * 32;
        m_fileIndex = 0;
        m_fileName = NULL;
    }
    
    virtual ~SDKMMapWriterBuffer(){
        if (m_writer != NULL) {
            delete m_writer;
            m_writer = NULL;
        }
        
        if (m_fileName && strlen(m_fileName) > 0) {
            free(m_fileName);
            m_fileName = NULL;
        }
    }
    
    //resetIndex: 是否将m_file_index置为0
    bool set(char *fileName, int resetIndex){
        if (fileName == NULL) {
            APM_LOG_DEBUG(@"SDKMMapWriteBuffer::set parameter file_name is NULL");
            return false;
        }
        
        if (resetIndex) {
            m_fileIndex = 0;
            m_fileName = strdup(fileName);
        }
        
        if (m_writer != NULL) {
            delete m_writer;
            m_writer = NULL;
        }
        
        FileManager *fileManager = [FileManager sharedFileManager];
        NSString *partFileName = [NSString stringWithFormat:@"%s_%d.part",m_fileName, m_fileIndex];
        BOOL ret = [fileManager createCacheFileName:partFileName];
        if (!ret) {
            APM_LOG_DEBUG(@"SDKMMapWriteBuffer::set create file of name: %@ failure.", partFileName);
            return false;
        }
        
        NSString *path = [fileManager constructCachePath:partFileName];
        if (!path.length) {
            APM_LOG_DEBUG(@"SDKMMapWriteBuffer::set get file: %@ path failure.", partFileName);
            return false;
        }
        
        MmapFileWriter *writer = new MmapFileWriter(path.UTF8String, m_mmapSize);
        if (!writer->isValid()) {
            APM_LOG_DEBUG(@"SDKMMapWriteBuffer::set MmapFileWriter init  failure.");
            delete writer;
            return false;
        }
        m_writer = writer;
        return true;
    }
    
    SDKError::ErrorType writeBytes(const void* src, int count)
    {
        if (count < 0 || count > (16 * 1024 + 1))
        {
            return SDKError::SDK_ERR_INT_LEN_TOO_BIG;
        }
        
        if (NULL == src)
        {
            return SDKError::SDK_ERR_ARG_POINTER_IS_NULL;
        }
        
        if (m_writer->currentSize() + count >=  m_writer->mmapSize()) {
            openNewFileWithFileNameIndexIncrease();
        }
        
        m_writer->append((uint8_t *)src, count);
        
        return SDKError::SDK_NO_ERROR;
    }
    
    SDKError::ErrorType writeChar(const char src)
    {
        return writeUInt8(*(uint8_t*)&src);
    }
    
    
    SDKError::ErrorType writeInt8(const int8_t src)
    {
        return writeUInt8(*(uint8_t*)&src);
    }
    
    SDKError::ErrorType writeUInt8(const uint8_t src)
    {
        if (m_writer == NULL) {
            return SDKError::SDK_ERR_NULL_POINTER;
        }
        
        if (m_writer->currentSize() + sizeof(src) >=  m_writer->mmapSize()) {
            openNewFileWithFileNameIndexIncrease();
        }
        
        m_writer->append(&src, sizeof(src));
        return SDKError::SDK_NO_ERROR;
    }
    
    SDKError::ErrorType writeInt16(const int16_t src)
    {
        return writeUInt16(*(uint16_t *)&src);
    }
    
    SDKError::ErrorType writeUInt16(const uint16_t src)
    {
        if (m_writer == NULL) {
            return SDKError::SDK_ERR_NULL_POINTER;
        }
        
        if (m_writer->currentSize() + sizeof(src) >=  m_writer->mmapSize()) {
            openNewFileWithFileNameIndexIncrease();
        }
        
        m_writer->append((uint8_t *)&src, sizeof(src));
        return SDKError::SDK_NO_ERROR;
    }
    
    
    SDKError::ErrorType writeInt32(const int32_t src)
    {
        return writeUInt32(*(uint32_t *)&src);
    }
    
    SDKError::ErrorType writeUInt32(const uint32_t src)
    {
        if (m_writer == NULL) {
            return SDKError::SDK_ERR_NULL_POINTER;
        }
        
        if (m_writer->currentSize() + sizeof(src) >= m_writer->mmapSize()) {
            openNewFileWithFileNameIndexIncrease();
        }
        
        m_writer->append((uint8_t *)&src, sizeof(src));
        
        return SDKError::SDK_NO_ERROR;
    }
    
    
    SDKError::ErrorType writeInt64(const int64_t src)
    {
        return writeUInt64(*(uint64_t *)&src);
    }
    
    SDKError::ErrorType writeUInt64(const uint64_t src)
    {
        if (m_writer == NULL) {
            return SDKError::SDK_ERR_NULL_POINTER;
        }
        
        if (m_writer->currentSize() + sizeof(src) >=  m_writer->mmapSize()) {
            openNewFileWithFileNameIndexIncrease();
        }
        
        m_writer->append((uint8_t *)&src, sizeof(src));
        return SDKError::SDK_NO_ERROR;
    }
    
    virtual int getUsedSize() const
    {
        return (int)m_writer->currentSize();
    }
    
    virtual const char* getBeginPtr() const
    {
        return (char *)m_writer->mmapPtr();
    }
    
    void closeBuf(){
        if (m_writer != NULL) {
            m_writer->close();
            m_writer = NULL;
        }
        if (m_fileName){
            margeFileWithFileNameAndMaxIndex(@(m_fileName), m_fileIndex);
        }
    }
public:
    static NSMutableArray<NSDictionary *> *checkLastRunPartFile(){
        FileManager *fileManager = [FileManager sharedFileManager];
        NSArray<NSString *> *allFiles = [fileManager showAllUnUploadCachedFile];
        if (!allFiles.count) {
            return nil;
        }
        NSArray<NSString *> *partFiles = [allFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"SELF ENDSWITH '.part'"]];
        partFiles = [partFiles sortedArrayUsingSelector:@selector(compare:)];
        NSUInteger partFilesCount = partFiles.count;
        NSString *currentFileName = nil;
        int maxIndex = 0;
        
        NSMutableArray<NSDictionary *> *groups = [NSMutableArray array];
        for (int i = 0; i < partFilesCount; i++) {
            NSString *partFile = partFiles[i];
            NSUInteger underlineLocation  = [partFile rangeOfString:@"_" options:NSBackwardsSearch].location;
            if (underlineLocation == NSNotFound) {
                continue;//不是以_idnex.part结尾的文件，忽略之
            }
            NSString *fileName = [partFile substringToIndex:underlineLocation];
            
            NSUInteger dotLocation  = [partFile rangeOfString:@"." options:NSBackwardsSearch].location;
            NSString *indexStr = [partFile substringWithRange:NSMakeRange(underlineLocation + 1, dotLocation - underlineLocation -1)];
            int indexNum = [indexStr intValue];// his property is 0 if the string doesn’t begin with a valid decimal text representation of a number.
            
            if (![currentFileName isEqualToString:fileName]) {//新的一个文件开始
                if (currentFileName) {
                    [groups addObject:@{kSDKMMapWriterBufferFileName:currentFileName,kSDKMMapWriterBufferFileMaxIndex: @(maxIndex)}];
                }
                currentFileName = fileName;
                maxIndex = 0;
            }else{//更新maxIndex
                if (indexNum > maxIndex) {
                    maxIndex = indexNum;
                }
            }
        }
        if (currentFileName) {//加上最后一个group
            [groups addObject:@{kSDKMMapWriterBufferFileName:currentFileName,kSDKMMapWriterBufferFileMaxIndex: @(maxIndex)}];
        }
        
        return groups;
    }
    
    
     static BOOL margeFileWithFileNameAndMaxIndex(NSString *fileName, int maxIndex){
        if (!fileName) {
            return NO;
        }
        
        FileManager *fileManager = [FileManager sharedFileManager];
        NSFileManager *defaultManager = [NSFileManager defaultManager];
        
        NSString *filePath = [fileManager constructCachePath:fileName];
        
        if (![defaultManager fileExistsAtPath:filePath]) {
            BOOL ret = [fileManager createCacheFileName:fileName];
            if (!ret) {
                APM_LOG_DEBUG(@"SDKMMapWriteBuffer::closeBuf create file : %@ failure.", filePath);
                return NO;
            }
        }
        
        FILE *allDataFile = fopen(filePath.UTF8String, "w");
        if (allDataFile == NULL) {
            APM_LOG_DEBUG(@"SDKMMapWriteBuffer::closeBuf open file : %@ failure.", filePath);
            return NO;
        }
        fseek(allDataFile, 0, SEEK_SET);
        
        NSMutableArray *waitDeleteFilePathArr = [NSMutableArray arrayWithCapacity:maxIndex +1];
        BOOL hasMisingOrOpenFailureFileError = NO;
        for (int i = 0; i <= maxIndex; i++) {
            NSString *partFileName = [NSString stringWithFormat:@"%@_%d.part",fileName,i];
            NSString *partFilePath = [fileManager constructCachePath:partFileName];
            if (![defaultManager fileExistsAtPath:filePath]) {
                APM_LOG_DEBUG(@"SDKMMapWriteBuffer::closeBuf file:%@ is missing!", partFilePath);
                hasMisingOrOpenFailureFileError = YES;
                continue;
            }
            [waitDeleteFilePathArr addObject:partFilePath];
            
            //!hasMisingOrOpenFailureFileError 为真表示中间有文件丢失或打开失败，后续的文件无需再写入
            if (hasMisingOrOpenFailureFileError) {
                continue;
            }
            
            FILE *partDataFile = fopen(partFilePath.UTF8String, "r");
            if (partDataFile == NULL) {
                APM_LOG_DEBUG(@"SDKMMapWriteBuffer::closeBuf open file : %@ failure.", partFilePath);
                hasMisingOrOpenFailureFileError = YES;
                continue;
            }
            
            fseek(partDataFile, 0, SEEK_SET);
            size_t bufferSize = 1024;
            uint8_t bytes[bufferSize];
            size_t readCount = fread(bytes, sizeof(uint8_t), bufferSize, partDataFile);
            while (readCount > 0) {
                fwrite(bytes, sizeof(uint8_t), readCount, allDataFile);
                readCount = fread(bytes, sizeof(uint8_t), bufferSize, partDataFile);
                APM_LOG_DEBUG(@"%p", &bytes);
            }
            fclose(partDataFile);
        }
        
        fclose(allDataFile);
        
        for (NSString *path : waitDeleteFilePathArr) {
            NSError *err = nil;
            [defaultManager removeItemAtPath:path error:&err];
            if (err) APM_LOG_DEBUG(@"SDKMMapWriteBuffer::closeBuf remove file: %@ failure, with error message: %@. ", path, err);
        }
        return YES;
    }
};
    
}

#endif /* SDKMMapWriterBuffer_hpp */
