//
//  SDKWriteArrayBuffer.hpp
//  LearnOpenGLES
//
//  Created by yongpengliang on 2019/6/13.
//  Copyright © 2019 xianglin. All rights reserved.
//

#ifndef SDKWriteArrayBuffer_hpp
#define SDKWriteArrayBuffer_hpp

#import "SDKBuf.h"

namespace TAPMIOS_SDKBuf
{

class SDKWriteArrayBuffer : public SDKWriteBuffer
{
    
private:
    char*       beginPtr;
    int         length;
    int         position;
public:
    
    SDKWriteArrayBuffer()
    {
        beginPtr = NULL;
        length = 0;
        position = 0;
    }
    
    SDKWriteArrayBuffer(char* ptr, int size)
    {
        beginPtr = ptr;
        position = 0;
        if (NULL == ptr)
        {
            length = 0;
        }
        else
        {
            length = size;
        }
    }
    
    virtual SDKError::ErrorType writeBytes(const void* src, int count)
    {
        if (count < 0 || count > (16 * 1024 + 1))
        {
            return SDKError::SDK_ERR_INT_LEN_TOO_BIG;
        }
        
        if (beginPtr == NULL)
        {
            return SDKError::SDK_ERR_NULL_BEGIN_PTR;
        }
        
        if (NULL == src)
        {
            return SDKError::SDK_ERR_ARG_POINTER_IS_NULL;
        }
        
        if (count > (length - position))
        {
            return SDKError::SDK_ERR_SHORT_BUF_FOR_WRITE;
        }
        
        memcpy(beginPtr + position, src, count);
        position += count;
        
        return SDKError::SDK_NO_ERROR;
    }
    
    virtual SDKError::ErrorType writeChar(const char src)
    {
        return writeUInt8(*(uint8_t*)&src);
    }
    
    
    virtual SDKError::ErrorType writeInt8(const int8_t src)
    {
        return writeUInt8(*(uint8_t*)&src);
    }
    
    virtual SDKError::ErrorType writeUInt8(const uint8_t src)
    {
        if (beginPtr == NULL)
        {
            return SDKError::SDK_ERR_NULL_BEGIN_PTR;
        }
        
        if (sizeof(src) > (length - position))
        {
            return SDKError::SDK_ERR_SHORT_BUF_FOR_WRITE;
        }
        
        *(uint8_t*)(beginPtr + position) = src;
        position += sizeof(src);
        
        return SDKError::SDK_NO_ERROR;
    }
    
    virtual SDKError::ErrorType writeInt16(const int16_t src)
    {
        return writeUInt16(*(uint16_t *)&src);
    }
    
    virtual SDKError::ErrorType writeUInt16(const uint16_t src)
    {
        if (beginPtr == NULL)
        {
            return SDKError::SDK_ERR_NULL_BEGIN_PTR;
        }
        
        if (sizeof(src) > (length - position))
        {
            return SDKError::SDK_ERR_SHORT_BUF_FOR_WRITE;
        }
        
        memcpy(beginPtr + position, &src, sizeof(src));
        position += sizeof(src);
        
        return SDKError::SDK_NO_ERROR;
    }
    
    
    virtual SDKError::ErrorType writeInt32(const int32_t src)
    {
        return writeUInt32(*(uint32_t *)&src);
    }
    
    virtual SDKError::ErrorType writeUInt32(const uint32_t src)
    {
        if (beginPtr == NULL)
        {
            return SDKError::SDK_ERR_NULL_BEGIN_PTR;
        }
        
        if (sizeof(src) > (length - position))
        {
            return SDKError::SDK_ERR_SHORT_BUF_FOR_WRITE;
        }
        
        memcpy(beginPtr + position, &src, sizeof(src));
        position += sizeof(src);
        
        return SDKError::SDK_NO_ERROR;
    }
    
    
    virtual SDKError::ErrorType writeInt64(const int64_t src)
    {
        return writeUInt64(*(uint64_t *)&src);
    }
    
    virtual SDKError::ErrorType writeUInt64(const uint64_t src)
    {
        
        if (beginPtr == NULL)
        {
            return SDKError::SDK_ERR_NULL_BEGIN_PTR;
        }
        
        if (sizeof(src) > (length - position))
        {
            return SDKError::SDK_ERR_SHORT_BUF_FOR_WRITE;
        }
        
        memcpy(beginPtr + position, &src, sizeof(src));
        position += sizeof(src);
        
        return SDKError::SDK_NO_ERROR;
    }
    
    virtual int getUsedSize() const
    {
        return position;
    }
    
    virtual const char* getBeginPtr() const
    {
        return beginPtr;
    }
    
    bool set(char* ptr, int size)
    {
        beginPtr = ptr;
        position = 0;
        if (NULL == beginPtr)
        {
            length = 0;
        } else
        {
            length = size;
        }
        return true;
    }
    
    int getTotalSize() const
    {
        return length;
    }
    
    void closeBuf(){
        //do nothing
    }
};

}

#endif /* SDKWriteArrayBuffer_hpp */
