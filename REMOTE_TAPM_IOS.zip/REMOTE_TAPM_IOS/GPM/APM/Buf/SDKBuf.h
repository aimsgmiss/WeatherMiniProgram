//
//  SDKBuf.hpp
//  LearnOpenGLES
//
//  Created by xiang lin on 11/01/2018.
//  Copyright xiang lin . All rights reserved.
//

#ifndef SDKBuf_hpp
#define SDKBuf_hpp

#include <stdio.h>
#import <assert.h>
#import <string.h>
#import "MmapFileWriter.h"
#import <Foundation/Foundation.h>

class SDKError
{
public:
    enum ErrorType
    {
        SDK_NO_ERROR = 0,
        SDK_ERR_SHORT_BUF_FOR_WRITE             =  -1,
        SDK_ERR_SHORT_BUF_FOR_READ              =  -2,
        SDK_ERR_STR_LEN_TOO_BIG                 =  -3,
        SDK_ERR_STR_LEN_TOO_SMALL               =  -4,
        SDK_ERR_STR_LEN_CONFLICT                =  -5,
        SDK_ERR_MINUS_REFER_VALUE               =  -6,
        SDK_ERR_REFER_SURPASS_COUNT             =  -7,
        SDK_ERR_ARG_POINTER_IS_NULL             =  -8,
        SDK_ERR_CUTVER_TOO_SMALL                =  -9,
        SDK_ERR_CUTVER_CONFILICT                = -10,
        SDK_ERR_PARSE_SDKIP_FAILED              = -11,
        SDK_ERR_INVALID_SDKIP_VALUE             = -12,
        SDK_ERR_INVALID_SDKTIME_VALUE           = -13,
        SDK_ERR_INVALID_SDKDATE_VALUE           = -14,
        SDK_ERR_INVALID_SDKDATETIME_VALUE       = -15,
        SDK_ERR_FUNC_LOCALTIME_FAILED           = -16,
        SDK_ERR_INVALID_HEX_STR_LEN             = -17,
        SDK_ERR_INVALID_HEX_STR_FORMAT          = -18,
        SDK_ERR_NULL_POINTER_PARAMETER          = -19,
        SDK_ERR_NET_CUTVER_INVALID              = -20,
        SDK_ERR_VALUE_UNDER_OR_OVER_FLOW        = -21,
        SDK_ERR_OPEN_FILE_READ_FAILED           = -22,
        SDK_ERR_OPEN_FILE_WRITE_FAILED          = -23,
        SDK_ERR_READ_FILE_FAILED                = -24,
        SDK_ERR_WRITE_FILE_FAILED               = -25,
        SDK_ERR_ALLOC_MEMORY_FAILED             = -26,
        SDK_ERR_PARSE_XML_FAILED                = -27,
        SDK_ERR_INVALID_ROOT_NODE               = -28,
        SDK_ERR_FAILED_TO_PARSE_NUMERIC         = -29,
        SDK_ERR_UNDEFINED_MACRO_NAME            = -30,
        SDK_ERR_FUNCTION_NOT_IMPLEMENTED        = -31,
        SDK_ERR_BAD_TLV_MAGIC                   = -32,
        SDK_ERR_SUSPICIOUS_SELECTOR             = -33,
        SDK_ERR_UNMATCHED_LENGTH                = -34,
        SDK_ERR_UNKNOWN_TYPE_ID                 = -35,
        SDK_ERR_LOST_REQUIRED_FIELD             = -36,
        SDK_ERR_NULL_ARRAY                      = -37,
        SDK_ERR_NULL_BEGIN_PTR                  = -38,
        SDK_ERR_INT_LEN_TOO_BIG                 = -39,
        SDK_ERR_NULL_POINTER                    = -40
    };
    
public:
    static const char* getErrorString(ErrorType errorCode);
};

namespace TAPMIOS_SDKBuf
{
    
    class SDKWriteBuffer{
        
    public:
        virtual SDKError::ErrorType writeBytes(const void* src, int count) = 0;
        
        virtual SDKError::ErrorType writeChar(const char src) = 0;
        
        virtual SDKError::ErrorType writeInt8(const int8_t src) = 0;
        
        virtual SDKError::ErrorType writeUInt8(const uint8_t src) = 0;
        
        virtual SDKError::ErrorType writeInt16(const int16_t src) = 0;
        
        virtual SDKError::ErrorType writeUInt16(const uint16_t src) = 0;
        
        virtual SDKError::ErrorType writeInt32(const int32_t src) = 0;
        
        virtual SDKError::ErrorType writeUInt32(const uint32_t src) = 0;
        
        virtual SDKError::ErrorType writeInt64(const int64_t src) = 0;
        
        virtual SDKError::ErrorType writeUInt64(const uint64_t src) = 0;
        
        virtual int getUsedSize() const = 0;
        
        virtual const char* getBeginPtr() const = 0;
        
        virtual bool set(char* ptr, int size) = 0;
        
        virtual void closeBuf() = 0;
        
        virtual ~SDKWriteBuffer(){}
        
    };
    
}
#endif 
