//
//  CPUCollectPerformance.h
//  LearnOpenGLESWithGPUImage
//
//  Created by xiang lin on 13/12/2017.
//  Copyright © 2017 xiang All rights reserved.
//

#import "TApmCollectPerformance.h"

@interface CPUCollectPerformance : TApmCollectPerformance

@end
