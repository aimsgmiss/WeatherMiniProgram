//
//  CPUCollectPerformance.m
//  LearnOpenGLESWithGPUImage
//
//  Created by xiang lin on 13/12/2017.
//  Copyright © 2017 xiang All rights reserved.
//

#import <mach-o/arch.h>
#import <mach/mach_types.h>
#import <mach/task.h>
#import <mach/vm_map.h>
#import <mach/thread_act.h>
#import <mach/mach_init.h>
#import <mach/mach_host.h>
#import <sys/sysctl.h>
#import <CoreGraphics/CoreGraphics.h>
#import <QuartzCore/QuartzCore.h>
#import "CPUCollectPerformance.h"
#import "MessageQueue.h"
#import "SDKHeader.h"
#import "SDKHelper.h"
#import "TApmLog.h"

using namespace SDKHelper;

@interface CPUCollectPerformance()
{
    
    short         _appCpuUsage;
    short         _totalCpuUsage;
}
@end

@implementation CPUCollectPerformance

-(instancetype)init
{
    if (self = [super init])
    {
        _appCpuUsage = 0;
        _totalCpuUsage = 0;
    }
    
    return self;
}

- (void)startMonitor
{
    [super startMonitor];
}

- (void)collectionDatas
{
    DataPerSec          dataPerSec;
    
    if (!self.isCollectionData) return;
    [super collectionDatas];
    _appCpuUsage = 0;
    if (kCPU_OPT & SDKUtill::opts)
    {
        _appCpuUsage = 0;
    }
    else
    {
        if([self getAppCpuUsage] == kSDKERROR) APM_LOG_DEBUG(@"get current app cpu usage error");
    }

    memset(&dataPerSec, 0, sizeof(DataPerSec));
    dataPerSec.appCpuUsage = _appCpuUsage;
    //APM_LOG_DEBUG(@"the cpu frequency is %f MHZ", GetCPUFrequency()/1000000);
    APMSDKLog(@"CPU:%d",_appCpuUsage);
    [[MessageQueue sharedInstance] pushMessageToGloabelBufferQueue:GamePerformanceDataType_CPU DataPerSec:dataPerSec isWriteToBuffer:NO];
    
}

- (CGFloat)getAppCpuUsage
{
    kern_return_t           kr;
    thread_array_t          thread_list;
    mach_msg_type_number_t  thread_count;
    thread_info_data_t      thinfo;
    mach_msg_type_number_t  thread_info_count;
    thread_basic_info_t     basic_info_th;
    CGFloat                 cpu_usage = 0;
    
    kr = task_threads(mach_task_self(), &thread_list, &thread_count);
    if (kr != KERN_SUCCESS) return kSDKERROR;
    
    if (thread_list == NULL)
    {
        _appCpuUsage = 0;
        return kSDKERROR;
    }
    
    for (int i = 0; i < thread_count; i++)
    {
        thread_info_count = THREAD_INFO_MAX;
        kr = thread_info(thread_list[i], THREAD_BASIC_INFO,(thread_info_t)thinfo, &thread_info_count);
        if (kr != KERN_SUCCESS) return kSDKERROR;
        basic_info_th = (thread_basic_info_t)thinfo;
        
        if (!(basic_info_th->flags & TH_FLAGS_IDLE)) cpu_usage += basic_info_th->cpu_usage;
    }
    
    cpu_usage = cpu_usage / (float)TH_USAGE_SCALE * 100.0;
    vm_deallocate(mach_task_self(), (vm_offset_t)thread_list, thread_count * sizeof(thread_t));
    
    if (isnan(cpu_usage))
    {
        _appCpuUsage = 0;
        return kSDKERROR;
    }
    _appCpuUsage = (short)(cpu_usage + 0.5);
  
    return _appCpuUsage;
}


- (void)stopMonitor
{
    
    [super stopMonitor];
    
}

@end
