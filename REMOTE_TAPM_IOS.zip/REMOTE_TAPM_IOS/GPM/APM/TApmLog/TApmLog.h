//
//  TApmLog.h
//  APM
//
//  Created by vincentwgao on 2019/7/10.
//  Copyright © 2019年 xianglin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GCloudCoreGPM.h"

#define APM_LOG(logLevel,log,...)                    [[TApmLog sharedInstance] apmLog:logLevel format:log,##__VA_ARGS__]
#define APM_LOG_DEBUG(log,...)                       do {[[TApmLog sharedInstance] gcloudLog:GCloud::kLogDebug file:__FILE__ line:__LINE__ function:__FUNCTION__ format:log,##__VA_ARGS__];} while (0)
#define APM_LOG_INFO(log,...)                        do {[[TApmLog sharedInstance] gcloudLog:GCloud::kLogInfo file:__FILE__ line:__LINE__ function:__FUNCTION__ format:log,##__VA_ARGS__];} while (0)
#define APM_LOG_WARN(log,...)                        do {[[TApmLog sharedInstance] gcloudLog:GCloud::kLogWarning file:__FILE__ line:__LINE__ function:__FUNCTION__ format:log,##__VA_ARGS__];} while (0)
#define APM_LOG_EVENT(log,...)                       do {[[TApmLog sharedInstance] gcloudLog:GCloud::kLogEvent file:__FILE__ line:__LINE__ function:__FUNCTION__ format:log,##__VA_ARGS__];} while (0)
#define APM_LOG_ERROR(log,...)                       do {[[TApmLog sharedInstance] gcloudLog:GCloud::kLogError file:__FILE__ line:__LINE__ function:__FUNCTION__ format:log,##__VA_ARGS__];} while (0)

NS_ASSUME_NONNULL_BEGIN

@interface TApmLog : NSObject

+ (instancetype)sharedInstance;

- (void)gcloudLog:(GCloud::ALogPriority)pri file:(const char*) file line:(unsigned int)line function:(const char*)function format:(NSString*)format,...;

- (void)apmLog:(int)logLevel format:(NSString*)format,...;

@property (nonatomic,assign) GCloud::ALogPriority logLevel;

@end

NS_ASSUME_NONNULL_END
