//
//  TApmLog.m
//  APM
//
//  Created by vincentwgao on 2019/7/10.
//  Copyright © 2019年 xianglin. All rights reserved.
//
#import <pthread.h>
#import "SDKStructEnumDefine.h"
#import "TApmLog.h"
#import "FileManager.h"
#import "SDKHelper.h"
#import "MmapFileWriter.h"

@interface TApmLog()
{
    GCloud::ILogger*        _logger;
}

@end

@implementation TApmLog

+ (instancetype)sharedInstance
{
    static TApmLog* singleInstance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        singleInstance = [[[self class] alloc] init];
        
    });
    
    return singleInstance;
}

- (instancetype)init
{
    if (self = [super init])
    {
        _logger = GCloud::GPM::GetLogger();
       
        if (_logger) {
            _logger->SetOption(GCLOUD_LOG_MODE, GCloud::kNoCompressNoEncryt);
            _logger->SetOption(GCLOUD_LOG_SINGLE_SIZE_LIMIT, 10);
            _logger->SetOption(GCLOUD_LOG_EXCEED_OP,GCloud::kFileDelete);
            _logger->Init();
            _logger->SetLogLevel(GCloud::kLogEvent);
        }
    }

    return self;
}

- (void)setLogLevel:(GCloud::ALogPriority)pri{
    if (!_logger) {
        return;
    }
    _logger -> SetLogLevel(pri);
}

- (void)gcloudLog:(GCloud::ALogPriority)pri file:(const char*) file line:(unsigned int)line function:(const char*)function format:(NSString*)format,...{
    if (!format) {
       return;
    }
       
    va_list args;
    va_start(args, format);
    NSString* consoleLog = [NSString stringWithFormat:@"%@\n",[[NSString alloc] initWithFormat:format arguments:args]];
    va_end(args);
    const char* consoleLogStr = consoleLog.UTF8String;
    if (!consoleLogStr) {
       //NSLog(@"[gpm] consoleLogStr is NULL");
       return;
    }

    if (_logger) {
         _logger -> Log(pri, file, line, function, "", consoleLogStr);
    }
}

- (void)apmLog:(int)logLevel format:(NSString*)format,...
{

}

@end
