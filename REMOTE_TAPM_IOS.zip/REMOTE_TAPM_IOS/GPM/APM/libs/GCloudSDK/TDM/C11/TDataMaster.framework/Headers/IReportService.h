//
//  IReportService.h
//  GCloudPluginManager
//
//  Created by cedar on 2018/8/3.
//  Copyright © 2018年 tencent. All rights reserved.
//

#ifndef IReportService_h
#define IReportService_h

#ifdef ANDROID
#include "GCloudPluginManager/IPluginService.h"
#endif

#ifdef __APPLE__
#include "IPluginService.h"
#endif

GCLOUD_PLUGIN_NAMESPACE

#define GCLOUDCORE_REPORT_ENV_TEST         0x01
#define GCLOUDCORE_REPORT_ENV_RELEASE      0x02

#define GCLOUDCORE_REPORT_INTERFACE_INFO   0x01
#define GCLOUDCORE_REPORT_QUALITY_INFO     0x02

#if defined(_WIN32) || defined(_WIN64)
typedef long long int64_t;
#endif


enum GCLoudCoreEventKeys
{
    kIntKeyAccountType = 100000,
    kIntKeyDataType = 100001,
    kIntKeyInterfaceDataType = 100002,
    
    kIntKeyResultCode = 100100,
    kIntKeyErrorCode,
    KIntKeySecondErrorCode,
    KIntKeyMethodType,
    KIntKeySessionID,
    KIntKeyDuration,
    
    KStrKeyGCloudVersion = 110000,
    KStrKeyGCloudCoreVersion,
    KStrKeyAccountID,
    
    KStrKeyComponentName = 110100,
    KStrKeyComponentVersion,
    KStrKeyMethodName,
    KStrKeyMethodParams,
    KStrKeyResultData,
    KStrKeyErrorMsg,
    KStrKeySecondErrorMsg,
};


class IEvent
{
public:
    virtual ~IEvent(){}
    
public:
    virtual void Add(const char* key, const char* value, const int valueLen) = 0;
    virtual void Add(int key, const char* value, const int valueLen) = 0;
    virtual void Add(int key, int64_t value) = 0;
    
public:
    virtual void Report() = 0;
};


class IReportService : public IPluginService
{
protected:
    ~IReportService(){}
    
public:
    virtual IEvent* CreateEvent(int srcID, const char* eventName) = 0;
    virtual void DestroyEvent(GCloud::Plugin::IEvent** ppEvent) = 0;
    virtual void ReportBinary(int srcID, const char * eventName, const char* data, int len) = 0;
    virtual const char* GetSessionID() = 0;
};

//Inner use only
class ICoreReportService : public IPluginService
{
protected:
    ~ICoreReportService(){}
    
public:
    virtual IEvent* CreateEvent(int env, int srcID, const char* eventName) = 0;
    virtual void DestroyEvent(GCloud::Plugin::IEvent** ppEvent) = 0;
};


GCLOUD_PLUGIN_NAMESPACE_END


#endif /* IReportService_h */
