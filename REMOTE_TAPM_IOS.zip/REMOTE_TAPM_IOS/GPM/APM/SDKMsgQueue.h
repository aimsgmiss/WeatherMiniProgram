//
//  SDKMsgQueue.hpp
//  LearnOpenGLES
//
//  Created by vincentwgao on 2018/3/29.
//  Copyright © 2018年  All rights reserved.
//

#ifndef SDKMsgQueue_h
#define SDKMsgQueue_h

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <malloc/malloc.h>

#pragma pack (1) /*指定按1字节对齐*/
typedef struct _MsgQueueBody
{
    const char*         charValue;
    char                flag;
    int8_t              int8Value;
    int16_t             int16Value;
    int32_t             int32Value;
    int64_t             int64Value;
    void*               voidPtr;
    int16_t             sceneType;
    int16_t             sceneIndex;
    int32_t             drawcall;
    int32_t             triangle;
    uint32_t            timeInterval;
    int32_t             deltaSeconds;
    
}MsgQueueBody;
#pragma pack () /*取消指定对齐，恢复缺省对齐*/

static inline void constructMsgQueueBody(MsgQueueBody& obj)
{
    
    obj.flag = 0;
    obj.charValue = NULL;
    obj.int8Value = 0;
    obj.int16Value = 0;
    obj.int32Value = 0;
    obj.int64Value = 0;
    obj.voidPtr = NULL;
    obj.sceneIndex = 0;
    obj.sceneType = 0;
    obj.drawcall = 0;
    obj.triangle = 0;
    obj.timeInterval = 0;
    obj.deltaSeconds = 0;

}

static inline void constructMsgQueueBody(MsgQueueBody msgBody,MsgQueueBody& obj)
{
    size_t                     sizeCharLen;
    
    constructMsgQueueBody(obj);
    obj.flag = msgBody.flag;
    obj.int8Value = msgBody.int8Value;
    obj.int16Value = msgBody.int16Value;
    obj.int32Value = msgBody.int32Value;
    obj.int64Value = msgBody.int64Value;
    obj.voidPtr = msgBody.voidPtr;
    obj.sceneType = msgBody.sceneType;
    obj.sceneIndex = msgBody.sceneIndex;
    obj.drawcall = msgBody.drawcall;
    obj.triangle = msgBody.triangle;
    obj.timeInterval = msgBody.timeInterval;
    obj.deltaSeconds = msgBody.deltaSeconds;
    
    if (msgBody.charValue)
    {
        sizeCharLen = strlen(msgBody.charValue) + 1;
        obj.charValue = (char*)malloc(sizeCharLen);
        if (NULL == obj.charValue)
        {
            return ;
        }
        memset((void*)obj.charValue, 0, sizeCharLen);
        // 字符串需要拷贝
        strcpy((char*)obj.charValue,msgBody.charValue);
    }
    
    // 仅仅赋值指针
    if (msgBody.voidPtr)
    {
        obj.voidPtr = msgBody.voidPtr;
    }
    
}

namespace  SDKMsgQueue
{
    class MsgQueue
    {
    public:
        unsigned            mHeadIdx;
        unsigned            mTailIdx;
        int                 mQueueSz;
        bool                mLockable;
        bool                mCosumeLockable;
        pthread_mutex_t     mQueueMutex;
        pthread_mutex_t     mQueueConsumeMutex;
        MsgQueueBody*       mMsgQueuePtr;
        char*               msgQueueName;
        
    public:
        MsgQueue(int queueSz, bool lock,const char* msgQueName);
        MsgQueue(int queueSz, bool lock, bool clock,const char* msgQueName);
        void postMsg(MsgQueueBody& value);
        bool consumeMsgOnce(MsgQueueBody& target);
        void safeFree(MsgQueueBody& target);
        ~MsgQueue();
    };
}


#endif /* SDKMsgQueue_hpp */
