/*
 * APM_IOS_Mutex.cpp
 *
 *  Created on: 2018��6��18��
 *      Author: vincentwgao
 */


#include "TApm_Mutex.h"

#include <string>
//#include "logger.h"


TApmMutex::TApmMutex ()
{
    memset (&mMutex, 0, sizeof(mMutex));
    int res = pthread_mutex_init (&mMutex, NULL);
    if (res != 0)
    {
        printf("PTHREAD MUTEX INIT ERROR");
    }
}

TApmMutex::~TApmMutex ()
{
	int res = pthread_mutex_destroy (&mMutex);
	if (res != 0)
	{
		printf("PTHREAD MUTEX DESTORY ERROR");
	}
}


void TApmMutex::lock ()
{
	int res = pthread_mutex_lock (&mMutex);
	if (res != 0)
	{
		printf("PTHREAD MUTEX LOCK ERROR");
	}
}


void TApmMutex::unlock ()
{
	int res = pthread_mutex_unlock (&mMutex);
	if (res != 0)
	{
		printf("PTHREAD MUTEX UNLOCK ERROR");
	}
}

