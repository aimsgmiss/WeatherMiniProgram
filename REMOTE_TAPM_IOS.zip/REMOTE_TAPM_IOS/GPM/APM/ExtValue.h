#ifndef __EXT_VALUE_H
#define __EXT_VALUE_H

#include <stdio.h>
#define JNIEXPORT
#define JNICALL
// 保留3为小数
extern "C"
{
    JNIEXPORT void JNICALL tapmNativePostV3F(const char* category, const char* key, float a, float b, float c);
    
    JNIEXPORT void JNICALL tapmNativePostV2F(const char* category, const char* key, float a, float b);
    
    JNIEXPORT void JNICALL tapmNativePostV1F(const char* category, const char* key, float a);
    
    JNIEXPORT void JNICALL tapmNativePostV3I(const char* category, const char* key, int a, int b, int c);
    
    JNIEXPORT void JNICALL tapmNativePostV2I(const char* category, const char* key, int a, int b);
    
    JNIEXPORT void JNICALL tapmNativePostV1I(const char* category, const char* key, int a);
    
    JNIEXPORT void JNICALL tapmNativePostV1S(const char* category, const char* key, const char* value);
    
    JNIEXPORT void JNICALL tapmNativeBeginTupleWrap(const char* key);
    
    JNIEXPORT void JNICALL tapmNativeEndTupleWrap();
}

namespace TAPM
{
    void serlizeExtToFile(FILE* file, uint8_t eventPrefix, unsigned int targetSceneIdx);
    
    void serlizeExtToFileCompress(FILE* file, uint8_t eventPrefix, unsigned targetSceneIdx);
    
    void clearIndexMap();
}

#endif

