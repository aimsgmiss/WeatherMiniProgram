#ifndef __ZIGZAG_H
#define __ZIGZAG_H
//
#include <stdint.h>
#include <sys/types.h>
namespace Hawk{


	// ZigZag Transform:  Encodes signed integers so that they can be
	// effectively used with varint encoding.
	//
	// varint operates on unsigned integers, encoding smaller numbers into
	// fewer bytes.  If you try to use it on a signed integer, it will treat
	// this number as a very large unsigned integer, which means that even
	// small signed numbers like -1 will take the maximum number of bytes
	// (10) to encode.  ZigZagEncode() maps signed integers to unsigned
	// in such a way that those with a small absolute value will have smaller
	// encoded values, making them appropriate for encoding using varint.
	//
	//       int32 ->     uint32
	// -------------------------
	//           0 ->          0
	//          -1 ->          1
	//           1 ->          2
	//          -2 ->          3
	//         ... ->        ...
	//  2147483647 -> 4294967294
	// -2147483648 -> 4294967295
	//
	//        >> encode >>
	//        << decode <<

	inline uint32_t ZigZagEncode32(int32_t n) {
	  // Note:  the right-shift must be arithmetic
	  return (n << 1) ^ (n >> 31);
	}

	inline int32_t ZigZagDecode32(uint32_t n) {
	  return (n >> 1) ^ -static_cast<int32_t>(n & 1);
	}

    const uint8_t* ReadVarint32FromArray(const uint8_t* buffer, uint32_t* value);
	int WriteVarintInt32(
	    uint32_t value, uint8_t* target);

}


#endif
