//
//  SDKStack.h
//  LearnOpenGLES
//
//  Created by vincentwgao on 2018/7/18.
//  Copyright © 2018年 xianglin. All rights reserved.
//

#ifndef SDKStack_h
#define SDKStack_h
#import <stdio.h>
template<class T>
class SDKStack
{
    private:
        unsigned    _count;
        T*          _ptr;
        int         _index;
    public:
        SDKStack(unsigned int count);
        ~SDKStack();
        bool push(T& obj);
        bool pop(T& obj);
        int  getIdex();
};

template<class T> SDKStack<T>::SDKStack(unsigned  count)
{
    _index = 0;
    _count = count;
    _ptr =  (T*)malloc(sizeof(T) * count);
    if (_ptr == NULL)
    {
        printf(" SDKStack malloc error");
        return;
    }
}

template<class T> SDKStack<T>::~SDKStack()
{
    if(_ptr != NULL)
    {
        free(_ptr);
        _ptr = NULL;
    }
}

template <class T> bool SDKStack<T>::push(T& obj)
{
    if (_ptr == NULL) return false;
    if (_index == _count)
    {
        _ptr = (T*)realloc(_ptr, sizeof(T) * _count * 2);
        if (_ptr == NULL)
        {
            printf(" SDKStack realloc error");
            return false;
        }
         _count = 2 * _count;
    }
    
    _ptr[_index] = obj;
    _index++;
    
    return true;
}

template <class T> bool SDKStack<T>::pop(T& obj)
{
    if (_ptr == NULL) return false;
    if (_index == 0) return false;
    
    _index--;
    obj = _ptr[_index];
    
    return true;
}

template <class T> int SDKStack<T>::getIdex()
{
    return _index;
}

#endif /* SDKStack_h */
