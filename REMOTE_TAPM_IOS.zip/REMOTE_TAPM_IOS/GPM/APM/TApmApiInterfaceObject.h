//
//  TApmApiInterfaceObject.h
//  SDK
//
//  Created by xiang lin on 11/12/2017.
//  Copyright © 2017 xiang lin. All rights reserved.
//


#if defined(__cplusplus)
extern "C"
{
    
#endif
    /**
     *  选择第一个或主场景，在任意脚本文件中调用如下代码(建议选择较早加载 的脚本)进行初始化。
     *  必选，AppId在WeTest上申请。
     */
    int g_InitContext(const char* appid);
    /**
     *  场景(关卡)加载标记(必选)
     *  TApm 中的场景只是一个逻辑的标记，和具体的流关卡或者永久关卡的加载或
     *  者卸载没有对应的关系，因此可以在一个物理关卡中多次调用 g_MarkLevelLoad()函数进行逻辑标记，标记时可以传入画质的参数，默认为0。
     *  如果画质参数被设定，APM 后台的数据统计将以上传的画质进行机器分级，否则默认采用APM内部的分级标准。
     */
    int g_MarkLoadlevel(const char* sceneName,int quality);
    /**
     *  通过其计算场景的加载时间（非必要）,
     *  在同一个场景中多次调用此接口无效，只会执行一次。
     */
    int g_MarkLoadlevelCompleted(void);
    /**
     *  函数来标记场景结束(非必要)
     *  如果没有通过调用 g_MarkLevelFin()函数来结束场景，整个场景的时间以下一次调用 g_MarkLoadlevel()函数的时间为场景结束时间
     */
    int g_MarkLevelFin();
    
    /**
     *  函数来表示一个标签的开始，标签和场景是依附的关系，意味着如果当前没有MarkLoadlevel进行标记，则BeginTag无效，
     *  BeginTag中继承MarkLoadlevel中的画质(可选)
     */
    void g_BeginTag(const char* tagName);
    /**
     *  结束当前的标签，如果没有调用EndTag则MarkLevelFin中会默认自动插入一个EndTag的标记(可选)
     */
    void g_EndTag(void);
    
    /**
     *  每帧调用一次，用来计算FPS(放在主线程中)
     */
    void g_PostFrame(float deltaSeconds);
    /**
     *  设置全局画质
     */
    void g_SetQuality(int32_t quality);
    
    
    void g_SetDeviceLevel(int32_t deviceLevel);
    /**
     *  APM既能反映整体大盘的外网性能状况，也提供接口进行单用户的性能回溯，
     *  在Web端可以通过玩家ID查看其性能数据，准确还原玩家游戏性能，此接口可在程序任意位置调用。
     */
    void g_SetUserID(const char* userID);
    
    /**
     *  设置本地信息
     */
    void g_SetLocal(const char* cLocal);
    
    /**
     *  网络延时(可选)
     *  通过 g_PostNTL (latency)函数来进行网络延时的统计，可以在一个单独
     *  计算网络延时的线程中进行调用。
     */
    void g_PostNTL(int32_t latency);
    /**
     *  上报回扯信息，distance表示回扯的距离。
     */
    void g_PostLagStatus(int32_t distance);
    /**
     *   上报游戏内的事件，比如预定义的，上载具，下载具，天气系统等。
     *   info参数可以添加一些额外的信息，比如载具的信息，天气系统的信息。
     *   通过Event接口上传的信息APM后台会进行各维度的统计分析。
     */
    void g_PostEvent(int32_t key,const char* info);
    
    /**
     *   设置版本
     */
    void g_SetVersionIden(const char* version);
    
    void g_InitStepEventContext();
    
    void g_PostStepEvent(const char* eventCategory, int stepId, int status, int code, const char* msg, const char* extraKey="NA");
    
    //deprecated
    void g_PostStreamEvent(int stepId, int code, int status, const char* msg);
    
    void g_ReleaseStepEventContext();
    
    void g_LinkSession(const char* eventName);
    
    /**
     *   返回值是一个INT整型，只会返回2,4,8三个值，分别代表低端机，中端机以及高端机。
     */
    int g_GetDeviceLevel(const char* absolutePath,const char* configLevel);
    
    
    /**
     *   返回值是一个INT整型，只会返回2,4,8三个值，分别代表低端机，中端机以及高端机，数据从网络同步获取，网络失败返回0
     */
    int g_GetDeviceLevelSyncFromServer(const char* absolutePath, const char* configLevel);
    
    /**
     *
     */
    void g_PostCoordinate(int x, int y, int z, int pitch, int yaw, int roll);
    /**
     *
     */
    void g_BeginExclude();
    /**
     *
     */
    void g_EndExclude();
    
    float g_GetInstantFps();
    
    float g_GetSceneMeanFps(const char* sceneName);
    
    int g_GetSceneMaxPss(); //MB
    
    int g_GetSceneTotalTime();
    
    int g_GetSceneTotalFrames();
    
    char* g_GetCurrentSceneName();
    
    char* g_GetErrorMsg(int errorCode);
 
    int g_GetSceneLoadedTime();
    
    void  tapmNativePostV3F(const char* category, const char* key, float a, float b, float c);
    
    void  tapmNativePostV2F(const char* category, const char* key, float a, float b);
    
    void  tapmNativePostV1F(const char* category, const char* key, float a);
    
    void  tapmNativePostV3I(const char* category, const char* key, int a, int b, int c);
    
    void  tapmNativePostV2I(const char* category, const char* key, int a, int b);
    
    void  tapmNativePostV1I(const char* category, const char* key, int a);
    
    void  tapmNativePostV1S(const char* category, const char* key, const char* value);
    
    void  tapmNativeBeginTupleWrap(const char* key);
    
    void  tapmNativeEndTupleWrap();
    

#if defined(__cplusplus)
}
#endif


