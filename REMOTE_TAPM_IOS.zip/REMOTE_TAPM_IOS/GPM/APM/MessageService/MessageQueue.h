//
//  MessageQueue.h
//  LearnOpenGLESWithGPUImage
//
//  Created by xiang lin on 20/12/2017.
//  Copyright © 2017 xiang. All rights reserved.
//




#import <Foundation/Foundation.h>
#import "SDKStructEnumDefine.h"
#import "SDKMsgQueue.h"

#define FWRITE_1(value, uselessParameter1) [[MessageQueue sharedInstance] pushMessageToGloabelBufferQueueInt8:value]
#define FWRITE_2(value, uselessParameter1,uselessParameter2,uselessParameter3) [[MessageQueue sharedInstance] pushMessageToGloabelBufferQueueInt16:value]
#define FWRITE_4(value, uselessParameter1) [[MessageQueue sharedInstance] pushMessageToGloabelBufferQueueInt32:value]
#define FWRITE_Bytes(value,len,uselessParameter1,uselessParameter2) [[MessageQueue sharedInstance] pushMessageToGloabelBufferQueueBytes:value bufferLen:len]
#define PRINT_I printf

@interface MessageQueue : NSObject

+ (MessageQueue*)sharedInstance;

- (void)reset;

- (void)consumeFramesWithCompress:(SDKMsgQueue::MsgQueue*)frameMsgQueue;

- (void)setCacheFileName:(NSString *)cacheFileName;

//- (void)flushBufferToFile;
/**
 * 场景数据
 */
- (void)pushMessageToGloabelBufferQueue:(Scene)scene forceWriteToFile:(BOOL)isForce;
/**
 * 帧秒数据
 */
- (void)pushMessageToGloabelBufferQueue:(GamePerformanceDataType)gpDataType DataPerSec:(DataPerSec)dataPerSec isWriteToBuffer:(BOOL)isWriteToBuffer;

/**
 * 放在帧秒数据后面
 */
- (void)pushMessageToGloabelBufferCustomData:(MsgQueueBody)msgQueueBody type:(MsgQueueBodyType)type;

- (void)pushMessageToGloabelBufferQueue:(FrameStateS)frameState;

- (void)pushMessageToGloabelBufferQueueInt8:(int8_t)value;

- (void)pushMessageToGloabelBufferQueueInt16:(int16_t)value;

- (void)pushMessageToGloabelBufferQueueInt32:(int32_t)value;

- (void)pushMessageToGloabelBufferQueueInt64:(int64_t)value;

- (void)pushMessageToGloabelBufferQueueBytes:(const char *)buffer bufferLen:(int16_t)len;

@property (nonatomic,assign) uint32_t maxPss;

@end


