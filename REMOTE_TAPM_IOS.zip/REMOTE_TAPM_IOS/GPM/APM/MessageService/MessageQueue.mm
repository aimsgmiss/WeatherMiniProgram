//
//  MessageQueue.m
//  LearnOpenGLESWithGPUImage
// flushBufferToFile
//  Created by xiang lin on 20/12/2017.
//  Copyright © 2017 xiang. All rights reserved.
//

#import <pthread.h>
#include <time.h>
#import "FileManager.h"
#import "SDKHeader.h"
#import "MessageQueue.h"
#import "SDKBuf.h"
#import "SDKHelper.h"
#import "SDKStructEnumDefine.h"
#import "zigzag.h"
#import "SDKMMapWriterBuffer.h"
#import "SDKWriteArrayBuffer.h"
#import "DeviceInfoHelper.h"
#import "APMCCStrategy.h"
#import "FPS/GPMFps.h"

using namespace TAPMIOS_SDKBuf;
using namespace SDKHelper;
static  MessageQueue*             singleInstance = nil;
extern char*                      g_sCachedBuffer[kGlobalEventBufferCached];
extern int                        g_sCachedBufferIdx[kGlobalEventBufferCached];
extern uint16_t                   g_apmRandom_seed;
extern time_t                     g_apmAppInitTime;
extern time_t                     g_apmTempSceneTime;


void g_apm_write_zigzag_int32(int32_t value)
{
    uint8_t tempBuffer[5];
    uint32_t zigzagValue = Hawk::ZigZagEncode32(value);
    int retLen = Hawk::WriteVarintInt32(zigzagValue, tempBuffer);
    
    FWRITE_Bytes((const char*)tempBuffer, retLen, NULL, NULL);
}

@interface MessageQueue()
{
    char                    _buffer[kGloabelBufferLen];
    SDKWriteBuffer          *_writeBuffer;
    DataPerSec              _dataPerSec;
    uint32_t                _lastFrameTimestamp;
}
@end

@implementation MessageQueue

- (instancetype)init
{
    if (self = [super init])
    {
        if ([[APMCCStrategy sharedInstance] isFeatureEnabled:FEATURE_MMAP]) {
            _writeBuffer = new SDKMMapWriterBuffer();
        }else{
            _writeBuffer = new SDKWriteArrayBuffer();
            _writeBuffer->set(_buffer, kGloabelBufferLen);
        }
        [self reset];
    }
    
    return self;
}


+ (MessageQueue*)sharedInstance
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        singleInstance = [[self alloc] init];
    });
    
    return singleInstance;
}

- (void)reset
{
    _lastFrameTimestamp = 0;
    //_lastSecTimestamp = 0;
    memset(&_dataPerSec, 0, sizeof(DataPerSec));
    memset(_buffer, 0,kGloabelBufferLen);
    _maxPss = 0;
}

- (void)setCacheFileName:(NSString *)cacheFileName{
    if (![[APMCCStrategy sharedInstance] isFeatureEnabled:FEATURE_MMAP]) {
        return;
    }
    
    if (_writeBuffer) {
        _writeBuffer->set((char *)cacheFileName.UTF8String, 1);
    }
}

- (void)closeCacheFile{
    if (![[APMCCStrategy sharedInstance] isFeatureEnabled:FEATURE_MMAP]) {
        return;
    }
    
    if (_writeBuffer) {
        _writeBuffer->closeBuf();
    }
}


- (void)consumeFramesWithCompress:(SDKMsgQueue::MsgQueue*)frameMsgQueue
{
    if (!frameMsgQueue)
    {
        return;
    }
    
    int gap = frameMsgQueue -> mHeadIdx - frameMsgQueue -> mTailIdx - 1; //NOTE: 0-1 will never happens
    int length = MIN(gap, 120);
    //APM_LOG_DEBUG(@"frameMsgQueue:%d",length);
    uint32_t startTimeStamp = 0;
    if (length > 0)
    {
        MsgQueueBody msgQueueBody = frameMsgQueue -> mMsgQueuePtr[(frameMsgQueue -> mTailIdx + 1) & (frameMsgQueue -> mQueueSz - 1)];
        startTimeStamp = msgQueueBody.timeInterval;
        if (_lastFrameTimestamp == 0)
        {
            _lastFrameTimestamp = startTimeStamp;
            uint8_t caseflag = kFrameTimeAxisFlag;
            FWRITE_1(caseflag, 1);
            FWRITE_4(_lastFrameTimestamp, 4);
        }
        
        uint8_t caseflag = kFrameEndCompressedBatchFlag;
        FWRITE_1(caseflag, 1);
        
        uint8_t batchFrames = length & 0xFF;
        FWRITE_1(batchFrames, 1);
        
        // new level
        while (length -- > 0)
        {
            frameMsgQueue -> mTailIdx = frameMsgQueue -> mTailIdx + 1;

            MsgQueueBody msgQueueBody = frameMsgQueue -> mMsgQueuePtr[(frameMsgQueue -> mTailIdx) & (frameMsgQueue -> mQueueSz - 1)];
            uint32_t diff = msgQueueBody.timeInterval - _lastFrameTimestamp;//mills
            g_apm_write_zigzag_int32(msgQueueBody.deltaSeconds);
            
            g_apm_write_zigzag_int32(diff);
            _lastFrameTimestamp = msgQueueBody.timeInterval;

        }
    }
    
    int diff = (_lastFrameTimestamp - startTimeStamp);
    if (diff > 0) {
        int fps = gap / (diff * 0.001);
        [[GPMFps sharedInstance] addFps:fps];
        //NSLog(@"fps:%d ---:frames:%d -- interval:%.3f",fps,gap,(_lastFrameTimestamp - startTimeStamp) * 0.001);
    }
}

- (void)pushMessageToGloabelBufferCustomData:(MsgQueueBody)msgQueueBody type:(MsgQueueBodyType)type
{
    SDKError::ErrorType     ret = SDKError::SDK_NO_ERROR;
 
    switch (type)
    {
        case MsgQueueBodyType_FileStartData:
        {
            uint32_t                totalSpace;
            uint32_t                freeSpace;
            FileAttribute           fileAttribute;
            
            // 先将文件属性写入到文件开始位置  version,randseed,networType,SceneQuality,flag
            fileAttribute.hawkVersion = kHawkVersion;
            fileAttribute.randSeed = g_apmRandom_seed;
            fileAttribute.networkType = SDKUtill::networkType;;
            fileAttribute.sceneQuality = msgQueueBody.int32Value;
            fileAttribute.appInitTime = (int32_t)g_apmAppInitTime;
            fileAttribute.tempSceneTime = (int32_t)g_apmTempSceneTime;
            ret = SDKHelper::SDKWriteHelper::writeFileAttribute(*_writeBuffer, fileAttribute);
            APMSDKAssert(ret == SDKError::SDK_NO_ERROR, @"writeFileAttribute error");

            // deviceLevel
            int32_t deviceLevel = (int32_t)msgQueueBody.int64Value;
            ret = SDKHelper::SDKWriteHelper::writeInt32(*_writeBuffer, deviceLevel);
            
            int8_t zigzag = [[APMCCStrategy sharedInstance] isFeatureEnabled:FEATURE_ZIGZAG];
            ret = SDKHelper::SDKWriteHelper::writeInt8(*_writeBuffer, zigzag);
            
            // 设备空间大小
            totalSpace = DeviceInfo::DeviceInfoHelper::getDeviceTotalSpace();
            freeSpace = SDKUtill::getDeviceFreeSpace();
            ret = SDKHelper::SDKWriteHelper::writeDeviceSpaceData(*_writeBuffer, totalSpace, freeSpace);
            APMSDKAssert(ret == SDKError::SDK_NO_ERROR, @"writeDeviceSpaceData error");
            
            //将全局事件写入到文件
            for (int bufferPos = 302; bufferPos < kGlobalEventBufferCached; bufferPos++)
            {
                if (g_sCachedBufferIdx[bufferPos] != 0)
                {
                    if (g_sCachedBuffer[bufferPos] != NULL)
                    {
                        if (strlen(g_sCachedBuffer[bufferPos]) > 128) continue;
                        [self isFlushBufferToFile:kSizeofGameEventCached(g_sCachedBuffer[bufferPos])];
                
                        ret = SDKHelper::SDKWriteHelper::writeGameEventCached(*_writeBuffer, bufferPos, g_sCachedBuffer[bufferPos]);
                        APMSDKAssert(ret == SDKError::SDK_NO_ERROR, @"writeGameEventCached error");
                    }
                }
            }
            //强制性flush
            [self flushBufferToFile];
    
        }
            break;
        // 回扯距离
        case MsgQueueBodyType_LagStatus:
        {
            [self isFlushBufferToFile:kSizeofLagStatus];
            ret = SDKHelper::SDKWriteHelper::writeLagStatus(*_writeBuffer, msgQueueBody.timeInterval, msgQueueBody.int32Value);
            APMSDKAssert(ret == SDKError::SDK_NO_ERROR, @"pushMessageToGloabelBufferCustomData distance error");
        }
            break;
        // 用户ID
        case MsgQueueBodyType_UserID:
        {
            if (!msgQueueBody.charValue) return;
            
            [self isFlushBufferToFile:kSizeofUserIDSLen(msgQueueBody.charValue)];
            ret = SDKHelper::SDKWriteHelper::writeUserID(*_writeBuffer, msgQueueBody.charValue);
            APMSDKAssert(ret == SDKError::SDK_NO_ERROR, @"pushMessageToGloabelBufferCustomData userID error");
        }
            break;
        // local
        case MsgQueueBodyType_Local:
        {
            if (!msgQueueBody.charValue) return;
            
            [self isFlushBufferToFile:kSizeofLocal(msgQueueBody.charValue)];
            ret = SDKHelper::SDKWriteHelper::writeLocal(*_writeBuffer, msgQueueBody.charValue);
            APMSDKAssert(ret == SDKError::SDK_NO_ERROR, @"pushMessageToGloabelBufferCustomData local error");
        }
            break;
            
        // 游戏事件
        case MsgQueueBodyType_Info:
        {
            if (!msgQueueBody.charValue) return;
    
            [self isFlushBufferToFile:kSizeofGameEvent(msgQueueBody.charValue)];
            ret = SDKHelper::SDKWriteHelper::writeGameEvent(*_writeBuffer,msgQueueBody.timeInterval, msgQueueBody.int32Value, msgQueueBody.charValue);
            APMSDKAssert(ret == SDKError::SDK_NO_ERROR, @"pushMessageToGloabelBufferCustomData info error");
        }
            break;
        // 游戏全局缓存事件
        case MsgQueueBodyType_Global_Info:
        {
            if (!msgQueueBody.charValue) return;
            
            [self isFlushBufferToFile:kSizeofGameEventCached(msgQueueBody.charValue)];
            ret = SDKHelper::SDKWriteHelper::writeGameEventCached(*_writeBuffer, msgQueueBody.int32Value, msgQueueBody.charValue);
            APMSDKAssert(ret == SDKError::SDK_NO_ERROR, @"pushMessageToGloabelBufferCustomData info error");
        }
            break;
            
        // 游戏画质
        case MsgQueueBodyType_Quality:
        {
            [self isFlushBufferToFile:kSizeofSceneQualityS];
            ret = SDKHelper::SDKWriteHelper::writeQuality(*_writeBuffer, msgQueueBody.int32Value);
            APMSDKAssert(ret == SDKError::SDK_NO_ERROR, @"pushMessageToGloabelBufferCustomData quality  error");
        }
            break;
            
        case MsgQueueBodyType_DeviceLevel:
        {
            [self isFlushBufferToFile:kSizeofSceneDeviceLevelS];
            ret = SDKHelper::SDKWriteHelper::writeDeviceLevel(*_writeBuffer, msgQueueBody.int32Value);
            APMSDKAssert(ret == SDKError::SDK_NO_ERROR, @"pushMessageToGloabelBufferCustomData device level  error");
        }
            break;
            
        // 网络延迟
        case MsgQueueBodyType_NetLatency:
        {
            
            if ([[APMCCStrategy sharedInstance] isFeatureEnabled:FEATURE_ZIGZAG])
            {
                FWRITE_1(kNetLatencyFlag, NULL);
                
                g_apm_write_zigzag_int32(msgQueueBody.timeInterval);
                
                g_apm_write_zigzag_int32(0);
                
                g_apm_write_zigzag_int32(msgQueueBody.int32Value);
            }
            else
            {
                [self isFlushBufferToFile:kSizeofNetLatency];
                ret = SDKHelper::SDKWriteHelper::writeNetLatency(*_writeBuffer, msgQueueBody.timeInterval,msgQueueBody.int32Value);
                APMSDKAssert(ret == SDKError::SDK_NO_ERROR, @"pushMessageToGloabelBufferCustomData latency  error");
            }
        }
            break;
        // 网络状态 wifi,2g,3g,4g
        case MsgQueueBodyType_NetworkStatus:
        {
            [self isFlushBufferToFile:kSizeofNetStats];
            ret = SDKHelper::SDKWriteHelper::writeNetworkStat(*_writeBuffer, msgQueueBody.flag,msgQueueBody.int16Value);
            APMSDKAssert(ret == SDKError::SDK_NO_ERROR, @"pushMessageToGloabelBufferCustomData netStatus error");
        }
            break;
            
        // 处理标签
        case MsgQueueBodyType_Tag:
        {
            APMSDKAssert(msgQueueBody.charValue != NULL, @"info is empty");
            if (!msgQueueBody.charValue) return;
            Scene     scene;
            scene.flag = kSceneFlag;
            scene.timeStamp =  msgQueueBody.timeInterval;
            scene.sceneType = msgQueueBody.sceneType;
            scene.sceneIndex = msgQueueBody.sceneIndex;
            scene.sceneStrstr = msgQueueBody.charValue;
            scene.sceneStrLen = strlen(msgQueueBody.charValue);
            [self isFlushBufferToFile:kSceneWriteToBufferLen(scene)];
            ret = SDKHelper::SDKWriteHelper::writeSceneDataToBuffer(*_writeBuffer, scene);
            APMSDKAssert(ret == SDKError::SDK_NO_ERROR, @"pushMessageToGloabelBufferCustomData Tag  error");
        }
            break;
        // 帧数据
        case MsgQueueBodyType_Frame:
        {
            Frame obj;
            [self isFlushBufferToFile:kSizeofFrame];
            obj.flag = msgQueueBody.flag;
            obj.drawcall = msgQueueBody.drawcall;
            obj.triangle = msgQueueBody.triangle;
            obj.timeInterval = msgQueueBody.timeInterval;
            obj.deltaSeconds = msgQueueBody.deltaSeconds;
            ret = SDKHelper::SDKWriteHelper::writeFrameBuffer(*_writeBuffer, obj);
            APMSDKAssert(ret == SDKError::SDK_NO_ERROR, @"pushMessageToGloabelBufferCustomData Tag  error");
        }
            break;
        case MsgQueueBodyType_Version:
        {
            APMSDKAssert(msgQueueBody.charValue != NULL, @"version is empty");
            if (!msgQueueBody.charValue) return;
         
            [self isFlushBufferToFile:kSizeofVersion(msgQueueBody.charValue)];
            ret = SDKHelper::SDKWriteHelper::writeVersion(*_writeBuffer, msgQueueBody.charValue, strlen(msgQueueBody.charValue));
            APMSDKAssert(ret == SDKError::SDK_NO_ERROR, @"pushMessageToGloabelBufferCustomData version  error");
        }
            break;
        // app状态
        case MsgQueueBodyType_Appstate:
        {
            [self isFlushBufferToFile:kSizeofAppStateS];
            ret = SDKHelper::SDKWriteHelper::writeAppState(*_writeBuffer, msgQueueBody.flag, msgQueueBody.timeInterval);
            APMSDKAssert(ret == SDKError::SDK_NO_ERROR, @"pushMessageToGloabelBufferCustomData Appstate  error");
        }
            break;
            // IPCUUID
        case MsgQueueBodyType_IPCUUID:
        {
            
            APMSDKAssert(msgQueueBody.charValue != NULL, @"IPCUUID is empty");
            if (!msgQueueBody.charValue) return;
            
            [self isFlushBufferToFile:kSizeofIPCUUID(msgQueueBody.charValue)];
            ret = SDKHelper::SDKWriteHelper::writeIPCUUID(*_writeBuffer, msgQueueBody.charValue, strlen(msgQueueBody.charValue));
            APMSDKAssert(ret == SDKError::SDK_NO_ERROR, @"pushMessageToGloabelBufferCustomData IPCUUID  error");
        }
            break;
        default:
            break;
    }
}


- (void)pushMessageToGloabelBufferQueue:(FrameStateS)frameState
{
    SDKError::ErrorType     ret = SDKError::SDK_NO_ERROR;
    
    if ([[APMCCStrategy sharedInstance] isFeatureEnabled:FEATURE_ZIGZAG])
    {
        FWRITE_1(frameState.flag,NULL);
        
        g_apm_write_zigzag_int32(frameState.timeInterval);
        
        g_apm_write_zigzag_int32(frameState.mX);
        
        g_apm_write_zigzag_int32(frameState.mY);
        
        g_apm_write_zigzag_int32(frameState.mZ);
        
        g_apm_write_zigzag_int32(frameState.mPitch);
        
        g_apm_write_zigzag_int32(frameState.mYaw);
        
        g_apm_write_zigzag_int32(frameState.mRoll);
    }
    else
    {
        [self isFlushBufferToFile:kSizeofFrameStateS];
        ret = SDKHelper::SDKWriteHelper::writeFrameState(*_writeBuffer, frameState);
        APMSDKAssert(ret == SDKError::SDK_NO_ERROR, @"pushMessageToGloabelBufferQueue frameState error");
    }
}

- (void)pushMessageToGloabelBufferQueueInt8:(int8_t)value
{
    [self pushMessageToGloabelBufferQueueType:NumberOfBytes_Int8 int8:value int16:0 int32:0 bytes:NULL bytesLen:0];
}

- (void)pushMessageToGloabelBufferQueueInt16:(int16_t)value
{
    [self pushMessageToGloabelBufferQueueType:NumberOfBytes_Int16 int8:0 int16:value int32:0 bytes:NULL bytesLen:0];
}

- (void)pushMessageToGloabelBufferQueueInt32:(int32_t)value
{
    [self pushMessageToGloabelBufferQueueType:NumberOfBytes_Int32 int8:0 int16:0 int32:value bytes:NULL bytesLen:0];
}

- (void)pushMessageToGloabelBufferQueueInt64:(int64_t)value
{
    
}

- (void)pushMessageToGloabelBufferQueueBytes:(const char *)buffer bufferLen:(int16_t)len
{
     [self pushMessageToGloabelBufferQueueType:NumberOfBytes_bytes int8:0 int16:0 int32:0 bytes:buffer bytesLen:len];
}

- (SDKError::ErrorType)pushMessageToGloabelBufferQueueType:(NumberOfBytes)type int8:(int8_t)value8 int16:(int16_t)value16 int32:(int32_t)value32 bytes:(const char*)bytes bytesLen:(int)bytesLen
{
    SDKError::ErrorType     ret = SDKError::SDK_NO_ERROR;
    
    switch (type)
    {
        case NumberOfBytes_Int8:
            
             [self isFlushBufferToFile:1];
             ret = SDKHelper::SDKWriteHelper::writeInt8(*_writeBuffer, value8);
             APMSDKAssert(ret == SDKError::SDK_NO_ERROR, @"pushMessageToGloabelBufferQueueType writeInt8 error");
            
            break;
        case NumberOfBytes_Int16:
            
            [self isFlushBufferToFile:2];
            ret = SDKHelper::SDKWriteHelper::writeInt16(*_writeBuffer, value16);
            APMSDKAssert(ret == SDKError::SDK_NO_ERROR, @"pushMessageToGloabelBufferQueueType writeInt16 error");
            
            break;
        case NumberOfBytes_Int32:
            
            [self isFlushBufferToFile:4];
            ret = SDKHelper::SDKWriteHelper::writeInt32(*_writeBuffer, value32);
            APMSDKAssert(ret == SDKError::SDK_NO_ERROR, @"pushMessageToGloabelBufferQueueType writeInt32 error");
            
            break;
        case NumberOfBytes_Int64:
            
        
            break;
        case NumberOfBytes_bytes:
            
            if (bytes == NULL) return ret;
            [self isFlushBufferToFile:bytesLen];
            ret = SDKHelper::SDKWriteHelper::writeBytes(*_writeBuffer, bytes, bytesLen);
            APMSDKAssert(ret == SDKError::SDK_NO_ERROR, @"pushMessageToGloabelBufferQueueType writeBytes error");
            break;
            
        default:
            break;
    }
    
    return ret;
}

- (void)pushMessageToGloabelBufferQueue:(Scene)scene forceWriteToFile:(BOOL)isForce
{
    SDKError::ErrorType     ret = SDKError::SDK_NO_ERROR;
 
    if (scene.sceneStrstr)
    {
        // todo
        [self isFlushBufferToFile:kSceneWriteToBufferLen(scene)];
        ret = SDKHelper::SDKWriteHelper::writeSceneDataToBuffer(*_writeBuffer, scene);
        APMSDKAssert(ret == SDKError::SDK_NO_ERROR, @"pushMessageToGloabelBufferQueue drError::TDR_NO_ERROR");
    }
     // 强制性清空缓冲区，准备将数据上传到服务器
    if (isForce)
    {
        if ([[APMCCStrategy sharedInstance] isFeatureEnabled:FEATURE_MMAP])
        {
            [self closeCacheFile];
        }
        else
        {
            [self flushBufferToFile];
            [[FileManager sharedFileManager] closeFilePtr];
        }
        
    
    }
    
}

- (void)pushMessageToGloabelBufferQueue:(GamePerformanceDataType)gpDataType DataPerSec:(DataPerSec)dataPerSec                                                                                                                                                                                                                                                                                                                     isWriteToBuffer:(BOOL)isWriteToBuffer
{
    SDKError::ErrorType     ret = SDKError::SDK_NO_ERROR;
  
    switch (gpDataType)
    {
        case GamePerformanceDataType_CPU:
        {
            _dataPerSec.appCpuUsage = dataPerSec.appCpuUsage;
        }
            break;
        case GamePerformanceDataType_Memory:
        {
            _dataPerSec.appMemoryUsed = dataPerSec.appMemoryUsed;
            _dataPerSec.reserved1 = dataPerSec.reserved1;
            _maxPss = _dataPerSec.reserved1 > _maxPss ?  _dataPerSec.reserved1 :_maxPss;
        }
            break;
        case GamePerformanceDataType_GPU:
        {
            //_dataPerSec.gpu1 = dataPerSec.gpu1;
            //_dataPerSec.gpu2 = dataPerSec.gpu2;
        }
            break;
        case GamePerformanceDataType_NetworkTraffic:
        {
            _dataPerSec.netSend = dataPerSec.netSend;
            _dataPerSec.netRecv = dataPerSec.netRecv;
        }
            break;
        case GamePerformanceDataType_Battery:
            
            break;
        case GamePerformanceDataType_FPS:
            
            break;
        case GamePerformanceDataType_Unkown:
            
            break;
        default:
            
            break;
    }

    APMSDKLog(@"NSThread current Thread:%@",[NSThread currentThread]);
    if (isWriteToBuffer)
    {
        _dataPerSec.flag = kDataPerSecFlag;
        _dataPerSec.fps = 0;
        _dataPerSec.timeInterval = SDKHelper::SDKUtill::getCurrentTimeIntervalMillisecond();
        
        if ([[APMCCStrategy sharedInstance] isFeatureEnabled:FEATURE_ZIGZAG])
        {
            FWRITE_1(_dataPerSec.flag, NULL);
            
            g_apm_write_zigzag_int32(_dataPerSec.fps);
            
            g_apm_write_zigzag_int32(_dataPerSec.appCpuUsage);
            
            //uint32_t diff = _dataPerSec.timeInterval - _lastSecTimestamp;
            g_apm_write_zigzag_int32(_dataPerSec.timeInterval);
            
            g_apm_write_zigzag_int32(_dataPerSec.appMemoryUsed);
            
            for (int index = 0; index < (sizeof(_dataPerSec.reserved) / sizeof(int32_t)); index++)
            {
               g_apm_write_zigzag_int32(_dataPerSec.reserved[index]);
            }
            
            g_apm_write_zigzag_int32(_dataPerSec.netSend);
            
            g_apm_write_zigzag_int32(_dataPerSec.netRecv);
            
            g_apm_write_zigzag_int32(_dataPerSec.reserved1);
            
            g_apm_write_zigzag_int32(_dataPerSec.reserved2);
            
        }
        else
        {
            [self isFlushBufferToFile:kSizeofDataPerSec];
            // 将帧秒数据放入到缓存区，准备写入到文件缓冲区
            ret = SDKHelper::SDKWriteHelper::writeDataPerSecToBuffer(*_writeBuffer, _dataPerSec);
            APMSDKAssert(ret == SDKError::SDK_NO_ERROR, @"writeToGlobalBuffer error");
            
        }
       
        //_lastSecTimestamp = _dataPerSec.timeInterval;
        memset(&_dataPerSec, 0, sizeof(DataPerSec));
    }

}


- (void)flushBufferToFile
{
    if ([[APMCCStrategy sharedInstance] isFeatureEnabled:FEATURE_MMAP]) {
        return;
    }
    
    const char*             buffer;
    NSUInteger              bufferLen;
    
    buffer = _writeBuffer->getBeginPtr();
    bufferLen = _writeBuffer->getUsedSize();
    if (buffer && bufferLen > 0)
    {
        // 将缓冲区的数据写入到文件缓冲区
        [[FileManager sharedFileManager] flushBufferToFile:buffer bufferLen:bufferLen];
        memset(_buffer, 0, kGloabelBufferLen);
        _writeBuffer->set(_buffer, kGloabelBufferLen);
    }
}

- (void)isFlushBufferToFile:(unsigned long)len
{
    if ([[APMCCStrategy sharedInstance] isFeatureEnabled:FEATURE_MMAP]) {
        return;
    }
    
    if ((_writeBuffer->getUsedSize() + len) > kGloabelBufferLen) [self flushBufferToFile];
}


- (void)dealloc
{
    if (_writeBuffer != NULL) {
        delete _writeBuffer;
        _writeBuffer = NULL;
    }
}


@end




