//
//  SDKHelper.hpp
//  LearnOpenGLES
//
//  Created by xiang lin on 17/01/2018.
//  Copyright © 2018 . All rights reserved.
//

#ifndef SDKHelper_h
#define SDKHelper_h

#include <stdio.h>
#import "SDKStructEnumDefine.h"
#import "SDKBuf.h"
//#import "apm_spec.h"
class GPMObserver;
using namespace TAPMIOS_SDKBuf;
namespace SDKHelper
{
    class SDKWriteHelper
    {
     
        public:
            /**
             * 将文件属性，将添加到文件开始几个字节，写入到writeBuffer
             */
            static SDKError::ErrorType writeFileAttribute(SDKWriteBuffer& writeBuffer,FileAttribute fileAttribute);
            /**
             *  将场景结构体写入到writeBuffer
             */
            static SDKError::ErrorType writeSceneDataToBuffer(SDKWriteBuffer& writeBuffer,Scene scene);
            /**
             *  将帧数据三角形个数和drawcall写入到writeBuffer
             */
            static SDKError::ErrorType writeFrameBuffer(SDKWriteBuffer& writeBuffer,Frame drawTriangleObj);
        
            /**
             *  将frameState数据写入到writeBuffer
             */
            static SDKError::ErrorType writeFrameState(SDKWriteBuffer& writeBuffer,FrameStateS frameState);
            /**
             *  将秒数据写入到writeBuffer
             */
            static SDKError::ErrorType writeDataPerSecToBuffer(SDKWriteBuffer& writeBuffer,DataPerSec dataPerSec);

            /**
             *  将用户ID写入到writeBuffer
             */
            static SDKError::ErrorType writeUserID(SDKWriteBuffer& writeBuffer,const char* userID);
            /**
             *  将全局画质写入到writeBuffer
             */
            static SDKError::ErrorType writeQuality(SDKWriteBuffer& writeBuffer,int32_t quality);
        
        
            static SDKError::ErrorType writeDeviceLevel(SDKWriteBuffer& writeBuffer,int32_t deviceLevel);
            /**
             *  将自定义事件写入到writeBuffer
             */
            static SDKError::ErrorType writeGameEvent(SDKWriteBuffer& writeBuffer,int32_t timeInterval,int32_t key,const char* info);
            /**
             *  将自定义全局事件写入到writeBuffer
             */
            static SDKError::ErrorType writeGameEventCached(SDKWriteBuffer& writeBuffer,int32_t key,const char* info);
            /**
             *  将网络延迟写入到writeBuffer
             */
            static SDKError::ErrorType writeNetLatency(SDKWriteBuffer& writeBuffer,int32_t timeInterval,int16_t latency);
            /**
             *  将网络状态写入到writeBuffer
             */
            static SDKError::ErrorType writeNetworkStat(SDKWriteBuffer& writeBuffer,int8_t flag,int16_t netstat);
            /**
             *  将回扯距离写入到writeBuffer
             */
            static SDKError::ErrorType writeLagStatus(SDKWriteBuffer& writeBuffer,int32_t timeInterval,int32_t distance);
            /**
             *  将本地写入到writeBuffer
             */
            static SDKError::ErrorType writeLocal(SDKWriteBuffer& writeBuffer,const char* cLocal);
            /**
             *  将version写入到writeBuffer
             */
            static SDKError::ErrorType writeVersion(SDKWriteBuffer& writeBuffer,const char* version,uint16_t versionLen);
            /**
             *  将设备存储空间，空闲空间写入到writeBuffer
             */
            static SDKError::ErrorType writeDeviceSpaceData(SDKWriteBuffer& writeBuffer,int32_t totalSpace,int32_t freeSpace);
            /**
             *  将app状态，及其时间写入到writeBuffer
             */
            static SDKError::ErrorType writeAppState(SDKWriteBuffer& writeBuffer,char flag,int32_t timeInterval);
            /**
             *  将IPCUUID，及其时间写入到writeBuffer
             */
            static SDKError::ErrorType writeIPCUUID(SDKWriteBuffer& writeBuffer,const char* iPCUUID,uint16_t len);
        
        public:
        
            /**
             *  将1个整型字节写入到writeBuffer
             */
            static SDKError::ErrorType writeInt8(SDKWriteBuffer& writeBuffer,int8_t value);
        
            /**
             *  将2个整型字节写入到writeBuffer
             */
        static SDKError::ErrorType writeInt16(SDKWriteBuffer& writeBuffer,int16_t value);
        
            /**
             *  将4个整型字节写入到writeBuffer
             */
            static SDKError::ErrorType writeInt32(SDKWriteBuffer& writeBuffer,int32_t value);
        
            /**
             *  将buffer写入到writeBuffer
             */
            static SDKError::ErrorType writeBytes(SDKWriteBuffer& writeBuffer,const char* buffer,int len);
    };
    
    class SDKUtill
    {
        public:
            /**
             *  网络类型
             */
            static short  networkType;
            /**
             *  采集选项
             */
            static int  opts;
            /**
             *  当前版本字符串
             */
            static NSString*  currVersionStr;
            /**
             *  当前版本double
             */
            static double  currVersionDoub;
        
            static NSString*  sessionUUID;
        
            static NSString*  uniqueSessionUUID;
        
            static NSString*  linkSessionUUID;
        
            static GPMObserver* gpmObserver;
        
        public:
        
            //static NSString* getNSStringFromTDM(const char* deviceInfoName);
        
            //static int64_t getInt64FromTDM(const char* deviceInfoName);
        
            //static NSString* getSysVersion();
        
            //static NSString* getAppVersion();
        
            /**
             *  获取设备型号 eg:Iphone x
             */
            //static NSString* getDeviceModel();
        
            //static NSString* getDeviceModelFromTDM();
        
            //static NSString* getBrand();
        
            //static NSString* getIDFV();
            /**
             *
             */
            static NSString* getCPUArchName();
            /**
             *  设备硬盘总的空间
             */
            //static uint32_t getDeviceTotalSpace();
            /**
             *  获取设备空闲空间
             */
            static uint32_t getDeviceFreeSpace();
        
            /**
             *  获取当前毫秒级时间戳
             */
            static uint32_t  getCurrentTimeIntervalMillisecond();
        
            static uint64_t  getCurrentTimeMicroseconds();
            /**
             *  获取当前设备物理内存
             */
            static uint32_t getTotalRAMCount();
            /**
             *  获取当前设备处理器个数
             */
            static NSUInteger getProccessorCount();
        
            static NSString* generateUuid();
        
            static NSString* getCurrentFullTime();
        
            static NSString* getCurrentTimeIntervalSince1970();
        
            static NSString* getCurrentLogTime();
        
            static const char* getErrorMsg(int errorCode);
   
        public:
        
            //NSMutableDictionary* mIphoneModelMutableDic;
        
        public:
        
            SDKUtill();
        
            ~SDKUtill();
        
            NSDictionary* getDeviceEasyReadModel(NSString* deviceIdent);
        
            //void IPhoneInfo(const char* iphoneIdent,const char* iphoneModel,int cpu,int core,const char* coreType,const char*gpuVendor,const char*gpuType);
        
            NSString* convertLowerCaseNoEmptyStr(NSString* sourceStr);
        
    };
}


#endif /* SDKHelper_hpp */
