//
//  TApmGCloud.hpp
//  APM
//
//  Created by xiang lin on 2019/10/15.
//  Copyright © 2019 xianglin. All rights reserved.
//

#include "IRemoteConfig.h"
#include "GCloudPluginManager/Service/RemoteConfig/IRemoteConfigService.h"
#include "PluginAPM.h"
//#include <string>

namespace GCloud {
    namespace APM {
    
        IRemoteConfig* GetIRemoteConfig();
    }
}
