/*
 * AutoLock.h
 *
 *  Created on: 2018��6��18��
 *      Author: vincentwgao
 */

#ifndef AUTOLOCK_H_
#define AUTOLOCK_H_

#import "TApm_Mutex.h"

class TApm_AutoLock
{
public:
	inline TApm_AutoLock(TApmMutex& mutex) : mLock(mutex)  { mLock.lock();}
	inline ~TApm_AutoLock() { mLock.unlock(); }
private:
	TApmMutex& mLock;
};



#endif /* AUTOLOCK_H_ */
