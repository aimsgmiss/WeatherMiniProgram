//
//  TApmCollectPerformance.m
//  SDK
//
//  Created by xiang lin on 11/12/2017.
//  Copyright © 2017 xiang lin. All rights reserved.
//

#import "TApmCollectPerformance.h"


@interface TApmCollectPerformance()

@end

@implementation TApmCollectPerformance

-(instancetype)init
{
    self = [super init];
    
    return self;
}

-(void)startMonitor
{
    self.isCollectionData = YES;
}

-(void)collectionDatas
{
    
}

-(void)stopMonitor
{
    self.isCollectionData = NO;
}

-(void)dealloc
{
    
    
}

@end


//温度监控
@implementation TemperatureCollectPerformance

-(void)startMonitor
{
    
    [super startMonitor];
}

-(void)stopMonitor
{
    
    [super stopMonitor];
    
}

@end






