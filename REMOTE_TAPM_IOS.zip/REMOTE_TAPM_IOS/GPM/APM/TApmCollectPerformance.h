//
//  TApmCollectPerformance.h
//  SDK
//
//  Created by xiang lin on 11/12/2017.
//  Copyright © 2017 xiang lin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TApmCollectPerformance : NSObject

@property (nonatomic,assign) BOOL isCollectionData;

-(void)startMonitor;

-(void)collectionDatas;

-(void)stopMonitor;

@end

//温度监控
@interface TemperatureCollectPerformance:TApmCollectPerformance


@end









