//
//  SDKIPC.m
//  LearnOpenGLES
//
//  Created by vincentwgao on 2018/9/13.
//  Copyright © 2018年 xianglin. All rights reserved.
//
#import <UIKit/UIKit.h>
#import "SDKIPC.h"
#import "SDKSocket.h"
#import "TApmLog.h"

#define kIPCURL             [NSURL URLWithString:@"https://127.0.0.1:7889"]

@interface SDKIPC()

@end

@implementation SDKIPC

- (NSString*)uuidStr
{
    SDKSocket*              sdkSocket;
    ssize_t                 result;
    char                    buffer[128];
    const void*             sendData = NULL;
    NSString*               sendStr;
    NSString*               revStr;
    
    sdkSocket = [[SDKSocket alloc] initWithURL:kIPCURL];
    if (!sdkSocket)
    {
        APM_LOG_DEBUG(@"TApm_IPC_ios IPC server not exist");
        return nil;
    }
    
    do{
        result = [sdkSocket sdkRecv:buffer size:sizeof(buffer)];
        if (result <= 0)
        {
            [sdkSocket closeSocket];
            return nil;
        }
        APM_LOG_DEBUG(@"TApm_IPC_ios SDKIPC uuid:%s",buffer);
        revStr = [NSString stringWithFormat:@"%s",buffer];
        if (revStr && [revStr containsString:@"wetest"])
        {
            sendStr = [revStr substringToIndex:36];
            NSDictionary *infoPlist = [[NSBundle mainBundle] infoDictionary];
            if (!infoPlist) goto ret;
            
            NSString *icon = [[infoPlist valueForKeyPath:@"CFBundleIcons.CFBundlePrimaryIcon.CFBundleIconFiles"] lastObject];
            if (!icon) goto ret;
            
            NSData *iconData = UIImageJPEGRepresentation([UIImage imageNamed:icon], 0);
            if (!iconData) goto ret;
            
            NSString *appIcon = [iconData base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
            if (!appIcon) goto ret;
            
            NSString *appVersion = [infoPlist objectForKey:@"CFBundleShortVersionString"];
            if (!appVersion) goto ret;
            
            NSString *appExcutable = [infoPlist objectForKey:@"CFBundleExecutable"];
            if (!appExcutable) goto ret;
            
            NSString *appName;
            if ([infoPlist objectForKey:@"CFBundleDisplayName"]) {
                appName = [infoPlist objectForKey:@"CFBundleDisplayName"];
            }else {
                appName = @"";
            }
            APM_LOG_DEBUG(@"icon:%@,appVersion:%@,appExcutable:%@,appName:%@",icon,appVersion,appExcutable,appName);
            NSDictionary *dic = @{@"wetest_uuid":sendStr,@"appIcon":appIcon,@"appVersion":appVersion,@"appExcutable":appExcutable,@"appName":appName};
            NSData *datas = [NSJSONSerialization dataWithJSONObject:dic options:0 error:nil];
            sendData = [datas bytes];
            size_t len = [datas length];
            if (!sendData)
            {
                char buffer[] = "error";
                result = [sdkSocket sdkSend:buffer size:strlen(buffer)];
                goto ret;
            }
            
            result = [sdkSocket sdkSend:(void*)sendData size:len];
            goto ret;
        }
        else
        {
            [sdkSocket closeSocket];
            return nil;
        }
    } while (YES);
    
ret:
    [sdkSocket closeSocket];
    return revStr;
}

@end
