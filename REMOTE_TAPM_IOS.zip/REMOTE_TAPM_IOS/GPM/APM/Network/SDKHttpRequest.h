//
//  SDKHttpRequest.h
//  LearnOpenGLES
//
//  Created by vincentwgao on 2018/7/2.
//  Copyright © 2018年 xianglin. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (^SDKResponeBlock)(NSData* data, NSURLResponse* response, NSError*  error);

@interface SDKHttpRequest : NSObject

- (void)requestURL:(NSURL*)url  completionHandler:(SDKResponeBlock)handler;

@end
