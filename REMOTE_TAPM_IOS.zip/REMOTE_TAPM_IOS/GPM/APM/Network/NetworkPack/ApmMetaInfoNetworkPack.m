//
//  ApmMetaInfoNetworkPack.m
//  LearnOpenGLESWithGPUImage
//
//  Created by xiang lin on 26/12/2017.
//  Copyright © 2017 xiang. All rights reserved.
//

#import "ApmMetaInfoNetworkPack.h"

static ApmMetaInfoNetworkPack* singleInstance = nil;

@implementation ApmMetaInfoNetworkPack

+ (ApmMetaInfoNetworkPack*)sharedApmMetaInfoNetworkPack
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        singleInstance = [[[self class] alloc] init];
    });
    
    return singleInstance;
}

@end
