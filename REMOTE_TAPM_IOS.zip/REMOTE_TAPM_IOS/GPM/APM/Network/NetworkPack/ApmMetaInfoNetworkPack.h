//
//  ApmMetaInfoNetworkPack.h
//  LearnOpenGLESWithGPUImage
//
//  Created by xiang lin on 26/12/2017.
//  Copyright © 2017 xiang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ApmMetaInfoNetworkPack : NSObject

@property (nonatomic,copy) NSString* szUserID;

@property (nonatomic,copy) NSString* szAppID;

@property (nonatomic,copy) NSString* szAppVersion;

@property (nonatomic,copy) NSString* szBuildVersion;

@property (nonatomic,copy) NSString* szSystemVersion;

@property (nonatomic,assign) uint16_t randomSeed;

@property (nonatomic,assign) uint64_t ullImei;                 // uuid为什么是整型的

@property (nonatomic,assign) uint64_t ullMac;

@property (nonatomic,assign) uint16_t wOsType;

@property (nonatomic,copy) NSString* szAppFrom;

@property (nonatomic,assign) time_t tLaunchTime;

@property (nonatomic,copy) NSString* szManu;                    // iPhone，ipad,ipod

@property (nonatomic,copy) NSString* szModel;                   // 型号

@property (nonatomic,assign) uint16_t wOsLevel;                 ////系统版本是整型的 为什么是整型的

@property (nonatomic,assign) uint32_t dwMem;

@property (nonatomic,assign) uint32_t dwCpuCore;

@property (nonatomic,assign) uint32_t dwCpuFreq;

@property (nonatomic,copy) NSString* szCpuArch;

@property (nonatomic,copy) NSString* szVendorUUID;

@property (nonatomic,copy) NSString* szGpuVendor;

@property (nonatomic,copy) NSString* szGpuRenderer;

@property (nonatomic,copy) NSString* szGpuVersion;

@property (nonatomic,assign) uint32_t dwDatasz;

@property (nonatomic,assign) uint16_t wNetwork_type;

@property (nonatomic,assign) uint16_t wFlash_size;

@property (nonatomic,assign) uint16_t wFlash_size_free;

+ (ApmMetaInfoNetworkPack*)sharedApmMetaInfoNetworkPack;

@end
