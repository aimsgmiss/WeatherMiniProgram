//
//  NetworkCollectPerformance.m
//  LearnOpenGLESWithGPUImage
//
//  Created by xiang lin on 14/12/2017.
//  Copyright © 2017 xiang All rights reserved.
//
#import <UIKit/UIKit.h>
#import <SystemConfiguration/SystemConfiguration.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import <dlfcn.h>
#import <ifaddrs.h>
#import <arpa/inet.h>
#import <net/if.h>
#import <net/if_dl.h>
#import "NetworkCollectPerformance.h"
#import "SDKHeader.h"
#import "TApmApiSingleInstance.h"
#import "TApmLog.h"

#define kHostName       @"www.apple.com"

typedef NS_ENUM(NSUInteger, NetworkType) // 网络类型
{
    NetworkType_WIFI = 1,
    NetworkType_2G,
    NetworkType_3G,
    NetworkType_4G,
    NetworkType_Unkown,
};

typedef enum : NSInteger
{
    APMSDK_NotReachable = 0,
    APMSDK_ReachableViaWiFi,
    APMSDK_ReachableViaWWAN,
    APMSDK_ReachableVia2G,
    APMSDK_ReachableVia3G,
    APMSDK_ReachableVia4G
} APMSDKNetworkStatus;

@interface NetworkCollectPerformance()
{
    NetworkType         _currentNetworkType;
    NSUInteger          _preWifiSend;
    NSUInteger          _preWifiReceieved;
    NSUInteger          _preWWANSend;
    NSUInteger          _preWWANReceieved;
    
    NSUInteger          _diffWifiSend;
    NSUInteger          _diffWifiReceieved;
    NSUInteger          _diffWWANSend;
    NSUInteger          _diffWWANReceieved;
}

@end

static NetworkCollectPerformance*  singleInstance = nil;

@implementation NetworkCollectPerformance

+ (instancetype)sharedInstance
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        singleInstance = [[NetworkCollectPerformance alloc] init];
    });
    
    return singleInstance;
}

- (id)init
{
    if (self = [super init])
    {
        _currentNetworkType = NetworkType_Unkown;
        _preWifiSend = 0;
        _preWifiReceieved = 0;
        _preWWANSend = 0;
        _preWWANReceieved = 0;
        _diffWifiSend = 0;
        _diffWifiReceieved = 0;
        _diffWWANSend = 0;
        _diffWWANReceieved = 0;
    }
    
    return self;
}

- (void)startMonitor
{
    [super startMonitor];
    //[self getNetworkType];
}

- (void)collectionDatas
{
    if (!self.isCollectionData) return;
    [super collectionDatas];
    [self getNetworkTraffic];
}


#pragma mark - Network Flag Handling

- (APMSDKNetworkStatus)networkStatusForFlags:(SCNetworkReachabilityFlags)flags
{
    if ((flags & kSCNetworkReachabilityFlagsReachable) == 0)
    {
        // The target host is not reachable.
        return  APMSDK_NotReachable;
    }
    
    APMSDKNetworkStatus returnValue =  APMSDK_NotReachable;
    
    if ((flags & kSCNetworkReachabilityFlagsConnectionRequired) == 0)
    {
        /*
         If the target host is reachable and no connection is required then we'll assume (for now) that you're on Wi-Fi...
         */
        returnValue =  APMSDK_ReachableViaWiFi;
    }
    
    if ((((flags & kSCNetworkReachabilityFlagsConnectionOnDemand ) != 0) ||
         (flags & kSCNetworkReachabilityFlagsConnectionOnTraffic) != 0))
    {
        /*
         ... and the connection is on-demand (or on-traffic) if the calling application is using the CFSocketStream or higher APIs...
         */
        
        if ((flags & kSCNetworkReachabilityFlagsInterventionRequired) == 0)
        {
            /*
             ... and no [user] intervention is needed...
             */
            returnValue =  APMSDK_ReachableViaWiFi;
        }
    }
    
    
    if ((flags & kSCNetworkReachabilityFlagsIsWWAN) == kSCNetworkReachabilityFlagsIsWWAN)
    {
        /*
         ... but WWAN connections are OK if the calling application is using the CFNetwork APIs.
         */
        returnValue = APMSDK_ReachableViaWWAN;
        
        CTTelephonyNetworkInfo *phonyNetwork = [[CTTelephonyNetworkInfo alloc] init];
        if (phonyNetwork == nil)
        {
            return APMSDK_NotReachable;
        }
        
        NSString *currentStr = phonyNetwork.currentRadioAccessTechnology;
        if (currentStr) {
            if ([currentStr isEqualToString:CTRadioAccessTechnologyLTE]) {
                return APMSDK_ReachableVia4G;
            }else if ([currentStr isEqualToString:CTRadioAccessTechnologyGPRS]|| [currentStr isEqualToString:CTRadioAccessTechnologyEdge]){
                return APMSDK_ReachableVia2G;
            }else{
                return APMSDK_ReachableVia3G;
            }
        }
        
        if ((flags & kSCNetworkReachabilityFlagsTransientConnection) == kSCNetworkReachabilityFlagsTransientConnection) {
            if((flags & kSCNetworkReachabilityFlagsConnectionRequired) == kSCNetworkReachabilityFlagsConnectionRequired) {
                return APMSDK_ReachableVia2G;
            }
            return APMSDK_ReachableVia3G;
        }
        return APMSDK_ReachableViaWWAN;
        
    }
    
    return returnValue;
}


- (short)getNetworkType
{
    NetworkType                 currentType= NetworkType_4G;
    SCNetworkReachabilityRef    reachability;
    SCNetworkReachabilityFlags  flags;
    APMSDKNetworkStatus         networkStatus = APMSDK_NotReachable;
    
    reachability = SCNetworkReachabilityCreateWithName(NULL, [kHostName UTF8String]);
    if(SCNetworkReachabilityGetFlags(reachability, &flags))
    {
        networkStatus = [self networkStatusForFlags:flags];
    }
    
    switch (networkStatus)
    {
            
        case APMSDK_NotReachable:
            currentType = NetworkType_Unkown;
            break;
        case APMSDK_ReachableViaWWAN:
            currentType = NetworkType_4G;
            break;
        case APMSDK_ReachableViaWiFi:
            currentType = NetworkType_WIFI;
            break;
        case APMSDK_ReachableVia2G:
            currentType = NetworkType_2G;
            break;
        case APMSDK_ReachableVia3G:
            currentType = NetworkType_3G;
            break;
        case APMSDK_ReachableVia4G:
            currentType = NetworkType_4G;
            break;
        default:
            currentType = NetworkType_Unkown;
            break;
    }
    
    _currentNetworkType = currentType;
    APMSDKLog(@"currentNetworkType:%lu",_currentNetworkType);
    if (_currentNetworkType != currentType)
    {
        //_currentNetworkType = currentType;
        //g_PostNetworkStatus(kNetworkTypeFlag_2,currentType);
    }
    
    CFRelease(reachability);
    
    return currentType;
    
}

- (void)getNetworkTraffic
{
    BOOL                    success;
    struct ifaddrs*         addrs;
    const struct ifaddrs*   cursor;
    const struct if_data*   networkStatisc;
    unsigned int            wiFiSend = 0;
    unsigned int            wiFiReceived = 0;
    unsigned int            wWANSend = 0;
    unsigned int            wWANReceived = 0;
    NSString*               name;
    DataPerSec              dataPerSec;
    
    memset(&dataPerSec, 0, sizeof(dataPerSec));
    success = getifaddrs(&addrs) == 0;
    if (success)
    {
        cursor = addrs;
        while (cursor != NULL)
        {
            name = [NSString stringWithFormat:@"%s",cursor->ifa_name];
            if ( name && cursor->ifa_addr && cursor->ifa_addr->sa_family == AF_LINK)
            {
                if ([name hasPrefix:@"en"] && cursor->ifa_data)
                {
                    networkStatisc = (const struct if_data *) cursor->ifa_data;
                    if (networkStatisc)
                    {
                        wiFiSend += networkStatisc->ifi_obytes;
                        wiFiReceived += networkStatisc->ifi_ibytes;
                    }
                }
                
                if ([name hasPrefix:@"pdp_ip"] && cursor->ifa_data)
                {
                    networkStatisc = (const struct if_data *) cursor->ifa_data;
                    if (networkStatisc)
                    {
                        wWANSend += networkStatisc->ifi_obytes;
                        wWANReceived += networkStatisc->ifi_ibytes;
                    }
                }
            }
            cursor = cursor->ifa_next;
        }
        
        if(_preWifiSend == 0) _preWifiSend = wiFiSend;
        if(_preWifiReceieved == 0) _preWifiReceieved = wiFiReceived;
        if(_preWWANSend == 0) _preWWANSend = wWANSend;
        if(_preWWANReceieved == 0) _preWWANReceieved = wWANReceived;
        
        _diffWifiSend = wiFiSend - _preWifiSend;
        _diffWifiReceieved = wiFiReceived - _preWifiReceieved;
        _diffWWANSend =  wWANSend - _preWWANSend;
        _diffWWANReceieved = wWANReceived - _preWWANReceieved;
        
        if(wiFiSend > 0)  _preWifiSend = wiFiSend;
        if(wiFiReceived > 0) _preWifiReceieved = wiFiReceived;
        if(wWANSend > 0) _preWWANSend = wWANSend;
        if(wWANReceived > 0) _preWWANReceieved = wWANReceived;
        
        freeifaddrs(addrs);
    }

    //APM_LOG_DEBUG(@" WifiSend:%lu,WifiReceieved:%lu,WWANSend:%lu,WWANReceieved:%lu",(unsigned long)_diffWifiSend/kByteConvertKB,(unsigned long)_diffWifiReceieved/kByteConvertKB,(unsigned long)_diffWWANSend/kByteConvertKB,(unsigned long)_diffWWANReceieved/kByteConvertKB);
   
    dataPerSec.netRecv = int32_t(_diffWifiReceieved + _diffWWANReceieved) / kByteConvertKB;
    dataPerSec.netSend = int32_t(_diffWifiSend + _diffWWANSend) / kByteConvertKB;
    [[MessageQueue sharedInstance] pushMessageToGloabelBufferQueue:GamePerformanceDataType_NetworkTraffic DataPerSec:dataPerSec isWriteToBuffer:NO];
    
}


-(void)stopMonitor
{
    [super stopMonitor];
    _currentNetworkType = NetworkType_Unkown;
}

@end

