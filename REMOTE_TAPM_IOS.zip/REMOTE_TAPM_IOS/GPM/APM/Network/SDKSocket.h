//
//  SDKIPC.h
//  LearnOpenGLES
//
//  Created by vincentwgao on 2018/9/3.
//  Copyright © 2018年 xianglin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SDKSocket : NSObject

@property(nonatomic,assign) int socketId;

-(instancetype)initWithURL:(NSURL*)url;

- (ssize_t)sdkSend:(void *)buffer size:(size_t)size;

- (ssize_t)sdkRecv:(void*)buffer size:(size_t)size;

- (void)closeSocket;
@end
