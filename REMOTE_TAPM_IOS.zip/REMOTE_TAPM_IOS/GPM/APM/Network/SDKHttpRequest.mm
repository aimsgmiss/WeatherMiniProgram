//
//  SDKHttpRequest.m
//  LearnOpenGLES
//
//  Created by vincentwgao on 2018/7/2.
//  Copyright © 2018年 xianglin. All rights reserved.
//

#import "SDKHttpRequest.h"

@implementation SDKHttpRequest

- (void)requestURL:(NSURL*)url  completionHandler:(SDKResponeBlock)handler
{
    NSURLSession*               urlSession;
    NSURLSessionTask*           task;
    NSURLSessionConfiguration*  configuration;
    
    configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    if (!configuration) return ;
    
    configuration.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    [configuration setURLCache:[NSURLCache sharedURLCache]];
    urlSession = [NSURLSession sessionWithConfiguration:configuration];
    if (!urlSession) return ;
    
    task = [urlSession dataTaskWithURL:url completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (handler) {
            handler(data,response,error);
        }
        
        [urlSession finishTasksAndInvalidate];
    }];
    
    if (task) [task resume];
    
}
@end
