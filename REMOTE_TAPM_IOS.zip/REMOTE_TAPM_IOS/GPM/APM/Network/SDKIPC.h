//
//  SDKIPC.h
//  LearnOpenGLES
//
//  Created by vincentwgao on 2018/9/13.
//  Copyright © 2018年 xianglin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SDKIPC : NSObject

- (NSString*)uuidStr;

@end
