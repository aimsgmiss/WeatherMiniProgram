//
//  SDKIPC.m
//  LearnOpenGLES
//
//  Created by vincentwgao on 2018/9/3.
//  Copyright © 2018年 xianglin. All rights reserved.
//

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#import <arpa/inet.h>
#import <netdb.h>
#import "SDKSocket.h"
#import "TApmLog.h"

#define kRecvBufferLen      256


@implementation SDKSocket

- (instancetype)initWithURL:(NSURL*)url
{
    if (!url) return nil;
    
    if (self = [super init])
    {
        _socketId = [self sdkCreateSocketService:url];
        
        if (_socketId == -1) return nil;
        
        return self;
    }
    
    return nil;
}

- (ssize_t)sdkSend:(void *)buffer size:(size_t)size
{
    if (buffer == NULL || size == 0)
    {
        APM_LOG_RELEASE(@"sdkSend buffer is NULL or size is 0");
        return 0;
    }
    ssize_t bufferLen = send(self.socketId, buffer, size, 0);
    
    return bufferLen;
}

- (ssize_t)sdkRecv:(void*)buffer size:(size_t)size
{
    if (buffer == NULL || size == 0)
    {
        APM_LOG_RELEASE(@"sdkRecv buffer is NULL or size is 0 ");
        return 0;
    }
    
    ssize_t bufferLen = recv(self.socketId, buffer, size, 0);
    
    return bufferLen;
}


- (int)sdkCreateSocketService:(NSURL* )serverURL
{
    NSString*           host;
    NSNumber*           port;
    struct hostent*     remoteHost;
    struct in_addr*     remoteInAddr;
    struct sockaddr_in  addr;
    struct sockaddr_in  peerAddr;
    int                 noSigpipe;
    int                 result = -1;
    int                 clientId = -1;
    
    host = [serverURL host];
    port = [serverURL port];
    if(host == nil || port == nil)
    {
        APM_LOG_RELEASE(@"network connect error(host or port is nil)..");
        return -1;
    }

    remoteHost = gethostbyname([host UTF8String]);
    if (remoteHost == NULL || remoteHost->h_addr_list == NULL)
    {
        APM_LOG_RELEASE(@"network connect error(remoteHost or remoteHost->h_addr_list is NULL)..");
        return -1;
    }

    remoteInAddr = (struct in_addr *)remoteHost->h_addr_list[0];
    if (remoteInAddr == NULL)
    {
        APM_LOG_RELEASE(@"network connect error(remoteInAddr is NULL)..");
        return -1;
    }

    clientId = socket(AF_INET, SOCK_STREAM, 0);
    if (clientId == -1)
    {
        APM_LOG_RELEASE(@"network create socket error");
        return -1;
    }
    
    memset(&addr, 0, sizeof(addr));
    addr.sin_len = sizeof(addr);
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    
    result = bind(clientId, (const struct sockaddr *)&addr, sizeof(addr));
    if (result != 0)
    {
        APM_LOG_RELEASE(@"network bind socket error");
        close(clientId);
        return -1;
    }
    
    noSigpipe = 1;
    result = setsockopt(clientId, SOL_SOCKET, SO_NOSIGPIPE, &noSigpipe, sizeof(noSigpipe));
    if (result != 0)
    {
        APM_LOG_RELEASE(@"network getsockname error");
        close(clientId);
        return -1;
    }
    
    memset(&peerAddr, 0, sizeof(peerAddr));
    peerAddr.sin_len = sizeof(peerAddr);
    peerAddr.sin_family = AF_INET;
    peerAddr.sin_port = htons([port intValue]);
    peerAddr.sin_addr = *remoteInAddr;
    
    socklen_t addrLen;
    addrLen = sizeof(peerAddr);
    result = connect(clientId, (struct sockaddr *)&peerAddr, addrLen);
    if (result != 0)
    {
        APM_LOG_RELEASE(@"network getsockname error");
        close(clientId);
        return -1;
    }
    APM_LOG_RELEASE(@"network connnect success");
    result = getsockname(clientId, (struct sockaddr *)&addr, &addrLen);
    if (result == 0) return clientId;
    
    return clientId;
}

- (void)closeSocket
{
    shutdown(self.socketId, SHUT_RDWR);
    close(self.socketId);
    self.socketId = -1;
}



@end
