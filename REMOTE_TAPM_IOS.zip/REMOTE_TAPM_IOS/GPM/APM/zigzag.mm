#include <stdio.h> 
#include "zigzag.h"

namespace Hawk
{

	// int encodeInt(int n, char* buf, int pos) {
	//// move sign to low-order bit, and flip others if negative
	//  n = (n << 1) ^ (n >> 31);
	//  int start = pos;
	//  if ((n & ~0x7F) != 0) {
	//    buf[pos++] = (byte)((n | 0x80) & 0xFF);
	//    n >>>= 7;
	//    if (n > 0x7F) {
	//      buf[pos++] = (byte)((n | 0x80) & 0xFF);
	//      n >>>= 7;
	//      if (n > 0x7F) {
	//        buf[pos++] = (byte)((n | 0x80) & 0xFF);
	//        n >>>= 7;
	//        if (n > 0x7F) {
	//          buf[pos++] = (byte)((n | 0x80) & 0xFF);
	//          n >>>= 7;
	//        }
	//      }
	//    }
	//  }
	//  buf[pos++] = (byte) n;
	//  return pos - start;
	//}

	static const int kMaxVarintBytes = 10;
	static const int kMaxVarint32Bytes = 5;
    const uint8_t* ReadVarint32FromArray(const uint8_t* buffer, uint32_t* value)
    //inline const uint8_t* ReadVarint32FromArray(const uint8_t* buffer, uint32_t* value)
	{
		// Fast path:  We have enough bytes left in the buffer to guarantee that
		// this read won't cross the end, so we can skip the checks.
		const uint8_t* ptr = buffer;
		uint32_t b;
		uint32_t result;

		b = *(ptr++);
		result = (b & 0x7F);
		if (!(b & 0x80))
			goto done;
		b = *(ptr++);
		result |= (b & 0x7F) << 7;
		if (!(b & 0x80))
			goto done;
		b = *(ptr++);
		result |= (b & 0x7F) << 14;
		if (!(b & 0x80))
			goto done;
		b = *(ptr++);
		result |= (b & 0x7F) << 21;
		if (!(b & 0x80))
			goto done;
		b = *(ptr++);
		result |= b << 28;
		if (!(b & 0x80))
			goto done;

		// If the input is larger than 32 bits, we still need to read it all
		// and discard the high-order bits.
		for (int i = 0; i < kMaxVarintBytes - kMaxVarint32Bytes; i++)
		{
			b = *(ptr++);
			if (!(b & 0x80))
				goto done;
		}

		// We have overrun the maximum size of a varint (10 bytes).  Assume
		// the data is corrupt.
		return NULL;

		done: *value = result;
		return ptr;
	}

	int WriteVarintInt32(uint32_t value, uint8_t* target)
	{
		target[0] = static_cast<uint8_t> (value | 0x80);
		if (value >= (1 << 7))
		{
			target[1] = static_cast<uint8_t> ((value >> 7) | 0x80);
			if (value >= (1 << 14))
			{
				target[2] = static_cast<uint8_t> ((value >> 14) | 0x80);
				if (value >= (1 << 21))
				{
					target[3] = static_cast<uint8_t> ((value >> 21) | 0x80);
					if (value >= (1 << 28))
					{
						target[4] = static_cast<uint8_t> (value >> 28);
						return  5;
					}
					else
					{
						target[3] &= 0x7F;
						return  4;
					}
				}
				else
				{
					target[2] &= 0x7F;
					return  3;
				}
			}
			else
			{
				target[1] &= 0x7F;
				return  2;
			}
		}
		else
		{
			target[0] &= 0x7F;
			return  1;
		}
	}

}

