//
//  SDKMsgQueue.cpp
//  LearnOpenGLES
//
//  Created by vincentwgao on 2018/3/29.
//  Copyright © 2018年 . All rights reserved.
//

#include <string.h>
#import "SDKMsgQueue.h"
#import <Foundation/Foundation.h>
#import "TApmLog.h"

using namespace SDKMsgQueue;
MsgQueue::MsgQueue(int queueSz, bool lock,const char* msgQueName)
{
    mHeadIdx = 1;
    mTailIdx = 0;
    mLockable = lock;
    mQueueSz = queueSz;
    mMsgQueuePtr = new MsgQueueBody[mQueueSz];
    mQueueMutex = PTHREAD_MUTEX_INITIALIZER;
    mQueueConsumeMutex = PTHREAD_MUTEX_INITIALIZER;
    mCosumeLockable = false;
   
    if (msgQueName == NULL) msgQueName = "NA";
    msgQueueName = (char*)malloc(strlen(msgQueName) + 1);
    if (msgQueueName != NULL) strcpy(msgQueueName, msgQueName);
}

MsgQueue::MsgQueue(int queueSz, bool lock, bool clock,const char* msgQueName)
{
    mHeadIdx = 1;
    mTailIdx = 0;
    mLockable = lock;
    mQueueSz = queueSz;
    mMsgQueuePtr = new MsgQueueBody[mQueueSz];
    mQueueConsumeMutex = PTHREAD_MUTEX_INITIALIZER;
    mQueueMutex = PTHREAD_MUTEX_INITIALIZER;
    mCosumeLockable = clock;
    if (msgQueName == NULL) msgQueName = "NA";
    msgQueueName = (char*)malloc(strlen(msgQueName) + 1);
    if (msgQueueName != NULL) strcpy(msgQueueName, msgQueName);
}

void MsgQueue::postMsg(MsgQueueBody& value)
{
    MsgQueueBody    obj;

    if (mMsgQueuePtr == NULL)
    {
       APM_LOG_DEBUG(@"MsgQueue is NULL");
       return;
    }
    
    if (mHeadIdx == mTailIdx)
    {
        APM_LOG_DEBUG(@"head tail equal, return");
        return;
    }
    
    if (mLockable) {
        pthread_mutex_lock(&mQueueMutex);
    }
    
    int gap = mHeadIdx - mTailIdx;
    if (gap >= (mQueueSz - 2)) {
        if(msgQueueName != NULL) APM_LOG_DEBUG(@"avoid growing so fast, msgQueuName:%s is full,return,mhead:%d,mtail:%d",msgQueueName,mHeadIdx,mTailIdx);
        if (mLockable) {
            pthread_mutex_unlock(&mQueueMutex);
        }
        return;
    }

    constructMsgQueueBody(value,obj);
    memcpy(&mMsgQueuePtr[mHeadIdx & (mQueueSz - 1)], (const void*)&obj, sizeof(MsgQueueBody));
    //mMsgQueuePtr[mHeadIdx & (mQueueSz - 1)] = obj;
    mHeadIdx++;
    if (mLockable) {
        pthread_mutex_unlock(&mQueueMutex);
    }
}


bool MsgQueue::consumeMsgOnce(MsgQueueBody& target)
{
    constructMsgQueueBody(target);
    if (mMsgQueuePtr == NULL)
    {
        APM_LOG_DEBUG(@"MsgQueue is NULL");
        return false;
    }
    if (mCosumeLockable) {
        pthread_mutex_lock(&mQueueConsumeMutex);
    }
    
    int gap = mHeadIdx - mTailIdx - 1;//NOTE: 0-1 will never happens
    //int length = std::min(gap, mQueueSz - 1);
    
    if (gap > 0)
    {
        memcpy((void*)&target, (const void*)&mMsgQueuePtr[(mTailIdx+1) & (mQueueSz - 1)], sizeof(MsgQueueBody));
        
        if (mCosumeLockable) {
            pthread_mutex_unlock(&mQueueConsumeMutex);
        }
        //target = mMsgQueuePtr[(mTailIdx+1) & (mQueueSz - 1)];
        return true;
    }
    
    if (mCosumeLockable) {
        pthread_mutex_unlock(&mQueueConsumeMutex);
    }
    
    return false;
}

void MsgQueue::safeFree(MsgQueueBody& target)
{
    mTailIdx++;
    if (target.charValue)
    {
        free((void*)target.charValue);
        target.charValue = NULL;
    }
}

MsgQueue::~MsgQueue()
{
    if (mMsgQueuePtr != NULL) delete[] mMsgQueuePtr;
    if (msgQueueName != NULL) free((void*)msgQueueName);
}
