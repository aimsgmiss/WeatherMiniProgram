/*
 * APM_IOS_Mutex.h
 *
 *  Created on: 2018��6��18��
 *      Author: vincentwgao
 */

#ifndef MUTEX_H_
#define MUTEX_H_


#include <pthread.h>

class TApmMutex
{
public:
	TApmMutex();
	~TApmMutex();

	void lock();
	void unlock();

private:
	pthread_mutex_t mMutex;

};


#endif /* MUTEX_H_ */
