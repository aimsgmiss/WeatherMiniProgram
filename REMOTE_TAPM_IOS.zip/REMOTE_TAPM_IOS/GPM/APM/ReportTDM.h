#include "GCloudPluginManager/Service/Report/IReportService.h"
#include "GCloudPluginManager/Service/Report/GCloudCoreReporter.h"

#include "PluginGPM.h"
#include <string>

namespace GCloud {
    namespace APM {
        void ReportInitContext(bool success, int errorCode, int sessionId);

        void ReportMarkLevelLoad(const std::string &levelName, bool success, int errorCode);

        void ReportPostStatus(bool status, int errorCode, int duration, int size);

        void ReportDeviceClassStatus(bool status, int errorCode, int duration, const char *domain);

        const char *GetTDMUID();

        void ReportBinaryByTDM(int srcID, const char *eventName, const char *data, int len);
        
        //GCloud::Plugin::IReportService* GetReportService();
    }
}
