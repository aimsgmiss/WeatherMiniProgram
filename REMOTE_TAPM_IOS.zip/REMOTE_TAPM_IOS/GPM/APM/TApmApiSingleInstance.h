//
//  TApmApiInterClass.h
//  LearnOpenGLES
//
//  Created by vincentwgao on 2018/6/29.
//  Copyright © 2018年 . All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TApmApiInterfaceObject.h"

@interface TApmApiSingleInstance : NSObject
{

}

@property(nonatomic,assign) int markLoadLevelTimeStamp;

+ (instancetype)sharedInstance;

- (int)initContext:(NSString*)appid;

- (int)markLoadlevel:(const char* )sceneName;

- (int)markLoadlevelCompleted;

- (int)markLevelFin;

- (void)setQuality:(int32_t)quality;

- (void)setDeviceLevel:(int32_t)deviceLevel;

- (void)setUserID:(const char*)userID;

- (void)setLocal:(NSString*)local;

- (void)setAPPID:(NSString*)appid;

- (void)setVersionIden:(NSString*)version;

- (void)postEvent:(uint32_t)key info:(const char*)info;

- (void)postNTL:(int32_t)latency;

- (void)postLagStatus:(int32_t)distance;

- (void)postFrame:(float)deltaSeconds;

- (void)initStepEventContext;

- (void)releaseStepEventContext;

- (void)linkStreamEventSession:(NSString *)eventName;

- (void)postStepEvent:(const char*)eventName stepId:(int)stepId status:(int)status code:(int)code msg:(const char*)msg extDefineKey:(const char*)extDefineKey;

- (void)beginTag:(NSString*)tagName;

- (void)endTag;

- (void)postNetworkStatusFlag:(int8_t)flag status:(int16_t)status;

- (int)getDeviceLevelAbsPath:(NSString*)absolutePath configLevel:(NSString*)configLevel;

- (int)ayncGetDeviceLevelWithAbsPath:(NSString*)absolutePath configLevel:(NSString*)configLevel;

- (int)getDeviceLevel:(NSDictionary*)modelGearJson configLevel:(NSString* )configLevel;

- (void)postCoordinate:(int)x y:(int)y z:(int)z pitch:(int)pitch yaw:(int)yaw roll:(int)roll;

- (void)beginExclude;

- (void)endExclude;

- (float)getInstantFps;

- (float)getSceneMeanFps:(NSString*)sceneName;

- (int)getSceneMaxPss; //MB

- (int)getSceneTotalTime;

- (int)getSceneTotalFrames;

- (char*)getCurrentSceneName;

- (char*)getErrorMsg:(int)errorCode;

- (void)postDetectTimeOut:(NSDictionary*)detectTimeOutDic;

@end
