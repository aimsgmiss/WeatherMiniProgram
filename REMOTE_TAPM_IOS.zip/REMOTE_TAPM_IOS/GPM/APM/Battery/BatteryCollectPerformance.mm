//
//  BatteryCollectPerformance.m
//  LearnOpenGLESWithGPUImage
//
//  Created by xiang lin on 13/12/2017.
//  Copyright © 2017 xiang All rights reserved.
//

#import "SDKHeader.h"
#import <UIKit/UIKit.h>



@implementation BatteryCollectPerformance


-(void)startMonitor
{
    UIDevice*           currentDevi;

    [super startMonitor];
    currentDevi = [UIDevice currentDevice];
    currentDevi.batteryMonitoringEnabled = YES;
    
    [kNotificationCenterDefaultCenter addObserver:self selector:@selector(didChangeBatteryLevel:) name:UIDeviceBatteryLevelDidChangeNotification object:currentDevi];
    [kNotificationCenterDefaultCenter addObserver:self selector:@selector(didChangeBatteryState:) name:UIDeviceBatteryStateDidChangeNotification object:currentDevi];
    
 
}

- (void)didChangeBatteryLevel:(id)sender
{
    UIDevice*           currentDevi;
    
    if(!self.isCollectionData) return;
    currentDevi = [UIDevice currentDevice];
    currentDevi.batteryMonitoringEnabled = YES;
}

- (void)didChangeBatteryState:(id)sender
{
    /*UIDevice*           currentDevi;
    NSString*           batteryState;
    
    if(!self.isCollectionData) return;
    currentDevi = [UIDevice currentDevice];
    currentDevi.batteryMonitoringEnabled = YES;
    
    if (currentDevi.batteryState == UIDeviceBatteryStateUnknown) batteryState = @"Unkown";
    else if (currentDevi.batteryState == UIDeviceBatteryStateUnplugged) batteryState = @"Unplugged";
    else if (currentDevi.batteryState == UIDeviceBatteryStateCharging) batteryState = @"Charging";
    else if (currentDevi.batteryState == UIDeviceBatteryStateFull) batteryState = @"Full";
    else batteryState = @"Unkown";*/
    
}



-(void)stopMonitor{
    
    [super stopMonitor];
    [kNotificationCenterDefaultCenter removeObserver:self];
}


@end
