/*
 * FrameState.h
 *
 *  Created on: 2018��7��12��
 *      Author: vincentwgao
 */

#ifndef FRAMESTATE_H_
#define FRAMESTATE_H_

#include "MsgQueue.h"

//struct FrameState
//{
//	uint32_t mTickTime; // frame tick time
//	uint32_t mFrameTimeStamp; // timestamp
//};

struct Rotator
{
	int mPitch;
	int mYaw;
	int mRoll;
};

struct Coordinate
{
	int mX;
	int mY;
	int mZ;
};

struct SnapshotState
{
	uint32_t mTimeStamp; // timestamp
	Coordinate mCoordinate;
	Rotator mRotator;
};

//struct StateThrsd
//{
//	int mFrameTimeThrsd; // ֡ʱ�䣬��Ҫ���ݲ�ͬ��Ŀ��֡������
//	int mFpsSpikeThrsd; // ����
//	int mFpsLoWatThrsd; // ��֡
//};
//
//struct JudgeRet
//{
//	int mMatchRule;
//	int mCurrentValue;
//	int mLastValue;
//};

//#define FWRITE_4(value, tfile) fwrite(&(value), 4, 1, tfile)
//#define FWRITE_1(value, tfile) fwrite(&(value), 1, 1, tfile);
/**
 * 1s����һ��
 * ��֡
 * ����
 * ֡ʱ��
 * ���ǲ�ͬ��Ŀ��֡��
 */
class FrameStateJudger
{
public:
	enum Switch
	{
		SwitchLoWat = 1, SwitchFrt = 2, SwitchSpike = 3
	};

	GPM::MsgQueue<SnapshotState>* mSnapshotsStatePtr;
	//MsgQueue<FrameState>* mFrameStatePtr;

	//StateThrsd mStateThrsd;

	//float mCachedFps;

	/**
	 * frame time 1
	 * spike 2
	 * under std 4
	 */
	//int mSwitchOpts;

	FrameStateJudger(int bufferSz)
	{

		//mSwitchOpts = switchOpts;
		//mStateThrsd = sst;

		//mCachedFps = 0.0f;
		mSnapshotsStatePtr = new GPM::MsgQueue<SnapshotState> (bufferSz, false, "mSnapshotsStatePtr");
		//mFrameStatePtr = new MsgQueue<FrameState> (bufferSz, false);
	}

	~FrameStateJudger()
	{
		if (mSnapshotsStatePtr != NULL)
			delete mSnapshotsStatePtr;
	}

	void postSnapshotState(SnapshotState& ss)
	{
		mSnapshotsStatePtr->postMsg(ss);
	}

};

#endif /* FRAMESTATE_H_ */
