//
//  MmapFileWriter.cpp
//  mmapfos
//
//  Created by yongpengliang on 2019/6/11.
//  Copyright © 2019 yongpengliang. All rights reserved.
//


#include "MmapFileWriter.h"
#include <sys/mman.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <stdio.h>


namespace mmapfw{
  
    MmapFileWriter::MmapFileWriter(const char* path,int fileSize,int mmapSize)
    {
        if (!path)
        {
            printf("TApm_ios mmap path is NULL\n");
            m_failed = true;
            m_mmapPtr = NULL;
            return;
        }
        
        m_failed = false;
        m_fd = open(path, O_RDWR, S_IRWXU);
        if (m_fd < 0)
        {
            printf("TApm_ios open file error\n");
            m_failed = true;
            m_mmapPtr = NULL;
            return;
        }
        
        m_currentSize = fileSize;
        m_mmapSize = mmapSize;
        
        if (ftruncate(m_fd, m_mmapSize) == -1)
        {
            printf("TApm_ios ftruncate error\n");
            m_failed = true;
            m_mmapPtr = NULL;
            return;
        }
    
        m_mmapPtr =(uint8_t *)mmap(NULL,m_mmapSize,PROT_READ | PROT_WRITE,MAP_SHARED,m_fd,0);
        if(m_mmapPtr == MAP_FAILED)
        {
            printf("TApm_ios mmap fail\n");
            m_failed = true;
            return;
        }
    }
    
    MmapFileWriter::MmapFileWriter(const char *path, size_t mmapSize):m_mmapSize(mmapSize){
        m_currentSize = 0;
        m_failed = false;
        m_fd = open(path, O_RDWR, S_IRWXU);
        if (m_fd < 0) {
            m_failed = true;
            m_mmapPtr = NULL;
            return;
        }
        
        if (ftruncate(m_fd, mmapSize) == -1) {
            m_failed = true;
            m_mmapPtr = NULL;
            return;
        }
        
        m_mmapPtr = (uint8_t *)mmap(NULL, m_mmapSize, PROT_WRITE | PROT_READ, MAP_SHARED, m_fd, 0);
        if (m_mmapPtr == MAP_FAILED) {
            m_failed = true;
            return;
        }
        memset(m_mmapPtr, '\0', m_mmapSize);
    }
    
    bool MmapFileWriter::expandMem(int mapSize)
    {
        if (!isValid())
        {
            return false;
        }
        
        void *tmp = malloc(m_currentSize);
        memcpy(tmp, m_mmapPtr, m_currentSize);
        
        munmap(m_mmapPtr, m_mmapSize);
        m_mmapSize = mapSize;
        
        if (ftruncate(m_fd, m_mmapSize) == -1) {
            if (tmp) free(tmp);
            return false;
        }
        
        m_mmapPtr = (uint8_t *)mmap(NULL, m_mmapSize, PROT_WRITE | PROT_READ, MAP_SHARED, m_fd, 0);
        if (m_mmapPtr == MAP_FAILED) {
            m_failed = true;
            if (tmp) free(tmp);
            printf("TApm_ios expand mem error\n");
            return false;
        }
        
        memset(m_mmapPtr, '\0', m_mmapSize);
        memcpy(m_mmapPtr, tmp, m_currentSize);
        
        free(tmp);
    
        return true;
    }
    
    
    bool MmapFileWriter::resetFileSize()
    {
        if (!isValid())
        {
            return false;
        }
        
        memcpy(m_mmapPtr, &m_currentSize, 4);
        
        return true;
    }
    
    bool MmapFileWriter::append(const uint8_t *data, size_t size){
        if (!isValid()) {
            return false;
        }
        size_t new_size = m_currentSize + size;
        if (new_size >= m_mmapSize) {
            if(!this -> expandMem(m_mmapSize * 2))
                return false;
        }
    
        memcpy(m_mmapPtr + m_currentSize, data, size);
        m_currentSize += size;
        
        
        return true;
    }
    
    MmapFileWriter:: ~MmapFileWriter(){
        close();
    }
    
    void MmapFileWriter::close(){
        sync();
        
        if (m_mmapPtr != MAP_FAILED && m_mmapPtr != NULL) {
            munmap(m_mmapPtr, m_mmapSize);
            m_mmapPtr = NULL;
        }
        
        if(m_fd >= 0){
            ftruncate(m_fd, m_currentSize);
            ::close(m_fd);
            m_fd = -1;
        }
        m_failed = true;
    }
    
    void MmapFileWriter::sync(){
        if (m_mmapPtr != MAP_FAILED && m_mmapPtr != NULL && m_fd >= 0) {
            msync(m_mmapPtr, m_mmapSize, MS_ASYNC);
        }
    }
    
    void MmapFileWriter::clear(){
        if (m_mmapPtr != MAP_FAILED && m_mmapPtr != NULL) {
            memset(m_mmapPtr, '\0', m_mmapSize);
            m_currentSize = 0;
        }
    }
    
    bool MmapFileWriter::isValid() const{
        return !m_failed;
    }
    
    size_t MmapFileWriter::currentSize() const{
        return m_currentSize;
    }
    
    size_t MmapFileWriter::mmapSize() const{
        return m_mmapSize;
    }
    
    uint8_t *MmapFileWriter::mmapPtr() const{
        return m_mmapPtr;
    }
    
}




