//
//  MmapFileWriter.hpp
//  mmapfos
//
//  Created by yongpengliang on 2019/6/11.
//  Copyright © 2019 yongpengliang. All rights reserved.
//

#ifndef MmapFileWriter_hpp
#define MmapFileWriter_hpp

#include <stdint.h>
#include <unistd.h>

namespace mmapfw{
    
    class MmapFileWriter{
    private:
        int m_fd;
        bool m_failed;
        uint8_t *m_mmapPtr;
        size_t m_mmapSize;
        size_t m_currentSize;
        
    public:
        //文件必须已存在
        MmapFileWriter(const char* path,int fileSize,int mmapSize);
        MmapFileWriter(const char *path, size_t mmapSize = getpagesize());
        virtual ~MmapFileWriter();
        
        bool append(const uint8_t *data, size_t len);
        bool expandMem(int mapSize);
        bool resetFileSize();
        void sync();
        void clear();
        void close();
        
        bool isValid() const;
        size_t currentSize() const;
        size_t mmapSize() const;
        uint8_t *mmapPtr() const;
    };
    
}
    
#endif /* MmapFileWriter_hpp */
