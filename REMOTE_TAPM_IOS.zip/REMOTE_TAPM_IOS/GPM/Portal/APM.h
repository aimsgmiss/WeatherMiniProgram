//
//  APM.h
//  APM
//
//  Created by vincentwgao on 2018/9/14.
//  Copyright © 2018年 xianglin. All rights reserved.
//

#import <Foundation/Foundation.h>
#include <string>
#include <vector>
#include <TriObserver.h>

typedef struct
{
    std::string key;
    std::string value;
    
} APMDictionary;

extern "C" {

/// 初始化SDK，调用其他API之前必须先做初始化操作
/// @param appId  appId
/// @param engine 上层使用引擎，如：UE4、Unity等
/// @param debug 是否为调试模式
 int tri_initContext(char *appId, char *engine, BOOL debug);


 /// 设置一个事件观察者
 /// @param observer 事件观察者
  void tri_setObserver(TriObserver *observer);


/// 是否允许为debug模式
 void tri_enableDebugMode();


/// 设置服务器信息
/// @param zoneId 大区Id
/// @param roomIp 房间服务器ip
 void tri_setServerInfo(char *zoneId, char *roomIp);


/// 进入游戏场景
/// @param sceneId 场景Id
 void tri_markLevelLoad(char *sceneId);

/// 结束游戏场景
 void tri_markLevelFin();


/// 游戏进度条加载结束
void tri_markLevelLoadCompleted();

/// 设置玩家登陆后的openid
/// @param openId  openID 玩家登陆后的openid
 void tri_setOpenId(char *openId);


/// 设置游戏画质
/// @param quality 游戏画质, 默认为0
 void tri_setQulaity(int quality);


/// 自定义事件上报接口
/// @param eventName 事件名称，最大长度128
/// @param eventList 事件内容 key最大长度64，value最大长度1024，key最大个数50
 //void tri_postEvent(char *eventName, std::vector<APMDictionary>& eventList);
void tri_postEventSS(char *eventName, char* eventList);


/// 自定义数据流事件上报接口
/// @param eventCategory 事件名称
/// @param stepId 事件步骤
/// @param status 事件状态
/// @param code 事件状态码
/// @param msg 事件详细信息
/// @param extraKey 事件额外信息
 void tri_postStepEvent(char *eventCategory, int stepId, int status, int code, char *msg, char *extraKey);

/// 当出现网络时延跳变/超时时，调用此方法进行网络质量诊断
 void tri_detectInTimeout();




    //APM features
 void tri_postTrackState(float x, float y, float z, float pitch, float yaw, float roll);

 int tri_checkDCLSByQcc(char *absolutePath,char *configName);

 int tri_checkDCLSByQccSync(char *absolutePath,char *configName);

 void tri_postFrame(float deltaTime);

 void tri_postNetLatency(int latency);

 void tri_beginTupleWrap(char *category);

 void tri_endTupleWrap();

void tri_postValueF1(char *category, char *key, float a);

void tri_postValueF2(char *category, char *key, float a, float b) ;

void tri_postValueF3(char *category, char *key, float a, float b, float c);

void tri_postValueI1(char *category, char *key, int a);

void tri_postValueI2(char *category, char *key, int a, int b);

void tri_postValueI3(char *category, char *key, int a, int b, int c);

void tri_postValueS(char *category, char *key, char *value);

void tri_setDefinedDeviceClass(int deviceClass);

void tri_beginTag(char *tagName);

void tri_endTag();

void tri_setVersionIden(char *versionName);

void tri_beignExclude();

void tri_endExclude();

///获取的错误信息字符串使用完毕后需要free操作
const char * tri_getErrorMsg(int errorCode);
    
void tri_linkSession(const char* eventName);

void tri_initStepEventContext();

void tri_releaseStepEventContext();
    
void tri_postEventIS(int key,const char* value);

const char* tri_getSDKVersion();
    
    
}
