//
//  GCloudMSDK.h
//  APM
//
//  Created by xiang lin on 2019/12/27.
//  Copyright © 2019 xianglin. All rights reserved.
//

//#include "IRemoteConfig.h"
#include "GCloudPluginManager/Service/Account/IServiceAccount.h"
#include "GCloudPluginManager/Service/Report/IReportService.h"
#include "GCloudPluginManager/Service/Log/ILogService.h"
#include "GCloudPluginManager/Service/RemoteConfig/IRemoteConfigService.h"

#include "PluginGPM.h"

namespace GCloud {
    namespace GPM{
            // need free
        char* getOpenID();
        
        IRemoteConfig* GetIRemoteConfig();
        
        GCloud::ILogger* GetLogger();
    
        GCloud::Plugin::IReportService* GetReportService();
    
    }
}

