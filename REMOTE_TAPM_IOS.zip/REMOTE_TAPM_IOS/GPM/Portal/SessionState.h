//
//  SessionState.h
//  APM
//
//  Created by xiang lin on 2019/10/24.
//  Copyright © 2019 xianglin. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SessionState : NSObject

+ (instancetype)sharedInstance;

@end

NS_ASSUME_NONNULL_END
