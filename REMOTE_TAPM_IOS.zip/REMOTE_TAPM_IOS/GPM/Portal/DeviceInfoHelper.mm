//
//  DeviceInfoHelper.cpp
//  APM
//
//  Created by xiang lin on 2019/10/25.
//  Copyright © 2019 xianglin. All rights reserved.
//

#import <mach-o/arch.h>
#import <assert.h>
#import <UIKit/UIKit.h>
#import <sys/utsname.h>
#import <sys/mount.h>
#import <stdlib.h>
#import <sys/socket.h> // Per msqr
#import <sys/sysctl.h>
#import <net/if.h>
#import <net/if_dl.h>
#include "DeviceInfoHelper.h"
#include "GCloudPluginManager/Service/Report/IReportService.h"
#include "ReportTDM.h"
#import "TApmLog.h"
#import "SDKHelper.h"

using namespace DeviceInfo;


NSString* DeviceInfo::DeviceInfoHelper::getNSStringFromTDM(const char* deviceInfoName){

    if (!deviceInfoName) {
        return nil;
    }
    
    GCloud::Plugin::IReportService* pService = GCloud::GPM::GetReportService();
    if (!pService) {
        return nil;
    }
    
    char *model = (char*)calloc(1024, sizeof(char));
    if(!model){
        return nil;
    }
    
    GCloud::Plugin::DeviceInfoStatus deviceInfoStatus = pService->GetDeviceInfo(deviceInfoName, &model, 64);
    NSString* deviceInfo = nil;
    if(deviceInfoStatus == GCloud::Plugin::kDeviceInfoStatusSuccess || deviceInfoStatus == GCloud::Plugin::kDeviceInfoStatusEncrypted){
        deviceInfo = [NSString stringWithUTF8String:model];
    }
    
    free(model);
    model = NULL;
    APM_LOG_DEBUG(@"TApm_ios device info from tdm:%s,%@",deviceInfoName,deviceInfo);
    return deviceInfo;
}

int64_t DeviceInfo::DeviceInfoHelper::getInt64FromTDM(const char* deviceInfoName){
    
    if (!deviceInfoName) {
        return -1;
    }
    
    GCloud::Plugin::IReportService* pService = GCloud::GPM::GetReportService();
    if (!pService) {
        return -1;
    }
    
    int64_t deviceInfoValue;
    GCloud::Plugin::DeviceInfoStatus deviceInfoStatus = pService->GetDeviceInfo(deviceInfoName, &deviceInfoValue);
    if(deviceInfoStatus == GCloud::Plugin::kDeviceInfoStatusSuccess ||deviceInfoStatus == GCloud::Plugin::kDeviceInfoStatusEncrypted){
        APM_LOG_DEBUG(@"TApm_ios device info from tdm:%s,%lld",deviceInfoName,deviceInfoValue);
        return deviceInfoValue;
    }
    
    APM_LOG_DEBUG(@"TApm_ios device info from tdm error:%s,%lld",deviceInfoName,deviceInfoValue);
    return -1;
}

NSString* DeviceInfo::DeviceInfoHelper::getCPUArchName(){
    const NXArchInfo * arch = NXGetLocalArchInfo();
    if (arch && arch -> name){
        return [NSString stringWithCString:arch->name encoding:NSUTF8StringEncoding];
    }
    return @"unknown";
}

NSString* DeviceInfo::DeviceInfoHelper::getDeviceModel()
{
    struct utsname      systemInfo;
    NSString*           platform;
    
    uname(&systemInfo);
    platform = [NSString stringWithCString:systemInfo.machine encoding:NSASCIIStringEncoding];
    return platform;
}

uint32_t DeviceInfo::DeviceInfoHelper::getDeviceTotalSpace(){
    
    return (uint32_t)getInt64FromTDM(COLLECT_DEVICE_INFO_TOTAL_SPACE_LONG);
}

NSString* DeviceInfo::DeviceInfoHelper::getSysVersion(){
    
    return getNSStringFromTDM(COLLECT_DEVICE_INFO_SYS_VERSION_STRING);
}

NSString* DeviceInfo::DeviceInfoHelper::getAppVersion(){
    return  [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
}

NSString* DeviceInfo::DeviceInfoHelper::getDeviceModelFromTDM(){
    
    return getNSStringFromTDM(COLLECT_DEVICE_INFO_MODEL_STRING);
}

NSString* DeviceInfo::DeviceInfoHelper::getBrand(){
    
    return getNSStringFromTDM(COLLECT_DEVICE_INFO_BRAND_STRING);
}

NSString* DeviceInfo::DeviceInfoHelper::getIDFV(){
    
    return getNSStringFromTDM(COLLECT_DEVICE_INFO_DEVICE_ID_STRING);
}

uint32_t DeviceInfo::DeviceInfoHelper::getTotalRAMCount(){
    
    return SDKHelper::SDKUtill::getTotalRAMCount();
    //return (uint32_t)getInt64FromTDM(COLLECT_DEVICE_INFO_TOTAL_MEM_LONG);
}

NSUInteger DeviceInfo::DeviceInfoHelper::getProccessorCount(){
    return SDKHelper::SDKUtill::getProccessorCount();
    //return (NSUInteger)getInt64FromTDM(COLLECT_DEVICE_INFO_CPU_CORE_LONG);
}

