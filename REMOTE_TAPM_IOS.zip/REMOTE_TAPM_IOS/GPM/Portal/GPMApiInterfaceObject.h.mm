//
//  APM.m
//  APM
//
//  Created by vincentwgao on 2018/9/14.
//  Copyright © 2018年 xianglin. All rights reserved.
//

#import "GPMApiInterfaceObject.h"
#include "GPMAgent.h"
#include "GPMBuildConfig.h"
#import "TApmLog.h"

#if defined(__cplusplus)
extern "C"
{
#endif
    
int gpm_initContext(const char *appId, const char *engine,bool debug){
    @autoreleasepool {
        if (appId == NULL || engine == NULL) {
            return -1;
        }
        return [[GPMAgent sharedInstance] initContextWithAppId:@(appId) engine:@(engine) debug:debug];
    }
}


void gpm_setObserver(GPMObserver *observer){
    @autoreleasepool {
        if (!observer) {
             APM_LOG_DEBUG(@"gpm_setObserver observer is NULL");
             return;
        }
        [[GPMAgent sharedInstance] setObserver:observer];
    }
}

void gpm_enableDebugMode(){
    @autoreleasepool {
        [[GPMAgent sharedInstance] enableDebugMode];
    }
}

void gpm_setServerInfo(const char *zoneId, const char *roomIp){
    @autoreleasepool {
        if (zoneId == NULL || roomIp == NULL) {
            return;
        }
        [[GPMAgent sharedInstance] setServerInfoWithZoneId:@(zoneId) roomIp:@(roomIp)];
    }
}

void gpm_markLevelLoad(const char *sceneId){
    @autoreleasepool {
        if (sceneId == NULL) {
             return;
        }
        [[GPMAgent sharedInstance] markLevelLoadWithSceneId:@(sceneId)];
    }
}

void gpm_saveFps(float favg, int fmax, int fmin, int ftotal, int fheavy, int flight, int fcntx0, int flfps1, int flfps2, int flfps3, const char * fpsdots){
    @autoreleasepool {
        [[GPMAgent sharedInstance] saveFps:favg FMax:fmax FMin:fmin Ftotal:ftotal Fheavy:fheavy Flight:flight Fcntx0:fcntx0 Flfps1:flfps1 Flfps2:flfps2 Flfps3:flfps3 Fpsdots:[NSString stringWithUTF8String:fpsdots]];
    }
}

void gpm_markLevelFin(){
    @autoreleasepool {
        [[GPMAgent sharedInstance] markLevelFin];
        //test
        //gpm_saveFps(0.0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "20.0,20.0,29");
    }
}

void gpm_markLevelLoadCompleted(){
    @autoreleasepool {
        [[GPMAgent sharedInstance] markLevelLoadCompleted];
    }
}

void gpm_setOpenId(const char *openId){
    @autoreleasepool {
        if (openId == NULL) {
             return;
        }
        [[GPMAgent sharedInstance] setOpenId:@(openId)];
    }
}

void gpm_setQulaity(int quality){
    @autoreleasepool {
        [[GPMAgent sharedInstance] setQulaity:quality];
    }
}

void gpm_postEventSS(const char *eventName, const char* eventList){
    @autoreleasepool {
        NSString * event = [NSString stringWithUTF8String:eventList];
        if (!event) {
            return;
        }
        NSArray * eventArray = [event componentsSeparatedByString:@";"];
        if ([eventArray count] < 1) {
            return;
        } else {
            NSMutableDictionary * params = [NSMutableDictionary new];
            for (int i = 0; i < [eventArray count]; i++) {
                NSArray * valueArray = [eventArray[i] componentsSeparatedByString:@":"];
                if (valueArray && ([valueArray count] == 2) && valueArray[0] && valueArray[1]) {
                    [params setValue:valueArray[1] forKey:valueArray[0]];
                } else {
                    continue;
                }
            }
            NSString * name = [NSString stringWithUTF8String:eventName];
            [[GPMAgent sharedInstance] postEventWithName:name params:params];
        }
    }
}

void gpm_postStepEvent(const char *eventCategory, int stepId, int status, int code, const char *msg, const char *extraKey,  bool authorize, bool finish){
    @autoreleasepool {
        if (eventCategory == NULL) {
            return;
        }
        NSString *ocExtraKey = extraKey ? @(extraKey) : nil;
        NSString *ocMsg = msg ? @(msg) : nil;
        [[GPMAgent sharedInstance] postStepEventWithCategory:@(eventCategory) stepId:stepId status:status code:code msg:ocMsg extraKey:ocExtraKey authorize:authorize finish:finish];
    }
}

void gpm_detectInTimeout(){
    @autoreleasepool {
        [[GPMAgent sharedInstance] detectInTimeout];
    }
}

//APM features
void gpm_postTrackState(float x, float y, float z, float pitch, float yaw, float roll){
    @autoreleasepool {
        [[GPMAgent sharedInstance] postTrackStateX:x y:y z:z pitch:pitch yaw:yaw roll:roll];
    }
}

int gpm_checkDCLSByQcc(const char *absolutePath, const char *configName){
    @autoreleasepool {
        if (absolutePath == NULL || configName == NULL) {
            return -1;
        }

        return [[GPMAgent sharedInstance] checkDCLSByQccWithAbsolutePath:@(absolutePath) configName:@(configName)];
    }
}

int gpm_checkDCLSByQccSync(const char *absolutePath, const char*configName){
    @autoreleasepool {
        if (absolutePath == NULL || configName == NULL) {
               return -1;
        }
        return [[GPMAgent sharedInstance] checkDCLSByQccSyncAbsolutePath:@(absolutePath) configName:@(configName)];
    }
}

void gpm_postFrame(float deltaTime){
    @autoreleasepool {
        [[GPMAgent sharedInstance] postFrameWithDeltaTime:deltaTime];
    }
}

void gpm_postNetLatency(int latency){
    @autoreleasepool {
        [[GPMAgent sharedInstance] postNetLatency:latency];
    }
}

void gpm_beginTupleWrap(const char *category){
    @autoreleasepool {
        if (category == NULL) {
            return;
        }
        [[GPMAgent sharedInstance] beginTupleWrapWithCategory:@(category)];
    }
}

void gpm_endTupleWrap(){
    @autoreleasepool {
        [[GPMAgent sharedInstance] endTupleWrap];
    }
}

void gpm_postValueF1(const char *category, const char *key, float a){
    @autoreleasepool {
        if (category == NULL || key == NULL) {
            return;
        }
        [[GPMAgent sharedInstance] postValueFWithCategory:@(category) key:@(key) a:a];
    }
}

void gpm_postValueF2(const char *category, const char *key, float a, float b){
    @autoreleasepool {
        if (category == NULL || key == NULL) {
              return;
        }
        [[GPMAgent sharedInstance] postValueFWithCategory:@(category) key:@(key) a:a b:b];
    }
}

void gpm_postValueF3(const char *category, const char *key, float a, float b, float c){
    @autoreleasepool {
        if (category == NULL || key == NULL) {
              return;
        }
        [[GPMAgent sharedInstance] postValueFWithCategory:@(category) key:@(key) a:a b:b c:c];
    }
}

void gpm_postValueI1(const char *category, const char *key, int a){
    @autoreleasepool {
        if (category == NULL || key == NULL) {
              return;
        }
        [[GPMAgent sharedInstance] postValueIWithCategory:@(category) key:@(key) a:a];
    }
}

void gpm_postValueI2(const char *category, const char *key, int a, int b){
    @autoreleasepool {
        if (category == NULL || key == NULL) {
              return;
        }
        [[GPMAgent sharedInstance] postValueIWithCategory:@(category) key:@(key) a:a b:b];
    }
}

void gpm_postValueI3(const char *category, const char *key, int a, int b, int c){
    @autoreleasepool {
        if (category == NULL || key == NULL) {
              return;
        }
        [[GPMAgent sharedInstance] postValueIWithCategory:@(category) key:@(key) a:a b:b c:c];
    }
}

void gpm_postValueS(const char *category, const char *key, const char *value){
    @autoreleasepool {
        if (category == NULL || key == NULL || value == NULL) {
              return;
        }
        [[GPMAgent sharedInstance] postValueSWithCategory:@(category) key:@(key) value:@(value)];
    }
}

void gpm_setDefinedDeviceClass(int deviceClass){
    @autoreleasepool {
        [[GPMAgent sharedInstance] setDefinedDeviceClass:deviceClass];
    }
}

void gpm_beginTag(const char *tagName){
    @autoreleasepool {
        if (tagName == NULL) {
            return;
        }
        [[GPMAgent sharedInstance] beginTagWithName:@(tagName)];
    }
}

void gpm_endTag(){
    @autoreleasepool {
        [[GPMAgent sharedInstance] endTag];
    }
}

void gpm_setVersionIden(const char *versionName){
    @autoreleasepool {
        if (versionName == NULL) {
            return;
        }
        [[GPMAgent sharedInstance] setVersionIden:@(versionName)];
    }
}

void gpm_beignExclude(){
    @autoreleasepool {
        [[GPMAgent sharedInstance] beignExclude];
    }
}

void gpm_endExclude(){
    @autoreleasepool {
        [[GPMAgent sharedInstance] endExclude];
    }
}

const char *gpm_getErrorMsg(int errorCode){
    @autoreleasepool {
        const char *cstr = [[GPMAgent sharedInstance] getErrorMsgWithErrorCode:errorCode].UTF8String;
        if (cstr == NULL) {
            cstr = "";
        }
        cstr = strdup(cstr);
        return cstr;
    }
}


void gpm_linkSession(const char* eventName){
    @autoreleasepool {
        if (eventName == NULL) {
            return;
        }

        [[GPMAgent sharedInstance] linkSessionWithEventName:@(eventName)];
    }
}

void gpm_initStepEventContext(){
    @autoreleasepool {
        [[GPMAgent sharedInstance] initStepEventContext];
    }
}

void gpm_releaseStepEventContext(){
    @autoreleasepool {
        [[GPMAgent sharedInstance] releaseStepEventContext];
    }
}

void gpm_postEventIS(int key,const char* value){
    @autoreleasepool {
        if (value == NULL) {
            return;
        }
        [[GPMAgent sharedInstance] postEventISWithKey:key value:value];
    }
}

const char* gpm_getSDKVersion(){
    @autoreleasepool {
        const char* version = VERSION_NAME.UTF8String;
        if (!version) {
            version = "NA";
        }
        version = strdup(version);
        return version;
    }
}


void gpm_log(const char * log){
    @autoreleasepool {
        if (!log) {
            return;
        }
        APM_LOG_DEBUG(@(log));
    }
}


#if defined(__cplusplus)
}
#endif
