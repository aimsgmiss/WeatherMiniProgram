//
//  GemAgent.m
//  APM
//
//  Created by 雍鹏亮 on 2019/10/23.
//  Copyright © 2019 xianglin. All rights reserved.
//

#import "GemAgent.h"
#import "ErrorCodeHelper.h"
#import "GemCCStrategy.h"
#import "GPMObserver.h"
#import "TApmLog.h"
#import "GSDKReporter.h"
#import "GSDKPayEvent.h"
#import "GSDKInfoTool.h"
#import "GSDKLoginEvent.h"
#import "GSDKInitManager.h"
#import "GSDKInGameManager.h"
#import "GSDKCallRecorder.h"
#import "GPMFps.h"

static NSString * const LOGIN_EVENT_CATEGORY = @"login";

@interface GemAgent()

@property (assign,nonatomic) BOOL isInitialized;

@property (nonatomic, readwrite, copy) NSString * zoneId;
@property (nonatomic, readwrite, copy) NSString * roomIp;

@end

@implementation GemAgent

- (instancetype)init{
    
    if(self = [super init]){
        _isInitialized = NO;
    }
    
    return self;
}

- (int)initContextWithAppId:(NSString *)appId engine:(NSString *)engine debug:(BOOL) debug{
    if (_isInitialized) {
        // TODO: Log for Test
        return DUPLICATE_INIT;
    }
    // TODO: Log for Test
    
    // NOTE: GCloud云控实现注入
    CCStrategyTemplate* strategy = [self getCCStrategy];
    if ([strategy isKindOfClass:[GemCCStrategy class]]) {
        GemCCStrategy* gemStrategy = (GemCCStrategy *) strategy;
        [GSDKInfoTool setGemCCStrategy:gemStrategy];
    }
    [[GSDKInitManager sharedInstance] GSDKInit:debug];
    _isInitialized = YES;
    return 0;
}

- (void)enableDebugMode{
    [[GSDKLogger sharedInstance] setEnableLog:YES];
}

- (void)setServerInfoWithZoneId:(NSString *) zoneId roomIp:(NSString *)roomIp{
    if (!zoneId) {
        zoneId = @"";
    }
    if (!roomIp) {
        roomIp = @"";
    }
    self.zoneId = [zoneId copy];
    self.roomIp = [roomIp copy];
}

- (void)markLevelLoadWithSceneId:(NSString *)sceneId{
    if (!sceneId) {
        sceneId = @"";
    }
    [[GSDKInGameManager sharedInstance] GSDKStart:_zoneId SceneID:sceneId RoomIP:_roomIp Observer:_mObserver];
}

- (void)saveFps:(float)favg FMax:(int)fmax FMin:(int)fmin Ftotal:(int)ftotal Fheavy:(int)fheavy Flight:(int)flight Fcntx0:(int)fcntx0 Flfps1:(int)flfps1 Flfps2:(int)flfps2 Flfps3:(int)flfps3 Fpsdots:(NSString *)fpsdots{
    [[GSDKInGameManager sharedInstance] GSDKSaveFps:favg FMax:fmax FMin:fmin Ftotal:ftotal Fheavy:fheavy Flight:flight Fcntx0:fcntx0 Flfps1:flfps1 Flfps2:flfps2 Flfps3:flfps3 Fpsdots:fpsdots];
}

- (void)markLevelFin{
    
    [[GPMFps sharedInstance] end:^(GPMFpsInfo * fpsInfo) {
              float favg = fpsInfo.avg;
              int fmax = fpsInfo.max;
              int fmin = fpsInfo.min;
              int ftotal = fpsInfo.totalTimes;
              int fheavy = fpsInfo.heavyTimes;
              int flight = fpsInfo.lightTimes;
              int fcntx0 = fpsInfo.cusTimes;
              int flfps1 = fpsInfo.lightTimes1;
              int flfps2 = fpsInfo.lightTimes2;
              int flfps3 = fpsInfo.lightTimes3;
              NSString* fpsdots = fpsInfo.fpsdots ;
            [[GSDKInGameManager sharedInstance] GSDKSaveFps:favg FMax:fmax FMin:fmin Ftotal:ftotal Fheavy:fheavy Flight:flight Fcntx0:fcntx0 Flfps1:flfps1 Flfps2:flfps2 Flfps3:flfps3 Fpsdots:fpsdots];
          }];
    
    [[GSDKInGameManager sharedInstance] GSDKEnd:_mObserver];
}

- (void)markLevelLoadCompleted{
    APM_LOG_DEBUG(@"%@ not implement in GemAgent",NSStringFromSelector(_cmd));
}

- (void)setOpenId:(NSString *)openId{
    if (!openId) {
        openId = @"";
    }
   [[GSDKInitManager sharedInstance] GSDKSetUserName:openId];
}

- (void)setQulaity:(int)quality{
    APM_LOG_DEBUG(@"%@ not implement in GemAgent",NSStringFromSelector(_cmd));
}

- (void)postEventWithName:(NSString *)eventName params:(NSDictionary<NSString *, NSString *> *)_params{
    if (!eventName || !_params) {
        return;
    }
    // NOTE: port from GSDK.mm
    NSMutableDictionary * params = [_params mutableCopy];
    params[kGSDKLDNS] = [GSDKInfoTool dnsIP];
    if (![params objectForKey:kGSDKOpenid]) {
        params[kGSDKOpenid] = [GSDKInfoTool openID];
        if (_mObserver) {
            _mObserver->GPMOnLog("[GPM]1__ReportEvent");
        }
    } else {
        // NOTE: 自动化测试回调
        if (_mObserver) {
            _mObserver->GPMOnLog("[GPM]0__ReportEvent");
        }
    }
    GSDKLOG(@"GSDKReportEvent eventName:%@, params:%@", eventName, params);
    [GSDKReporter gsdkReport:eventName Params:params];
}

- (void)postStepEventWithCategory:(NSString *)eventCategory stepId:(int)stepId status:(int)status code:(int)code msg:(NSString *)msg extraKey:(NSString *) extraKey authorize:(BOOL)authorize finish:(BOOL)finish {
    if (!eventCategory) {
        return;
    }
    if (!msg) {
        msg = @"";
    }
    // NOTE: 自动化测试回调
    if ([LOGIN_EVENT_CATEGORY caseInsensitiveCompare:eventCategory] == NSOrderedSame) {
        [[GSDKLoginEvent sharedInstance] GSDKSetEvent:stepId Result:(0 == status) Description:msg Authorize:authorize Finish:finish Observer:_mObserver];
    } else {
        if (_mObserver) {
            _mObserver->GPMOnLog("[GPM]2__SetEvent");

        }
    }
}

- (void)detectInTimeout{
    [[GSDKInitManager sharedInstance] GSDKRealTimeTCPDetect];
    // NOTE(三合一): 自动化测试回调
    if (_mObserver) {
        _mObserver->GPMOnLog("[GPM]0__DetectInTimeout");
    }
}

@end
