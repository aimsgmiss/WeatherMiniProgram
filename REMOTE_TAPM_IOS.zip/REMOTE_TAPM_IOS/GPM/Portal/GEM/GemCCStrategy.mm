//
//  GemCCStrategy.m
//  APM
//
//  Created by xiang lin on 2019/10/24.
//  Copyright © 2019 xianglin. All rights reserved.
//

#import "GemCCStrategy.h"

static NSString * const GEM_SWITCH_NAME = @"gem";

static NSString * const GEM_INIT_SWITCH_NAME = @"gem_init";
static NSString * const GEM_LOGIN_RECORD_SWITCH_NAME = @"gem_set_event";
static NSString * const GEM_CUS_REPORT_EVENT_SWITCH_NAME = @"gem_report_event";
static NSString * const GEM_DETECT_IN_TIMEOUT_SWITCH_NAME = @"gem_detect_in_timeout";
static NSString * const GEM_GAME_COLLECT_SWITCH_NAME = @"gem_start";

static const BOOL GEM_SWITCH_DEFAULT_VALUE = YES;

static const BOOL GEM_INIT_SWITCH_DEFAULT_VALUE = YES;
static const BOOL GEM_LOGIN_RECORD_SWITCH_DEFAULT_VALUE = YES;
static const BOOL GEM_CUS_REPORT_EVENT_SWITCH_DEFAULT_VALUE = YES;
static const BOOL GEM_DETECT_IN_TIMEOUT_SWITCH_DEFAULT_VALUE = YES;
static const BOOL GEM_GAME_COLLECT_SWITCH_DEFAULT_VALUE = YES;

@implementation GemCCStrategy

- (BOOL)isModuleEnabled{
    return [self getBool:GEM_SWITCH_NAME defaultValue:GEM_SWITCH_DEFAULT_VALUE];
}

- (BOOL)isFeatureEnabled:(FEATURE)feature{
    switch (feature) {
        case FEATURE_INIT:
            return [self getBool:GEM_INIT_SWITCH_NAME defaultValue:GEM_INIT_SWITCH_DEFAULT_VALUE];
        case FEATURE_POST_STEP_EVENT:
            return [self getBool:GEM_LOGIN_RECORD_SWITCH_NAME defaultValue:GEM_LOGIN_RECORD_SWITCH_DEFAULT_VALUE];
        case FEATURE_POST_EVENT:
            return [self getBool:GEM_CUS_REPORT_EVENT_SWITCH_NAME defaultValue:GEM_CUS_REPORT_EVENT_SWITCH_DEFAULT_VALUE];
        case FEATURE_DETECH_IN_TIMEOUT:
            return [self getBool:GEM_DETECT_IN_TIMEOUT_SWITCH_NAME defaultValue:GEM_DETECT_IN_TIMEOUT_SWITCH_DEFAULT_VALUE];
        case FEATURE_MARK_LEVEL_LOAD:
        case FEATURE_SAVE_FPS:
        case FEATURE_MARK_LEVEL_LOAD_COMPLETED:
        case FEATURE_MARK_LEVEL_FIN:
            return [self getBool:GEM_GAME_COLLECT_SWITCH_NAME defaultValue:GEM_GAME_COLLECT_SWITCH_DEFAULT_VALUE];
        case FEATURE_CHECK_DECLS_BY_QCC:
        case FEATURE_CHECK_DECLS_BY_QCC_SYNC:
        case FEATURE_TAG_FUNC:
        case FEATURE_POST_VALUE_XX:
        case FEATURE_POST_FRAME:
        case FEATURE_SET_QUALITY:
        case FEATURE_POST_NETWORK_LATENCY:
        case FEATURE_POST_TRACK_STATE:
        case FEATURE_DEF_DCLS:
        case FEATURE_SET_VERSION_IDEN:
            return NO;
        case FEATURE_ENABLED_DEBUG_MODE:
        case FEATURE_SET_SERVERINFO:
        case FEATURE_SET_OPENID:
        case FEATURE_SET_OBSERVER:
            return YES;
        default:
            return NO;
    }
}

@end
