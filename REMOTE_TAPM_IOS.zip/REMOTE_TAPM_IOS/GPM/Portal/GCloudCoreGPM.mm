//
//  GCloudMSDK.m
//  APM
//
//  Created by xiang lin on 2019/12/27.
//  Copyright © 2019 xianglin. All rights reserved.
//
#include <stdlib.h>
#import "GCloudCoreGPM.h"
#import "TApmLog.h"

namespace GCloud {
    namespace GPM{
            using namespace GCloud::Plugin::MSDK;
    
            static GCloud::Plugin::IReportService* g_report_service_inf = NULL;
    
            static GCloud::IRemoteConfig* g_remote_config = NULL;
    
            static IServiceAccount* g_msdk_account_service = NULL;
    
            IServiceAccount* getServiceAccount(){
                
                if (g_msdk_account_service == NULL) {
                    
                    GCloud::Plugin::PluginBase*  pluginBase = PluginGPM::GetInstance();
                    if(NULL == pluginBase){
                        APM_LOG_DEBUG(@"GCloud init PluginBase error");
                        return NULL;
                    }
                    GCloud::Plugin::IPluginManager* pluginManager = pluginBase->GetPluginManager();
                    if(NULL == pluginManager){
                        APM_LOG_DEBUG(@"GCloud init IPluginManager error");
                        return NULL;
                    }
                    
                    GCloud::Plugin::IPlugin* plugin = (GCloud::Plugin::IPlugin*)pluginManager->GetPluginByName(PLUGIN_NAME_MSDK);
                    if(NULL == plugin){
                        APM_LOG_DEBUG(@"GCloud init IPlugin error");
                        return NULL;
                    }
                    
                    g_msdk_account_service = ( GCloud::Plugin::MSDK::IServiceAccount*)plugin->GetServiceByName(PLUGIN_SERVICE_NAME_ACCOUNT);
                    if(NULL == g_msdk_account_service){
                        APM_LOG_DEBUG(@"GCloud init msdk account error");
                        return NULL;
                    }
                }
                
                return g_msdk_account_service;
            }
            
            char* getOpenID(){
                
                IServiceAccount* msdkService = NULL;
                msdkService = getServiceAccount();
                if(msdkService){
                    MSDKAccount msdkAccount;
                    bool result = msdkService -> getLoginRet(msdkAccount);
                    if(result){
                        if(msdkAccount.openID){
                            APM_LOG_DEBUG(@"GCloud get msdk account open id success:%s",msdkAccount.openID);
                            
                            return strdup((const char*)msdkAccount.openID);
                        }else{
                            APM_LOG_DEBUG(@"GCloud get msdk account open id error");
                        }
                    }else{
                        APM_LOG_DEBUG(@" GCloud get msdk account error");
                    }
                }
              
                return NULL;
            }
        
            GCloud::ILogger* GetLogger(){
                ILogger* logger = NULL;
                //get sdkRemoteConfig
                GCloud::Plugin::PluginBase*  pluginBase = PluginGPM::GetInstance();
                if(NULL == pluginBase){
                   
                    return NULL;
                }
                GCloud::Plugin::IPluginManager* pluginManager = pluginBase->GetPluginManager();
                if(NULL == pluginManager){
                    return NULL;
                }
                GCloud::Plugin::IPlugin* plugin = (GCloud::Plugin::IPlugin*)pluginManager->GetPluginByName(PLUGIN_NAME_GCLOUDCORE);
                if(NULL == plugin){
                    return NULL;
                }
                GCloud::Plugin::ILogService* logService = (GCloud::Plugin::ILogService*)plugin->GetServiceByName(PLUGIN_SERVICE_NAME_LOG);
                if(NULL == logService){
                    return NULL;
                }
                logger = logService->GetLogger(pluginBase);
                return logger;
            }
    
            IRemoteConfig* GetIRemoteConfig(){
                
                if (g_remote_config == NULL) {
                    
                    GCloud::Plugin::PluginBase*  pluginBase = PluginGPM::GetInstance();
                    if(NULL==pluginBase){
                        APM_LOG_DEBUG(@"GCloud init PluginBase error");
                        return NULL;
                    }
                    GCloud::Plugin::IPluginManager* pluginManager = pluginBase->GetPluginManager();
                    if(NULL==pluginManager){
                        APM_LOG_DEBUG(@"GCloud init IPluginManager error");
                        return NULL;
                    }
                    GCloud::Plugin::IPlugin* plugin = (GCloud::Plugin::IPlugin*)pluginManager->GetPluginByName(PLUGIN_NAME_GCLOUDCORE);
                    if(NULL==plugin){
                        APM_LOG_DEBUG(@"GCloud init IPlugin error");
                        return NULL;
                    }
                    
                    GCloud::Plugin::IRemoteConfigService* remote_config_service = (GCloud::Plugin::IRemoteConfigService*)plugin->GetServiceByName(PLUGIN_SERVICE_NAME_REMOTECONFIG);
                    if(NULL==remote_config_service){
                        APM_LOG_DEBUG(@"GCloud init IReportService error");
                        return NULL;
                    }
                    
                    g_remote_config = remote_config_service -> GetRemoteConfig(pluginBase);
                    
                    APM_LOG_DEBUG(@"GCloud get remote config success");
                }
                
                return g_remote_config;
            }
        
             GCloud::Plugin::IReportService* GetReportService(){
                
                if(g_report_service_inf == NULL){
                    GCloud::Plugin::PluginBase*  pluginBase = PluginGPM::GetInstance();
                    if(NULL==pluginBase){
                        APM_LOG_DEBUG(@"GCloud init PluginBase error");
                        return NULL;
                    }
                    GCloud::Plugin::IPluginManager* pluginManager = pluginBase->GetPluginManager();
                    if(NULL==pluginManager){
                        APM_LOG_DEBUG(@"GCloud init IPluginManager error");
                        return NULL;
                    }
                    GCloud::Plugin::IPlugin* plugin = (GCloud::Plugin::IPlugin*)pluginManager->GetPluginByName(PLUGIN_NAME_TDM);
                    if(NULL==plugin){
                        APM_LOG_DEBUG(@"GCloud get TDM init IPlugin error");
                        return NULL;
                    }
                    g_report_service_inf = (GCloud::Plugin::IReportService*)plugin->GetServiceByName(PLUGIN_SERVICE_NAME_REPORT);
                    if(NULL==g_report_service_inf){
                        APM_LOG_DEBUG(@"GCloud report init IReportService error");
                        return NULL;
                    }
                }
                
                return g_report_service_inf;
            }
    }
}
