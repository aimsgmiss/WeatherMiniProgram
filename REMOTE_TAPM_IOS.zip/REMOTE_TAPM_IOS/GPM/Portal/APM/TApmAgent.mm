//
//  TApmAgent.m
//  APM
//
//  Created by 雍鹏亮 on 2019/10/23.
//  Copyright © 2019 xianglin. All rights reserved.
//
#import "TApmLog.h"
#import "TApmAgent.h"
#import "TApmApiSingleInstance.h"
#import "ExtValue.h"
#import "SDKHelper.h"
#import "SDKStructEnumDefine.h"
#include "GCloudPluginManager/Service/Log/ILogService.h"

@implementation TApmAgent

- (int)initContextWithAppId:(NSString *)appId engine:(NSString *)engine debug:(BOOL) debug{
    if (!appId){
        APM_LOG_DEBUG(@"appId is NULL");
        return -1;
    }

    int ret = [[TApmApiSingleInstance sharedInstance] initContext:appId];
    if (debug) {
        [[TApmLog sharedInstance] setLogLevel:GCloud::kLogDebug];
    }else{
        [[TApmLog sharedInstance] setLogLevel:GCloud::kLogEvent];
    }
    
    return ret;
}

- (void)setServerInfoWithZoneId:(NSString *) zoneId roomIp:(NSString *)roomIp{
    APM_LOG_DEBUG(@"%@ not implement in TApmAgent",NSStringFromSelector(_cmd));
}

- (void)postEventWithName:(NSString *)eventName params:(NSDictionary<NSString *, NSString *> *)params{
    APM_LOG_DEBUG(@"%@ not implement in TApmAgent",NSStringFromSelector(_cmd));
}

- (void)enableDebugMode{
   
}

- (void)markLevelLoadWithSceneId:(NSString *)sceneId{
    if (!sceneId){
        APM_LOG_DEBUG(@"sceneId is NULL");
        return;
    }
    
    GCloudErrorCode code = (GCloudErrorCode)[[TApmApiSingleInstance sharedInstance] markLoadlevel:[sceneId UTF8String]];
    
    if(_mObserver){
        _mObserver->GPMOnMarkLevelLoad([sceneId UTF8String]);
    }
    
    if (SDKHelper::SDKUtill::gpmObserver != NULL) {
        if (code == GCloudErrorCode_None) {
             SDKHelper::SDKUtill::gpmObserver -> GPMOnLog("[GPM]0__MarkLevelLoad");
        }else {
             SDKHelper::SDKUtill::gpmObserver -> GPMOnLog("[GPM]1__MarkLevelLoad");
        }
    }else {
        APM_LOG_DEBUG(@"gpm Observer is NULL");
    }
}

- (void)markLevelLoadCompleted{
     [[TApmApiSingleInstance sharedInstance] markLoadlevelCompleted];
}

- (void)markLevelFin{
    [[TApmApiSingleInstance sharedInstance] markLevelFin];
}

- (void)setOpenId:(NSString *)openId{
    if (!openId){
        APM_LOG_DEBUG(@"openId is NULL");
        if (SDKHelper::SDKUtill::gpmObserver != NULL) {
            SDKHelper::SDKUtill::gpmObserver -> GPMOnLog("[GPM]1__SetOpenId");
        }else {
            APM_LOG_DEBUG(@"gpm Observer is NULL");
        }
        return;
    }
    [[TApmApiSingleInstance sharedInstance] setUserID:[openId UTF8String]] ;
    
    if (SDKHelper::SDKUtill::gpmObserver != NULL) {
        SDKHelper::SDKUtill::gpmObserver -> GPMOnLog("[GPM]0__SetOpenId");
    }else {
        APM_LOG_DEBUG(@"gpm Observer is NULL");
    }
}

- (void)setQulaity:(int)quality{
    [[TApmApiSingleInstance sharedInstance] setQuality:quality];
    
    if(_mObserver){
        _mObserver->GPMOnSetQulaity([@(quality) description].UTF8String);
    }
}

- (void)postStepEventWithCategory:(NSString *)eventCategory stepId:(int)stepId status:(int)status code:(int)code msg:(NSString *)msg extraKey:(NSString *) extraKey authorize:(BOOL)authorize finish:(BOOL)finish{
    if (!eventCategory){
        eventCategory = @"NA";
        APM_LOG_DEBUG(@"step event event name is NULL");
    }
    
    if (!msg){
        msg = @"NA";
        APM_LOG_DEBUG(@"step event msg is NULL");
    }
    
    if (!extraKey){
        extraKey = @"NA";
        APM_LOG_DEBUG(@"step event extDefinekey is NULL");
    }
    
    [[TApmApiSingleInstance sharedInstance] postStepEvent:[eventCategory UTF8String] stepId:stepId status:status code:code msg:[msg UTF8String] extDefineKey:[extraKey UTF8String]];
}

- (void)detectInTimeout{
     APM_LOG_DEBUG(@"%@ not implement in TApmAgent",NSStringFromSelector(_cmd));
}


- (void)postTrackStateX:(float)x y:(float)y  z:(float)z  pitch:(float)pitch yaw:(float)yaw roll:(float)roll{
    [[TApmApiSingleInstance sharedInstance] postCoordinate:x y:y z:z pitch:pitch yaw:yaw roll:roll];
}

- (int)checkDCLSByQccWithAbsolutePath:(NSString *)absolutePath configName:(NSString *)configName{
    
    if (SDKHelper::SDKUtill::gpmObserver != NULL) {
        SDKHelper::SDKUtill::gpmObserver -> GPMOnLog("[GPM]0__CheckDCLSByQcc");
    }else {
        APM_LOG_DEBUG(@"gpm Observer is NULL");
    }
    
    return [[TApmApiSingleInstance sharedInstance] getDeviceLevelAbsPath:absolutePath configLevel:configName];
}

- (int)checkDCLSByQccSyncAbsolutePath:(NSString *)absolutePath configName:(NSString *)configName{
    
//    if (SDKHelper::SDKUtill::gpmObserver != NULL) {
//        SDKHelper::SDKUtill::gpmObserver -> GPMOnLog("[GPM]1__CheckDCLSByQcc");
//    }else {
//        APM_LOG_DEBUG(@"gpm Observer is NULL");
//    }
    
    return [[TApmApiSingleInstance sharedInstance] ayncGetDeviceLevelWithAbsPath:absolutePath configLevel:configName];
}

- (void)postFrameWithDeltaTime:(float)deltaTime{
    [[TApmApiSingleInstance sharedInstance] postFrame:deltaTime];
}

- (void)postNetLatency:(int)latency{
    [[TApmApiSingleInstance sharedInstance] postNTL:latency];
    
    if (SDKHelper::SDKUtill::gpmObserver != NULL) {
        SDKHelper::SDKUtill::gpmObserver -> GPMOnLog("[GPM]0__PostNetLatency");
    }else {
        APM_LOG_DEBUG(@"gpm Observer is NULL");
    }
}

- (void)beginTupleWrapWithCategory:(NSString *)category{
    tapmNativeBeginTupleWrap([category UTF8String]);
    if (SDKHelper::SDKUtill::gpmObserver != NULL) {
        SDKHelper::SDKUtill::gpmObserver -> GPMOnLog("[GPM]0__BeginTupleWrap");
    }else {
        APM_LOG_DEBUG(@"gpm Observer is NULL");
    }
}

- (void)endTupleWrap{
    tapmNativeEndTupleWrap();
    if (SDKHelper::SDKUtill::gpmObserver != NULL) {
        SDKHelper::SDKUtill::gpmObserver -> GPMOnLog("[GPM]0__EndTupleWrapy");
    }else {
        APM_LOG_DEBUG(@"gpm Observer is NULL");
    }
}

- (void)postValueFWithCategory:(NSString *)category key:(NSString *)key a:(float)a{
    tapmNativePostV1F([category UTF8String],[key UTF8String],a);
}

- (void)postValueFWithCategory:(NSString *)category key:(NSString *)key a:(float)a b:(float)b{
    tapmNativePostV2F([category UTF8String],[key UTF8String],a,b);
}

- (void)postValueFWithCategory:(NSString *)category key:(NSString *)key a:(float)a b:(float)b c:(float)c{
    tapmNativePostV3F([category UTF8String],[key UTF8String],a,b,c);
}

- (void)postValueIWithCategory:(NSString *)category key:(NSString *)key a:(int)a{
    tapmNativePostV1I([category UTF8String],[key UTF8String],a);
}

- (void)postValueIWithCategory:(NSString *)category key:(NSString *)key a:(int)a b:(int)b{
    tapmNativePostV2I([category UTF8String],[key UTF8String],a,b);
}

- (void)postValueIWithCategory:(NSString *)category key:(NSString *)key a:(int)a b:(int)b c:(int)c{
    tapmNativePostV3I([category UTF8String],[key UTF8String],a,b,c);
}

- (void)postValueSWithCategory:(NSString *)category key:(NSString *)key value:(NSString *)value{
    tapmNativePostV1S([category UTF8String],[key UTF8String], [value UTF8String]);
}

- (void)setDefinedDeviceClass:(int)deviceClass {
    [[TApmApiSingleInstance sharedInstance] setDeviceLevel:deviceClass];
}

- (void)beginTagWithName:(NSString *)tagName{
    [[TApmApiSingleInstance sharedInstance] beginTag:tagName];
    if (SDKHelper::SDKUtill::gpmObserver != NULL) {
        SDKHelper::SDKUtill::gpmObserver -> GPMOnLog("[GPM]0__BeginTag");
    }else {
        APM_LOG_DEBUG(@"gpm Observer is NULL");
    }
    
}

- (void)endTag{
    [[TApmApiSingleInstance sharedInstance] endTag];
    if (SDKHelper::SDKUtill::gpmObserver != NULL) {
        SDKHelper::SDKUtill::gpmObserver -> GPMOnLog("[GPM]0__EndTag");
    }else {
        APM_LOG_DEBUG(@"gpm Observer is NULL");
    }
}

- (void)setVersionIden:(NSString *)versionName {
    [[TApmApiSingleInstance sharedInstance] setVersionIden:versionName];
}

- (void)beignExclude{
    [[TApmApiSingleInstance sharedInstance] beginExclude];
}

- (void)endExclude{
    [[TApmApiSingleInstance sharedInstance] endExclude];
}

- (NSString *)getErrorMsgWithErrorCode:(int)errorCode{
    const char* error = [[TApmApiSingleInstance sharedInstance] getErrorMsg:errorCode];
    if (!error) {
        return @"NA";
    }
    return @(error);
}

- (void)linkSessionWithEventName:(NSString* )eventName{
    [[TApmApiSingleInstance sharedInstance] linkStreamEventSession:eventName];
}

- (void)initStepEventContext{
    [[TApmApiSingleInstance sharedInstance] initStepEventContext];
}

- (void)releaseStepEventContext{
    [[TApmApiSingleInstance sharedInstance] releaseStepEventContext];
}

- (void)postEventISWithKey:(int)key value:(const char*)value{
     [[TApmApiSingleInstance sharedInstance] postEvent:key info:value];
}

- (void)setObserver:(GPMObserver *)observer{
    [super setObserver:observer];
    SDKHelper::SDKUtill::gpmObserver = observer;
}
@end
