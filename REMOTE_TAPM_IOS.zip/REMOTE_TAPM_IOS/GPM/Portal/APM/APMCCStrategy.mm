//
//  APMCCStrategy.m
//  APM
//
//  Created by xiang lin on 2019/10/24.
//  Copyright © 2019 xianglin. All rights reserved.
//

#import "APMCCStrategy.h"
#import "TApmLog.h"

@interface APMCCStrategy()

@property (assign,nonatomic) BOOL mEnabledLevelFunc;
@property (assign,nonatomic) BOOL mEnabledDCLSFunc;
@property (assign,nonatomic) BOOL mEnabledDyeingEventFunc;
@property (assign,nonatomic) BOOL mEnabledStepEventFunc;
@property (assign,nonatomic) BOOL mEnabledPostValueXXFunc;
@property (assign,nonatomic) BOOL mEnabledTagFunc;
@property (assign,nonatomic) BOOL mEnabledPostFrameFunc;
@property (assign,nonatomic) BOOL mEnabledDebugModeFunc;

@property (assign,nonatomic) BOOL mEnableMmapFunc;
@property (assign,nonatomic) BOOL mEnableAppStateFunc;
@property (assign,nonatomic) BOOL mEnableLaunchMsgFunc;
@property (assign,nonatomic) BOOL mEnableOpenIDFunc;
@property (assign,nonatomic) BOOL mLocalSettleSeed;
@property (assign,nonatomic) BOOL mEnableThermalState;
@end

static int MAX_SEED_VALUE = 10000;

@implementation APMCCStrategy

+ (instancetype)sharedInstance{
    static APMCCStrategy* instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[APMCCStrategy alloc] init];
    });
    return instance;
}

- (instancetype)init{
    
        if(self = [super init]){
            
        int mSeedModule = [self getInt:@"APM_MODULE" defaultValue:MAX_SEED_VALUE];
        int mSeedInitFunc = [self getInt:@"APM_INIT_FUNC" defaultValue:MAX_SEED_VALUE];
        int mSeedLevelFunc = [self getInt:@"APM_LEVEL_FUNC" defaultValue:MAX_SEED_VALUE];
        int mSeedDCLSFunc = [self getInt:@"APM_DCLS_FUNC" defaultValue:MAX_SEED_VALUE];
        int mSeedDyeingEventFunc = [self getInt:@"APM_DYEING_EVENT_FUNC" defaultValue:MAX_SEED_VALUE];
        int mSeedStepEventFunc = [self getInt:@"APM_STEP_EVENT_FUNC" defaultValue:MAX_SEED_VALUE];
        int mSeedPostValueXXFunc = [self getInt:@"APM_PVXX_FUNC" defaultValue:MAX_SEED_VALUE];
        int mSeedTagFunc = [self getInt:@"APM_TAG_FUNC" defaultValue:MAX_SEED_VALUE];
        int mSeedPostFrameFunc = [self getInt:@"APM_POSTFRAME_FUNC" defaultValue:MAX_SEED_VALUE];
        int mSeedEnableDebugModeFunc = [self getInt:@"APM_ENABLE_DEBUG_MODE_FUNC" defaultValue:MAX_SEED_VALUE];
            
        int mEnableMmapFunc = [self getInt:@"APM_ENABLE_MMAP_FUNC" defaultValue:0];//默认关闭
        int mEnableAppStateFunc = [self getInt:@"APM_ENABLE_APP_STATE_FUNC" defaultValue:MAX_SEED_VALUE];
        _mPssIntervals = [self getInt:@"APM_PSS_INTERVALS_IOS" defaultValue:1];
        int launchMsg = [self getInt:@"APM_LAUNCH_MSG" defaultValue:MAX_SEED_VALUE];
        int getOpenID = [self getInt:@"APM_AUTO_OPENID" defaultValue:0];//默认关闭
        int mLocalSettleSeed = [self getInt:@"APM_LOCAL_SETTLE" defaultValue:MAX_SEED_VALUE];
        int thermalState = [self getInt:@"APM_THERMALSTATE" defaultValue:MAX_SEED_VALUE];
            
        _mEnabledModule = arc4random() % 1000 < mSeedModule;
        _mEnabledInitFunc = arc4random() % 1000 < mSeedInitFunc;
        _mEnabledLevelFunc = arc4random() % 1000 < mSeedLevelFunc;
        _mEnabledDCLSFunc = arc4random() % 1000 < mSeedDCLSFunc;
        _mEnabledDyeingEventFunc = arc4random() % 1000 < mSeedDyeingEventFunc;
        _mEnabledStepEventFunc = arc4random() % 1000 < mSeedStepEventFunc;
        _mEnabledPostValueXXFunc = arc4random() % 1000 < mSeedPostValueXXFunc;
        _mEnabledTagFunc = arc4random() % 1000 < mSeedTagFunc;
        _mEnabledPostFrameFunc = arc4random() % 1000 < mSeedPostFrameFunc;
        _mEnabledDebugModeFunc = arc4random() % 1000 < mSeedEnableDebugModeFunc;
        _mEnableMmapFunc = arc4random() % 1000 < mEnableMmapFunc;
        _mEnableAppStateFunc = arc4random() % 1000 < mEnableAppStateFunc;
        _mEnableLaunchMsgFunc = arc4random() % 1000 < launchMsg;
        _mEnableOpenIDFunc = arc4random() % 1000 < getOpenID;
        _mLocalSettleSeed = arc4random() % 1000 < mLocalSettleSeed;
        _mEnableThermalState = arc4random() % 1000 < thermalState;
    }

    return self;
}

- (BOOL)isFeatureEnabled:(FEATURE)feature{
    switch (feature) {
        case FEATURE_INIT:
            return _mEnabledInitFunc;
        case FEATURE_MARK_LEVEL_LOAD:
        case FEATURE_SAVE_FPS:
        case FEATURE_MARK_LEVEL_LOAD_COMPLETED:
        case FEATURE_MARK_LEVEL_FIN:
            return _mEnabledLevelFunc;
            
        case FEATURE_CHECK_DECLS_BY_QCC:
        case FEATURE_CHECK_DECLS_BY_QCC_SYNC:
            return _mEnabledDCLSFunc;
            
        case FEATURE_TAG_FUNC:
            return _mEnabledTagFunc;
            
        case FEATURE_POST_EVENT:
            return _mEnabledDyeingEventFunc;
            
        case FEATURE_POST_STEP_EVENT:
            return _mEnabledStepEventFunc;
            
        case FEATURE_POST_VALUE_XX:
            return _mEnabledPostValueXXFunc;
            
        case FEATURE_POST_FRAME:
            return _mEnabledPostFrameFunc;
            
        case FEATURE_ENABLED_DEBUG_MODE:
            return _mEnabledDebugModeFunc;
            
        case FEATURE_SET_OBSERVER:
        case FEATURE_SET_OPENID:
        case FEATURE_SET_QUALITY:
        case FEATURE_POST_NETWORK_LATENCY:
        case FEATURE_POST_TRACK_STATE:
        case FEATURE_DEF_DCLS:
        case FEATURE_SET_VERSION_IDEN:
            return YES;
            
        case FEATURE_DETECH_IN_TIMEOUT:
        case FEATURE_SET_SERVERINFO:
            return NO;
        case FEATURE_MMAP:
            return _mEnableMmapFunc;
        case FEATURE_ZIGZAG:
            return YES;
        case FEATURE_FPS:
            return YES;
        case FEATURE_APP_STATE:
            return _mEnableAppStateFunc;
        case FEATURE_LANUCH_MSG:
            return _mEnableLaunchMsgFunc;
        case FEATURE_AUTO_OPENID:
            return _mEnableOpenIDFunc;
        case FEATURE_POST_DETECT_TIMEOUT:
            return NO;
        case FEATURE_LOCAL_SETTLE:
            return _mLocalSettleSeed;
        case FEATURE_THERMALSTATE:
            return _mEnableThermalState;
        default:
            return NO;
    }
}

- (BOOL)validCheck:(NSString*)fuctionName tag:(FEATURE)feature{
    
    if (!_mEnabledInitFunc) {
        APM_LOG_DEBUG(@"APM module inited failed");
        return NO;
    }
    
    if (!_mEnabledModule) {
        APM_LOG_DEBUG(@"function name:%@ disable by qcc",fuctionName);
        return NO;
    }
    
    if (![[APMCCStrategy sharedInstance] isFeatureEnabled:feature]) {
        APM_LOG_DEBUG(@"function name:%@ disable by qcc",fuctionName);
        return NO;
    }
    
    return YES;
}

- (int)getPssInterval {
    return _mPssIntervals;
}

- (int)getBatteryIntervals{
    return 0;
}

@end
