//
//  SessionState.m
//  APM
//
//  Created by xiang lin on 2019/10/24.
//  Copyright © 2019 xianglin. All rights reserved.
//

#import "SessionState.h"

@implementation SessionState

+ (instancetype)sharedInstance{
    static SessionState *instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[SessionState alloc] init];
    });
    return instance;
}


@end
