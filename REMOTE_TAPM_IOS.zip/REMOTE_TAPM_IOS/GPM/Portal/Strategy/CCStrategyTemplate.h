//
//  CCStrategyTemplate.h
//  APM
//
//  Created by xiang lin on 2019/10/24.
//  Copyright © 2019 xianglin. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, FEATURE) {
    FEATURE_INIT = 1,
    FEATURE_ENABLED_DEBUG_MODE,
    FEATURE_SET_SERVERINFO,
    FEATURE_MARK_LEVEL_LOAD,
    FEATURE_MARK_LEVEL_LOAD_COMPLETED,
    FEATURE_MARK_LEVEL_FIN,
    FEATURE_SET_OPENID,
    FEATURE_SET_QUALITY,
    FEATURE_POST_EVENT,
    FEATURE_POST_STEP_EVENT,
    FEATURE_DETECH_IN_TIMEOUT,
    FEATURE_POST_TRACK_STATE,
    FEATURE_CHECK_DECLS_BY_QCC,
    FEATURE_CHECK_DECLS_BY_QCC_SYNC,
    FEATURE_POST_FRAME,
    FEATURE_POST_NETWORK_LATENCY,
    FEATURE_POST_VALUE_XX,
    FEATURE_DEF_DCLS,
    FEATURE_TAG_FUNC,
    FEATURE_SET_VERSION_IDEN,
    FEATURE_SET_OBSERVER,
    FEATURE_MMAP,
    FEATURE_ZIGZAG,
    FEATURE_FPS,
    FEATURE_APP_STATE,
    FEATURE_LANUCH_MSG,
    FEATURE_AUTO_OPENID,
    FEATURE_POST_DETECT_TIMEOUT,
    FEATURE_SAVE_FPS,
    FEATURE_LOCAL_SETTLE,    //apm calculate fps
    FEATURE_THERMALSTATE,
};

@interface CCStrategyTemplate : NSObject

- (BOOL)checkModuleEnabled;

- (BOOL)isFeatureEnabled:(FEATURE)feature;

- (int)getInt:(NSString*)key defaultValue:(int)defaultValue;

- (int64_t)getLong:(NSString*)key defaultValue:(long)defaultValue;

- (double)getDouble:(NSString*)key defaultValue:(double)defaultValue;

- (BOOL)getBool:(NSString*)key defaultValue:(BOOL)defaultvalue;

- (NSString*)getString:(NSString*)key value:(NSString*)value defaultValue:(NSString*)defaultvalue;

@end

NS_ASSUME_NONNULL_END
