//
//  GPMCCStrategy.h
//  APM
//
//  Created by xiang lin on 2019/10/24.
//  Copyright © 2019 xianglin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CCStrategyTemplate.h"
NS_ASSUME_NONNULL_BEGIN

@interface GPMCCStrategy : CCStrategyTemplate

@end

NS_ASSUME_NONNULL_END
