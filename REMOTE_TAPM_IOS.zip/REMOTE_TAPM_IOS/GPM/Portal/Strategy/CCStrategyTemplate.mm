//
//  CCStrategyTemplate.m
//  APM
//
//  Created by xiang lin on 2019/10/24.
//  Copyright © 2019 xianglin. All rights reserved.
//

#import "CCStrategyTemplate.h"
#import "TApmLog.h"
@interface CCStrategyTemplate()

@property (assign,nonatomic) BOOL mIsModuleEnabled;

@end

@implementation CCStrategyTemplate

- (BOOL)checkModuleEnabled{
    return YES;
}

- (BOOL)isFeatureEnabled:(FEATURE)feature{
    return YES;
}

- (int)getInt:(NSString*)key defaultValue:(int)defaultValue{
    if (!key) {
        APM_LOG_DEBUG(@"get getInt key is nil");
        return defaultValue;
    }
    
    GCloud::IRemoteConfig* iRemoteConfig = GCloud::GPM::GetIRemoteConfig();
    if (!iRemoteConfig) {
        APM_LOG_DEBUG(@"get remote config is nil");
        return defaultValue;
    }
    int retValue = iRemoteConfig -> GetInt([key UTF8String], defaultValue);
    return retValue;
}

- (int64_t)getLong:(NSString*)key defaultValue:(long)defaultValue{
    if (!key) {
        APM_LOG_DEBUG(@"get getLong key is nil");
        return defaultValue;
    }
    
    GCloud::IRemoteConfig* iRemoteConfig = GCloud::GPM::GetIRemoteConfig();
    if (!iRemoteConfig) {
        APM_LOG_DEBUG(@"get remote config is nil");
        return defaultValue;
    }
    
    int64_t retValue = iRemoteConfig -> GetLong([key UTF8String], defaultValue);
    return retValue;
}

- (double)getDouble:(NSString*)key defaultValue:(double)defaultValue{
    if (!key) {
        APM_LOG_DEBUG(@"get getDouble key is nil");
        return defaultValue;
    }
    
    GCloud::IRemoteConfig* iRemoteConfig = GCloud::GPM::GetIRemoteConfig();
    if (!iRemoteConfig) {
        APM_LOG_DEBUG(@"get remote config is nil");
        return defaultValue;
    }
    
    long retValue = iRemoteConfig -> GetDouble([key UTF8String], defaultValue);
    return retValue;
}

- (BOOL)getBool:(NSString*)key defaultValue:(BOOL)defaultvalue{
    if (!key) {
        APM_LOG_DEBUG(@"get getBool key is nil");
        return defaultvalue;
    }
    
    GCloud::IRemoteConfig* iRemoteConfig = GCloud::GPM::GetIRemoteConfig();
    if (!iRemoteConfig) {
        
        APM_LOG_DEBUG(@"get remote config is nil");
        return defaultvalue;
    }

    BOOL retValue = iRemoteConfig -> GetBool([key UTF8String], defaultvalue);
    return retValue;
}

- (NSString*)getString:(NSString*)key value:(NSString*)value defaultValue:(NSString*)defaultvalue{
    if (!key) {
        APM_LOG_DEBUG(@"get getString key is nil");
        return defaultvalue;
    }
    
    GCloud::IRemoteConfig* iRemoteConfig = GCloud::GPM::GetIRemoteConfig();
    if (!iRemoteConfig) {
        APM_LOG_DEBUG(@"get remote config is nil");
        return defaultvalue;
    }

    static int count = 1024 * 5;
    char *valueArr = (char *)calloc(count, 1);
    if (!valueArr) {
        return defaultvalue;
    }
    int len = count;
    bool b = iRemoteConfig->GetString(key.UTF8String, valueArr, len, defaultvalue.UTF8String);
    
    if (len >= count) {
        free(valueArr);
        APM_LOG_DEBUG(@"error GetString too long:%d", len);
        return defaultvalue;
    }
    
    if (b) {
        NSString *retValue =  [NSString  stringWithCString:valueArr encoding:NSUTF8StringEncoding];
        free(valueArr);
        return retValue;
    }

    free(valueArr);
    return defaultvalue;
    
}


@end
