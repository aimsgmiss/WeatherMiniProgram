//
//  GPMAgent.m
//  APM
//
//  Created by 雍鹏亮 on 2019/10/23.
//  Copyright © 2019 xianglin. All rights reserved.
//

#import "GPMAgent.h"
#import "TApmLog.h"
#import "ErrorCodeHelper.h"
#import "GPMModuleTemplate.h"
#import "CCStrategyTemplate.h"
#import "GPMCCStrategy.h"
#import "TDMReportExecStatusHelper.h"
#import "TApmAgent.h"
#import "GemAgent.h"
#import "SessionState.h"
#import "APMCCStrategy.h"
#import "GemCCStrategy.h"

@interface GPMAgent()

@property (assign,nonatomic)BOOL mIsInitContext;
@property (strong, nonatomic)NSMutableArray *mTriKitList;

@property(nonatomic,strong) CCStrategyTemplate* mCCStrategyTemplate;
@property(nonatomic,strong) TDMReportExecStatusHelper* mTdmReporterExecStatusHelper;

@property(nonatomic,strong) SessionState* mSessionState;

@end

@implementation GPMAgent

+ (instancetype)sharedInstance{
    static GPMAgent *instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[GPMAgent alloc] init];
    });
    return instance;
}

- (instancetype)init{
    if (self = [super init]) {
        _mIsInitContext = NO;
        _mTriKitList = [[NSMutableArray alloc] init];
        
        _mCCStrategyTemplate = [[GPMCCStrategy alloc] init];
        _mTdmReporterExecStatusHelper = [TDMReportExecStatusHelper sharedInstance];
        
    }
    return self;
}

- (int)initContextWithAppId:(NSString *)appId engine:(NSString *)engine debug:(BOOL)debug{
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_INIT]) {
        APM_LOG_DEBUG(@"InitContext error switch disable");
        return DISABLED_BY_CC;
    }
    if (self.mIsInitContext) {
        APM_LOG_DEBUG(@"InitContext has been invoked");
        return DUPLICATE_INIT;
    }
    
    _mSessionState = [SessionState sharedInstance];

    GPMModuleTemplate *tapmProxy = [[TApmAgent alloc] initWithStrategy:[APMCCStrategy sharedInstance] reportExecStatusHelper:_mTdmReporterExecStatusHelper sessionState:_mSessionState];
    GPMModuleTemplate *gemProxy = [[GemAgent alloc] initWithStrategy:[GemCCStrategy new] reportExecStatusHelper:_mTdmReporterExecStatusHelper sessionState:_mSessionState];

    [_mTriKitList addObject:tapmProxy];
    [_mTriKitList addObject:gemProxy];

    int retValue = 0;
    self.mIsInitContext = true;
    for (GPMModuleTemplate *temp in self.mTriKitList) {
      
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_INIT]) {
            retValue = [temp initContextWithAppId:appId engine:engine debug:debug];
            if (retValue != 0) break;
        }else{
            APM_LOG_DEBUG(@"InitContext error switch disable");
        }
    }
    
    APM_LOG_DEBUG(@"GPM init finished");

    return retValue;
}

- (void)enableDebugMode {
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_ENABLED_DEBUG_MODE]) {
        APM_LOG_DEBUG(@"enableDebugMode error switch disable");
        return;
    }
    
     for (GPMModuleTemplate *temp in self.mTriKitList) {
         if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_ENABLED_DEBUG_MODE]) {
             [temp enableDebugMode];
         }else{
            APM_LOG_DEBUG(@"enableDebugMode error switch disable");
         }
    }
}


///设置事件观察者
- (void)setObserver:(GPMObserver *)observer{
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_SET_OBSERVER]) {
        APM_LOG_DEBUG(@"setObserver error switch disable");
        return;
    }
    
    for (GPMModuleTemplate *temp in self.mTriKitList) {
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_SET_OBSERVER]) {
            [temp setObserver:observer];
        }else{
            APM_LOG_DEBUG(@"setObserver error switch disable");
        }
    }
    
}

- (void)setServerInfoWithZoneId:(NSString *) zoneId roomIp:(NSString *)roomIp {
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_SET_SERVERINFO]) {
        APM_LOG_DEBUG(@"setServer error switch disable");
        return;
    }
    
    for (GPMModuleTemplate *temp in self.mTriKitList) {
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_SET_SERVERINFO]) {
            [temp setServerInfoWithZoneId:zoneId roomIp:roomIp];
        }else{
            APM_LOG_DEBUG(@"setServer error switch disable");
        }
    }
}

- (void)markLevelLoadWithSceneId:(NSString *)sceneId {
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_MARK_LEVEL_LOAD]) {
        APM_LOG_DEBUG(@"markLevelLoad error switch disable");
        return;
    }
    
     for (GPMModuleTemplate *temp in self.mTriKitList) {
         if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_MARK_LEVEL_LOAD]) {
             [temp markLevelLoadWithSceneId:sceneId];
         }else{
            APM_LOG_DEBUG(@"markLevelLoad error switch disable");
         }
    }
}

- (void)saveFps:(float)favg FMax:(int)fmax FMin:(int)fmin Ftotal:(int)ftotal Fheavy:(int)fheavy Flight:(int)flight Fcntx0:(int)fcntx0 Flfps1:(int)flfps1 Flfps2:(int)flfps2 Flfps3:(int)flfps3 Fpsdots:(NSString *)fpsdots {
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_SAVE_FPS]) {
        APM_LOG_DEBUG(@"saveFps error switch disable");
        return;
    }
    
     for (GPMModuleTemplate *temp in self.mTriKitList) {
         if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_SAVE_FPS]) {
             [temp saveFps:favg FMax:fmax FMin:fmin Ftotal:ftotal Fheavy:fheavy Flight:flight Fcntx0:fcntx0 Flfps1:flfps1 Flfps2:flfps2 Flfps3:flfps3 Fpsdots:fpsdots];
         }else{
            APM_LOG_DEBUG(@"saveFps error switch disable");
         }
    }
}

- (void)markLevelLoadCompleted {
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_MARK_LEVEL_LOAD_COMPLETED]) {
        APM_LOG_DEBUG(@"markLevelLoadCompleted error switch disable");
        return;
    }
    
    for (GPMModuleTemplate* temp in  self.mTriKitList) {
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_MARK_LEVEL_LOAD_COMPLETED]) {
            [temp markLevelLoadCompleted];
        }else{
            APM_LOG_DEBUG(@"markLevelLoadCompleted error switch disable");
        }
    }
}

- (void)markLevelFin {
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_MARK_LEVEL_FIN]) {
        APM_LOG_DEBUG(@"markLevelFin error switch disable");
        return;
    }
    
     for (GPMModuleTemplate *temp in self.mTriKitList) {
         if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_MARK_LEVEL_FIN]) {
             [temp markLevelFin];
         }else{
              APM_LOG_DEBUG(@"markLevelFin error switch disable");
         }
    }
}

- (void)setOpenId:(NSString *)openId {
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_SET_OPENID]) {
        APM_LOG_DEBUG(@"setOpenId error switch disable");
        return;
    }
    
    for (GPMModuleTemplate *temp in self.mTriKitList) {
         if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_SET_OPENID]) {
             [temp setOpenId:openId];
         }else{
            APM_LOG_DEBUG(@"setOpenId error switch disable");
         }
    }
}

- (void)setQulaity:(int)quality {
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_SET_QUALITY]) {
        APM_LOG_DEBUG(@"setQulaity error switch disable");
        return;
    }
    
   for (GPMModuleTemplate *temp in self.mTriKitList) {
       if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_SET_QUALITY]) {
           [temp setQulaity:quality];
       }else{
           APM_LOG_DEBUG(@"setQulaity error switch disable");
       }
      
    }
}

- (void)postEventWithName:(NSString *)eventName params:(NSDictionary<NSString *, NSString *> *)params{
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_POST_EVENT]) {
        APM_LOG_DEBUG(@"postEvent error switch disable");
        return;
    }
    
    for (GPMModuleTemplate *temp in self.mTriKitList) {
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_POST_EVENT]) {
            [temp postEventWithName:eventName params:params];
        }else{
            APM_LOG_DEBUG(@"postEvent error switch disable");
        }
    }
}

- (void)postStepEventWithCategory:(NSString *)eventCategory stepId:(int)stepId status:(int)status code:(int)code msg:(NSString *)msg extraKey:(NSString *) extraKey authorize:(BOOL)authorize finish:(BOOL)finish{
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_POST_STEP_EVENT]) {
        APM_LOG_DEBUG(@"postStepEvent error switch disable");
        return;
    }
    
    for (GPMModuleTemplate *temp in self.mTriKitList) {
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_POST_STEP_EVENT]) {
            [temp postStepEventWithCategory:eventCategory stepId:stepId status:status code:code msg:msg extraKey:extraKey authorize:authorize finish:finish];
        }else{
            APM_LOG_DEBUG(@"postStepEvent error switch disable");
        }
    }
}

- (void)detectInTimeout{
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_DETECH_IN_TIMEOUT]) {
        APM_LOG_DEBUG(@"detectInTimeout error switch disable");
        return;
    }
    
     for (GPMModuleTemplate *temp in self.mTriKitList) {
         if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_DETECH_IN_TIMEOUT]) {
             [temp detectInTimeout];
         }else{
            APM_LOG_DEBUG(@"detectInTimeout error switch disable");
         }
    }
}


//APM features
- (void)postTrackStateX:(float) x y:(float)y z:(float)z pitch:(float)pitch yaw:(float)yaw roll:(float)roll {
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_POST_TRACK_STATE]) {
        APM_LOG_DEBUG(@"postTrackStateX error switch disable");
        return;
    }
    
    for (GPMModuleTemplate* temp in self.mTriKitList) {
    
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_POST_TRACK_STATE]) {
            [temp postTrackStateX:x y:y z:z pitch:pitch yaw:yaw roll:roll];
        }else{
             APM_LOG_DEBUG(@"postTrackStateX error switch disable");
        }
    }
}

- (int)checkDCLSByQccWithAbsolutePath:(NSString *)absolutePath configName:(NSString *)configName{

    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_CHECK_DECLS_BY_QCC]) {
        APM_LOG_DEBUG(@"FEATURE_CHECK_DECLS_BY_QCC error switch disable");
        return -1;
    }
    
    for (GPMModuleTemplate* temp in self.mTriKitList) {
         if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_CHECK_DECLS_BY_QCC]) {
             return [temp checkDCLSByQccWithAbsolutePath:absolutePath configName:configName];
        }else{
            APM_LOG_DEBUG(@"FEATURE_CHECK_DECLS_BY_QCC error switch disable");
        }
    }
    
    return -1;
}

- (int)checkDCLSByQccSyncAbsolutePath:(NSString *)absolutePath configName:(NSString *)configName{
  
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_CHECK_DECLS_BY_QCC_SYNC]) {
        APM_LOG_DEBUG(@"FEATURE_CHECK_DECLS_BY_QCC_SYNC error switch disable");
        return -1;
    }
    
    for (GPMModuleTemplate* temp in self.mTriKitList) {
       if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_CHECK_DECLS_BY_QCC_SYNC]) {
           return [temp checkDCLSByQccSyncAbsolutePath:absolutePath configName:configName];
        }else{
            APM_LOG_DEBUG(@"FEATURE_CHECK_DECLS_BY_QCC_SYNC error switch disable");
        }
    }
    
    return -1;
}

- (void)postFrameWithDeltaTime:(float)deltaTime {
   
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_POST_FRAME]) {
        return;
    }
    
    for (GPMModuleTemplate* temp in self.mTriKitList) {
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_POST_FRAME]) {
            [temp postFrameWithDeltaTime:deltaTime];
        }
    }
}

- (void)postNetLatency:(int)latency {
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_POST_NETWORK_LATENCY]) {
        APM_LOG_DEBUG(@"postNetLatency error switch disable");
        return;
    }
    
    
    for (GPMModuleTemplate* temp in self.mTriKitList) {
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_POST_NETWORK_LATENCY]) {
            [temp postNetLatency:latency];
        }else{
            APM_LOG_DEBUG(@"postNetLatency error switch disable");
        }
    }
}

- (void)beginTupleWrapWithCategory:(NSString*)category {
   
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_POST_VALUE_XX]) {
        //APM_LOG_DEBUG(@"beginTuple error switch disable");
        return;
    }
    
    for (GPMModuleTemplate* temp in self.mTriKitList) {
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_POST_VALUE_XX]) {
            [temp beginTupleWrapWithCategory:category];
        }else{
            //APM_LOG_DEBUG(@"beginTuple error switch disable");
        }
    }
}

- (void)endTupleWrap {
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_POST_VALUE_XX]) {
        //APM_LOG_DEBUG(@"endTupleWrap error switch disable");
        return;
    }
    
    for (GPMModuleTemplate* temp in self.mTriKitList) {
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_POST_VALUE_XX]) {
            [temp endTupleWrap];
        }else{
            //APM_LOG_DEBUG(@"endTupleWrap error switch disable");
        }
    }
}

- (void)postValueFWithCategory:(NSString*)category key:(NSString*)key a:(float) a {
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_POST_VALUE_XX]) {
        //APM_LOG_DEBUG(@"postValue error switch disable");
        return;
    }

    for (GPMModuleTemplate* temp in self.mTriKitList) {
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_POST_VALUE_XX]) {
            [temp postValueFWithCategory:category key:key a:a];
        }else{
            //APM_LOG_DEBUG(@"postValue error switch disable");
        }
    }
}

- (void)postValueFWithCategory:(NSString*)category key:(NSString*)key a:(float)a b:(float)b {
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_POST_VALUE_XX]) {
        //APM_LOG_DEBUG(@"postValue error switch disable");
        return;
    }
    
    for (GPMModuleTemplate* temp in self.mTriKitList) {
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_POST_VALUE_XX]) {
            [temp postValueFWithCategory:category key:key a:a b:b];
        }else{
             //APM_LOG_DEBUG(@"postValue error switch disable");
        }
    }
}

- (void)postValueFWithCategory:(NSString*)category key:(NSString*)key a:(float)a b:(float)b c:(float)c {
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_POST_VALUE_XX]) {
        //APM_LOG_DEBUG(@"postValue error switch disable");
        return;
    }
    
    for (GPMModuleTemplate* temp in self.mTriKitList) {
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_POST_VALUE_XX]) {
            [temp postValueFWithCategory:category key:key a:a b:b c:c];
        }else{
            //APM_LOG_DEBUG(@"postValue error switch disable");
        }
    }
}

- (void)postValueIWithCategory:(NSString*)category key:(NSString*)key a:(int)a {
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_POST_VALUE_XX]) {
        //APM_LOG_DEBUG(@"postValue error switch disable");
        return;
    }

    for (GPMModuleTemplate* temp in self.mTriKitList) {
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_POST_VALUE_XX]) {
            [temp postValueIWithCategory:category key:key a:a];
        }else{
            //APM_LOG_DEBUG(@"postValue error switch disable");
        }
    }
}

- (void)postValueIWithCategory:(NSString*)category key:(NSString*)key a:(int)a b:(int)b {
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_POST_VALUE_XX]) {
        //APM_LOG_DEBUG(@"postValue error switch disable");
        return;
    }
    
    for (GPMModuleTemplate* temp in self.mTriKitList) {
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_POST_VALUE_XX]) {
            [temp postValueIWithCategory:category key:key a:a b:b];
        }else{
            //APM_LOG_DEBUG(@"postValue error switch disable");
        }
    }
}

- (void)postValueIWithCategory:(NSString*)category key:(NSString*)key a:(int)a b:(int)b c:(int)c {
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_POST_VALUE_XX]) {
        //APM_LOG_DEBUG(@"postValue error switch disable");
        return;
    }
    
    for (GPMModuleTemplate* temp in self.mTriKitList) {
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_POST_VALUE_XX]) {
            [temp postValueIWithCategory:category key:key a:a b:b c:c];
        }else{
            //APM_LOG_DEBUG(@"postValue error switch disable");
        }
    }
}

- (void)postValueSWithCategory:(NSString*)category key:(NSString*)key value:(NSString*)value {
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_POST_VALUE_XX]) {
        //APM_LOG_DEBUG(@"postValue error switch disable");
        return;
    }
    
    for (GPMModuleTemplate* temp in self.mTriKitList) {
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_POST_VALUE_XX]) {
            [temp postValueSWithCategory:category key:key value:value];
        }else{
            //APM_LOG_DEBUG(@"postValue error switch disable");
        }
    }
}

- (void)setDefinedDeviceClass:(int)deviceClass {
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_DEF_DCLS]) {
        APM_LOG_DEBUG(@"setDefinedDeviceClass error switch disable");
        return;
    }

    for (GPMModuleTemplate* temp in self.mTriKitList) {
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_DEF_DCLS]) {
            
            [temp setDefinedDeviceClass:deviceClass];
        }else{
            APM_LOG_DEBUG(@"setDefinedDeviceClass error switch disable");
        }
    }
}

- (void)beginTagWithName:(NSString*)tagName {
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_TAG_FUNC]) {
        APM_LOG_DEBUG(@"beginTag error switch disable");
        return;
    }
    
    for (GPMModuleTemplate* temp in self.mTriKitList) {
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_TAG_FUNC]) {
            [temp beginTagWithName:tagName];
        }else{
            APM_LOG_DEBUG(@"beginTag error switch disable");
        }
    }
}

- (void)endTag {
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_TAG_FUNC]) {
        APM_LOG_DEBUG(@"endTag error switch disable");
        return;
    }
    
    for (GPMModuleTemplate* temp in self.mTriKitList) {
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_TAG_FUNC]) {
            [temp endTag];
        }else{
             APM_LOG_DEBUG(@"endTag error switch disable");
        }
    }
}

- (void)setVersionIden:(NSString*)versionName {
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_SET_VERSION_IDEN]) {
        APM_LOG_DEBUG(@"setVersionIden error switch disable");
        return;
    }

    for (GPMModuleTemplate* temp in self.mTriKitList) {
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_SET_VERSION_IDEN]) {
            [temp setVersionIden:versionName];
        }else{
             APM_LOG_DEBUG(@"setVersionIden error switch disable");
        }
    }
}

- (void)beignExclude {
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_SET_VERSION_IDEN]) {
        APM_LOG_DEBUG(@"beignExclude error switch disable");
        return;
    }
  
    for (GPMModuleTemplate* temp in self.mTriKitList) {
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_SET_VERSION_IDEN]) {
            [temp beignExclude];
        }else{
            APM_LOG_DEBUG(@"beignExclude error switch disable");
        }
    }
}

- (void)endExclude {
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_SET_VERSION_IDEN]) {
        APM_LOG_DEBUG(@"endExclude error switch disable");
        return;
    }
    
    for (GPMModuleTemplate* temp in self.mTriKitList) {
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_SET_VERSION_IDEN]) {
            [temp endExclude];
        }else{
            APM_LOG_DEBUG(@"endExclude error switch disable");
        }
    }
}

- (NSString *)getErrorMsgWithErrorCode:(int)errorCode{
    
    for (GPMModuleTemplate* temp in self.mTriKitList) {
        return [temp getErrorMsgWithErrorCode:errorCode];
    }
    
    return [NSString stringWithFormat:@"unknow error:%d",errorCode];
}


- (void)linkSessionWithEventName:(NSString* )eventName{
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_POST_STEP_EVENT]) {
        APM_LOG_DEBUG(@"post step event error switch disable");
        return;
    }
    
    for (GPMModuleTemplate* temp in self.mTriKitList) {
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_POST_STEP_EVENT]) {
            [temp linkSessionWithEventName:eventName];
        }else{
            APM_LOG_DEBUG(@"post step event error switch disable");
        }
    }
    
}

- (void)initStepEventContext{
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_POST_STEP_EVENT]) {
        APM_LOG_DEBUG(@"post step event error switch disable");
        return;
    }
    
    for (GPMModuleTemplate* temp in self.mTriKitList) {
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_POST_STEP_EVENT]) {
            [temp initStepEventContext];
        }else{
            APM_LOG_DEBUG(@"post step event error switch disable");
        }
    }
   
}

- (void)releaseStepEventContext{
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_POST_STEP_EVENT]) {
        APM_LOG_DEBUG(@"post step event error switch disable");
        return;
    }
    
    for (GPMModuleTemplate* temp in self.mTriKitList) {
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_POST_STEP_EVENT]) {
            [temp releaseStepEventContext];
        }else{
            APM_LOG_DEBUG(@"post step event error switch disable");
        }
    }
}

- (void)postEventISWithKey:(int)key value:(const char*)value{
    
    if (![_mCCStrategyTemplate isFeatureEnabled:FEATURE_POST_EVENT]) {
        APM_LOG_DEBUG(@"postEventIS error switch disable");
        return;
    }
    
    for (GPMModuleTemplate* temp in self.mTriKitList) {
        if ([[temp getCCStrategy] isFeatureEnabled:FEATURE_POST_EVENT]) {
            [temp postEventISWithKey:key value:value];
        }else{
            APM_LOG_DEBUG(@"postEventIS error switch disable");
        }
    }
}

@end
