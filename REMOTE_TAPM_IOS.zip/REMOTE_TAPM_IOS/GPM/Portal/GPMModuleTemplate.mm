//
//  GPMModuleTemplate.m
//  APM
//
//  Created by 雍鹏亮 on 2019/10/23.
//  Copyright © 2019 xianglin. All rights reserved.
//

#import "GPMModuleTemplate.h"
#import "TApmLog.h"
#import "CCStrategyTemplate.h"

@interface GPMModuleTemplate()
@end

@implementation GPMModuleTemplate

- (instancetype)initWithStrategy:(CCStrategyTemplate *)sctrategy reportExecStatusHelper:(TDMReportExecStatusHelper *)reportExecStatusHelper sessionState:(SessionState *)sessionState{
    if (self = [super init]) {
        _mCCStrategyTemplate = sctrategy;
        _mTdmReporterExecStatusHelper = reportExecStatusHelper;
        _mSessionState = sessionState;
    }
   return self;
}

- (CCStrategyTemplate *) getCCStrategy{
    return _mCCStrategyTemplate;
}

- (void)addLifeCycleCallbacks:(SDKObserver *)observer{
    
}


- (void)setObserver:(GPMObserver *)observer{
    _mObserver = observer;
}

- (int)initContextWithAppId:(NSString *)appId engine:(NSString *)engine debug:(BOOL) debug{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
    return 0;
}

- (void)enableDebugMode{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)setServerInfoWithZoneId:(NSString *) zoneId roomIp:(NSString *)roomIp{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)markLevelLoadWithSceneId:(NSString *)sceneId{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)saveFps:(float)favg FMax:(int)fmax FMin:(int)fmin Ftotal:(int)ftotal Fheavy:(int)fheavy Flight:(int)flight Fcntx0:(int)fcntx0 Flfps1:(int)flfps1 Flfps2:(int)flfps2 Flfps3:(int)flfps3 Fpsdots:(NSString *)fpsdots{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)markLevelFin{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)markLevelLoadCompleted{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)setOpenId:(NSString *)openId{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)setQulaity:(int)quality{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)postEventWithName:(NSString *)eventName params:(NSDictionary<NSString *, NSString *> *)params{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)postStepEventWithCategory:(NSString *)eventCategory stepId:(int)stepId status:(int)status code:(int)code msg:(NSString *)msg extraKey:(NSString *) extraKey authorize:(BOOL)authorize finish:(BOOL)finish{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)detectInTimeout{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}


- (void)postTrackStateX:(float)x y:(float)y  z:(float)z  pitch:(float)pitch yaw:(float)yaw roll:(float)roll{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (int)checkDCLSByQccWithAbsolutePath:(NSString *)absolutePath configName:(NSString *)configName{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
    return 0;
}

- (int)checkDCLSByQccSyncAbsolutePath:(NSString *)absolutePath configName:(NSString *)configName{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
    return 0;
}

- (void)postFrameWithDeltaTime:(float)deltaTime{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)postNetLatency:(int)latency{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)beginTupleWrapWithCategory:(NSString *)category{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)endTupleWrap{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)postValueFWithCategory:(NSString *)category key:(NSString *)key a:(float)a{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)postValueFWithCategory:(NSString *)category key:(NSString *)key a:(float)a b:(float)b{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)postValueFWithCategory:(NSString *)category key:(NSString *)key a:(float)a b:(float)b c:(float)c{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)postValueIWithCategory:(NSString *)category key:(NSString *)key a:(int)a{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)postValueIWithCategory:(NSString *)category key:(NSString *)key a:(int)a b:(int)b{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)postValueIWithCategory:(NSString *)category key:(NSString *)key a:(int)a b:(int)b c:(int)c{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)postValueSWithCategory:(NSString *)category key:(NSString *)key value:(NSString *)value{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)setDefinedDeviceClass:(int)deviceClass {
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)beginTagWithName:(NSString *)tagName{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)endTag{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)setVersionIden:(NSString *)versionName {
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)beignExclude{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)endExclude{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (NSString *)getErrorMsgWithErrorCode:(int)errorCode{
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
    return @"NA";
}

- (void)linkSessionWithEventName:(NSString* )eventName{
    
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)initStepEventContext{
    
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)releaseStepEventContext{
    
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

- (void)postEventISWithKey:(int)key value:(const char*)value{
    
    APM_LOG_DEBUG(@"%@ not implement in super class", NSStringFromSelector(_cmd));
}

@end
