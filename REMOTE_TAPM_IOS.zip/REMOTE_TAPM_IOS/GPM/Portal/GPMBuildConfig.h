//
//  GPMBuildConfig.h
//  APM
//
//  Created by xiang lin on 2019/10/30.
//  Copyright © 2019 xianglin. All rights reserved.
//

#import <Foundation/Foundation.h>

static  BOOL const GPM_DEBUG            = NO;
static  NSString* const APPLICATION_ID  = @"com.tencent.gcloud.gpmsdk";
static  NSString* const BUILD_TYPE      = @"release";
static  NSString* const FLAVOR          = @"";
static  BOOL const IsTGPAEnabled        = NO;
static  int const VERSION_CODE          = 636;
static  NSString* const VERSION_NAME    = @"6.3.6";

NS_ASSUME_NONNULL_BEGIN

@interface GPMBuildConfig : NSObject

@end

NS_ASSUME_NONNULL_END
