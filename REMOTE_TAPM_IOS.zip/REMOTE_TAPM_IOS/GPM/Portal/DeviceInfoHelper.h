//
//  DeviceInfoHelper.hpp
//  APM
//
//  Created by xiang lin on 2019/10/25.
//  Copyright © 2019 xianglin. All rights reserved.
//

#ifndef DeviceInfoHelper_hpp
#define DeviceInfoHelper_hpp

#include <stdio.h>
#import <UIKit/UIKit.h>

namespace DeviceInfo
{
    class DeviceInfoHelper
    {
   
    public:
        
        static NSString* getNSStringFromTDM(const char* deviceInfoName);
        
        static int64_t getInt64FromTDM(const char* deviceInfoName);
        
        static NSString* getSysVersion();
        
        static NSString* getAppVersion();
        
        /**
         *  获取设备型号 eg:Iphone x
         */
        static NSString* getDeviceModel();
        
        static NSString* getDeviceModelFromTDM();
        
        static NSString* getBrand();
        
        static NSString* getIDFV();
        
        static NSString* getCPUArchName();
        /**
         *
         */
        //static NSString* getCPUArchName();
        /**
         *  设备硬盘总的空间
         */
        static uint32_t getDeviceTotalSpace();
    
        /**
         *  获取当前设备物理内存
         */
        static uint32_t getTotalRAMCount();
        /**
         *  获取当前设备处理器个数
         */
        static NSUInteger getProccessorCount();
        
    };
}

#endif /* DeviceInfoHelper_hpp */
