//
//  TDMReportExecStatusHelper.h
//  APM
//
//  Created by xiang lin on 2019/10/23.
//  Copyright © 2019 xianglin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <string>
NS_ASSUME_NONNULL_BEGIN

@interface TDMReportExecStatusHelper : NSObject

+ (instancetype)sharedInstance;

- (void)postFunctionStatus:(NSString*)methodName methodParam:(NSString*)methodParam resultCode:(int)resultCode errorCode:(int)errorCode errorMsg:(NSString*)errorMsg costTime:(int)costTime;

@end

NS_ASSUME_NONNULL_END
