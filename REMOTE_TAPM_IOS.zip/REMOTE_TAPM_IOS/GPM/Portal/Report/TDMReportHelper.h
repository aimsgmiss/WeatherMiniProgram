//
//  TDMReportHelper.h
//  APM
//
//  Created by xiang lin on 2019/10/23.
//  Copyright © 2019 xianglin. All rights reserved.
//

#include "GCloudPluginManager/Service/Report/IReportService.h"
#include "GCloudPluginManager/Service/Report/GCloudCoreReporter.h"
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TDMReportHelper : NSObject


- (GCloud::Plugin::IEvent *)createEventWithName:(NSString *)eventName;

/// 添加一个字符串key和字符串value数据
/// @param key 符串key
/// @param value 字符串value
- (void)addSS:(NSString*)key value:(NSString*)value withEvent:(GCloud::Plugin::IEvent *) event;


/// 添加一个整型key和字符串value数据
/// @param key 整型key
/// @param value 字符串value
- (void)addIS:(int)key value:(NSString*)value withEvent:(GCloud::Plugin::IEvent *) event;


/// 添加一个整型key和长整型value数据
/// @param key 整型key
/// @param value 长整型value
- (void)addIL:(int)key value:(int64_t)value withEvent:(GCloud::Plugin::IEvent *) event;


/// 上报动作
- (void)reportWithEvent:(GCloud::Plugin::IEvent *) event;


/// 取消动作
- (void)destoryWithEvent:(GCloud::Plugin::IEvent *) event;

@end

NS_ASSUME_NONNULL_END
