//
//  TDMReportHelper.m
//  APM
//
//  Created by xiang lin on 2019/10/23.
//  Copyright © 2019 xianglin. All rights reserved.
//

#import "TDMReportHelper.h"
#include "PluginGPM.h"

@interface TDMReportHelper()


@end


@implementation TDMReportHelper

- (GCloud::Plugin::IEvent *)createEventWithName:(NSString *)eventName{
    if (!eventName) {
        return NULL;
    }
    GCloud::Plugin::IEvent *event = CREATE_GCLOUDCORE_REPORT_EVENT(
    PluginGPM,    // 插件实现类
    GCLOUDCORE_REPORT_ENV_TEST | GCLOUDCORE_REPORT_ENV_RELEASE,
    2005,
    eventName.UTF8String);
    return event;
    
}

- (void)addSS:(NSString*)key value:(NSString*)value withEvent:(GCloud::Plugin::IEvent *) event{
    if (!key || !value) {
        return;
    }
    if (event) {
        event->Add(key.UTF8String, value.UTF8String, (int)strlen(value.UTF8String));
    }
}

- (void)addIS:(int)key value:(NSString*)value withEvent:(GCloud::Plugin::IEvent *) event{
    if (!value) {
        return;
    }
    if (event) {
        event->Add(key, value.UTF8String, (int)strlen(value.UTF8String));
    }
}

- (void)addIL:(int)key value:(int64_t)value withEvent:(GCloud::Plugin::IEvent *) event{
    if (event) {
        event->Add(key, value);
    }
}

- (void)reportWithEvent:(GCloud::Plugin::IEvent *) event{
    if (event) {
        event->Report();
    }
}

- (void)destoryWithEvent:(GCloud::Plugin::IEvent *) event{
    if (event) {
        DESTROY_GCLOUDCORE_REPORT_EVENT(PluginGPM, &event);
    }
}

@end
