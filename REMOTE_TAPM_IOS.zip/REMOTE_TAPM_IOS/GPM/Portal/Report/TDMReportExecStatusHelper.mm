//
//  TDMReportExecStatusHelper.m
//  APM
//
//  Created by xiang lin on 2019/10/23.
//  Copyright © 2019 xianglin. All rights reserved.
//

#import "TDMReportExecStatusHelper.h"
#import "GCloudPluginManager/Service/Report/IReportService.h"
#import "TDMReportHelper.h"

@implementation TDMReportExecStatusHelper

+ (instancetype)sharedInstance{
    static TDMReportExecStatusHelper *instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[TDMReportExecStatusHelper alloc] init];
    });
    return instance;
}

- (void)postFunctionStatus:(NSString*)methodName methodParam:(NSString*)methodParam resultCode:(int)resultCode errorCode:(int)errorCode errorMsg:(NSString*)errorMsg costTime:(int)costTime {
    
    TDMReportHelper* tdmReportHelper = [[TDMReportHelper alloc] init];
    
    if (tdmReportHelper) {
        GCloud::Plugin::IEvent* event = [tdmReportHelper createEventWithName:@"monitor"];
        if (methodName) {
            [tdmReportHelper addIS:GCloud::Plugin::KStrKeyMethodName value:methodName withEvent:event];
        }
        
        if (methodParam) {
            [tdmReportHelper addIS:GCloud::Plugin::KStrKeyMethodParams value:methodParam withEvent:event];
        }
        
        [tdmReportHelper addIL:GCloud::Plugin::kIntKeyResultCode value:resultCode withEvent:event];
        [tdmReportHelper addIL:GCloud::Plugin::kIntKeyErrorCode value:errorCode withEvent:event];
        
        if (errorMsg) {
            [tdmReportHelper addIS:GCloud::Plugin::KStrKeyErrorMsg value:errorMsg withEvent:event];
        }
        
        [tdmReportHelper addIL:GCloud::Plugin::KIntKeyDuration value:costTime withEvent:event];
        
        [tdmReportHelper reportWithEvent:event];
        [tdmReportHelper destoryWithEvent:event];
    }
}

@end
