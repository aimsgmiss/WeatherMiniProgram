//
//  APM.m
//  APM
//
//  Created by vincentwgao on 2018/9/14.
//  Copyright © 2018年 xianglin. All rights reserved.
//

#import "APM.h"
#include "TriAgent.h"
#include "TriBuildConfig.h"

int tri_initContext(char *appId, char *engine, BOOL debug){
    if (appId == NULL || engine == NULL) {
        return -1;
    }
    return [[TriAgent sharedInstance] initContextWithAppId:@(appId) engine:@(engine) debug:debug];
}


void tri_setObserver(TriObserver *observer){
    [[TriAgent sharedInstance] setObserver:observer];
    
}

void tri_enableDebugMode(){
    [[TriAgent sharedInstance] enableDebugMode];
}

void tri_setServerInfo(char *zoneId, char *roomIp){
    if (zoneId == NULL || roomIp == NULL) {
        return;
    }
    [[TriAgent sharedInstance] setServerInfoWithZoneId:@(zoneId) roomIp:@(roomIp)];
}

void tri_markLevelLoad(char *sceneId){
    if (sceneId == NULL) {
         return;
    }
    [[TriAgent sharedInstance] markLevelLoadWithSceneId:@(sceneId)];
}

void tri_markLevelFin(){
    [[TriAgent sharedInstance] markLevelFin];
}

void tri_markLevelLoadCompleted(){
    [[TriAgent sharedInstance] markLevelLoadCompleted];
}

void tri_setOpenId(char *openId){
    if (openId == NULL) {
         return;
    }
    [[TriAgent sharedInstance] setOpenId:@(openId)];
}

void tri_setQulaity(int quality){
    [[TriAgent sharedInstance] setQulaity:quality];
}

void tri_postEventSS(char *eventName, char* eventList){
    
    
}
//void tri_postEvent(char *eventName, std::vector<APMDictionary>& eventList){
//    if (eventName == NULL) {
//            return;
//    }
//    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithCapacity:eventList.size()];
//    for (int i = 0; i < eventList.size(); i++) {
//        std::string key = eventList[i].key;
//        std::string value = eventList[i].value;
//        char *keyZoom = (char *)calloc(key.length() + 1, 1);
//        char *valueZoom = (char *)calloc(value.length() +1, 1);
//        if (keyZoom == NULL || valueZoom == NULL) {
//            return;
//        }
//        strcpy(keyZoom, key.c_str());
//        strcpy(valueZoom, value.c_str());
//
//        dic[@(keyZoom)] = @(valueZoom);
//    }
//    [[TriAgent sharedInstance] postEventWithName:@(eventName) params:dic];
//
//}

void tri_postStepEvent(char *eventCategory, int stepId, int status, int code, char *msg, char *extraKey){
    if (eventCategory == NULL) {
        return;
    }
    NSString *ocExtraKey = extraKey ? @(extraKey) : nil;
    NSString *ocMsg = msg ? @(msg) : nil;
    [[TriAgent sharedInstance] postStepEventWithCategory:@(eventCategory) stepId:stepId status:status code:code msg:ocMsg extraKey:ocExtraKey finish:NO authorize:NO];
}

void tri_detectInTimeout(){
    [[TriAgent sharedInstance] detectInTimeout];
}

//APM features
void tri_postTrackState(float x, float y, float z, float pitch, float yaw, float roll){
    [[TriAgent sharedInstance] postTrackStateX:x y:y z:z pitch:pitch yaw:yaw roll:roll];
}

int tri_checkDCLSByQcc(char *absolutePath, char *configName){
    if (absolutePath == NULL || configName == NULL) {
        return -1;
    }
   
    return [[TriAgent sharedInstance] checkDCLSByQccWithAbsolutePath:@(absolutePath) configName:@(configName)];
}

int tri_checkDCLSByQccSync(char *absolutePath, char*configName){
    if (absolutePath == NULL || configName == NULL) {
           return -1;
    }
    return [[TriAgent sharedInstance] checkDCLSByQccSyncAbsolutePath:@(absolutePath) configName:@(configName)];
}

void tri_postFrame(float deltaTime){
    [[TriAgent sharedInstance] postFrameWithDeltaTime:deltaTime];
}

void tri_postNetLatency(int latency){
    [[TriAgent sharedInstance] postNetLatency:latency];
}

void tri_beginTupleWrap(char *category){
    if (category == NULL) {
        return;
    }
    [[TriAgent sharedInstance] beginTupleWrapWithCategory:@(category)];
}

void tri_endTupleWrap(){
    [[TriAgent sharedInstance] endTupleWrap];
}

void tri_postValueF1(char *category, char *key, float a){
    if (category == NULL || key == NULL) {
        return;
    }
    [[TriAgent sharedInstance] postValueFWithCategory:@(category) key:@(key) a:a];
}

void tri_postValueF2(char *category, char *key, float a, float b){
    if (category == NULL || key == NULL) {
          return;
    }
    [[TriAgent sharedInstance] postValueFWithCategory:@(category) key:@(key) a:a b:b];
}

void tri_postValueF3(char *category, char *key, float a, float b, float c){
    if (category == NULL || key == NULL) {
          return;
    }
    [[TriAgent sharedInstance] postValueFWithCategory:@(category) key:@(key) a:a b:b c:c];
}

void tri_postValueI1(char *category, char *key, int a){
    if (category == NULL || key == NULL) {
          return;
    }
    [[TriAgent sharedInstance] postValueIWithCategory:@(category) key:@(key) a:a];
}

void tri_postValueI2(char *category, char *key, int a, int b){
    if (category == NULL || key == NULL) {
          return;
    }
    [[TriAgent sharedInstance] postValueIWithCategory:@(category) key:@(key) a:a b:b];
}

void tri_postValueI3(char *category, char *key, int a, int b, int c){
    if (category == NULL || key == NULL) {
          return;
    }
    [[TriAgent sharedInstance] postValueIWithCategory:@(category) key:@(key) a:a b:b c:c];
}

void tri_postValueS(char *category, char *key, char *value){
    if (category == NULL || key == NULL || value == NULL) {
          return;
    }
    [[TriAgent sharedInstance] postValueSWithCategory:@(category) key:@(key) value:@(value)];
}

void tri_setDefinedDeviceClass(int deviceClass){
    [[TriAgent sharedInstance] setDefinedDeviceClass:deviceClass];
}

void tri_beginTag(char *tagName){
    if (tagName == NULL) {
        return;
    }
    [[TriAgent sharedInstance] beginTagWithName:@(tagName)];
}

void tri_endTag(){
    [[TriAgent sharedInstance] endTag];
}

void tri_setVersionIden(char *versionName){
    if (versionName == NULL) {
        return;
    }
    [[TriAgent sharedInstance] setVersionIden:@(versionName)];
}

void tri_beignExclude(){
    [[TriAgent sharedInstance] beignExclude];
}

void tri_endExclude(){
    [[TriAgent sharedInstance] endExclude];
}

const char *tri_getErrorMsg(int errorCode){
    const char *cstr = [[TriAgent sharedInstance] getErrorMsgWithErrorCode:errorCode].UTF8String;
    if (cstr == NULL) {
        cstr = "";
    }
    cstr = strdup(cstr);
    return cstr;
}


void tri_linkSession(const char* eventName){
    if (eventName == NULL) {
        return;
    }
    
    [[TriAgent sharedInstance] linkSessionWithEventName:@(eventName)];
}

void tri_initStepEventContext(){
    [[TriAgent sharedInstance] initStepEventContext];
}

void tri_releaseStepEventContext(){
    [[TriAgent sharedInstance] releaseStepEventContext];
}

void tri_postEventIS(int key,const char* value){
    if (value == NULL) {
        return;
    }
    [[TriAgent sharedInstance] postEventISWithKey:key value:value];
}

const char* tri_getSDKVersion(){
    
    return VERSION_NAME;
}
