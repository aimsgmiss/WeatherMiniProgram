//
//  GSDKPrivate.h
//  GSDK
//
//  Created by fu chunhui on 2017/1/5.
//  Copyright © 2017年 fu chunhui. All rights reserved.
//

#ifndef GSDKPrivate_h
#define GSDKPrivate_h

#import "GPMBuildConfig.h"

// ???:版本号
// NOTE(三合一): 版本号统一
static NSString * const GSDK_VERSION = VERSION_NAME;

// httpdns地址
static NSString * const HTTP_DNS_HTTP_SERVER = @"182.254.116.120";
// httpdns加解密秘钥
static NSString * const HTTP_DNS_DOMAIN_ENCRYPT_KEY = @">srW/8;&";

static NSString * const kGSDKOpenID = @"gsdkReportOpenId";

static NSString * const kGSDKRcr = @"rcr";
static NSString * const kGSDKIsCache = @"isCache";

static NSString * const REQUEST_CLOUD_CONFIG_REQUEST_KEY = @"request";
static NSString * const REQUEST_CLOUD_CONFIG_ERR_MSG_KEY = @"errMsg";

// 游戏内云控上报事件名
static NSString * const GameCloudReportName = @"gsdk_report_0";

// 游戏内采集结果上报事件名
static NSString * const GameReportName = @"gsdk_report_1";

// 云控下发键值，公共
static NSString * const kGSDKErrorCode = @"errno";
static NSString * const kGSDKErrorMsg = @"errmsg";

// 游戏内上报Key值 & 云控下发键值
static NSString * const kGSDKPing = @"ping";
static NSString * const kGSDKFrequency = @"frequency";
static NSString * const kGSDKSip = @"sip";
static NSString * const KGSDKSport = @"sport";
static NSString * const kGSDKCPU = @"cpu";
static NSString * const kGSDKMem = @"mem";
static NSString * const kGSDKCpu_cycle = @"cpu_cycle";
static NSString * const kGSDKPcntx00 = @"pcntx00";
static NSString * const kGSDKBatteryUsage = @"battery";
static NSString * const kGSDKNetFlow = @"netflow";
static NSString * const kGSDKWiFi = @"wifi";
static NSString * const kGSDKSignal_cycle = @"signal_cycle";
static NSString * const kGSDKFps = @"fps";
static NSString * const kGSDKFps_cycle = @"fps_cycle";
static NSString * const kGSDKFcntx0 = @"fcntx0";
static NSString * const kGSDKFLfps1 = @"lfps1";
static NSString * const kGSDKFLfps2 = @"lfps2";
static NSString * const kGSDKFLfps3 = @"lfps3";

// 游戏内上报Key值
// cpu&mem
static NSString * const kGSDKTotalCPU = @"totcpu";
static NSString * const kGSDKAvailMem = @"availmem";
static NSString * const kGSDKMaxMem = @"max_mem";
static NSString * const kGSDKStartMem = @"start_mem";
static NSString * const kGSDKEndMem = @"end_mem";
static NSString * const kGSDKTotalMem = @"totalmem";

// udp
static NSString * const kGSDKMaxPing = @"pmax";
static NSString * const kGSDKMinPing = @"pmin";
static NSString * const kGSDKAvgPing = @"pavg";
static NSString * const kGSDKHeavyPing = @"pheavy";
static NSString * const kGSDKLostPing = @"plost";
static NSString * const kGSDKTotalPing = @"ptotal";
// wifi
static NSString * const kGSDKWiFiNum = @"wifi_num";
static NSString * const kGSDKWiFiRSSI = @"wifi_rssi";
static NSString * const kGSDKWiFiSpeed = @"wifi_speed";
static NSString * const kGSDKNetType = @"xg";
static NSString * const kGSDKGateDelay = @"gate_delay";
// fps
static NSString * const kGSDKAvgFPS = @"favg";
static NSString * const kGSDKMinFPS = @"fmin";
static NSString * const kGSDKMaxFPS = @"fmax";
static NSString * const kGSDKTotalFPS = @"ftotal";
static NSString * const kGSDKHeavyFPS = @"fheavy";
static NSString * const kGSDKLightFPS = @"flight";
// battery
static NSString * const kGSDKBatteryStatus = @"bs";
static NSString * const kGSDKBatteryTemperature = @"bt";
static NSString * const kGSDKMaxBatteryTemperature = @"max_battery_temp";
static NSString * const kGSDKStartBattery = @"start_battery";
static NSString * const kGSDKEndBattery = @"end_battery";
// netCard
static NSString * const kGSDKWSndPkt = @"wsndpkt";
static NSString * const kGSDKWRcvPkt = @"wrcvpkt";
static NSString * const kGSDKWSndDrop = @"wsnddrop";
static NSString * const kGSDKWRcvDrop = @"wrcvdrop";
static NSString * const kGSDKWSndErr = @"wsnderr";
static NSString * const kGSDKWRcvErr = @"wrcverr";
static NSString * const kGSDKMSndPkt = @"msndpkt";
static NSString * const kGSDKMRcvPkt = @"mrcvpkt";
static NSString * const kGSDKMSndDrop = @"msnddrop";
static NSString * const kGSDKMRcvDrop = @"mrcvdrop";
static NSString * const kGSDKMSndErr = @"msnderr";
static NSString * const kGSDKMRcvErr = @"mrcverr";
// others
static NSString * const kGSDKTag = @"tag";
static NSString * const kGSDKEndTime = @"etime";
static NSString * const kGSDKDuration = @"time";
static NSString * const kGSDKTotalStorage = @"total_storage";
static NSString * const kGSDKFreeStorage = @"free_storage";
static NSString * const kGSDKRoomIP = @"roomip";
static NSString * const kGSDKVersion = @"version";
static NSString * const kGSDKDevices = @"devices";
static NSString * const kGSDKOpenid = @"openid";
static NSString * const kGSDKZoneID = @"zoneid";
static NSString * const kGSDKFpsMode = @"fps_mode";
static NSString * const kGSDKQualityLev = @"quality_Lev";
static NSString * const kGSDKOptLev = @"opt_lev";
static NSString * const kGSDKLDNS = @"ldns";

// gsdk_report_1上报字段: 测速ip
static NSString * const GAME_SPEED_TEST_IP_NAME = @"speedip";

//实时探测结果上报事件名
static NSString * const TCPDetectReportName = @"gsdk_report_tcpdelay";
static NSString * const UDPDetectReportName = @"gsdk_report_udpdelay";

//游戏内时延跳变实时探测上报Key值
static NSString * const kGSDK_RealTime_RSSI = @"signalLevel"; // -->信号强度
static NSString * const kGSDK_RealTime_NetType = @"xg";       // --> 2/3/4G
static NSString * const kGSDK_RealTime_GateDelay = @"gateway";// -->网关延迟

// uuid可能被视为敏感数据
//static NSString * const kGSDKUUID = @"uuid";
static NSString * const kGSDKISBACK = @"isBack";

static NSString * const kGSDKCreateTime = @"create_time";
static NSString * const kGSDKDebug = @"debug";

#pragma pack(1)
struct udpPacket{
    UInt32 seqno;
    char svalue;
};
#pragma options align=reset

#endif /* GSDKPrivate_h */
