//
//  CPU.m
//  GSDK
//
//  Created by 曹爽 on 16/3/18.
//  Copyright © 2016年 fu chunhui. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GSDKCPU.h"
#import <sys/sysctl.h>
#import <mach/mach.h>
#import "GSDKLogger.h"

@interface GSDKCPU()

@property (nonatomic, strong, readwrite) NSMutableArray * cpu_numList;
@property (nonatomic, strong, readwrite) NSMutableArray * systemcpu_numList;
@property (nonatomic, strong, readwrite) NSMutableArray * cpu_Dots;

@end

@implementation GSDKCPU

processor_info_array_t cpuInfo, prevCpuInfo;
mach_msg_type_number_t numCpuInfo, numPrevCpuInfo;
unsigned numCPUs;
NSLock * CPUUsageLock;

static GSDKCPU * _sharedInstance = nil;
//方法实现
+ (instancetype) sharedInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[GSDKCPU alloc] init];
    });
    return _sharedInstance;
}

- (void) startCPU {
    if (_cpu_numList == nil) {
        self.cpu_numList = [NSMutableArray array];
    } else {
        [self.cpu_numList removeAllObjects];
    }
    if (_systemcpu_numList == nil) {
        self.systemcpu_numList = [NSMutableArray array];
    } else {
        [self.systemcpu_numList removeAllObjects];
    }
    if (_cpu_Dots == nil) {
        self.cpu_Dots = [NSMutableArray array];
    } else {
        [self.cpu_Dots removeAllObjects];
    }
    [self getSystemCPU];
}

- (void) getCPUMessage {
    double cpu = [self getCPU];
    double systemcpu = [self getSystemCPUCircle];
    if (cpu >= 0) {
        [self.cpu_numList addObject:@(cpu)];
        [self.cpu_Dots addObject:[NSString stringWithFormat:@"%.0f", cpu]];
    }
    if (systemcpu >= 0) {
        [self.systemcpu_numList addObject:@(systemcpu)];
    }
}

- (void) dealloc {
    if (_systemcpu_numList != nil) {
        [_systemcpu_numList removeAllObjects];
        _systemcpu_numList = nil;
    }
    if (_cpu_numList != nil) {
        [_cpu_numList removeAllObjects];
        _cpu_numList = nil;
    }
    if (_cpu_Dots != nil) {
        [_cpu_Dots removeAllObjects];
        _cpu_Dots = nil;
    }
}

- (NSDictionary *) resultCPU {
    NSString * cpu_avg = @"-1";
    NSString * syscpu_avg = @"-1";
    @try {
        if ((_cpu_numList != nil) && [_cpu_numList count] > 0) {
            cpu_avg = [NSString stringWithFormat:@"%d", [[_cpu_numList valueForKeyPath:@"@avg.doubleValue"] intValue]];
        }
        if ((_systemcpu_numList != nil) && [_systemcpu_numList count] > 0) {
            syscpu_avg = [NSString stringWithFormat:@"%d", [[_systemcpu_numList valueForKeyPath:@"@avg.doubleValue"] intValue]];
        }
        GSDKLOG(@"cpu==%@ totcpu==%@",cpu_avg,syscpu_avg);
    } @catch (NSException *exception) {
        GSDKLOG(@"resultCPU Exception:%@", exception);
    } @finally {
        if (_systemcpu_numList != nil) {
            [self.systemcpu_numList removeAllObjects];
            [self setSystemcpu_numList:nil];
        }
        if (_cpu_numList != nil) {
            [self.cpu_numList removeAllObjects];
            [self setCpu_numList:nil];
        }
        return @{kGSDKCPU: cpu_avg,
                 kGSDKTotalCPU: syscpu_avg};
    }
}

- (NSDictionary *) resultCPU_noCollect {
    return @{kGSDKCPU: @"-1",
             kGSDKTotalCPU: @"-1"};
}

- (NSArray *) cpuDots {
    if (_cpu_Dots) {
        NSArray * cpuDots = [_cpu_Dots copy];
        [_cpu_Dots removeAllObjects];
        _cpu_Dots = nil;
        return cpuDots;
    }
    return nil;
}

- (void) getSystemCPU {
    int mib[2U] = { CTL_HW, HW_NCPU };
    size_t sizeOfNumCPUs = sizeof(numCPUs);
    int status = sysctl(mib, 2U, &numCPUs, &sizeOfNumCPUs, NULL, 0U);
    if (status)
        numCPUs = 1;
    CPUUsageLock = [[NSLock alloc] init];
}

- (double) getSystemCPUCircle {
    natural_t numCPUsU = 0U;
    kern_return_t err = host_processor_info(mach_host_self(), PROCESSOR_CPU_LOAD_INFO, &numCPUsU, &cpuInfo, &numCpuInfo);
    if (err == KERN_SUCCESS) {
        [CPUUsageLock lock];
        float tot_inUse = 0;
        float tot_total = 0;
        for(unsigned i = 0U; i < numCPUs; ++i) {
            float inUse, total;
            if(prevCpuInfo) {
                inUse = ((cpuInfo[(CPU_STATE_MAX * i) + CPU_STATE_USER] - prevCpuInfo[(CPU_STATE_MAX * i) + CPU_STATE_USER])
                         + (cpuInfo[(CPU_STATE_MAX * i) + CPU_STATE_SYSTEM] - prevCpuInfo[(CPU_STATE_MAX * i) + CPU_STATE_SYSTEM])
                         + (cpuInfo[(CPU_STATE_MAX * i) + CPU_STATE_NICE]   - prevCpuInfo[(CPU_STATE_MAX * i) + CPU_STATE_NICE]));
                total = inUse + (cpuInfo[(CPU_STATE_MAX * i) + CPU_STATE_IDLE] - prevCpuInfo[(CPU_STATE_MAX * i) + CPU_STATE_IDLE]);
            } else {
                inUse = cpuInfo[(CPU_STATE_MAX * i) + CPU_STATE_USER] + cpuInfo[(CPU_STATE_MAX * i) + CPU_STATE_SYSTEM] + cpuInfo[(CPU_STATE_MAX * i) + CPU_STATE_NICE];
                total = inUse + cpuInfo[(CPU_STATE_MAX * i) + CPU_STATE_IDLE];
            }
            tot_inUse += inUse;
            tot_total += total;
        }
        [CPUUsageLock unlock];
        if (prevCpuInfo) {
            size_t prevCpuInfoSize = sizeof(integer_t) * numPrevCpuInfo;
            vm_deallocate(mach_task_self(), (vm_address_t)prevCpuInfo, prevCpuInfoSize);
        }
        
        prevCpuInfo = cpuInfo;
        numPrevCpuInfo = numCpuInfo;
        
        cpuInfo = NULL;
        numCpuInfo = 0U;
        if (tot_total > 0) {
            GSDKLOG(@"CPU Usage: %.2f%%",tot_inUse/tot_total * 100.f);
            return tot_inUse/tot_total * 100.f;
        } else {
            return -1;
        }
    } else {
        GSDKLOG(@"Error!");
        return -1;
    }
}

- (double) getCPU {
    kern_return_t kr;
    thread_array_t         thread_list;
    mach_msg_type_number_t thread_count;
    thread_info_data_t     thinfo;
    mach_msg_type_number_t thread_info_count;
    thread_basic_info_t basic_info_th;
    // get threads in the task
    kr = task_threads(mach_task_self(), &thread_list, &thread_count);
    if (kr != KERN_SUCCESS) {
        GSDKLOG(@"=============CPU:%.2f",-1.0f);
        return -1;
    }
    float tot_cpu = 0;
    int j;
    for (j = 0; j < thread_count; j++)
    {
        thread_info_count = THREAD_INFO_MAX;
        kr = thread_info(thread_list[j], THREAD_BASIC_INFO,
                         (thread_info_t)thinfo, &thread_info_count);
        if (kr != KERN_SUCCESS) {
            GSDKLOG(@"=========CPU:%.2f",-1.0f);
            return -1;
        }
        
        basic_info_th = (thread_basic_info_t)thinfo;
        
        if (!(basic_info_th->flags & TH_FLAGS_IDLE)) {
            tot_cpu = tot_cpu + basic_info_th->cpu_usage / (float)TH_USAGE_SCALE * 100.0;
        }
        
    } // for each thread
    
    kr = vm_deallocate(mach_task_self(), (vm_offset_t)thread_list, thread_count * sizeof(thread_t));
    //    assert(kr == KERN_SUCCESS);
    GSDKLOG(@"=============CPU:%.2f",tot_cpu);
    return tot_cpu;
}

@end
