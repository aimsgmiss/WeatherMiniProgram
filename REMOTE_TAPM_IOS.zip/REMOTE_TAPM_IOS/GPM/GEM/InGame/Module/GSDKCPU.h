//
//  CPU.h
//  GSDK
//
//  Created by 曹爽 on 16/3/18.
//  Copyright © 2016年 fu chunhui. All rights reserved.
//

@interface GSDKCPU : NSObject

+ (id) sharedInstance;

- (void) startCPU;
- (void) getCPUMessage;
- (NSDictionary *) resultCPU;
- (NSDictionary *) resultCPU_noCollect;
- (NSArray *) cpuDots;

@end

