//
//  Memory.h
//  GSDK
//
//  Created by 曹爽 on 16/3/18.
//  Copyright © 2016年 fu chunhui. All rights reserved.
//

@interface GSDKMemory : NSObject

+ (id) sharedInstance;

- (void) startMemory;
- (void) getMemoryMessage;
- (NSDictionary *) resultMemory;
- (NSDictionary *) resultMemory_noCollect;
- (NSArray *) memDots;

@end
