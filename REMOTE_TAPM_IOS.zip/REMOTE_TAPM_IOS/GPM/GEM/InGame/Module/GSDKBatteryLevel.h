//
//  Battery.h
//  GSDK
//
//  Created by 曹爽 on 16/2/17.
//  Copyright © 2016年 fu chunhui. All rights reserved.
//

@interface GSDKBatteryLevel : NSObject

+ (id) sharedInstance;
- (void) startBattery;
- (NSDictionary *) resultBattery;
- (NSDictionary *) resultBattery_noCollect;

@property (readwrite, nonatomic, assign) int has_charged;

@end
