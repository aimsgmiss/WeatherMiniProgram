
//
//  Netflow.h
//  GSDK
//
//  Created by 曹爽 on 16/3/18.
//  Copyright © 2016年 fu chunhui. All rights reserved.
//

@interface GSDKNetflow : NSObject

+ (id) sharedInstance;

- (void) startNetflow;
- (NSString *) resultNetflow;
- (void) startNetCard;
- (NSDictionary *) resultNetCard;
- (NSDictionary *)resultNetCard_noCollect;

@end
