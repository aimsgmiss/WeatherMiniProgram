//
//  Netflow.m
//  GSDK
//
//  Created by 曹爽 on 16/3/18.
//  Copyright © 2016年 fu chunhui. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GSDKNetflow.h"
#include <ifaddrs.h>
#include <sys/socket.h>
#include <net/if.h>
#import "GSDKLogger.h"
#import "GSDKInfoTool.h"

@interface GSDKNetflow()

@property (nonatomic, readwrite, assign) int netflow;
// 发包总数
@property (nonatomic, readwrite, assign) u_int32_t WSndPk;
@property (nonatomic, readwrite, assign) u_int32_t MSndPk;
// 收包总数
@property (nonatomic, readwrite, assign) u_int32_t WRcvPk;
@property (nonatomic, readwrite, assign) u_int32_t MRcvPk;
// 发包丢包
@property (nonatomic, readwrite, assign) u_int32_t WSndDrops;
@property (nonatomic, readwrite, assign) u_int32_t MSndDrops;
// 收包丢包
@property (nonatomic, readwrite, assign) u_int32_t WRcvDrops;
@property (nonatomic, readwrite, assign) u_int32_t MRcvDrops;
// 发包错报
@property (nonatomic, readwrite, assign) u_int32_t WSndErrs;
@property (nonatomic, readwrite, assign) u_int32_t MSndErrs;
// 收包错包
@property (nonatomic, readwrite, assign) u_int32_t WRcvErrs;
@property (nonatomic, readwrite, assign) u_int32_t MRcvErrs;

@end

@implementation GSDKNetflow

static GSDKNetflow * _sharedInstance = nil;
//方法实现
+ (instancetype) sharedInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[GSDKNetflow alloc] init];
    });
    return _sharedInstance;
}

- (void) startNetflow {
    self.netflow = [self getDataTraffic];
}

- (NSString *) resultNetflow {
    int network = ([self getDataTraffic] - _netflow)/1024;
    NSString * resultNetflow = [NSString stringWithFormat:@"%d", network];
    GSDKLOG(@"netflow======%@",resultNetflow);
    return resultNetflow;
}

- (int) getDataTraffic {
    BOOL   success;
    struct ifaddrs * addrs;
    const struct ifaddrs * cursor;
    const struct if_data * networkStatisc;
    int WiFiSent = 0;
    int WiFiReceived = 0;
    int WWANSent = 0;
    int WWANReceived = 0;
    NSString * name= [[NSString alloc] init];
    success = getifaddrs(&addrs) == 0;
    if (success) {
        cursor = addrs;
        while (cursor != NULL) {
            name = [NSString stringWithFormat:@"%s", cursor->ifa_name];
            if (cursor->ifa_addr->sa_family == AF_LINK) {
                if ([name hasPrefix:@"en"]) {
                    networkStatisc = (const struct if_data *) cursor->ifa_data;
                    WiFiSent += networkStatisc->ifi_obytes;
                    WiFiReceived += networkStatisc->ifi_ibytes;
                }
                if ([name hasPrefix:@"pdp_ip"]) {
                    networkStatisc = (const struct if_data *) cursor->ifa_data;
                    WWANSent += networkStatisc->ifi_obytes;
                    WWANReceived += networkStatisc->ifi_ibytes;
                }
            }
            cursor = cursor->ifa_next;
        }
        freeifaddrs(addrs);
    }
    int result = WWANReceived + WWANSent + WiFiReceived + WiFiSent;
    return result;
}

- (void) startNetCard {
    self.WRcvErrs = 0;
    self.WRcvDrops = 0;
    self.WSndErrs = 0;
    self.WRcvPk = 0;
    self.WSndPk = 0;
    self.MRcvErrs = 0;
    self.MRcvDrops = 0;
    self.MSndErrs = 0;
    self.MRcvPk = 0;
    self.MSndPk = 0;
    struct ifaddrs * addrs;
    const struct ifaddrs * cursor;
    if (getifaddrs(&addrs) == 0) {
        cursor = addrs;
        while (cursor != NULL) {
            if (cursor->ifa_addr->sa_family == AF_LINK) {
                // name of interface:
                // en0 is WiFi
                // pdp_ip0 is WWAN
                NSString * name = [NSString stringWithFormat:@"%s", cursor->ifa_name];
                if ([name hasPrefix:@"en"]) {
                    const struct if_data * ifa_data = (struct if_data *)cursor->ifa_data;
                    if (ifa_data != NULL) {
                        self.WRcvErrs += ifa_data->ifi_ierrors;
                        self.WRcvDrops += ifa_data->ifi_iqdrops;
                        self.WSndErrs += ifa_data->ifi_oerrors;
                        self.WRcvPk += ifa_data->ifi_ipackets;
                        self.WSndPk += ifa_data->ifi_opackets;
                    }
                }
                if ([name hasPrefix:@"pdp_ip"]) {
                    const struct if_data * ifa_data = (struct if_data *) cursor->ifa_data;
                    if (ifa_data != NULL) {
                        self.MRcvErrs += ifa_data->ifi_ierrors;
                        self.MRcvDrops += ifa_data->ifi_iqdrops;
                        self.MSndErrs += ifa_data->ifi_oerrors;
                        self.MRcvPk += ifa_data->ifi_ipackets;
                        self.MSndPk += ifa_data->ifi_opackets;
                    }
                }
            }
            cursor = cursor->ifa_next;
        }
        freeifaddrs(addrs);
    }
}

- (NSDictionary *) resultNetCard {
    struct ifaddrs * addrs;
    const struct ifaddrs * cursor;
    u_int32_t WSndPk = 0;         // 发包总数
    u_int32_t WRcvPk = 0;         // 收包总数
    u_int32_t WRcvDrops = 0;      // 收包丢包
    u_int32_t WSndErrs = 0;       // 发包错报
    u_int32_t WRcvErrs = 0;       // 收包错包
    
    u_int32_t MSndPk = 0;         // 发包总数
    u_int32_t MRcvPk = 0;         // 收包总数
    u_int32_t MRcvDrops = 0;      // 收包丢包
    u_int32_t MSndErrs = 0;       // 发包错报
    u_int32_t MRcvErrs = 0;       // 收包错包
    
    if (getifaddrs(&addrs) == 0) {
        cursor = addrs;
        while (cursor != NULL) {
            if (cursor->ifa_addr->sa_family == AF_LINK) {
                // name of interface:
                // en0 is WiFi
                // pdp_ip0 is WWAN
                NSString * name = [NSString stringWithFormat:@"%s", cursor->ifa_name];
                if ([name hasPrefix:@"en"]) {
                    const struct if_data * ifa_data = (struct if_data *)cursor->ifa_data;
                    if (ifa_data != NULL) {
                        WRcvErrs += ifa_data->ifi_ierrors;
                        WRcvDrops += ifa_data->ifi_iqdrops;
                        WSndErrs += ifa_data->ifi_oerrors;
                        WRcvPk += ifa_data->ifi_ipackets;
                        WSndPk += ifa_data->ifi_opackets;
                    }
                }
                if ([name hasPrefix:@"pdp_ip"]) {
                    const struct if_data * ifa_data = (struct if_data *) cursor->ifa_data;
                    if (ifa_data != NULL) {
                        MRcvErrs += ifa_data->ifi_ierrors;
                        MRcvDrops += ifa_data->ifi_iqdrops;
                        MSndErrs += ifa_data->ifi_oerrors;
                        MRcvPk += ifa_data->ifi_ipackets;
                        MSndPk += ifa_data->ifi_opackets;
                    }
                }
            }
            cursor = cursor->ifa_next;
        }
        freeifaddrs(addrs);
    }
    
    NSDictionary * interfaceStats = @{kGSDKWSndPkt: @(WSndPk - _WSndPk),
                                      kGSDKWRcvPkt: @(WRcvPk - _WRcvPk),
                                      kGSDKWSndDrop: @(-1),
                                      kGSDKWRcvDrop: @(WRcvDrops - _WRcvDrops),
                                      kGSDKWSndErr: @(WSndErrs - _WSndErrs),
                                      kGSDKWRcvErr: @(WRcvErrs - _WRcvErrs),
                                      kGSDKMSndPkt: @(MSndPk - _MSndPk),
                                      kGSDKMRcvPkt: @(MRcvPk - _MRcvPk),
                                      kGSDKMSndDrop: @(-1),
                                      kGSDKMRcvDrop: @(MRcvDrops - _MRcvDrops),
                                      kGSDKMSndErr: @(MSndErrs - _MSndErrs),
                                      kGSDKMRcvErr: @(MRcvErrs - _MRcvErrs)};
    return interfaceStats;
}

- (NSDictionary *) resultNetCard_noCollect {
    NSDictionary * interfaceStats = @{kGSDKWSndPkt: @(-1),
                                      kGSDKWRcvPkt: @(-1),
                                      kGSDKWSndDrop: @(-1),
                                      kGSDKWRcvDrop: @(-1),
                                      kGSDKWSndErr: @(-1),
                                      kGSDKWRcvErr: @(-1),
                                      kGSDKMSndPkt: @(-1),
                                      kGSDKMRcvPkt: @(-1),
                                      kGSDKMSndDrop: @(-1),
                                      kGSDKMRcvDrop: @(-1),
                                      kGSDKMSndErr: @(-1),
                                      kGSDKMRcvErr: @(-1)};
    return interfaceStats;
}

@end
