//
//  UsePing.h
//  TechDevDemo
//
//  Created by haoJingjing on 16/1/12.
//  Copyright © 2016年 haoJingjing. All rights reserved.
//

@interface GSDKPing : NSObject

- (void) startPing:(NSString *)routerIP;
- (NSString *) stopPing;
+ (id) sharedInstance;

@end
