//
//  Battery.m
//  GSDK
//
//  Created by 曹爽 on 16/2/17.
//  Copyright © 2016年 fu chunhui. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "GSDKBatteryLevel.h"
#import "GSDKLogger.h"

@interface GSDKBatteryLevel()

@property (readwrite, nonatomic, assign) int start_battery;

@end

@implementation GSDKBatteryLevel

static GSDKBatteryLevel * _sharedInstance = nil;
//方法实现
+ (instancetype) sharedInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[GSDKBatteryLevel alloc] init];
    });
    return _sharedInstance;
}

- (void) startBattery {
    if ([UIDevice currentDevice].batteryMonitoringEnabled == NO) {
        [[UIDevice currentDevice] setBatteryMonitoringEnabled:YES];
    }
    self.start_battery = [UIDevice currentDevice].batteryLevel * 100;
    if (_start_battery < 0) {
        self.start_battery = -1;
    }
    // 初始化电量的状态
    UIDeviceBatteryState status = [UIDevice currentDevice].batteryState;
    if (status == UIDeviceBatteryStateCharging || status == UIDeviceBatteryStateFull) {
        self.has_charged = 1;
    } else {
        self.has_charged = 0;
    }
}

- (NSDictionary *) resultBattery {
    if ([UIDevice currentDevice].batteryMonitoringEnabled == NO) {
        [[UIDevice currentDevice] setBatteryMonitoringEnabled:YES];
    }
    int end_battery = [UIDevice currentDevice].batteryLevel * 100;
    int cost_battery = -1;
    if (end_battery < 0) {
        end_battery = -1;
    } else {
        cost_battery = _start_battery - end_battery;
        if (cost_battery < 0) {
            cost_battery = -1;
        }
    }
    return @{kGSDKStartBattery:@(_start_battery),
             kGSDKEndBattery:@(end_battery),
             kGSDKBatteryUsage:@(cost_battery),
             kGSDKBatteryStatus:@(_has_charged),
             kGSDKBatteryTemperature:@(-1),
             kGSDKMaxBatteryTemperature:@(-1)};
}

- (NSDictionary *) resultBattery_noCollect {
    return @{kGSDKStartBattery:@(-1),
             kGSDKEndBattery:@(-1),
             kGSDKBatteryUsage:@(-1),
             kGSDKBatteryStatus:@(-1),
             kGSDKBatteryTemperature:@(-1),
             kGSDKMaxBatteryTemperature:@(-1)};
}

@end
