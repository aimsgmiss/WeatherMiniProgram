
//
//  UdpTest.h
//  GSDK
//
//  Created by 曹爽 on 16/3/18.
//  Copyright © 2016年 fu chunhui. All rights reserved.
//

@interface GSDKUdpTest : NSObject

+ (id) sharedInstance;

- (void) startUdpTest:(NSString *)sip Sport:(int)sport Pcntx00:(int)pcntx00 Frequency:(double)frequence;
- (NSDictionary *) resultUDPTest;
- (NSDictionary *) resultUDPTest_noCollect;
- (NSArray *) pingDots;
- (void) clearPingDots;
- (void) stopUDPTimer;

- (NSDictionary *) speedReturnDict;
- (int) speedRealReturnInt;

@end
