//
//  Memory.m
//  GSDK
//
//  Created by 曹爽 on 16/3/18.
//  Copyright © 2016年 fu chunhui. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DeviceInfoHelper.h"
#import "GSDKMemory.h"
#import "GSDKLogger.h"
#import <UIKit/UIKit.h>
#import <sys/utsname.h>
#import <sys/sysctl.h>
#import <mach/mach.h>

@interface GSDKMemory()

@property (nonatomic, strong, readwrite) NSMutableArray * usedmem_numList;
@property (nonatomic, strong, readwrite) NSMutableArray * availmem_numList;
@property (nonatomic, strong, readwrite) NSMutableArray * mem_Dots;

@property (nonatomic, assign, readwrite) int total_mem;
@property (nonatomic, assign, readwrite) BOOL isLowLevelDevice;

@end

@implementation GSDKMemory

static GSDKMemory * _sharedInstance = nil;
//方法实现
+ (instancetype) sharedInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[GSDKMemory alloc] init];
    });
    return _sharedInstance;
}

- (instancetype) init {
    if (self = [super init]) {
        _total_mem = [self getTotalMemory];
        _isLowLevelDevice = NO;
        struct utsname systemInfo;
        uname(&systemInfo);
        NSString *platform = [NSString stringWithCString:systemInfo.machine encoding:NSASCIIStringEncoding];
        if ([platform isEqualToString:@"iPhone7,1"] || [platform isEqualToString:@"iPhone7,2"] || [platform isEqualToString:@"iPhone6,1"] || [platform isEqualToString:@"iPhone6,2"]) {
            _isLowLevelDevice = YES;
        }
    }
    return self;
}

- (void) startMemory {
    if (_usedmem_numList == nil) {
        self.usedmem_numList = [NSMutableArray array];
    } else {
        [self.usedmem_numList removeAllObjects];
    }
    if (_availmem_numList == nil) {
        self.availmem_numList = [NSMutableArray array];
    } else {
        [self.availmem_numList removeAllObjects];
    }
    if (_mem_Dots == nil) {
        self.mem_Dots = [NSMutableArray array];
    } else {
        [self.mem_Dots removeAllObjects];
    }
}

- (void)dealloc {
    if (_usedmem_numList != nil) {
        [_usedmem_numList removeAllObjects];
        _usedmem_numList = nil;
    }
    if (_availmem_numList != nil) {
        [_availmem_numList removeAllObjects];
        _availmem_numList = nil;
    }
    if (_mem_Dots != nil) {
        [_mem_Dots removeAllObjects];
        _mem_Dots = nil;
    }
}

- (NSDictionary *) resultMemory {
    NSString * mem_2avg = @"-1";
    NSString * availmem_2avg = @"-1";
    NSString * mem_2max = @"-1";
    NSString * mem_2start = @"-1";
    NSString * mem_2end = @"-1";
    NSString * mem_total = @"-1";
    @try {
        NSUInteger count = [_usedmem_numList count];
        if ((_usedmem_numList != nil) && count > 0) {
            mem_2avg = [NSString stringWithFormat:@"%d", [[_usedmem_numList valueForKeyPath:@"@avg.doubleValue"] intValue]];
            mem_2max = [NSString stringWithFormat:@"%d", [[_usedmem_numList valueForKeyPath:@"@max.doubleValue"] intValue]];
            mem_2start = [NSString stringWithFormat:@"%d", [_usedmem_numList[0] intValue]];
            mem_2end = [NSString stringWithFormat:@"%d", [_usedmem_numList[count - 1] intValue]];
        }
        if ((_availmem_numList != nil) && [_availmem_numList count] > 0) {
            availmem_2avg = [NSString stringWithFormat:@"%d", [[_availmem_numList valueForKeyPath:@"@avg.doubleValue"] intValue]];
        }
        mem_total = [NSString stringWithFormat:@"%d", _total_mem];
        GSDKLOG(@"mem==%@ availmem==%@ totalmem==%@", mem_2avg, availmem_2avg, mem_total);
    } @catch (NSException *exception) {
        GSDKLOG(@"resultMemory Exception:%@", exception);
    } @finally {
        if (_usedmem_numList != nil) {
            [self.usedmem_numList removeAllObjects];
            [self setUsedmem_numList:nil];
        }
        if (_availmem_numList != nil) {
            [self.availmem_numList removeAllObjects];
            [self setAvailmem_numList:nil];
        }
        return @{kGSDKMem:mem_2avg,
                 kGSDKAvailMem:availmem_2avg,
                 kGSDKStartMem:mem_2start,
                 kGSDKEndMem:mem_2end,
                 kGSDKMaxMem:mem_2max,
                 kGSDKTotalMem:mem_total};
    }
}

- (NSDictionary *) resultMemory_noCollect {
    return @{kGSDKMem:@"-1",
             kGSDKAvailMem:@"-1",
             kGSDKStartMem:@"-1",
             kGSDKEndMem:@"-1",
             kGSDKMaxMem:@"-1",
             kGSDKTotalMem:@"-1"};
}

- (NSArray *) memDots {
    if (_mem_Dots) {
        NSArray * memDots = [_mem_Dots copy];
        [_mem_Dots removeAllObjects];
        _mem_Dots = nil;
        return memDots;
    }
    return nil;
}

- (void) getMemoryMessage {
    double usedMemory = [self getFootPrint];
    double availableMemory = [self getSystemAvailableMemory];
    if (usedMemory >= 0) {
        [self.usedmem_numList addObject:@(usedMemory)];
        [self.mem_Dots addObject:[NSString stringWithFormat:@"%.0f", usedMemory]];
    }
    if (availableMemory >= 0) {
        [self.availmem_numList addObject:@(availableMemory)];
    }
}

- (double) getSystemAvailableMemory {
    // 获取当前设备可用内存(单位：MB）
    vm_statistics_data_t vmStats;
    mach_msg_type_number_t infoCount = HOST_VM_INFO_COUNT;
    kern_return_t kernReturn = host_statistics(mach_host_self(), HOST_VM_INFO, (host_info_t)&vmStats, &infoCount);
    if (kernReturn != KERN_SUCCESS) {
        GSDKLOG(@"AvailableMemory=====%.2f",-1.0f);
        return -1;
    }
    
    double availMem = (vm_page_size * vmStats.free_count + vm_page_size * vmStats.inactive_count) / 1024.0 / 1024.0;
    GSDKLOG(@"AvailableMemory=====%.2f",availMem);
    return availMem;
}

- (double) getFootPrint {
    task_vm_info_data_t vmInfo;
    mach_msg_type_number_t count = TASK_VM_INFO_COUNT;
    kern_return_t result = task_info(mach_task_self(), TASK_VM_INFO, (task_info_t) &vmInfo, &count);
    if (result != KERN_SUCCESS) {
        GSDKLOG(@"FootPrint=====%.2f",-1.0f);
        return -1;
    }
    double footPrint = -1;
    if (_isLowLevelDevice || [UIDevice.currentDevice.systemVersion doubleValue] >= 12.0) {
        footPrint = vmInfo.phys_footprint / 1024.0 / 1024.0;
    }
    if ([UIDevice.currentDevice.systemVersion doubleValue] < 12.0) {
        footPrint = (vmInfo.internal + vmInfo.compressed - vmInfo.purgeable_volatile_pmap) / 1024.0 / 1024.0;
    }
    GSDKLOG(@"FootPrint=====%i",int((vmInfo.phys_footprint) / 1024.0 / 1024.0));
    return footPrint;
}

- (int) getTotalMemory {
    // NOTE(三合一): 优先使用TDM静态数据采集
    return DeviceInfo::DeviceInfoHelper::getTotalRAMCount();
}

@end
