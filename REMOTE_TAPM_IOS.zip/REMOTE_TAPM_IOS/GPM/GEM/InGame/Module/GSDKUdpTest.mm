//
//  UdpTest.m
//  GSDK
//
//  Created by 曹爽 on 16/3/18.
//  Copyright © 2016年 fu chunhui. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GSDKUdpTest.h"
#import "GSDKInfoTool.h"
#import "GSDKLogger.h"
#include <arpa/inet.h>

@interface GSDKUdpTest()

@property (nonatomic, readwrite, assign) UInt32 mTag;
@property (nonatomic, readwrite, assign) int mLost;
@property (nonatomic, readwrite, assign) int mPcntx00_num;

@property (nonatomic, strong, readwrite) NSMutableArray * mUdpDotsList;
@property (nonatomic, assign, readwrite) int mSocketfd;
@property (nonatomic, strong) dispatch_source_t timerSource;

// 统计变量
@property (nonatomic, assign, readwrite) int mTotalCount;
@property (nonatomic, assign, readwrite) int mTotalConsume;
@property (nonatomic, assign, readwrite) int mMax;
@property (nonatomic, assign, readwrite) int mMin;
@property (nonatomic, assign, readwrite) int mCurrent;
@property (nonatomic, assign, readwrite) int mPheavy;

@end

@implementation GSDKUdpTest

static GSDKUdpTest * _sharedInstance = nil;
//方法实现
+ (instancetype) sharedInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[GSDKUdpTest alloc] init];
    });
    return _sharedInstance;
}

- (int) getSpeedSock {
    // 测试直连和转发网络时延均值
    if (_mSocketfd == 0) {
        self.mSocketfd = socket(PF_INET, SOCK_DGRAM, 0);
        struct timeval timeout = {0, 100 * 1000};
        int retreceive = setsockopt(self.mSocketfd, SOL_SOCKET, SO_RCVTIMEO,(const char *) &timeout, sizeof(timeout));
        int retsend = setsockopt(self.mSocketfd, SOL_SOCKET, SO_SNDTIMEO,(const char *) &timeout, sizeof(timeout));
        int nosigpipe = 1;
        int status = setsockopt(self.mSocketfd, SOL_SOCKET, SO_NOSIGPIPE, &nosigpipe, sizeof(nosigpipe));
        if (retreceive != 0 || retsend != 0 || status != 0) {
            GSDKLOG(@"Error start socket, retreceive is %d, retsend is %d, status is %d", retreceive, retsend, status);
            if (self.mSocketfd > 0) {
                close(self.mSocketfd);
            }
            self.mSocketfd = -1;
        }
    }
    return _mSocketfd;
}

- (int) getV6SpeedSock {
    // 测试直连和转发网络时延均值
    if (_mSocketfd == 0) {
        self.mSocketfd = socket(PF_INET6, SOCK_DGRAM, 0);
        struct timeval timeout = {0, 100 * 1000};
        int retreceive = setsockopt(self.mSocketfd, SOL_SOCKET, SO_RCVTIMEO,(const char *) &timeout, sizeof(timeout));
        int retsend = setsockopt(self.mSocketfd, SOL_SOCKET, SO_SNDTIMEO,(const char *) &timeout, sizeof(timeout));
        int nosigpipe = 1;
        int status = setsockopt(self.mSocketfd, SOL_SOCKET, SO_NOSIGPIPE, &nosigpipe, sizeof(nosigpipe));
        if (retreceive != 0 || retsend != 0 || status != 0) {
            GSDKLOG(@"Error start socket, retreceive is %d, retsend is %d, status is %d", retreceive, retsend, status);
            if (self.mSocketfd > 0) {
                close(self.mSocketfd);
            }
            self.mSocketfd = -1;
        }
    }
    return _mSocketfd;
}

- (void)stopSpeedTest {
    if (_mSocketfd > 0) {
        close(_mSocketfd);
    }
    [self setMSocketfd:0];
}

- (void) stopUDPTimer {
    if (self.timerSource) {
        dispatch_source_cancel(self.timerSource);
        [self setTimerSource:nil];
    }
    [self stopSpeedTest];
}

#pragma mark udp
- (void) startUdpTest:(NSString *)sip Sport:(int)sport Pcntx00:(int)pcntx00 Frequency:(double)frequence {
    [self stopUDPTimer];
    if (_mUdpDotsList == nil) {
        self.mUdpDotsList = [NSMutableArray array];
    } else {
        [self.mUdpDotsList removeAllObjects];
    }
    dispatch_async([GSDKInfoTool gsdk_udpArray_queue], ^{
        self.mCurrent = -1;
        self.mLost = 0;
        self.mTotalCount = 0;
        self.mTotalConsume = 0;
        self.mPcntx00_num = 0;
        self.mMax = 0;
        self.mMin = 0;
        self.mPheavy = 0;
    });
    self.mTag = 0;
    if (!sip || [sip length] == 0 || sport == 0) {
        return;
    }
    NSString * sipv4 = nil;
    BOOL isIPV6Env = [GSDKInfoTool addressesForHostname:sip ConvertString:&sipv4];
    if (!sipv4) {
        return;
    }
    struct sockaddr_in6 servaddr6 = {0};
    struct sockaddr_in servaddr = {0};
    if (isIPV6Env) {
        // 构建目标地址
        memset(&servaddr6, 0, sizeof(struct sockaddr_in6));
        servaddr6.sin6_family = AF_INET6;
        servaddr6.sin6_port = htons(sport);
        servaddr6.sin6_addr = [GSDKInfoTool convertIP2V6:sipv4];
    } else {
        // 构建目标地址
        memset(&servaddr, 0, sizeof(struct sockaddr_in));
        servaddr.sin_family = AF_INET;
        servaddr.sin_port = htons(sport);
        servaddr.sin_addr.s_addr = [GSDKInfoTool convertIPAddressToBinary:sipv4];
    }
    GSDKLOG(@"UDP测速域名: %@, IP:%@, 测速port: %d",sip, sipv4, sport);
    __weak __typeof(self) weakSelf = self;
    self.timerSource = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, [GSDKInfoTool gsdk_queue]);
    dispatch_source_set_timer(self.timerSource, dispatch_walltime(NULL, 0), frequence * NSEC_PER_MSEC, 1ull * NSEC_PER_SEC);
    dispatch_source_set_event_handler(self.timerSource, ^{
        __strong __typeof(self) strongSelf = weakSelf;
        if (strongSelf) {
            int consumeTime = 0;
            NSData * data1 = [strongSelf getSendData];
            if (isIPV6Env) {
                [strongSelf sendV6Data:servaddr6 Data:data1];
                NSData * data2 = [strongSelf getSendData];
                consumeTime = [strongSelf sendV6Data:servaddr6 Data:data2];
            } else {
                [strongSelf sendData:servaddr Data:data1];
                NSData * data2 = [strongSelf getSendData];
                consumeTime = [strongSelf sendData:servaddr Data:data2];
            }
            if (consumeTime > 1000) {
                consumeTime = 1000;
            }
            dispatch_async([GSDKInfoTool gsdk_udpArray_queue], ^{
                if (consumeTime > pcntx00) {
                    strongSelf.mPcntx00_num ++;
                }
                if (consumeTime == 1000) {
                    strongSelf.mLost ++;
                }
                if (_mTotalCount > 0) {
                    if (consumeTime - _mCurrent >= 100) {
                        strongSelf.mPheavy ++;
                    }
                } else {
                    strongSelf.mMax = consumeTime;
                    strongSelf.mMin = consumeTime;
                }
                if (consumeTime > _mMax) {
                    strongSelf.mMax = consumeTime;
                }
                if (_mMin > consumeTime) {
                    strongSelf.mMin = consumeTime;
                }
                strongSelf.mTotalCount ++;
                strongSelf.mTotalConsume += consumeTime;
                strongSelf.mCurrent = consumeTime;
            });
            [_mUdpDotsList addObject:@(consumeTime)];
        }
    });
    dispatch_resume(self.timerSource);
}

- (NSData *) getSendData {
    self.mTag ++;
    struct udpPacket udpsend;
    udpsend.seqno = _mTag;
    GSDKLOG(@"send===%d===",(unsigned int)udpsend.seqno);
    udpsend.svalue = 'A';
    HTONL(udpsend.seqno);
    NSData * data = [NSData dataWithBytes:&udpsend length:sizeof(udpsend)];
    return data;
}

- (int) sendV6Data:(struct sockaddr_in6) servaddr Data:(NSData *)data {
    int sockfd = [self getV6SpeedSock];
    if (sockfd <= 0) {
        [self stopSpeedTest];
        return 1000;
    }
    const void * sndByte = [data bytes];
    size_t sndLen = (size_t)[data length];
    NSTimeInterval startTime = [[NSDate date] timeIntervalSince1970];
    ssize_t sendStatus = sendto(sockfd, sndByte, sndLen, 0, (struct sockaddr *)&servaddr, sizeof(struct sockaddr_in6));
    // 如果发送失败，改变fd重试一次
    int countForReSendto = 0;
    if (sendStatus < 0) {
        int currentErrno = errno;
        if (countForReSendto < 1) {
            // 锁屏状态会造成管道破坏，因此重新创建fd
            if (currentErrno == EPIPE) {
                [self stopSpeedTest];
                // 再重新生成fd
                sockfd = [self getV6SpeedSock];
                if (sockfd <= 0) {
                    [self stopSpeedTest];
                    return 1000;
                }
            }
            sendStatus = sendto(sockfd, sndByte, sndLen, 0, (struct sockaddr *)&servaddr, sizeof(struct sockaddr_in6));
        }
        countForReSendto++;
    }
    if (sendStatus < 0) {
        return 1000;
    }
    // 初始化recvbuff
    struct udpPacket recvBuff;
    memset(&recvBuff, 0, sizeof(struct udpPacket));
    size_t bufflen = sizeof(struct udpPacket);
    int echo_time = 0;
    while (echo_time < 1000) {
        struct sockaddr_in6 sockaddr = {0};
        socklen_t sockaddrlen = sizeof(sockaddr);
        ssize_t rsize = recvfrom(sockfd, &recvBuff, bufflen, 0, (struct sockaddr *)&sockaddr, &sockaddrlen);
        NSTimeInterval currentTime = [[NSDate date] timeIntervalSince1970];
        // 如果收到包的长度跟预定的回包不一致，暂时设定为MAX_SEND_RECV_TIME_OUT_USEC时延
        if (rsize == bufflen) {
            NTOHL(recvBuff.seqno);
            if (recvBuff.svalue == 'B' && recvBuff.seqno == _mTag) {
                echo_time = (currentTime - startTime) * 1000;
                GSDKLOG(@"#%d received, echotime:%d",(unsigned int)recvBuff.seqno, echo_time);
                break;
            } else {
                echo_time = (currentTime - startTime) * 1000;
                GSDKLOG(@"recv len failed, echotime:%d", echo_time);
                continue;
            }
        } else {
            echo_time = (currentTime - startTime) * 1000;
            continue;
        }
    }
    return echo_time;
}

- (int) sendData:(struct sockaddr_in) servaddr Data:(NSData *)data {
    int sockfd = [self getSpeedSock];
    if (sockfd <= 0) {
        [self stopSpeedTest];
        return 1000;
    }
    const void * sndByte = [data bytes];
    size_t sndLen = (size_t)[data length];
    NSTimeInterval startTime = [[NSDate date] timeIntervalSince1970];
    ssize_t sendStatus = sendto(sockfd, sndByte, sndLen, 0, (struct sockaddr *)&servaddr, sizeof(struct sockaddr));
    // 如果发送失败，改变fd重试一次
    int countForReSendto = 0;
    if (sendStatus < 0) {
        int currentErrno = errno;
        if(countForReSendto < 1) {
            // 锁屏状态会造成管道破坏，因此重新创建fd
            if(currentErrno == EPIPE) {
                [self stopSpeedTest];
                // 再重新生成fd
                sockfd = [self getSpeedSock];
                if (sockfd <= 0) {
                    [self stopSpeedTest];
                    return 1000;
                }
            }
            sendStatus = sendto(sockfd, sndByte, sndLen, 0, (struct sockaddr *)&servaddr, sizeof(struct sockaddr));
        }
        countForReSendto++;
    }
    if (sendStatus < 0) {
        return 1000;
    }
    // 初始化recvbuff
    struct udpPacket recvBuff;
    memset(&recvBuff, 0, sizeof(struct udpPacket));
    size_t bufflen = sizeof(struct udpPacket);
    int echo_time = 0;
    while (echo_time < 1000) {
        struct sockaddr_in sockaddr = {0};
        socklen_t sockaddrlen = sizeof(sockaddr);
        ssize_t rsize = recvfrom(sockfd, &recvBuff, bufflen, 0, (struct sockaddr *)&sockaddr, &sockaddrlen);
        NSTimeInterval currentTime = [[NSDate date] timeIntervalSince1970];
        // 如果收到包的长度跟预定的回包不一致，暂时设定为MAX_SEND_RECV_TIME_OUT_USEC时延
        if (rsize == bufflen) {
            NTOHL(recvBuff.seqno);
            if (recvBuff.svalue == 'B' && recvBuff.seqno == _mTag) {
                echo_time = (currentTime - startTime) * 1000;
                GSDKLOG(@"#%d received, echotime:%d",(unsigned int)recvBuff.seqno, echo_time);
                break;
            } else {
                echo_time = (currentTime - startTime) * 1000;
                GSDKLOG(@"recv len failed, echotime:%d", echo_time);
                continue;
            }
        } else {
            echo_time = (currentTime - startTime) * 1000;
            continue;
        }
    }
    return echo_time;
}

- (void) dealloc {
    if (_mUdpDotsList != nil) {
        [_mUdpDotsList removeAllObjects];
        _mUdpDotsList = nil;
    }
}

- (NSDictionary *) resultUDPTest {
    [self stopUDPTimer];
    __block int pmax = -1;
    __block int pmin = -1;
    __block int pavg = -1;
    __block int pheavy = -1;
    __block int plost = -1;
    __block int ptotal = -1;
    __block int pcntx00 = -1;
    dispatch_sync([GSDKInfoTool gsdk_udpArray_queue], ^{
        if (_mTotalCount > 0) {
            pmax = _mMax;
            pmin = _mMin;
            pavg = _mTotalConsume / _mTotalCount;
            pheavy = _mPheavy;
            plost = _mLost;
            ptotal = _mTotalCount;
            pcntx00 = _mPcntx00_num;
        }
        self.mCurrent = -1;
        self.mLost = 0;
        self.mTotalCount = 0;
        self.mTotalConsume = 0;
        self.mPcntx00_num = 0;
        self.mMax = 0;
        self.mMin = 0;
        self.mPheavy = 0;
    });
    NSDictionary * resultUDPTest = @{kGSDKMaxPing:@(pmax),
                                     kGSDKMinPing:@(pmin),
                                     kGSDKAvgPing:@(pavg),
                                     kGSDKHeavyPing:@(pheavy),
                                     kGSDKLostPing:@(plost),
                                     kGSDKTotalPing:@(ptotal),
                                     kGSDKPcntx00:@(pcntx00)};
    return resultUDPTest;
}

- (NSDictionary *) speedReturnDict {
    __block int cping = -1;
    __block int pavg = -1;
    __block int clostpkg = -1;
    __block int lostpkgpct = -1;
    dispatch_sync([GSDKInfoTool gsdk_udpArray_queue], ^{
        if (_mTotalCount > 0) {
            cping = _mCurrent;
            pavg = _mTotalConsume / _mTotalCount;
            clostpkg = 0;
            lostpkgpct = 0;
            if (_mLost > 0) {
                clostpkg = 1;
                lostpkgpct = _mLost * 100/ _mTotalCount;
            }
        }
    });
    NSDictionary * speedReturnDict = @{@"cping": [NSString stringWithFormat:@"%d", cping],
                                       @"clostpkg": [NSString stringWithFormat:@"%d", clostpkg],
                                       @"avg_ping": [NSString stringWithFormat:@"%d", pavg],
                                       @"lostpkgpct": [NSString stringWithFormat:@"%d", lostpkgpct]};
    return speedReturnDict;
}

- (int) speedRealReturnInt {
    __block int cping = -1;
    dispatch_sync([GSDKInfoTool gsdk_udpArray_queue], ^{
        if (_mTotalCount > 0) {
            cping = _mCurrent;
        }
    });
    return cping;
}

- (NSDictionary *) resultUDPTest_noCollect {
    NSDictionary* resultUDPTest_noCollect = @{kGSDKMaxPing:@"-1",
                                              kGSDKMinPing:@"-1",
                                              kGSDKAvgPing:@"-1",
                                              kGSDKHeavyPing:@"-1",
                                              kGSDKLostPing:@"-1",
                                              kGSDKTotalPing:@"-1",
                                              kGSDKPcntx00:@"-1"};
    return resultUDPTest_noCollect;
}

- (NSArray *) pingDots {
    if (_mUdpDotsList) {
        NSArray * pingDots = [_mUdpDotsList copy];
        return pingDots;
    }
    return nil;
}

- (void) clearPingDots {
    if (_mUdpDotsList) {
        [_mUdpDotsList removeAllObjects];
        _mUdpDotsList = nil;
    }
}

@end
