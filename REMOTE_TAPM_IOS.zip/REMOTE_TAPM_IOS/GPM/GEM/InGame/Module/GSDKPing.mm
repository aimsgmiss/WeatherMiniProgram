//
//  GSDKPing.m
//  TechDevDemo
//
//  Created by haoJingjing on 16/1/12.
//  Copyright © 2016年 haoJingjing. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GSDKPing.h"
#include "GSDKSimplePing.h"
#import "GSDKLogger.h"

// 游戏内，ping的次数
static const int PING_COUNT = 3;

@interface GSDKPing() <GSDKSimplePingDelegate>

@property (nonatomic, strong, readwrite) NSMutableArray * ping_numList;
@property (nonatomic, readwrite, strong) NSMutableDictionary * time;
@property (nonatomic, strong, readwrite) NSString * router;
@property (strong, nonatomic) GSDKSimplePing * pinger;

@end

@implementation GSDKPing

static GSDKPing * _sharedInstance = nil;
//方法实现
+ (instancetype) sharedInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[GSDKPing alloc] init];
    });
    return _sharedInstance;
}

- (void) dealloc {
    GSDKLOG(@"GSDKPing dealloc.");
    if (_pinger) {
        [_pinger stop];
        _pinger = nil;
    }
    if (_ping_numList != nil){
        [_ping_numList removeAllObjects];
        _ping_numList = nil;
    }
    if (_time != nil){
        [_time removeAllObjects];
        _time = nil;
    }
    if (_router != nil) {
        _router = nil;
    }
}

// The Objective-C 'main' for this program.  It creates a SimplePing object
// and runs the runloop sending pings and printing the results.
- (void) startPing:(NSString *)routerIP {
    @synchronized (self.ping_numList) {
        if (_ping_numList){
            [self.ping_numList removeAllObjects];
        } else {
            self.ping_numList = [[NSMutableArray alloc] init];
        }
    }
    @synchronized (self.time) {
        if(_time == nil){
            self.time = [NSMutableDictionary dictionaryWithCapacity:1];
        } else{
            [self.time removeAllObjects];
        }
    }
    self.router = routerIP;
    
    [self performSelector:@selector(ping) onThread:[[self class] pingThread] withObject:nil waitUntilDone:YES];
}

- (void) ping {
    if (_pinger) {
        [_pinger stop];
        [self setPinger:nil];
    }
    if (!_router) {
        GSDKLOG(@"The router Ip is nil. Do not Start Ping!");
        return;
    } else {
        self.pinger = [[GSDKSimplePing alloc] initWithHostName:self.router];
        if (_pinger != nil) {
            self.pinger.delegate = self;
            //IPV6时，不会crash，但是也请求不通，每次回包类型都是135，邻居请求
            _pinger.addressStyle = GSDKSimplePingAddressStyleAny;
            [_pinger start];
        }
    }
}

+ (NSThread *)pingThread {
    static NSThread *_pingThread = nil;
    static dispatch_once_t oncePredicate;
    dispatch_once(&oncePredicate, ^{
        _pingThread = [[NSThread alloc] initWithTarget:self selector:@selector(pingThreadEntryPoint:) object:nil];
        [_pingThread start];
    });
    
    return _pingThread;
}

+ (void) pingThreadEntryPoint:(id)__unused object {
    @autoreleasepool {
        [[NSThread currentThread] setName:@"PingThread"];
        NSRunLoop *runLoop = [NSRunLoop currentRunLoop];
        [runLoop addPort:[NSMachPort port] forMode:NSDefaultRunLoopMode];
        [runLoop run];
    }
}

- (void) stopPingSocket {
    if(_pinger){
        [_pinger stop];
        [self setPinger:nil];
    }
}

//结束ping
- (NSString *) stopPing {
    //stop ping
    NSString* gate_delay = [[NSString alloc] init];
    @try {
        [self performSelector:@selector(stopPingSocket) onThread:[[self class] pingThread] withObject:nil waitUntilDone:YES];
        @synchronized (self.ping_numList) {
            if ((self.ping_numList != nil) && ([self.ping_numList count] > 0)) {
                gate_delay = [NSString stringWithFormat:@"%d", [[self.ping_numList valueForKeyPath:@"@avg.doubleValue"] intValue]];
            } else {
                gate_delay = @"-1";
            }
        }
    } @catch (NSException *exception) {
        GSDKLOG(@"stopPing Exception:%@", exception);
        gate_delay = @"-1";
    } @finally {
        @synchronized (self.ping_numList) {
            if (_ping_numList) {
                [self.ping_numList removeAllObjects];
                [self setPing_numList:nil];
            }
        }
        @synchronized (self.time) {
            if (_time) {
                [self.time removeAllObjects];
                [self setTime:nil];
            }
        }
        return gate_delay;
    }
}

- (void) sendPing
// Called to send a ping, both directly (as soon as the SimplePing object starts up)
// and via a timer (to continue sending pings periodically).
{
    if (_pinger != nil) {
        [_pinger sendPingWithData:nil];
    }
}

#pragma GSDKSimplePing Delegate

/*! A SimplePing delegate callback, called once the object has started up.
 *  \details This is called shortly after you start the object to tell you that the
 *      object has successfully started.  On receiving this callback, you can call
 *      `-sendPingWithData:` to send pings.
 *
 *      If the object didn't start, `-simplePing:didFailWithError:` is called instead.
 *  \param pinger The object issuing the callback.
 *  \param address The address that's being pinged; at the time this delegate callback
 *      is made, this will have the same value as the `hostAddress` property.
 */
- (void) simplePing:(GSDKSimplePing *)pinger didStartWithAddress:(nonnull NSData *)address
{
    GSDKLOG(@"didStartWithAddress");
    if (pinger == _pinger) {
        for (int i = 0; i < PING_COUNT; i++) {
            [self sendPing];
        }
    }
}

/*! A SimplePing delegate callback, called if the object fails to start up.
 *  \details This is called shortly after you start the object to tell you that the
 *      object has failed to start.  The most likely cause of failure is a problem
 *      resolving `hostName`.
 *
 *      By the time this callback is called, the object has stopped (that is, you don't
 *      need to call `-stop` yourself).
 *  \param pinger The object issuing the callback.
 *  \param error Describes the failure.
 */
- (void) simplePing:(GSDKSimplePing *)pinger didFailWithError:(nonnull NSError *)error
{
    GSDKLOG(@"didFailWithError");
}

/*! A SimplePing delegate callback, called when the object has successfully sent a ping packet.
 *  \details Each call to `-sendPingWithData:` will result in either a
 *      `-simplePing:didSendPacket:sequenceNumber:` delegate callback or a
 *      `-simplePing:didFailToSendPacket:sequenceNumber:error:` delegate callback (unless you
 *      stop the object before you get the callback).  These callbacks are currently delivered
 *      synchronously from within `-sendPingWithData:`, but this synchronous behaviour is not
 *      considered API.
 *  \param pinger The object issuing the callback.
 *  \param packet The packet that was sent; this includes the ICMP header (`ICMPHeader`) and the
 *      data you passed to `-sendPingWithData:` but does not include any IP-level headers.
 *  \param sequenceNumber The ICMP sequence number of that packet.
 */
- (void) simplePing:(GSDKSimplePing *)pinger didSendPacket:(nonnull NSData *)packet sequenceNumber:(uint16_t)sequenceNumber
{
    //此处记录发送次序
    if (pinger == _pinger) {
        GSDKLOG(@"#%u sent", sequenceNumber);
        NSString* pre_Time = [NSString stringWithFormat:@"%f", [[NSDate date] timeIntervalSince1970]];
        @synchronized (self.time) {
            [self.time setObject:pre_Time forKey:[NSString stringWithFormat:@"%u", sequenceNumber]];
        }
    }
}

/*! A SimplePing delegate callback, called when the object fails to send a ping packet.
 *  \details Each call to `-sendPingWithData:` will result in either a
 *      `-simplePing:didSendPacket:sequenceNumber:` delegate callback or a
 *      `-simplePing:didFailToSendPacket:sequenceNumber:error:` delegate callback (unless you
 *      stop the object before you get the callback).  These callbacks are currently delivered
 *      synchronously from within `-sendPingWithData:`, but this synchronous behaviour is not
 *      considered API.
 *  \param pinger The object issuing the callback.
 *  \param packet The packet that was not sent; see `-simplePing:didSendPacket:sequenceNumber:`
 *      for details.
 *  \param sequenceNumber The ICMP sequence number of that packet.
 *  \param error Describes the failure.
 */
- (void) simplePing:(GSDKSimplePing *)pinger didFailToSendPacket:(nonnull NSData *)packet sequenceNumber:(uint16_t)sequenceNumber error:(nonnull NSError *)error
// A SimplePing delegate callback method.  We just log the failure.
{
    if (pinger == _pinger) {
        GSDKLOG(@"#%u send failed: %@", sequenceNumber, error);
    }
}

/*! A SimplePing delegate callback, called when the object receives a ping response.
 *  \details If the object receives an ping response that matches a ping request that it
 *      sent, it informs the delegate via this callback.  Matching is primarily done based on
 *      the ICMP identifier, although other criteria are used as well.
 *  \param pinger The object issuing the callback.
 *  \param packet The packet received; this includes the ICMP header (`ICMPHeader`) and any data that
 *      follows that in the ICMP message but does not include any IP-level headers.
 *  \param sequenceNumber The ICMP sequence number of that packet.
 */
- (void) simplePing:(GSDKSimplePing *)pinger didReceivePingResponsePacket:(nonnull NSData *)packet sequenceNumber:(uint16_t)sequenceNumber
// A SimplePing delegate callback method.  We just log the reception of a ping response.
{
    //时间单位是毫秒
    if (pinger == _pinger) {
        NSTimeInterval currentTime = [[NSDate date] timeIntervalSince1970];
        int sendTime = 3000;
        @synchronized (self.time) {
            NSString* num = [_time objectForKey:[NSString stringWithFormat:@"%u",sequenceNumber]];
            sendTime = (currentTime - [num doubleValue]) * 1000;
        }
        GSDKLOG(@"#%u received, time:%d", sequenceNumber, sendTime);
        @synchronized (self.ping_numList) {
            [self.ping_numList addObject:@(sendTime)];
        }
        @synchronized (self.time) {
            [self.time removeObjectForKey:[NSString stringWithFormat:@"%u",sequenceNumber]];
        }
    }
}

/*! A SimplePing delegate callback, called when the object receives an unmatched ICMP message.
 *  \details If the object receives an ICMP message that does not match a ping request that it
 *      sent, it informs the delegate via this callback.  The nature of ICMP handling in a
 *      BSD kernel makes this a common event because, when an ICMP message arrives, it is
 *      delivered to all ICMP sockets.
 *
 *      IMPORTANT: This callback is especially common when using IPv6 because IPv6 uses ICMP
 *      for important network management functions.  For example, IPv6 routers periodically
 *      send out Router Advertisement (RA) packets via Neighbor Discovery Protocol (NDP), which
 *      is implemented on top of ICMP.
 *
 *      For more on matching, see the discussion associated with
 *      `-simplePing:didReceivePingResponsePacket:sequenceNumber:`.
 *  \param pinger The object issuing the callback.
 *  \param packet The packet received; this includes the ICMP header (`ICMPHeader`) and any data that
 *      follows that in the ICMP message but does not include any IP-level headers.
 */
- (void) simplePing:(GSDKSimplePing *)pinger didReceiveUnexpectedPacket:(nonnull NSData *)packet
// A SimplePing delegate callback method.  We just log the receive.
{
    if (pinger == _pinger) {
        GSDKLOG(@"Receive Unexpected Packet");
    }
}

@end
