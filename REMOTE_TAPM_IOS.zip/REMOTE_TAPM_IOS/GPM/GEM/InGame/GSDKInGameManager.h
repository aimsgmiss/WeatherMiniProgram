//
//  GSDKApi.h
//  GSDK
//
//  Created by 曹爽 on 16/3/31.
//  Copyright © 2016年 fu chunhui. All rights reserved.
//
#import "GPMObserver.h"

@interface GSDKInGameManager : NSObject

+ (id) sharedInstance;
- (void) GSDKStart:(NSString *)zoneid SceneID:(NSString *)sceneid RoomIP:(NSString *)roomip Observer:(GPMObserver *)observer;
//- (void) GSDKStart:(NSString *)zoneid SceneID:(NSString *)sceneid RoomIP:(NSString *)roomip FpsMode:(NSString *)fps_mode QualityLev:(NSString *)quality_Lev OptLev:(NSString *)opt_lev;
- (void) GSDKSaveFps:(float)favg FMax:(int)fmax FMin:(int)fmin Ftotal:(int)ftotal Fheavy:(int)fheavy Flight:(int)flight Fcntx0:(int)fcntx0 Flfps1:(int)flfps1 Flfps2:(int)flfps2 Flfps3:(int)flfps3 Fpsdots:(NSString *)fpsdots;
- (void) GSDKEnd:(GPMObserver *)observer;
//- (NSDictionary *) GSDKSpeedReturn;
//- (int) GSDKSpeedRealReturn;

@end
