//
//  GSDKEvent.m
//  GSDK
//
//  Created by fu chunhui on 16/7/28.
//  Copyright © 2016年 fu chunhui. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "GSDKLoginEvent.h"
#import "GSDKInitManager.h"
#import "GSDKInfoTool.h"
#import "GSDKReporter.h"
#import "GSDKPing.h"

//登陆事件上报事件名
static NSString * const LoginReportName = @"gsdk_report_login";

//登陆事件上报Key值
static NSString * const kLoginDevices = @"devices";
static NSString * const kLoginGateDelay = @"gate_delay";
static NSString * const kLoginVersion = @"version";
static NSString * const kLoginTotalStorage = @"total_storage";
static NSString * const kLoginFreeStorage = @"free_storage";

//const static int LOGIN_FIRST_STAGE = 0;
//const static int LOGIN_MIN_STAGE_NOT_SET = -1;

@interface GSDKLoginEvent()

@property (nonatomic, readwrite, strong) NSMutableDictionary * eventDictionary;
@property (nonatomic, readwrite, assign) NSTimeInterval currentTime;
@property (nonatomic, readwrite, assign) BOOL finish_flag;
@property (nonatomic, readwrite, assign) BOOL special_flag;
@property (nonatomic, readwrite, assign) BOOL report_flag;
@property (nonatomic, readwrite, assign) int isBack;

// NOTE: 登录打点自动补空
//@property (nonatomic, readwrite, assign) int minStage;
//@property (nonatomic, readwrite, assign) int maxStage;

@end

@implementation GSDKLoginEvent

static GSDKLoginEvent * _sharedInstance = nil;
//方法实现
+ (instancetype) sharedInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[GSDKLoginEvent alloc] init];
    });
    return _sharedInstance;
}

- (instancetype) init {
    @synchronized(self) {
        if (self = [super init]) {
            _currentTime = [[NSDate date] timeIntervalSince1970];
            _isBack = 0;
            _finish_flag = YES;
            _special_flag = NO;
            _report_flag = NO;
            _eventDictionary = [[NSMutableDictionary alloc] init];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(enterBack) name:UIApplicationDidEnterBackgroundNotification object:nil];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(enterExit) name:UIApplicationWillTerminateNotification object:nil];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(enterFore) name:UIApplicationWillEnterForegroundNotification object:nil];
            
//            _minStage = LOGIN_FIRST_STAGE;
//            _maxStage = LOGIN_FIRST_STAGE - 1;
        }
        return self;
    }
}

- (void) enterBack {
    dispatch_async([GSDKInfoTool gsdk_event_queue], ^{
        if (!_finish_flag && !_special_flag) {
            GSDKLOG(@"Application did enter background,report this login message!");
            //进入后台时上报，要判断下逻辑是否正确，是否会多次上报？
            self.isBack = 1;
            [self reportBeacon];
        }
    });
}

- (void) enterExit {
    dispatch_async([GSDKInfoTool gsdk_event_queue], ^{
        if (!_finish_flag) {
            GSDKLOG(@"Application will terminate,report this login message!");
            //杀进程时上报
            self.isBack = 2;
            [self reportBeacon];
        }
    });
}

- (void) enterFore {
    dispatch_async([GSDKInfoTool gsdk_event_queue], ^{
        if (!_finish_flag && !_special_flag) {
            GSDKLOG(@"Application will enter foreground, record the time!");
            //记录返回前台时间
            [self GSDKRecordTime];
        }
    });
}

- (void) GSDKSetEvent:(int)tag Result:(BOOL)result Description:(NSString *) description Authorize:(BOOL)authorize Finish:(BOOL)finish Observer:(GPMObserver *)observer {
    if (finish && result) {
        //设置标志位，如果这之后再进后台就不记录
        [[NSNotificationCenter defaultCenter] removeObserver:self];
    }
    dispatch_async([GSDKInfoTool gsdk_event_queue], ^{
        if (_report_flag || ([[GSDKInitManager sharedInstance] login_flag] == NO)) {
            return;
        }
        self.finish_flag = NO;
        self.special_flag = authorize;
        NSString * msg = [NSString stringWithFormat:@"%@_%@", result?@"true":@"false", description];
        int t = 0;
        if (_currentTime > 0) {
            t = ([[NSDate date] timeIntervalSince1970] - _currentTime) * 1000;
        }
        [self GSDKRecordTime];
        NSString * user_time = [NSString stringWithFormat:@"t%d", tag];
        NSString * user_tag = [NSString stringWithFormat:@"s%d", tag];
        self.eventDictionary[user_time] = @(t);
        self.eventDictionary[user_tag] = msg;
        // NOTE: 登录打点自动补空
//        if (_maxStage + 1 < tag) {
//            if (LOGIN_MIN_STAGE_NOT_SET == _minStage) {
//                _minStage = _minStage + 1;
//            }
//            for (int curStage = _maxStage + 1; curStage < tag; curStage++) {
//                self.eventDictionary[[NSString stringWithFormat:@"t%d", curStage]] = [NSString stringWithFormat:@"%d", (int)([[NSDate date] timeIntervalSince1970] - _currentTime) * 1000];
//                self.eventDictionary[[NSString stringWithFormat:@"s%d", curStage]] = @"true_AutoFilled";
//                [self GSDKRecordTime];
//            }
//            _maxStage = tag;
//        }
        GSDKLOG(@"The eventDictioary is: %@", _eventDictionary);
        if (!result || finish) {
            // NOTE(三合一): 自动化测试回调
            if (observer) {
                observer->GPMOnLog("[GPM]3__SetEvent");
            }
            
            self.isBack = 0;
            [self reportBeacon];
        } else {
            if (observer) {
                observer->GPMOnLog("[GPM]1__SetEvent");
            }
        }
        if (finish && result) {
            //设置标志位，如果这之后再进后台就不记录
            self.finish_flag = YES;
            self.report_flag = YES;
        }
    });
}

- (void) reportBeacon {
    if ([[GSDKInitManager sharedInstance] login_flag]) {
        if (_eventDictionary && [_eventDictionary count] > 0) {
            //切后台，value为-2
            self.eventDictionary[kGSDKOpenid] = [GSDKInfoTool openID];
            if ([[GSDKInfoTool netType] isEqualToString:@"wifi"]) {
                NSString * routerIp = [GSDKInfoTool routerIPAddress];
                GSDKLOG(@"The router's ip is: %@", routerIp);
                if (routerIp) {
                    [[GSDKPing sharedInstance] startPing:routerIp];
                }
                //???: TODO 优化ping路由结果获取的效率
                dispatch_semaphore_t sema = dispatch_semaphore_create(0);
                dispatch_semaphore_wait(sema, dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)));
                self.eventDictionary[kLoginGateDelay] = [[GSDKPing sharedInstance] stopPing];
            } else {
                self.eventDictionary[kLoginGateDelay] = @(-1);
            }
            self.eventDictionary[kLoginDevices] = @(-1);
            self.eventDictionary[kLoginVersion] = GSDK_VERSION;
            self.eventDictionary[kLoginTotalStorage] = [GSDKInfoTool totalDiskSpaceInBytes];
            self.eventDictionary[kLoginFreeStorage] = [GSDKInfoTool freeDiskSpaceInBytes];

            self.eventDictionary[kGSDKISBACK] = @(_isBack);
//            NSString * createTime = [[NSUserDefaults standardUserDefaults] stringForKey:kGSDKCreateTime];
//            if (createTime) {
//                self.eventDictionary[kGSDKCreateTime] = createTime;
//            } else {
//                self.eventDictionary[kGSDKCreateTime] = @"UNKNOWN";
//            }
            self.eventDictionary[kGSDKLDNS] = [GSDKInfoTool dnsIP];
            [GSDKReporter gsdkReport:LoginReportName Params:_eventDictionary];
            [self.eventDictionary removeAllObjects];
//            self.currentTime = 0;
            
//            if (1 == _isBack || 2 == _isBack) {
//                _minStage = LOGIN_MIN_STAGE_NOT_SET;
//            }
        }
    }
}

- (void) GSDKRecordTime {
    self.currentTime = [[NSDate date] timeIntervalSince1970];
}

- (void) dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    if (_eventDictionary != nil) {
        [_eventDictionary removeAllObjects];
        _eventDictionary = nil;
    }
}

@end
