//
//  GSDKEvent.h
//  GSDK
//
//  Created by fu chunhui on 16/7/28.
//  Copyright © 2016年 fu chunhui. All rights reserved.
//

#import "GPMObserver.h"

@interface GSDKLoginEvent : NSObject

+ (id) sharedInstance;
- (void) GSDKSetEvent:(int)tag Result:(BOOL)result Description:(NSString *) description Authorize:(BOOL)authorize Finish:(BOOL)finish Observer:(GPMObserver *)observer;

@end
