//
//  GSDKApi.h
//  GSDK
//
//  Created by 曹爽 on 16/3/18.
//  Copyright © 2016年 fu chunhui. All rights reserved.
//
#import "GSDKCPU.h"
#import "GSDKMemory.h"
#import "GSDKUdpTest.h"
#import "GPMObserver.h"

@interface GSDKInGameSystem: NSObject

+ (id) sharedInstance;
- (void) GSDKInnerStart:(NSString *)zoneid SceneID:(NSString *)sceneid RoomIP:(NSString *)roomip Observer:(GPMObserver *)observer;
//- (void) GSDKInnerStart:(NSString *)zoneid SceneID:(NSString *)sceneid RoomIP:(NSString *)roomip FpsMode:(NSString *)fps_mode QualityLev:(NSString *)quality_Lev OptLev:(NSString *)opt_lev;
- (void) GSDKInnerSaveFPS:(NSDictionary *)fpsDic FpsDots:(NSString *)fpsdots;
- (void) GSDKInnerEnd:(GPMObserver *)observer;

@property (nonatomic, readonly, assign) BOOL battery_flag;

@end


