//
//  GSDKApi.m
//  GSDK
//
//  Created by 曹爽 on 16/3/31.
//  Copyright © 2016年 fu chunhui. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GSDKInGameManager.h"
#import "GSDKInGameSystem.h"
#import "GSDKLogger.h"
#import "GSDKInfoTool.h"
#import <UIKit/UIKit.h>
#import "GSDKBatteryLevel.h"
#import "GSDKInitManager.h"
#import "GSDKPrivate.h"
#import "FPS/GPMFps.h"

@interface GSDKInGameManager()

@property (nonatomic, assign, readwrite) BOOL detectFlag;

@end

@implementation GSDKInGameManager

static GSDKInGameManager * _sharedInstance = nil;
//方法实现
+ (id) sharedInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[GSDKInGameManager alloc] init];
    });
    return _sharedInstance;
}

- (void) GSDKStart:(NSString *)zoneid SceneID:(NSString *)sceneid RoomIP:(NSString *)roomip Observer:(GPMObserver *)observer {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [[UIDevice currentDevice] setBatteryMonitoringEnabled:YES];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(checkBattery:) name:UIDeviceBatteryStateDidChangeNotification object:nil];
    });
    dispatch_async([GSDKInfoTool gsdk_queue], ^{
        self.detectFlag = YES;
        [[GSDKInGameSystem sharedInstance] GSDKInnerStart:zoneid SceneID:sceneid RoomIP:roomip Observer:observer];
    });
}

- (void)checkBattery: (id)sender {
    dispatch_async([GSDKInfoTool gsdk_queue], ^{
        if (_detectFlag && [[GSDKInGameSystem sharedInstance] battery_flag]) {
            UIDeviceBatteryState status = [UIDevice currentDevice].batteryState;
            if (status == UIDeviceBatteryStateCharging || status == UIDeviceBatteryStateFull) {
                GSDKLOG(@"电池状态发生变化: 1");
                [[GSDKBatteryLevel sharedInstance] setHas_charged:1];
            } else {
                GSDKLOG(@"电池状态发生变化: 0");
            }
        }
    });
}

- (void) GSDKSaveFps:(float)favg FMax:(int)fmax FMin:(int)fmin Ftotal:(int)ftotal Fheavy:(int)fheavy Flight:(int)flight Fcntx0:(int)fcntx0 Flfps1:(int)flfps1 Flfps2:(int)flfps2 Flfps3:(int)flfps3 Fpsdots:(NSString *)fpsdots {
    
    dispatch_async([GSDKInfoTool gsdk_queue], ^{
        NSDictionary * fpsDic = @{kGSDKAvgFPS: [NSString stringWithFormat:@"%.1f", favg],
                                            kGSDKMinFPS: @(fmin),
                                            kGSDKMaxFPS: @(fmax),
                                            kGSDKTotalFPS: @(ftotal),
                                            kGSDKHeavyFPS: @(fheavy),
                                            kGSDKLightFPS: @(flight),
                                            kGSDKFcntx0: @(fcntx0),
                                            kGSDKFLfps1: @(flfps1),
                                            kGSDKFLfps2: @(flfps2),
                                            kGSDKFLfps3: @(flfps3)};
    [[GSDKInGameSystem sharedInstance] GSDKInnerSaveFPS:fpsDic FpsDots:fpsdots];
      
    });
}

- (void) GSDKEnd:(GPMObserver *)observer {
    dispatch_async([GSDKInfoTool gsdk_queue], ^{
        self.detectFlag = NO;
        [[GSDKInGameSystem sharedInstance] GSDKInnerEnd:observer];
    });
}

/*
- (void) GSDKStart:(NSString *)zoneid SceneID:(NSString *)sceneid RoomIP:(NSString *)roomip FpsMode:(NSString *)fps_mode QualityLev:(NSString *)quality_Lev OptLev:(NSString *)opt_lev {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [[UIDevice currentDevice] setBatteryMonitoringEnabled:YES];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(checkBattery:) name:UIDeviceBatteryStateDidChangeNotification object:nil];
    });
    dispatch_async([GSDKInfoTool gsdk_queue], ^{
        self.detectFlag = YES;
        [[GSDKInGameSystem sharedInstance] GSDKInnerStart:zoneid SceneID:sceneid RoomIP:roomip FpsMode:fps_mode QualityLev:quality_Lev OptLev:opt_lev];
    });
}

- (NSDictionary *) GSDKSpeedReturn {
    return [[GSDKUdpTest sharedInstance] speedReturnDict];
}

- (int) GSDKSpeedRealReturn {
    return [[GSDKUdpTest sharedInstance] speedRealReturnInt];
}
*/

@end
