//
//  GSDKEvent.m
//  GSDK
//
//  Created by fu chunhui on 16/7/28.
//  Copyright © 2016年 fu chunhui. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GSDKPayEvent.h"
#import "GSDKLoginPayDetect.h"
#import "GSDKInitManager.h"
#import "GSDKInfoTool.h"
#import "GSDKReporter.h"

//支付事件上报事件名
static NSString * const PayReportName = @"gsdk_report_pay";

//支付事件上报Key值
static NSString * const kClickBuy = @"s1";
static NSString * const kOrder = @"s2";
static NSString * const kPay = @"s3";
static NSString * const kPayDone = @"s4";
static NSString * const kClickBuyDuration = @"t1";
static NSString * const kOrderDuration = @"t2";
static NSString * const kPayDuration = @"t3";
static NSString * const kPayDoneDuration = @"t4";

@interface GSDKPayEvent()

@property (nonatomic, readwrite, assign) NSTimeInterval payCurrentTime;
@property (nonatomic, readwrite, strong) NSMutableDictionary * payDictionary;
@property (nonatomic, readwrite, strong) NSMutableDictionary * payTimeDictionary;

@end

@implementation GSDKPayEvent

static GSDKPayEvent * _sharedInstance = nil;
//方法实现
+ (instancetype) sharedInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[GSDKPayEvent alloc] init];
    });
    return _sharedInstance;
}

- (instancetype) init {
    @synchronized(self) {
        if (self = [super init]) {
            _payCurrentTime = 0;
        }
        return self;
    }
}

- (void) GSDKRecordPayTime {
    self.payCurrentTime = [[NSDate date] timeIntervalSince1970];
}

- (void) dealloc {
    if (_payDictionary != nil) {
        [_payDictionary removeAllObjects];
        _payDictionary = nil;
    }
    if (_payTimeDictionary != nil) {
        [_payTimeDictionary removeAllObjects];
        _payTimeDictionary = nil;
    }
}

- (void) GSDKPay:(int)itemid Tag:(GSDKPayItem)tag Status:(BOOL)status Msg:(NSString *)msg {
    dispatch_async([GSDKInfoTool gsdk_event_queue], ^{
        if ([[GSDKInitManager sharedInstance] pay_flag]) {
            if (!_payDictionary) {
                self.payDictionary = [[NSMutableDictionary alloc] init];
            }
            NSString* message = [NSString stringWithFormat:@"%d_%@_%@", itemid, status?@"true":@"false", msg];
            switch (tag) {
                case gsdkPayStart:
                {
                    [self GSDKRecordPayTime];
                    break;
                }
                case gsdkClickBuy:
                {
                    int t1 = 0;
                    if (_payCurrentTime > 0) {
                        t1 = ([[NSDate date] timeIntervalSince1970] - _payCurrentTime) * 1000;
                    }
                    [self GSDKRecordPayTime];
                    self.payDictionary[kClickBuyDuration] = @(t1);
                    self.payDictionary[kClickBuy] = message;
                    break;
                }
                case gsdkOrder:
                {
                    int t2 = 0;
                    if (_payCurrentTime > 0) {
                        t2 = ([[NSDate date] timeIntervalSince1970] - _payCurrentTime) * 1000;
                    }
                    [self GSDKRecordPayTime];
                    self.payDictionary[kOrderDuration] = @(t2);
                    self.payDictionary[kOrder] = message;
                    break;
                }
                case gsdkPay:
                {
                    int t3 = 0;
                    if (_payCurrentTime > 0) {
                        t3 = ([[NSDate date] timeIntervalSince1970] - _payCurrentTime) * 1000;
                    }
                    [self GSDKRecordPayTime];
                    self.payDictionary[kPayDuration] = @(t3);
                    self.payDictionary[kPay] = message;
                    break;
                }
                case gsdkPayDone:
                {
                    int t4 = 0;
                    if (_payCurrentTime > 0) {
                        t4 = ([[NSDate date] timeIntervalSince1970] - _payCurrentTime) * 1000;
                    }
                    [self GSDKRecordPayTime];
                    self.payDictionary[kPayDoneDuration] = @(t4);
                    self.payDictionary[kPayDone] = message;
                    break;
                }
                default:
                {
                    int t5 = 0;
                    if (_payCurrentTime > 0) {
                        t5 = ([[NSDate date] timeIntervalSince1970] - _payCurrentTime) * 1000;
                    }
                    [self GSDKRecordPayTime];
                    NSString* user_time = [NSString stringWithFormat:@"t%d", tag];
                    NSString* user_tag = [NSString stringWithFormat:@"s%d", tag];
                    self.payDictionary[user_time] = @(t5);
                    self.payDictionary[user_tag] = message;
                    break;
                }
            }
            GSDKLOG(@"The payDictioary is: %@", _payDictionary);
//            if (!status) {
//                if ([[GSDKInitManager sharedInstance] domain_flag]) {
//                    static dispatch_once_t onceToken;
//                    dispatch_once(&onceToken, ^{
//                        GSDKLoginPayDetect *payDetct = [[GSDKLoginPayDetect alloc] init];
//                        [payDetct detectPayPort];
//                    });
//                }
//            }
            if ((!status) || (tag == gsdkPayDone)) {
                [self reportPayBeacon];
            }
        }
    });
}

- (void) reportPayBeacon {
    if ([[GSDKInitManager sharedInstance] pay_flag]) {
        self.payDictionary[kGSDKOpenid] = [GSDKInfoTool openID];
        [GSDKReporter gsdkReport:PayReportName Params:_payDictionary];
        [self.payDictionary removeAllObjects];
        self.payDictionary = nil;
        self.payCurrentTime = 0;
    }
}

@end
