//
//  GSDKEvent.h
//  GSDK
//
//  Created by fu chunhui on 16/7/28.
//  Copyright © 2016年 fu chunhui. All rights reserved.
//

#ifndef GSDKPayEvent_h
#define GSDKPayEvent_h

#import "GSDKStructs.h"

@interface GSDKPayEvent : NSObject

+ (id) sharedInstance;
- (void) GSDKPay:(int)itemid Tag:(GSDKPayItem)tag Status:(BOOL)status Msg:(NSString *)msg;

@end

#endif /* GSDKEvent_h */
