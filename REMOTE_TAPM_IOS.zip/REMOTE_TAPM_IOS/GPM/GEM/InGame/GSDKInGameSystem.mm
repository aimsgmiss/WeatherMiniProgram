//
//  GSDKApi.m
//  GSDK
//
//  Created by 曹爽 on 16/3/18.
//  Copyright © 2016年 fu chunhui. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GSDKInGameManager.h"
#import "GSDKInGameSystem.h"
#import "GSDKBatteryLevel.h"
#import "GSDKInitManager.h"
#import "GSDKInfoTool.h"
#import "GSDKReporter.h"
#import "GSDKNetflow.h"
#import "GSDKPing.h"
#import "FPS/GPMFps.h"

@interface GSDKInGameSystem()

@property (nonatomic, readwrite, strong) NSString * sip;
@property (nonatomic, readwrite, assign) int sport;
// 云控开关
@property (nonatomic, readwrite, assign) int cpu_flag;
@property (nonatomic, readwrite, assign) int memory_flag;
@property (nonatomic, readwrite, assign) int ping_flag;
@property (nonatomic, readwrite, assign) int fps_flag;
@property (nonatomic, readwrite, assign) BOOL wifi_flag;
@property (nonatomic, readwrite, assign) BOOL battery_flag;
@property (nonatomic, readwrite, assign) BOOL netflow_flag;

//流程控制标识位
@property (nonatomic, readwrite, assign) BOOL is_Success;
@property (nonatomic, readwrite, assign) BOOL isStarted;

// 定时器
@property (nonatomic, strong) dispatch_source_t timerSource;

// 用于上报
@property (nonatomic, readwrite, strong) NSMutableDictionary * reportBaseDict;
@property (nonatomic, readwrite, assign) NSTimeInterval currentTime;
@property (nonatomic, readwrite, strong) NSString * fpsDots;

@end

@implementation GSDKInGameSystem

static GSDKInGameSystem * _sharedInstance = nil;
+ (id) sharedInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[GSDKInGameSystem alloc] init];
    });
    return _sharedInstance;
}
/*
- (void) GSDKInnerStart:(NSString *)zoneid SceneID:(NSString *)sceneid RoomIP:(NSString *)roomip FpsMode:(NSString *)fps_mode QualityLev:(NSString *)quality_Lev OptLev:(NSString *)opt_lev {
    [self GSDKInnerStart:zoneid SceneID:sceneid RoomIP:roomip];
    if (fps_mode) {
        self.reportBaseDict[kGSDKFpsMode] = fps_mode;
    } else {
        self.reportBaseDict[kGSDKFpsMode] = @"-1";
    }
    if (quality_Lev) {
        self.reportBaseDict[kGSDKQualityLev] = quality_Lev;
    } else {
        self.reportBaseDict[kGSDKQualityLev] = @"-1";
    }
    if (opt_lev) {
        self.reportBaseDict[kGSDKOptLev] = opt_lev;
    } else {
        self.reportBaseDict[kGSDKOptLev] = @"-1";
    }
}
*/
- (NSDictionary *) gotGameControl {
    
    // NOTE(三合一): 直接从GCloud云控实现上获取值
    GemCCStrategy* gemStrategy = [GSDKInfoTool getGemCCStrategy];
    if (!gemStrategy) {
        return nil;
    }
    
    NSMutableDictionary* gameControlDict = [NSMutableDictionary dictionary];
    //errCode&errMsg
    gameControlDict[kGSDKErrorCode] = [NSString stringWithFormat:@"%d", [gemStrategy getInt:kGSDKErrorCode defaultValue:1]];
    gameControlDict[kGSDKErrorMsg] = [gemStrategy getString:kGSDKErrorMsg value:@"useDefaultValue" defaultValue:@"useDefaultValue"];
    
    //ping
    gameControlDict[kGSDKPing] = [NSString stringWithFormat:@"%d", [gemStrategy getInt:kGSDKPing defaultValue:1]];
    gameControlDict[kGSDKFrequency] = [NSString stringWithFormat:@"%d", [gemStrategy getInt:kGSDKFrequency defaultValue:2000]];
    gameControlDict[kGSDKPcntx00] = [NSString stringWithFormat:@"%d", [gemStrategy getInt:kGSDKPcntx00 defaultValue:200]];
    gameControlDict[kGSDKSip] = [gemStrategy getString:kGSDKSip value:@"speed.gsdk.qq.com" defaultValue:@"speed.gsdk.qq.com"];
    gameControlDict[KGSDKSport] = [NSString stringWithFormat:@"%d", [gemStrategy getInt:KGSDKSport defaultValue:17000]];
    
    //fps
    gameControlDict[kGSDKFps] = [NSString stringWithFormat:@"%d", [gemStrategy getInt:kGSDKFps defaultValue:1]];
    gameControlDict[kGSDKFps_cycle] = [NSString stringWithFormat:@"%d", [gemStrategy getInt:kGSDKFps_cycle defaultValue:5000]];
    gameControlDict[kGSDKFcntx0] = [NSString stringWithFormat:@"%d", [gemStrategy getInt:kGSDKFcntx0 defaultValue:20]];
    gameControlDict[kGSDKFLfps1] = [NSString stringWithFormat:@"%d", [gemStrategy getInt:kGSDKFLfps1 defaultValue:5]];
    gameControlDict[kGSDKFLfps2] = [NSString stringWithFormat:@"%d", [gemStrategy getInt:kGSDKFLfps2 defaultValue:8]];
    gameControlDict[kGSDKFLfps3] = [NSString stringWithFormat:@"%d", [gemStrategy getInt:kGSDKFLfps3 defaultValue:15]];

    //cpu&mem
    gameControlDict[kGSDKCpu_cycle] = [NSString stringWithFormat:@"%d", [gemStrategy getInt:kGSDKCpu_cycle defaultValue:5000]];
    gameControlDict[kGSDKCPU] = [NSString stringWithFormat:@"%d", [gemStrategy getInt:kGSDKCPU defaultValue:1]];
    gameControlDict[kGSDKMem] = [NSString stringWithFormat:@"%d", [gemStrategy getInt:kGSDKMem defaultValue:1]];
    
    //other
    gameControlDict[kGSDKWiFi] = [NSString stringWithFormat:@"%d", [gemStrategy getInt:kGSDKWiFi defaultValue:1]];
    gameControlDict[kGSDKSignal_cycle] = [NSString stringWithFormat:@"%d", [gemStrategy getInt:kGSDKSignal_cycle defaultValue:5000]];
    gameControlDict[kGSDKBatteryUsage] = [NSString stringWithFormat:@"%d", [gemStrategy getInt:kGSDKBatteryUsage defaultValue:1]];
    gameControlDict[kGSDKNetFlow] = [NSString stringWithFormat:@"%d", [gemStrategy getInt:kGSDKNetFlow defaultValue:1]];
    
    return gameControlDict;
}

- (void) GSDKInnerStart:(NSString *)zoneid SceneID:(NSString *)sceneid RoomIP:(NSString *)roomip Observer:(GPMObserver *)observer {
    NSLog(@"[Info] GSDKStart");
    // 1. 关闭定时器
    if (self.timerSource) {
        dispatch_source_cancel(self.timerSource);
        [self setTimerSource:nil];
    }
    [[GSDKUdpTest sharedInstance] stopUDPTimer];
    
    // 2. 上报字典赋值
    if (_reportBaseDict) {
        [_reportBaseDict removeAllObjects];
    } else {
        self.reportBaseDict = [[NSMutableDictionary alloc] init];
    }
    self.reportBaseDict[kGSDKVersion] = GSDK_VERSION;
    if (zoneid) {
        self.reportBaseDict[kGSDKZoneID] = zoneid;
    } else {
        self.reportBaseDict[kGSDKZoneID] = @"-1";
    }
    if (sceneid) {
        self.reportBaseDict[kGSDKTag] = sceneid;
    } else {
        self.reportBaseDict[kGSDKTag] = @"-1";
    }
    if (roomip) {
        self.reportBaseDict[kGSDKRoomIP] = roomip;
    } else {
        self.reportBaseDict[kGSDKRoomIP] = @"-1";
    }
    self.reportBaseDict[kGSDKOpenid] = [GSDKInfoTool openID];
    
    // 成员变量赋初值
    self.cpu_flag = 0;
    self.memory_flag = 0;
    self.ping_flag = 0;
    self.fps_flag = 0;
    self.battery_flag = NO;
    self.netflow_flag = NO;
    self.wifi_flag = NO;
    self.is_Success = NO;
    self.isStarted = YES;
    self.currentTime = [[NSDate date] timeIntervalSince1970];
    NSDictionary * resultsDictionary = [self gotGameControl];
    if (!resultsDictionary) {
        // NOTE(三合一): 自动化测试回调
        if (observer) {
            observer->GPMOnLog("[GPM]-1__Start");
        }
        return;
    }
    GSDKLOG(@"云控下发：%@",resultsDictionary);
    [GSDKReporter gsdkReport:GameCloudReportName Params:resultsDictionary];
    
    //解析数据
    NSString * errcode = resultsDictionary[kGSDKErrorCode];
    NSString * errmsg = resultsDictionary[kGSDKErrorMsg];
    GSDKLOG(@"errCode === %@, errmsg === %@", errcode, errmsg);
    if (errcode && [errcode intValue] >= 0) {
        // NOTE(三合一): 自动化测试回调
        if (observer) {
            observer->GPMOnLog("[GPM]0__Start");
        }
        // udp
        self.ping_flag = [resultsDictionary[kGSDKPing] intValue];
        self.sip = resultsDictionary[kGSDKSip];
        self.sport = [resultsDictionary[KGSDKSport] intValue];
        int udpfrequency = [resultsDictionary[kGSDKFrequency] intValue];
        int pcntx00 = [resultsDictionary[kGSDKPcntx00] intValue];
            
        // cpu&mem
        self.cpu_flag = [resultsDictionary[kGSDKCPU] intValue];
        self.memory_flag = [resultsDictionary[kGSDKMem] intValue];
        int cpufrequency = [resultsDictionary[kGSDKCpu_cycle] intValue];
        
        // fps
        self.fps_flag = [resultsDictionary[kGSDKFps] intValue];
        int fpsfrequency = [resultsDictionary[kGSDKFps_cycle] intValue];
        int fcntx0 = [resultsDictionary[kGSDKFcntx0] intValue];
        int lfps1 = [resultsDictionary[kGSDKFLfps1] intValue];
        int lfps2 = [resultsDictionary[kGSDKFLfps2] intValue];
        int lfps3 = [resultsDictionary[kGSDKFLfps3] intValue];
        /*{
            //test
            fpsfrequency = 3000;
            fcntx0 = 5;
        }*/
        if (fcntx0 > 0 && fpsfrequency > 0) {
            [[GPMFps sharedInstance] startInterval:200 cusTs:0 - fcntx0 lTs1:lfps1 lTs2:lfps2 lTs3:lfps3 dotFreq:fpsfrequency];
        }
        
        // others
        self.battery_flag = [resultsDictionary[kGSDKBatteryUsage] boolValue];
        self.netflow_flag = [resultsDictionary[kGSDKNetFlow] boolValue];
        self.wifi_flag = [resultsDictionary[kGSDKWiFi] boolValue];
        int routerfrequency = [resultsDictionary[kGSDKSignal_cycle] intValue];
        //分模块采集
        if (cpufrequency > 0) {
            //设置定时器，间隔5s取一次值
            [self cpuPrepare];
            __weak __typeof(self) weakSelf = self;
            self.timerSource = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, [GSDKInfoTool gsdk_queue]);
            dispatch_source_set_timer(self.timerSource, dispatch_walltime(NULL, 0), cpufrequency/1000ull * NSEC_PER_SEC, 1ull * NSEC_PER_SEC);
            dispatch_source_set_event_handler(self.timerSource, ^{
                __strong __typeof(self) strongSelf = weakSelf;
                if (strongSelf) {
                    [strongSelf cpuCollect];
                }
            });
            dispatch_resume(self.timerSource);
        }
        if (_ping_flag && udpfrequency > 0) {
            [[GSDKUdpTest sharedInstance] startUdpTest:_sip Sport:_sport Pcntx00:pcntx00 Frequency:udpfrequency];
        }
        if (_battery_flag) {
            [[GSDKBatteryLevel sharedInstance] startBattery];
        }
        if (_netflow_flag) {
            [[GSDKNetflow sharedInstance] startNetflow];
            [[GSDKNetflow sharedInstance] startNetCard];
        }
        if (_wifi_flag) {
            if ([[GSDKInfoTool netType] isEqualToString:@"wifi"]) {
                if (routerfrequency > 0) {
                    NSString * routerIp = [GSDKInfoTool routerIPAddress];
                    GSDKLOG(@"The router's ip is: %@", routerIp);
                    if (routerIp) {
                        [[GSDKPing sharedInstance] startPing:routerIp];
                    }
                }
            } else {
                GSDKLOG(@"Not wifi type, do not collect devices or ping the router.");
            }
        }
        NSString * fpsString = @"-1";
        if (_fps_flag) {
            fpsString = [NSString stringWithFormat:@"%@|%@|%d|%d|%d|%d|%d", errcode, errmsg, fcntx0, lfps1, lfps2, lfps3, fpsfrequency];
        } else {
            fpsString = [NSString stringWithFormat:@"%@|%@|0|0|0|0|0",errcode,errmsg];
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            if (observer) {
                observer->GPMOnFpsNotify([fpsString UTF8String]);
            }
        });
        self.is_Success = YES;
    } else {
        // NOTE(三合一): 自动化测试回调
        if (observer) {
            NSString *logString = [NSString stringWithFormat:@"[GPM]%@__Start", errcode];
            observer->GPMOnLog([logString UTF8String]);
        }
    }
}

- (void) cpuPrepare {
    if (_cpu_flag) {
        [[GSDKCPU sharedInstance] startCPU];
    }
    if (_memory_flag) {
        [[GSDKMemory sharedInstance] startMemory];
    }
}

- (void) cpuCollect {
    if (_cpu_flag) {
        [[GSDKCPU sharedInstance] getCPUMessage];
    }
    if (_memory_flag) {
        [[GSDKMemory sharedInstance] getMemoryMessage];
    }
}

- (void) dealloc {
    if (_sip != nil) {
        _sip = nil;
    }
}

- (void) reportDotsToBeacon: (NSDictionary *) paramsDic {
    if (_cpu_flag == 2) {
        //CPU
        NSArray * cpulist = [[GSDKCPU sharedInstance] cpuDots];
        NSString * cpulistString = [self arrayToString:cpulist MaxCount:250];
        if ([cpulistString isEqualToString:@"-1"]) {
            return;
        } else {
            NSMutableDictionary * beaconDic = [[NSMutableDictionary alloc] init];
            [beaconDic addEntriesFromDictionary:paramsDic];
            NSArray * cpulistArray = [cpulistString componentsSeparatedByString:@";"];
            NSUInteger maxKey = 46;
            if (cpulistArray.count < 46) {
                maxKey = cpulistArray.count;
            }
            for (int i = 0; i < maxKey; i++) {
                [beaconDic setObject:cpulistArray[i] forKey:[NSString stringWithFormat:@"list%d", i]];
            }
            [beaconDic setObject:@"cpu_list" forKey:@"listname"];
            beaconDic[kGSDKNetType] = [GSDKInfoTool netType];
            [GSDKReporter gsdkReport:@"gsdk_report_eventList" Params:beaconDic];
        }
    }
    if (_memory_flag == 2) {
        //Memory
        NSArray * memlist = [[GSDKMemory sharedInstance] memDots];
        NSString * memlistString = [self arrayToString:memlist MaxCount:200];
        if ([memlistString isEqualToString:@"-1"]) {
            return;
        } else {
            NSMutableDictionary * beaconDic = [[NSMutableDictionary alloc] init];
            [beaconDic addEntriesFromDictionary:paramsDic];
            NSArray * memlistArray = [memlistString componentsSeparatedByString:@";"];
            NSUInteger maxKey = 46;
            if (memlistArray.count < 46) {
                maxKey = memlistArray.count;
            }
            for (int i = 0; i < maxKey; i++) {
                [beaconDic setObject:memlistArray[i] forKey:[NSString stringWithFormat:@"list%d", i]];
            }
            [beaconDic setObject:@"mem_list" forKey:@"listname"];
            beaconDic[kGSDKNetType] = [GSDKInfoTool netType];
            [GSDKReporter gsdkReport:@"gsdk_report_eventList" Params:beaconDic];
        }
    }
    if (_ping_flag == 2) {
        //UDP
        NSArray * udplist = [[GSDKUdpTest sharedInstance] pingDots];
        NSString * udplistString = [self arrayToString:udplist MaxCount:200];
        if ([udplistString isEqualToString:@"-1"]) {
            return;
        } else {
            NSMutableDictionary * beaconDic = [[NSMutableDictionary alloc] init];
            [beaconDic addEntriesFromDictionary:paramsDic];
            NSArray * udplistArray = [udplistString componentsSeparatedByString:@";"];
            NSUInteger maxKey = 46;
            if (udplistArray.count < 46) {
                maxKey = udplistArray.count;
            }
            for (int i = 0; i < maxKey; i++) {
                [beaconDic setObject:udplistArray[i] forKey:[NSString stringWithFormat:@"list%d", i]];
            }
            [beaconDic setObject:@"udp_list" forKey:@"listname"];
            beaconDic[kGSDKNetType] = [GSDKInfoTool netType];
            [GSDKReporter gsdkReport:@"gsdk_report_eventList" Params:beaconDic];
        }
    }
    [[GSDKUdpTest sharedInstance] clearPingDots];
    if (_fps_flag == 2) {
        //FPS
        NSArray * fpslist = [self.fpsDots componentsSeparatedByString:@","];
        NSString * fpslistString = [self arrayToString:fpslist MaxCount:250];
        if ([fpslistString isEqualToString:@"-1"]) {
            return;
        } else {
            NSMutableDictionary * beaconDic = [[NSMutableDictionary alloc] init];
            [beaconDic addEntriesFromDictionary:paramsDic];
            NSArray * fpslistArray = [fpslistString componentsSeparatedByString:@";"];
            NSUInteger maxKey = 46;
            if (fpslistArray.count < 46) {
                maxKey = fpslistArray.count;
            }
            for (int i = 0; i < maxKey; i++) {
                [beaconDic setObject:fpslistArray[i] forKey:[NSString stringWithFormat:@"list%d", i]];
            }
            [beaconDic setObject:@"fps_list" forKey:@"listname"];
            beaconDic[kGSDKNetType] = [GSDKInfoTool netType];
            [GSDKReporter gsdkReport:@"gsdk_report_eventList" Params:beaconDic];
        }
    }
}

- (NSString *) arrayToString:(NSArray *)array MaxCount:(int)maxCount {
    NSString * result = [[NSString alloc] init];
    if (array) {
        for (int i = 0; i < array.count; i++) {
            result = [result stringByAppendingString:[NSString stringWithFormat:@"%@,", [array objectAtIndex:i]]];
            if (((i+1) % maxCount) == 0) {
                result = [result stringByAppendingString:@";"];
            }
        }
        return result;
    } else {
        return @"-1";
    }
}

- (void) GSDKInnerSaveFPS:(NSDictionary *)fpsDic FpsDots:(NSString *)fpsdots {
    GSDKLOG(@"The fps dot value is:%@", fpsdots);
    if (fpsDic) {
        [self.reportBaseDict addEntriesFromDictionary:fpsDic];
    }
    self.fpsDots = [fpsdots copy];
}

- (void) GSDKInnerEnd:(GPMObserver *)observer {
    NSLog(@"[Info] GSDKEnd");
    NSMutableDictionary * params = [NSMutableDictionary dictionaryWithCapacity:10];
    // NOTE(三合一): 自动化测试回调
    if (_isStarted) {
        if (observer) {
            observer->GPMOnLog("[GPM]0__End");
        }
        NSDictionary * tmp = nil;
        if (self.timerSource) {
            dispatch_source_cancel(self.timerSource);
            [self setTimerSource:nil];
        }
        //添加数据
        NSTimeInterval endTime = [[NSDate date] timeIntervalSince1970];
        NSTimeInterval duration = endTime - _currentTime;
        NSString * etime = [NSString stringWithFormat:@"%.0f", endTime];
        NSString * time = [NSString stringWithFormat:@"%.0f", duration];
        [params setObject:etime forKey:kGSDKEndTime];
        [params setObject:time forKey:kGSDKDuration];
        params[kGSDKTotalStorage] = [GSDKInfoTool totalDiskSpaceInBytes];
        params[kGSDKFreeStorage] = [GSDKInfoTool freeDiskSpaceInBytes];
        params[kGSDKDevices] = @"-1";
        params[kGSDKWiFiNum] = @"-1";
        params[kGSDKWiFiRSSI] = @"-1";
        params[kGSDKWiFiSpeed] = @"-1";
        
        if (_cpu_flag) {
            tmp = [[GSDKCPU sharedInstance] resultCPU];
            [params addEntriesFromDictionary:tmp];
        } else {
            tmp = [[GSDKCPU sharedInstance] resultCPU_noCollect];
            [params addEntriesFromDictionary:tmp];
        }
        if (self.memory_flag) {
            tmp = [[GSDKMemory sharedInstance] resultMemory];
            [params addEntriesFromDictionary:tmp];
        } else {
            tmp = [[GSDKMemory sharedInstance] resultMemory_noCollect];
            [params addEntriesFromDictionary:tmp];
        }
        if (_reportBaseDict) {
            [params addEntriesFromDictionary:_reportBaseDict];
        }
        if (_ping_flag) {
            tmp = [[GSDKUdpTest sharedInstance] resultUDPTest];
            [params addEntriesFromDictionary:tmp];
        } else {
            tmp = [[GSDKUdpTest sharedInstance] resultUDPTest_noCollect];
            [params addEntriesFromDictionary:tmp];
        }
        if (_battery_flag) {
            tmp = [[GSDKBatteryLevel sharedInstance] resultBattery];
            [params addEntriesFromDictionary:tmp];
        } else {
            tmp = [[GSDKBatteryLevel sharedInstance] resultBattery_noCollect];
            [params addEntriesFromDictionary:tmp];
        }
        if (_netflow_flag) {
            params[kGSDKNetFlow] = [[GSDKNetflow sharedInstance] resultNetflow];
            tmp = [[GSDKNetflow sharedInstance] resultNetCard];
            [params addEntriesFromDictionary:tmp];
        } else {
            params[kGSDKNetFlow] = @"-1";
            tmp = [[GSDKNetflow sharedInstance] resultNetCard_noCollect];
            [params addEntriesFromDictionary:tmp];
        }
        if (_wifi_flag) {
            params[kGSDKNetType] = [GSDKInfoTool netType];
            params[kGSDKGateDelay] = [[GSDKPing sharedInstance] stopPing];
        } else {
            params[kGSDKNetType] = @"-1";
            params[kGSDKGateDelay] = @"-1";
        }
        if (_is_Success) {
            params[kGSDKLDNS] = [GSDKInfoTool dnsIP];
            NSString * speedIp2Report = @"-1";
            if (_sip) {
                speedIp2Report = _sip;
            }
            params[GAME_SPEED_TEST_IP_NAME] = speedIp2Report;
            [GSDKReporter gsdkReport:GameReportName Params:params];
            NSString * tag = @"-1";
            if (params[kGSDKTag]) {
                tag = params[kGSDKTag];
            }
            NSString * openid = @"UNKNOWN";
            if (params[kGSDKOpenid]) {
                openid = params[kGSDKOpenid];
            }
            NSDictionary * paramDic = @{kGSDKTag: tag,
                                        kGSDKOpenid: openid,
                                        kGSDKEndTime: etime,
                                        kGSDKDuration: time};
            [self reportDotsToBeacon:paramDic];
            self.is_Success = NO;
        }
        self.isStarted = NO;
        tmp = nil;
        self.battery_flag = NO;
        self.netflow_flag = NO;
        self.wifi_flag = NO;
        self.is_Success = NO;
        self.cpu_flag = 0;
        self.ping_flag = 0;
        self.memory_flag = 0;
        self.fps_flag = 0;
//        [[GSDKInitManager sharedInstance] OnGSDKLogNotify:0 ErrMsg:@"success" ExtMsg:@"GSDKEnd"];
    } else {
        if (observer) {
            observer->GPMOnLog("[GPM]-1__End");
        }
        params = nil;
        GSDKLOG(@"未开始，或已上报");
//        [[GSDKInitManager sharedInstance] OnGSDKLogNotify:-1 ErrMsg:@"not Start Or already Uploaded" ExtMsg:@"GSDKEnd"];
    }
}

@end
