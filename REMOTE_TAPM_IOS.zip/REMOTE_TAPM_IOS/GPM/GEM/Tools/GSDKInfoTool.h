//
//  MSDKDnsInfoTool.h
//  MSDKDns
//
//  Created by Mike on 3/25/16.
//  Copyright © 2016 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <netinet/in.h>
#import <netinet6/in6.h>

#import "GemCCStrategy.h"
#import "GPMObserver.h"

@interface GSDKInfoTool : NSObject

+ (NSString *) openID;
+ (NSString *) netType;
+ (NSString *) dnsIP;
+ (BOOL) isIPLegal:(NSString *)ip errorInfo:(NSString **)errorInfo;
+ (NSString *) localWiFiIPAddress;//本机地址
+ (NSString *) netMask;//子网掩码地址
+ (NSString *) routerIPAddress;//路由器地址
+ (NSString *) freeDiskSpaceInBytes;//手机剩余空间
+ (NSString *) totalDiskSpaceInBytes;//手机总空间
+ (BOOL) addressesForHostname:(NSString *)hostname ConvertString:(NSString **)convertString;
// UUID在iOS上可能被视为敏感数据，去掉相关上报
//+ (NSString *) uuidString;
+ (NSString *) platApi;
+ (NSString *) carrierName;
+ (NSString *) phoneModel;
+ (in_addr_t) convertIPAddressToBinary:(NSString *)ipAddress;
+ (struct in6_addr) convertIP2V6:(NSString *) ipv6;
// 全局队列
+ (dispatch_queue_t) gsdk_queue;
+ (dispatch_queue_t) gsdk_event_queue;
+ (dispatch_queue_t) gsdk_quality_queue;
+ (dispatch_queue_t) gsdk_udpArray_queue;

// NOTE(三合一): GCloud云控实现注入
+ (void) setGemCCStrategy:(GemCCStrategy *)gemCCStrategy;
+ (GemCCStrategy *) getGemCCStrategy;

@end
