//
//  HttpDnsResolver.h
//  MSDKDns
//
//  Created by mikefu on 15/6/17.
//  Copyright (c) 2015年 Tencent. All rights reserved.
//

@interface GSDKHttpDnsResolver : NSObject

- (void) startWithDomain:(NSString *)domain success:(void (^)(NSString *ipInfo))success fail:(void (^)(NSString *error))fail;

@end
