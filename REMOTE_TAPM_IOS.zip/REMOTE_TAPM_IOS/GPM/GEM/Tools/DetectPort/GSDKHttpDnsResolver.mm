//
//  HttpDnsResolver.m
//  MSDKDns
//
//  Created by mikefu on 15/6/17.
//  Copyright (c) 2015年 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GSDKHttpDnsResolver.h"
#import "GSDKLogger.h"
#import "GSDKDESEncrypt.h"

//httpdns证书域名
static NSString * const kHost = @"httpdns.qq.com";

@interface GSDKHttpDnsResolver ()<NSURLConnectionDelegate,NSURLConnectionDataDelegate>

@property (strong, nonatomic) NSMutableData *responseData;
@property (strong, nonatomic) NSURLConnection *connection;
@property (nonatomic , assign) CFRunLoopRef rl;
@property (nonatomic, strong) void (^ success)(NSString *ipInfo);
@property (nonatomic, strong) void (^ fail)(NSString *error);

@end

@implementation GSDKHttpDnsResolver

- (void) dealloc {
    GSDKLOG(@"GSDKHttpDnsResolver dealloc!");
    _responseData = nil;
    [_connection cancel];
    _connection = nil;
}

- (void) startWithDomain:(NSString *)domain success:(void (^)(NSString *))success fail:(void (^)(NSString *))fail {
    self.success = success;
    self.fail = fail;
    if (!domain || domain.length == 0) {
        GSDKLOG(@"HttpDns Domain is must needed!");
        NSString* errorInfo = @"Domian is null";
        if (self.fail) {
            self.fail(errorInfo);
            self.fail = nil;
            self.success = nil;
        }
        return;
    }

    GSDKLOG(@"HttpDns startWithDomain: %@!", domain);
    NSURL * httpDnsUrl = [GSDKDESEncrypt httpDnsUrlWithDomain:domain];
    if (httpDnsUrl) {
        NSURLRequest *request = [NSURLRequest requestWithURL:httpDnsUrl cachePolicy:NSURLRequestReloadIgnoringCacheData timeoutInterval:1.0];
        self.connection = [NSURLConnection connectionWithRequest:request delegate:self];
        [self.connection start];
        self.rl = CFRunLoopGetCurrent();
        CFRunLoopRun();
    } else {
        GSDKLOG(@"HttpDns Domain encrypt fail!");
        NSString* errorInfo = @"HttpDns Domain encrypt fail";
        if (self.fail) {
            self.fail(errorInfo);
            self.fail = nil;
            self.success = nil;
        }
    }
}

#pragma mark - NSURLConnectionDelegate

- (void) connection:(NSURLConnection *)connection willSendRequestForAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge {
    GSDKLOG(@"https willSendRequestForAuthenticationChallenge");
    if (!challenge) {
        return;
    }
    
    /*
     * 判断challenge的身份验证方法是否是NSURLAuthenticationMethodServerTrust（HTTPS模式下会进行该身份验证流程），
     * 在没有配置身份验证方法的情况下进行默认的网络请求流程。
     */
    if ([challenge.protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust]) {
        if ([self evaluateServerTrust:challenge.protectionSpace.serverTrust forDomain:kHost]) {
            /*
             * 验证完以后，需要构造一个NSURLCredential发送给发起方
             */
            NSURLCredential *credential = [NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust];
            [[challenge sender] useCredential:credential forAuthenticationChallenge:challenge];
        } else {
            /*
             * 验证失败，取消这次验证流程
             */
            [[challenge sender] cancelAuthenticationChallenge:challenge];
        }
    } else {
        /*
         * 对于其他验证方法直接进行处理流程
         */
        [[challenge sender] continueWithoutCredentialForAuthenticationChallenge:challenge];
    }
}

- (BOOL) evaluateServerTrust:(SecTrustRef)serverTrust forDomain:(NSString *)domain {
    /*
     * 创建证书校验策略
     */
    NSMutableArray *policies = [NSMutableArray array];
    if (domain) {
        [policies addObject:(__bridge_transfer id)SecPolicyCreateSSL(true, (__bridge CFStringRef)domain)];
    } else {
        [policies addObject:(__bridge_transfer id)SecPolicyCreateBasicX509()];
    }
    
    /*
     * 绑定校验策略到服务端的证书上
     */
    SecTrustSetPolicies(serverTrust, (__bridge CFArrayRef)policies);
    
    /*
     * 评估当前serverTrust是否可信任，
     * 官方建议在result = kSecTrustResultUnspecified 或 kSecTrustResultProceed
     * 的情况下serverTrust可以被验证通过，https://developer.apple.com/library/ios/technotes/tn2232/_index.html
     * 关于SecTrustResultType的详细信息请参考SecTrust.h
     */
    SecTrustResultType result;
    SecTrustEvaluate(serverTrust, &result);
    
    return (result == kSecTrustResultUnspecified || result == kSecTrustResultProceed);
}

- (void) connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    GSDKLOG(@"HttpDnsResolver didReceiveResponse!");
    self.responseData = nil;
    self.responseData = [NSMutableData new];
}

- (void) connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    GSDKLOG(@"HttpDnsResolver didReceiveData!");
    if (data && data.length > 0)
    {
        [_responseData appendData:data];
    }
}

- (void) connectionDidFinishLoading:(NSURLConnection *)connection {
    GSDKLOG(@"connectionDidFinishLoading: %@",_responseData);
    NSString *errorInfo = @"";
    if (_responseData.length > 0) {
        NSArray *resultArr = nil;
        NSString *responseStr = [[NSString alloc] initWithData:_responseData encoding:NSUTF8StringEncoding];
        NSString *decryptStr = [GSDKDESEncrypt GSDKDES128Decrypt:responseStr key:HTTP_DNS_DOMAIN_ENCRYPT_KEY];
        if (decryptStr) {
                resultArr = [decryptStr componentsSeparatedByString:@"|"];
            }
        
        //内部59.37.96.63;14.17.42.40;14.17.32.211|14.17.22.32,300
        //外部59.37.96.63;14.17.32.211;14.17.42.40,130
        
        if (resultArr && resultArr.count == 2) {
            GSDKLOG(@"HttpDns Succeed:%@",decryptStr);
            NSString *ipsStr = resultArr[0];
            NSString *tempStr = ipsStr.length > 1 ? [ipsStr substringFromIndex:ipsStr.length - 1] : @"";
            if ([tempStr isEqualToString:@";"]) {
                ipsStr = [ipsStr substringToIndex:ipsStr.length - 1];
            }
            GSDKLOG(@"Http IpString:%@", ipsStr);
            if (self.success) {
                self.success(ipsStr);
                self.fail = nil;
                self.success = nil;
            }
            CFRunLoopStop(self.rl);
            return;
        } else {
            errorInfo = @"HttpDns Failed, resultArr is not format";
            GSDKLOG(@"HttpDns Failed, resultArr is not format.");
        }
    } else {
        errorInfo = @"HttpDns response data error";
        GSDKLOG(@"HttpDns response data error");
    }
    
    if (self.fail) {
        self.fail(errorInfo);
        self.fail = nil;
        self.success = nil;
    }
    CFRunLoopStop(self.rl);
}

- (void) connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    GSDKLOG(@"HttpDns Failed:%@",[error userInfo]);
    NSString * errorInfo = error.userInfo[@"NSLocalizedDescription"];
    if (self.fail) {
        self.fail(errorInfo);
        self.fail = nil;
        self.success = nil;
    }
    CFRunLoopStop(self.rl);
}

@end
