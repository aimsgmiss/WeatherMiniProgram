
//
//  GSDKUdpDetect.h
//  GSDK
//
//  Created by 曹爽 on 16/3/18.
//  Copyright © 2016年 fu chunhui. All rights reserved.
//

@interface GSDKUdpDetect : NSObject

- (NSString *) udpConnectTime:(NSString *)ip Port:(int)port;

@end
