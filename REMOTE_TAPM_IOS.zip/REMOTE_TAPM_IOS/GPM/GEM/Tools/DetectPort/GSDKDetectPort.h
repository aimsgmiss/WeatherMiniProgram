//
//  GSDKDetectPort.h
//  GSDK
//
//  Created by 曹爽 on 2016/10/10.
//  Copyright © 2016年 fu chunhui. All rights reserved.
//

#ifndef GSDKDetectPort_h
#define GSDKDetectPort_h

@interface GSDKDetectPort : NSObject

- (NSString *) isConnection:(NSString *) hostname Port:(int)port;
- (NSString *) connectionTime:(NSString *) hostname Port:(int)port;

@end

#endif /* GSDKDetectPort_h */
