//
//  GSDKDetectPort.m
//  GSDK
//
//  Created by 曹爽 on 2016/10/10.
//  Copyright © 2016年 fu chunhui. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GSDKDetectPort.h"
#import "GSDKInfoTool.h"
#import "GSDKHttpDnsResolver.h"
#import "GSDKLogger.h"
#include <arpa/inet.h>

@interface GSDKDetectPort()

@property (assign, nonatomic) BOOL isFinished;
@property (nonatomic, strong) NSString * hip;
@property (nonatomic, strong) NSString * result;

@end

@implementation GSDKDetectPort

-(void) dealloc {
    if (_result) {
        _result = nil;
    }
    if (_hip) {
        _hip = nil;
    }
}

- (NSString *) isConnection:(NSString *)hostname Port:(int)port {
    if (hostname && [hostname length] > 0 && port > 0) {
        self.isFinished = NO;
        GSDKLOG(@"StartHttpDns!");
        dispatch_semaphore_t sema = dispatch_semaphore_create(0);
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            __weak __typeof(self) weakSelf = self;
            GSDKHttpDnsResolver * httpDnsResolver = [[GSDKHttpDnsResolver alloc] init];
            [httpDnsResolver startWithDomain:hostname success:^(NSString *ipInfo) {
                __strong __typeof(self) strongSelf = weakSelf;
                if (strongSelf) {
                    strongSelf.hip = ipInfo;
                }
                dispatch_semaphore_signal(sema);
            } fail:^(NSString *error) {
                __strong __typeof(self) strongSelf = weakSelf;
                if (strongSelf) {
                    strongSelf.hip = @"-1";
                }
                dispatch_semaphore_signal(sema);
            }];
        });
        dispatch_semaphore_wait(sema, DISPATCH_TIME_FOREVER);
        NSDate * time = [NSDate date];
        NSString * ip = nil;
        BOOL isIPV6Env = [GSDKInfoTool addressesForHostname:hostname ConvertString:&ip];
        NSTimeInterval cost = [[NSDate date] timeIntervalSinceDate:time] * 1000;
        GSDKLOG(@"%@ Convert to %@, Consume time is %.0f", hostname, ip, cost);
        if (!ip) {
            GSDKLOG(@"failed to resolve host:%@", hostname);
            NSString * result = [NSString stringWithFormat:@"%@_%.0f_-1_%@_%d_false", hostname, cost, self.hip, port];
            return result;
        }
        int sockfd = 0;
        if (isIPV6Env) {
            sockfd = socket(AF_INET6, SOCK_STREAM, 0);
        } else {
            sockfd = socket(AF_INET, SOCK_STREAM, 0);
        }
        if (sockfd < 0) {
            GSDKLOG(@"failed to get sockfd:%d", sockfd);
            NSString * result = [NSString stringWithFormat:@"%@_%.0f_%@_%@_%d_false", hostname, cost, ip, self.hip, port];
            return result;
        }
        // 设置send和recv超时
        struct timeval timeout = {3,0};//3s
        int retreceive = setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, (const char *)&timeout, sizeof(timeout));
        int retsend = setsockopt(sockfd, SOL_SOCKET, SO_SNDTIMEO, (const char *)&timeout, sizeof(timeout));
        int nosigpipe = 1;
        int status = setsockopt(sockfd, SOL_SOCKET, SO_NOSIGPIPE, &nosigpipe, sizeof(nosigpipe));
        if (retreceive != 0 || retsend != 0 || status != 0) {
            close(sockfd);
            NSString * result = [NSString stringWithFormat:@"%@_%.0f_%@_%@_%d_false", hostname, cost, ip, self.hip, port];
            return result;
        }
        
        /***************************************************/
        //在connect之前，设成非阻塞模式
        int flags = fcntl(sockfd, F_GETFL, 0);
        fcntl(sockfd, F_SETFL, flags | O_NONBLOCK);
        /***************************************************
         //这是另外一种设置成非阻塞的方式
         int flags;
         if((flags = fcntl(sockfd, F_GETFL)) < 0 )
         {
         perror("fcntl F_SETFL");
         }
         flags |= O_NONBLOCK;
         if(fcntl(sockfd, F_SETFL,flags) < 0)
         {
         perror("fcntl");
         }
         ****************************************************/
        int error = 0;
        if (isIPV6Env) {
            // 构建目标地址
            struct sockaddr_in6 server_addr_in = {0};
            memset(&server_addr_in, 0, sizeof(struct sockaddr_in6));
            server_addr_in.sin6_family = AF_INET6;
            server_addr_in.sin6_port = htons(port);
            server_addr_in.sin6_addr = [GSDKInfoTool convertIP2V6:ip];
            error = connect(sockfd, (struct sockaddr *)&server_addr_in, sizeof(struct sockaddr_in6));
        } else {
            // 构建目标地址
            struct sockaddr_in server_addr_in = {0};
            memset(&server_addr_in, 0, sizeof(struct sockaddr_in));
            server_addr_in.sin_family = AF_INET;
            server_addr_in.sin_port = htons(port);
            server_addr_in.sin_addr.s_addr = [GSDKInfoTool convertIPAddressToBinary:ip];
            error = connect(sockfd, (struct sockaddr *)&server_addr_in, sizeof(struct sockaddr_in));
        }
        //非阻塞模式
        if (error < 0 && errno == EINPROGRESS) {
            // errno == EINPROGRESS表示正在建立链接
            // 等待连接完成，errno == EINPROGRESS表示正在建立链接
            fd_set set;
            FD_ZERO(&set);
            FD_SET(sockfd,&set);  //相反的是FD_CLR(_sock_fd,&set)
            
            int retval = select(sockfd + 1, NULL, &set, NULL, &timeout); //超时时间：3s          //事件监听
            if (retval < 0) {
                //建立链接错误close(_socket_fd)
                close(sockfd);
                NSString * result = [NSString stringWithFormat:@"%@_%.0f_%@_%@_%d_false", hostname, cost, ip, self.hip, port];
                return result;
            } else if (retval == 0) {
                // 超时
                //超时链接没有建立close(_socket_fd)
                close(sockfd);
                NSString * result = [NSString stringWithFormat:@"%@_%.0f_%@_%@_%d_false", hostname, cost, ip, self.hip, port];
                return result;
            }
            
            //将检测到_socket_fd读事件或写时间，并不能说明connect成功
            if (FD_ISSET(sockfd,&set)) {
                int error = 0;
                socklen_t len = sizeof(error);
                if (getsockopt(sockfd, SOL_SOCKET, SO_ERROR, &error, &len) < 0) {
                    //建立简介失败close(_socket_fd)
                    close(sockfd);
                    NSString * result = [NSString stringWithFormat:@"%@_%.0f_%@_%@_%d_false", hostname, cost, ip, self.hip, port];
                    return result;
                }
                if (error != 0) {
                    // 失败
                    //建立链接失败close(_socket_fd)
                    close(sockfd);
                    NSString * result = [NSString stringWithFormat:@"%@_%.0f_%@_%@_%d_false", hostname, cost, ip, self.hip, port];
                    return result;
                } else {
                    //建立链接成功
                    close(sockfd);
                    NSString* result = [NSString stringWithFormat:@"%@_%.0f_%@_%@_%d_true", hostname, cost, ip, self.hip, port];
                    return result;
                }
            } else {
                //出现错误 close(_sock_fd)
                close(sockfd);
                NSString * result = [NSString stringWithFormat:@"%@_%.0f_%@_%@_%d_false", hostname, cost, ip, self.hip, port];
                return result;
            }
        } else {
            //出现错误 close(_sock_fd)
            close(sockfd);
            NSString * result = [NSString stringWithFormat:@"%@_%.0f_%@_%@_%d_false", hostname, cost, ip, self.hip, port];
            return result;
        }
    } else {
        NSString * result = [NSString stringWithFormat:@"-1_-1_-1_-1_-1_-1"];
        return result;
    }
}

- (NSString *) connectionTime:(NSString *)hostname Port:(int)port {
    if (hostname && hostname.length > 0) {
        self.isFinished = NO;
        NSDate * time = [NSDate date];
        NSString * ip = nil;
        BOOL isIPV6Env = [GSDKInfoTool addressesForHostname:hostname ConvertString:&ip];
        if (!ip) {
            GSDKLOG(@"failed to resolve host:%@", hostname);
            return [NSString stringWithFormat:@"%@_-1", hostname];
        }
        int sockfd = 0;
        if (isIPV6Env) {
            sockfd = socket(AF_INET6, SOCK_STREAM, 0);
        } else {
            sockfd = socket(AF_INET, SOCK_STREAM, 0);
        }
        if (sockfd < 0) {
            GSDKLOG(@"failed to get sockfd:%d", sockfd);
            return [NSString stringWithFormat:@"%@_-2", hostname];
        }
        // 设置send和recv超时
        struct timeval timeout = {1,0};//1s
        int retreceive = setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, (const char *)&timeout, sizeof(timeout));
        int retsend = setsockopt(sockfd, SOL_SOCKET, SO_SNDTIMEO, (const char *)&timeout, sizeof(timeout));
        int nosigpipe = 1;
        int status = setsockopt(sockfd, SOL_SOCKET, SO_NOSIGPIPE, &nosigpipe, sizeof(nosigpipe));
        if (retreceive != 0 || retsend != 0 || status != 0) {
            close(sockfd);
            return [NSString stringWithFormat:@"%@_-3", hostname];
        }
        int error = 0;
        if (isIPV6Env) {
            // 构建目标地址
            struct sockaddr_in6 server_addr_in = {0};
            memset(&server_addr_in, 0, sizeof(struct sockaddr_in6));
            server_addr_in.sin6_family = AF_INET6;
            server_addr_in.sin6_port = htons(port);
            server_addr_in.sin6_addr = [GSDKInfoTool convertIP2V6:ip];
            error = connect(sockfd, (struct sockaddr *)&server_addr_in, sizeof(struct sockaddr_in6));
        } else {
            // 构建目标地址
            struct sockaddr_in server_addr_in = {0};
            memset(&server_addr_in, 0, sizeof(struct sockaddr_in));
            server_addr_in.sin_family = AF_INET;
            server_addr_in.sin_port = htons(port);
            server_addr_in.sin_addr.s_addr = [GSDKInfoTool convertIPAddressToBinary:ip];
            error = connect(sockfd, (struct sockaddr *)&server_addr_in, sizeof(struct sockaddr_in));
        }
        close(sockfd);
        NSTimeInterval cost = [[NSDate date] timeIntervalSinceDate:time] * 1000;
        if (cost > 1000) {
            cost = 1000;
        }
        return [NSString stringWithFormat:@"%@_%.0f", hostname, cost];
    } else {
        return @"-1";
    }
}

@end
