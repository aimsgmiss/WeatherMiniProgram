//
//  GSDKPingDetect.h
//  GSDK
//
//  Created by haoJingjing on 16/1/12.
//  Copyright © 2016年 haoJingjing. All rights reserved.
//

@interface GSDKPingDetect : NSObject

+ (id) sharedInstance;

- (void) isPingConnect: (NSString *)ip;
- (NSArray *) Completation;

@end
