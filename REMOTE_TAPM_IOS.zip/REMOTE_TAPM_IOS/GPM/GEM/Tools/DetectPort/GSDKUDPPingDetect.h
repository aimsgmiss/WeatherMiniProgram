//
//  GSDKUDPPingDetect.h
//  GSDK
//
//  Created by fu chunhui on 2018/7/31.
//  Copyright © 2018年 fu chunhui. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GSDKUDPPingDetect : NSObject

+ (id) sharedInstance;

- (void) isUDPPingConnect: (NSString *)ip;
- (NSArray *) UDPCompletation;

@end
