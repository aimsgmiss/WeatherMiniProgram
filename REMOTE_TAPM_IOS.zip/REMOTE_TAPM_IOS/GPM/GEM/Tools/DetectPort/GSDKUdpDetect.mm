//
//  UdpTest.m
//  GSDK
//
//  Created by 曹爽 on 16/3/18.
//  Copyright © 2016年 fu chunhui. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GSDKUdpDetect.h"
#import "GSDKInfoTool.h"
#import "GSDKLogger.h"
#include <arpa/inet.h>

static const int Detect_UDP_TIME_OUT = 1000;

@interface GSDKUdpDetect()

@property (nonatomic, assign, readwrite) int mSocketfd;

@end

@implementation GSDKUdpDetect

- (int) getSpeedSock {
    // 测试直连和转发网络时延均值
    if (_mSocketfd == 0) {
        self.mSocketfd = socket(PF_INET, SOCK_DGRAM, 0);
        struct timeval timeout = {0, 100 * 1000};
        int retreceive = setsockopt(self.mSocketfd, SOL_SOCKET, SO_RCVTIMEO,(const char *) &timeout, sizeof(timeout));
        int retsend = setsockopt(self.mSocketfd, SOL_SOCKET, SO_SNDTIMEO,(const char *) &timeout, sizeof(timeout));
        int nosigpipe = 1;
        int status = setsockopt(self.mSocketfd, SOL_SOCKET, SO_NOSIGPIPE, &nosigpipe, sizeof(nosigpipe));
        if (retreceive != 0 || retsend != 0 || status != 0) {
            GSDKLOG(@"Error start socket, retreceive is %d, retsend is %d, status is %d", retreceive, retsend, status);
            if (self.mSocketfd > 0) {
                close(self.mSocketfd);
            }
            self.mSocketfd = -1;
        }
    }
    return _mSocketfd;
}
- (int) getV6SpeedSock {
    // 测试直连和转发网络时延均值
    if (_mSocketfd == 0) {
        self.mSocketfd = socket(PF_INET6, SOCK_DGRAM, 0);
        struct timeval timeout = {0, 100 * 1000};
        int retreceive = setsockopt(self.mSocketfd, SOL_SOCKET, SO_RCVTIMEO,(const char *) &timeout, sizeof(timeout));
        int retsend = setsockopt(self.mSocketfd, SOL_SOCKET, SO_SNDTIMEO,(const char *) &timeout, sizeof(timeout));
        int nosigpipe = 1;
        int status = setsockopt(self.mSocketfd, SOL_SOCKET, SO_NOSIGPIPE, &nosigpipe, sizeof(nosigpipe));
        if (retreceive != 0 || retsend != 0 || status != 0) {
            GSDKLOG(@"Error start socket, retreceive is %d, retsend is %d, status is %d", retreceive, retsend, status);
            if (self.mSocketfd > 0) {
                close(self.mSocketfd);
            }
            self.mSocketfd = -1;
        }
    }
    return _mSocketfd;
}

- (void)stopSpeedTest {
    if (_mSocketfd > 0) {
        close(_mSocketfd);
    }
    [self setMSocketfd:0];
}

#pragma mark udp
- (NSString *) udpConnectTime:(NSString *)ip Port:(int)port {
    [self stopSpeedTest];
    if (!ip || [ip length] == 0 || port == 0) {
        return @"-1";
    }
    
    // step 1 域名解析
    NSString * sipv4 = nil;
    BOOL isIPV6Env = [GSDKInfoTool addressesForHostname:ip ConvertString:&sipv4];
    if (!sipv4) {
        return [NSString stringWithFormat:@"%@:%d_-1", ip, port];
    }
    GSDKLOG(@"UDP测速域名: %@, IP:%@, 测速port: %d",ip, sipv4, port);
    // step 2 创建socket
    int sockfd = 0;
    if (isIPV6Env) {
        sockfd = [self getV6SpeedSock];
    } else {
        sockfd = [self getSpeedSock];
    }
    if (sockfd <= 0) {
        [self stopSpeedTest];
        return [NSString stringWithFormat:@"%@:%d_-2", ip, port];
    }
    int tag = 0;
    int echo_time = 0;
    // step 3 测速
    if (isIPV6Env) {
        // 构建目标地址
        struct sockaddr_in6 servaddr = {0};
        memset(&servaddr, 0, sizeof(struct sockaddr_in6));
        servaddr.sin6_family = AF_INET6;
        servaddr.sin6_port = htons(port);
        servaddr.sin6_addr = [GSDKInfoTool convertIP2V6:sipv4];
        // 3次测速
        int t1 = [self udpV6Test:sockfd Tag:tag++ ServAddr:servaddr];
        int t2 = [self udpV6Test:sockfd Tag:tag++ ServAddr:servaddr];
        int t3 = [self udpV6Test:sockfd Tag:tag++ ServAddr:servaddr];
        echo_time = (t1 + t2 + t3)/3;
    } else {
        // 构建目标地址
        struct sockaddr_in servaddr = {0};
        memset(&servaddr, 0, sizeof(struct sockaddr_in));
        servaddr.sin_family = AF_INET;
        servaddr.sin_port = htons(port);
        servaddr.sin_addr.s_addr = [GSDKInfoTool convertIPAddressToBinary:sipv4];
        // 3次测速
        int t1 = [self udpV4Test:sockfd Tag:tag++ ServAddr:servaddr];
        int t2 = [self udpV4Test:sockfd Tag:tag++ ServAddr:servaddr];
        int t3 = [self udpV4Test:sockfd Tag:tag++ ServAddr:servaddr];
        echo_time = (t1 + t2 + t3)/3;
    }
    [self stopSpeedTest];
    return [NSString stringWithFormat:@"%@:%d_%d", ip, port, echo_time];
}

- (NSData *) genData:(int)tag {
    struct udpPacket udpsend;
    udpsend.seqno = (UInt32)tag;
    udpsend.svalue = 'A';
    HTONL(udpsend.seqno);
    NSData * data = [NSData dataWithBytes:&udpsend length:sizeof(udpsend)];
    return data;
}

- (int) udpV6Test:(int)sockfd Tag:(int)tag ServAddr:(struct sockaddr_in6)servaddr {
    NSData * data = [self genData:tag];
    const void * sndByte = [data bytes];
    size_t sndLen = (size_t)[data length];
    NSTimeInterval startTime = [[NSDate date] timeIntervalSince1970];
    ssize_t sendStatus = sendto(sockfd, sndByte, sndLen, 0, (struct sockaddr *)&servaddr, sizeof(struct sockaddr_in6));
    // 如果发送失败，改变fd重试一次
    int countForReSendto = 0;
    if (sendStatus < 0) {
        int currentErrno = errno;
        if (countForReSendto < 1) {
            // 锁屏状态会造成管道破坏，因此重新创建fd
            if(currentErrno == EPIPE) {
                [self stopSpeedTest];
                // 再重新生成fd
                sockfd = [self getV6SpeedSock];
                if (sockfd <= 0) {
                    return 1000;
                }
            }
            sendStatus = sendto(sockfd, sndByte, sndLen, 0, (struct sockaddr *)&servaddr, sizeof(struct sockaddr_in6));
        }
        countForReSendto++;
    }
    if (sendStatus < 0) {
        return 1000;
    }
    int echo_time = ([[NSDate date] timeIntervalSince1970] - startTime) * 1000;
    // 初始化recvbuff
    struct udpPacket recvBuff;
    memset(&recvBuff, 0, sizeof(struct udpPacket));
    size_t bufflen = sizeof(struct udpPacket);
    while (echo_time < Detect_UDP_TIME_OUT) {
        struct sockaddr_in6 sockaddr = {0};
        socklen_t sockaddrlen = sizeof(sockaddr);
        ssize_t rsize = recvfrom(sockfd, &recvBuff, bufflen, 0, (struct sockaddr *)&sockaddr, &sockaddrlen);
        echo_time = ([[NSDate date] timeIntervalSince1970] - startTime) * 1000;
        if (rsize == bufflen) {
            NTOHL(recvBuff.seqno);
            if (recvBuff.svalue == 'B' && recvBuff.seqno == tag) {
                break;
            }
        }
        continue;
    }
    if (echo_time > 1000) {
        echo_time = 1000;
    }
    return echo_time;
}

- (int) udpV4Test:(int)sockfd Tag:(int)tag ServAddr:(struct sockaddr_in)servaddr {
    NSData * data = [self genData:tag];
    const void * sndByte = [data bytes];
    size_t sndLen = (size_t)[data length];
    NSTimeInterval startTime = [[NSDate date] timeIntervalSince1970];
    ssize_t sendStatus = sendto(sockfd, sndByte, sndLen, 0, (struct sockaddr *)&servaddr, sizeof(struct sockaddr));
    // 如果发送失败，改变fd重试一次
    int countForReSendto = 0;
    if (sendStatus < 0) {
        int currentErrno = errno;
        if (countForReSendto < 1) {
            // 锁屏状态会造成管道破坏，因此重新创建fd
            if (currentErrno == EPIPE) {
                [self stopSpeedTest];
                // 再重新生成fd
                sockfd = [self getSpeedSock];
                if (sockfd <= 0) {
                    return 1000;
                }
            }
            sendStatus = sendto(sockfd, sndByte, sndLen, 0, (struct sockaddr *)&servaddr, sizeof(struct sockaddr));
        }
        countForReSendto++;
    }
    if (sendStatus < 0) {
        return 1000;
    }
    int echo_time = ([[NSDate date] timeIntervalSince1970] - startTime) * 1000;
    // 初始化recvbuff
    struct udpPacket recvBuff;
    memset(&recvBuff, 0, sizeof(struct udpPacket));
    size_t bufflen = sizeof(struct udpPacket);
    while (echo_time < Detect_UDP_TIME_OUT) {
        struct sockaddr_in sockaddr = {0};
        socklen_t sockaddrlen = sizeof(sockaddr);
        ssize_t rsize = recvfrom(sockfd, &recvBuff, bufflen, 0, (struct sockaddr *)&sockaddr, &sockaddrlen);
        echo_time = ([[NSDate date] timeIntervalSince1970] - startTime) * 1000;
        if (rsize == bufflen) {
            NTOHL(recvBuff.seqno);
            if (recvBuff.svalue == 'B' && recvBuff.seqno == tag) {
                break;
            }
        }
        continue;
    }
    if (echo_time > 1000) {
        echo_time = 1000;
    }
    return echo_time;
}

@end
