//
//  GSDKLog.m
//  GSDK
//
//  Created by 曹爽 on 16/3/24.
//  Copyright © 2016年 fu chunhui. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GSDKLogger.h"

@implementation GSDKLogger

static GSDKLogger * instance = nil;
+ (GSDKLogger *) sharedInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[GSDKLogger alloc] init];
    });
    return instance;
}

- (void) gsdkLog:(NSString *)logMsg {
    @synchronized(self) {
        if (logMsg) {
            if (_enableLog) {
                NSLog(@"%@",logMsg);
            }
        }
    }
}

@end
