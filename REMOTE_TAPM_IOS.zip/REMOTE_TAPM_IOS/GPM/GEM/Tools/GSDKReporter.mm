//
//  GSDKReporter.m
//  GSDK
//
//  Created by fu chunhui on 2018/8/8.
//  Copyright © 2018年 fu chunhui. All rights reserved.
//

#import "GSDKReporter.h"
#import "GSDKLogger.h"
#import "TDMReportHelper.h"

@implementation GSDKReporter

+ (void) gsdkReport:(NSString *)eventName Params:(NSDictionary *)params {
    if (!eventName || !params) {
        return;
    }
    GSDKLOG(@"上报结果：%@", params);
    TDMReportHelper* tdmReportHelper = [[TDMReportHelper alloc] init];
    if (tdmReportHelper) {
        GCloud::Plugin::IEvent* event = [tdmReportHelper createEventWithName:eventName];
        NSArray * keys = [params allKeys];
        for (int i = 0; i < [keys count]; i++) {
            if ([params[keys[i]] isKindOfClass:[NSNumber class]]) {
                NSString * myString = [params[keys[i]] stringValue];
                [tdmReportHelper addSS:keys[i] value:myString withEvent:event];
            } else {
                [tdmReportHelper addSS:keys[i] value:params[keys[i]] withEvent:event];
            }
        }
        [tdmReportHelper reportWithEvent:event];
        [tdmReportHelper destoryWithEvent:event];
    }
}

@end
