//
//  MSDKDnsInfoTool.m
//  MSDKDns
//
//  Created by Mike on 3/25/16.
//  Copyright © 2016 Tencent. All rights reserved.
//

#define CTL_NET         4               /* network, see socket.h */

#define ROUNDUP(a) \
((a) > 0 ? (1 + (((a) - 1) | (sizeof(long) - 1))) : sizeof(long))

#import "GSDKInfoTool.h"
#import "GSDKLogger.h"
#import "GSDKroute.h"
#import <SystemConfiguration/SCNetworkReachability.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import <CoreTelephony/CTCarrier.h>
#import <TargetConditionals.h>
#import <UIKit/UIKit.h>
#import <sys/utsname.h>
#import <netinet/in.h>
#import <sys/sysctl.h>
#import <sys/param.h>
#import <sys/mount.h>
#import <sys/ioctl.h>
#import <net/if_dl.h>
#import <arpa/inet.h>
#import <ifaddrs.h>
#import <net/if.h>
#import <stdlib.h>
#import <string.h>
#import <resolv.h>
#import <stdio.h>
#import <netdb.h>
#import <dns.h>

#import "DeviceInfoHelper.h"

static NSString * const kGSDK_QQAPPID = @"QQAppID";
static NSString * const kGSDK_WXAPPID = @"WXAppID";
static NSString * const kGSDK_MSDKOpenID = @"currentReportOpenId";

// NOTE(三合一): GCloud云控实现注入
static GemCCStrategy* gGemCCStrategy = nil;

@interface GSDK_Route_Info : NSObject
{
    struct sockaddr     m_addrs[RTAX_MAX];
    struct rt_msghdr2   m_rtm;
    int                 m_len;      /* length of the sockaddr array */
}

- initWithRtm: (struct rt_msghdr2 *) rtm;

+ (NSMutableArray *) getRoutes;
+ (nullable GSDK_Route_Info *) getRoute:(struct rt_msghdr2 *)rtm;

- (nullable NSString *) getDestination;
- (nullable NSString *) getNetmask;
- (nullable NSString *) getGateway;
- (nullable NSString *) getAddrStringByIndex: (int)rtax_index;

- (void) setAddr:(struct sockaddr *)sa index:(int)rtax_index;

@end

@implementation GSDK_Route_Info

- initWithRtm: (struct rt_msghdr2 *) rtm {
    int i;
    struct sockaddr * sa = (struct sockaddr *)(rtm + 1);
    memcpy(&(m_rtm), rtm, sizeof(struct rt_msghdr2));
    for(i = 0; i < RTAX_MAX; i++) {
        [self setAddr:&(sa[i]) index:i];
    }
    return self;
}

+ (NSMutableArray*) getRoutes {
    NSMutableArray* routeArray = [NSMutableArray array];
    GSDK_Route_Info * route = nil;
    size_t len;
    int mib[6];
    char *buf;
    struct rt_msghdr2 *rtm;
    mib[0] = CTL_NET;
    mib[1] = PF_ROUTE;
    mib[2] = 0;
    mib[3] = 0;
    mib[4] = NET_RT_DUMP2;
    mib[5] = 0;
    sysctl(mib, 6, NULL, &len, NULL, 0);
    buf = (char *)malloc(len);
    if (buf && sysctl(mib, 6, buf, &len, NULL, 0) == 0) {
        for (char * ptr = buf; ptr < buf + len; ptr += rtm->rtm_msglen) {
            rtm = (struct rt_msghdr2 *)ptr;
            route = [self getRoute:rtm];
            if(route != nil) {
                [routeArray addObject:route];
                break;
            }
        }
    }
    free(buf);
    return routeArray;
}

+ (nullable GSDK_Route_Info *) getRoute:(struct rt_msghdr2 *)rtm {
    struct sockaddr * dst_sa = (struct sockaddr *)(rtm + 1);
    GSDK_Route_Info * route = nil;
    if (rtm->rtm_addrs & RTA_DST) {
        if (dst_sa->sa_family == AF_INET && !((rtm->rtm_flags & RTF_WASCLONED) && (rtm->rtm_parentflags & RTF_PRCLONING))) {
            route = [[GSDK_Route_Info alloc] initWithRtm:rtm];
        }
    }
    return route;
}

- (void) setAddr:(struct sockaddr *)sa index:(int)rtax_index {
    if (rtax_index >= 0 && rtax_index < RTAX_MAX) {
        memcpy(&(m_addrs[rtax_index]), sa, sizeof(struct sockaddr));
    }
}

- (nullable NSString *) getDestination {
    return [self getAddrStringByIndex:RTAX_DST];
}

- (nullable NSString *) getNetmask {
    return [self getAddrStringByIndex:RTAX_NETMASK];
}

- (nullable NSString *) getGateway {
    return [self getAddrStringByIndex:RTAX_GATEWAY];
}

- (nullable NSString *) getAddrStringByIndex: (int)rtax_index {
    NSString * routeString = nil;
    int flagVal = 1 << rtax_index;
    if (!(m_rtm.rtm_addrs & flagVal)) {
        return nil;
    }
    if (rtax_index >= 0 && rtax_index < RTAX_MAX) {
        struct sockaddr* sa = &(m_addrs[rtax_index]);
        switch(sa->sa_family) {
            case AF_INET:
            {
                struct sockaddr_in * si = (struct sockaddr_in *)sa;
                if(si->sin_addr.s_addr == INADDR_ANY)
                    routeString = @"default";
                else
                    routeString = [self formatIPV4Address:si->sin_addr];
            }
                break;
            case AF_LINK:
            {
                struct sockaddr_dl * sdl = (struct sockaddr_dl *)sa;
                if(sdl->sdl_nlen + sdl->sdl_alen + sdl->sdl_slen == 0) {
                    routeString = [NSString stringWithFormat: @"link #%d", sdl->sdl_index];
                } else {
                    routeString = [NSString stringWithCString:link_ntoa(sdl) encoding:NSASCIIStringEncoding];
                }
            }
                break;
            default:
            {
                char a[3 * sa->sa_len];
                char *cp;
                char const *sep = "";
                int i;
                
                if(sa->sa_len == 0) {
                    routeString = nil;
                } else {
                    a[0] = '\0';
                    for(i = 0, cp = a; i < sa->sa_len; i++) {
                        cp += sprintf(cp, "%s%02x", sep, (unsigned char)sa->sa_data[i]);
                        sep = ":";
                    }
                    routeString = [NSString stringWithCString:a encoding:NSASCIIStringEncoding];
                }
            }
        }
    }
    
    return routeString;
}

- (NSString *) formatIPV4Address:(struct in_addr)ipv4Addr {
    NSString *address = @"";
    char dstStr[INET_ADDRSTRLEN];
    char srcStr[INET_ADDRSTRLEN];
    memcpy(srcStr, &ipv4Addr, sizeof(struct in_addr));
    if(inet_ntop(AF_INET, srcStr, dstStr, INET_ADDRSTRLEN) != NULL){
        address = [NSString stringWithUTF8String:dstStr];
    } else {
        GSDKLOG(@"[ERROR]: Failed to convert ipv4 from in_addr to NSString");
    }
    return address;
}

@end


static NSString * _total_storage = nil;

@implementation GSDKInfoTool

+ (NSString *) openID {
    NSString * openID = @"UNKNOWN";
    NSString * gsdkStr = [[NSUserDefaults standardUserDefaults] valueForKey:kGSDKOpenID];
    //取MSDK存储的openID
    NSString * tempStr = [[NSUserDefaults standardUserDefaults] valueForKey:kGSDK_MSDKOpenID];
    if (gsdkStr && [gsdkStr length] > 0) {
        openID = gsdkStr;
    } else if (tempStr && tempStr.length > 0) {
        openID = tempStr;
    }
    return openID;
}

//+ (NSString *) dnsIP {
//    /// 获取本机DNS服务器
//    res_state res = (res_state)malloc(sizeof(struct __res_state));
//    int result = res_ninit(res);
//    NSMutableArray * dnsArray = @[].mutableCopy;
//    if (result == 0) {
//        for (int i = 0; i < res->nscount; i++) {
//            char addrNamev4[INET_ADDRSTRLEN];
//            NSString * s = [NSString stringWithUTF8String:inet_ntop(AF_INET, &res->nsaddr_list[i].sin_addr, addrNamev4, INET_ADDRSTRLEN)];
//            [dnsArray addObject:s];
//        }
//    } else {
//        GSDKLOG(@"%@",@" res_init result != 0");
//    }
//    res_nclose(res);
//    NSString * dnsIP = @"";
//    if ([dnsArray count] > 0) {
//        dnsIP = dnsArray[0];
//        for (int i = 1; i < [dnsArray count]; i++) {
//            dnsIP = [NSString stringWithFormat:@"%@,%@", dnsIP, dnsArray[i]];
//        }
//    }
//    return dnsIP;
//}

+ (NSString *) dnsIP {
    /// 获取本机DNS服务器
    __block NSString * dnsIP = @"";
    dispatch_group_t group = dispatch_group_create();
    dispatch_group_async(group, dispatch_get_global_queue(0, 0), ^{
        res_state res = (res_state)malloc(sizeof(struct __res_state));
        int result = res_ninit(res);
        NSMutableArray * dnsArray = @[].mutableCopy;
        if (result == 0) {
            for (int i = 0; i < res->nscount; i++) {
                char addrNamev4[INET_ADDRSTRLEN];
                if (inet_ntop(AF_INET, &res->nsaddr_list[i].sin_addr, addrNamev4, INET_ADDRSTRLEN) != NULL) {
                    NSString * s = [NSString stringWithUTF8String:addrNamev4];
                    if (s) {
                        [dnsArray addObject:s];
                    }
                }
            }
        } else {
            GSDKLOG(@"%@",@" res_init result != 0");
        }
        res_nclose(res);
        if ([dnsArray count] > 0) {
            dnsIP = [NSString stringWithFormat:@"%@", dnsArray[0]];
            for (int i = 1; i < [dnsArray count]; i++) {
                dnsIP = [NSString stringWithFormat:@"%@,%@", dnsIP, dnsArray[i]];
            }
        }
    });
    dispatch_group_wait(group, dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)));
    return dnsIP;
}

+ (NSString*) netType {
#if TARGET_IPHONE_SIMULATOR
    return @"iphonesimulator";
#else
    NSString *networkType = @"UNKNOWN";
    if ([GSDKInfoTool activeWLAN]) {
        GSDKLOG(@"The NetType is WIFI");
        return @"wifi";
    }
    if ([GSDKInfoTool activeWWAN]) {
#ifdef __IPHONE_7_0
        //iOS7及以上版本可获取到，以下版本不获取
        if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0) {
            CTTelephonyNetworkInfo *telephonyInfo = [CTTelephonyNetworkInfo new];
            NSString *networkModel = telephonyInfo.currentRadioAccessTechnology;
            if ([networkModel isEqualToString:CTRadioAccessTechnologyLTE]){
                networkType = @"4G";
            } else if ([networkModel isEqualToString:CTRadioAccessTechnologyGPRS] ||
                       [networkModel isEqualToString:CTRadioAccessTechnologyEdge]) {
                networkType = @"2G";
            } else if ([networkModel isEqualToString:CTRadioAccessTechnologyWCDMA] ||
                       [networkModel isEqualToString:CTRadioAccessTechnologyEdge] ||
                       [networkModel isEqualToString:CTRadioAccessTechnologyHSDPA] ||
                       [networkModel isEqualToString:CTRadioAccessTechnologyHSUPA] ||
                       [networkModel isEqualToString:CTRadioAccessTechnologyCDMA1x] ||
                       [networkModel isEqualToString:CTRadioAccessTechnologyCDMAEVDORev0] ||
                       [networkModel isEqualToString:CTRadioAccessTechnologyCDMAEVDORevA] ||
                       [networkModel isEqualToString:CTRadioAccessTechnologyCDMAEVDORevB] ||
                       [networkModel isEqualToString:CTRadioAccessTechnologyeHRPD]){
                networkType = @"3G";
            }
        }
#else
        else {
            networkType = @"3G";
            if ([GSDKInfoTool is2G]) {
                networkType = @"2G";
            }
        }
#endif
    }
    return networkType;
#endif
}

static SCNetworkConnectionFlags ana_connectionFlags;
+ (BOOL) networkAvaliable {
#ifdef ANA_UNIT_TEST
    return YES;
#else
    SCNetworkReachabilityRef defaultRouteReachablilty = SCNetworkReachabilityCreateWithName(kCFAllocatorDefault, "www.qq.com");
    BOOL didRetrieveFlags = SCNetworkReachabilityGetFlags(defaultRouteReachablilty, &ana_connectionFlags);
    
    CFRelease(defaultRouteReachablilty);
    if(!didRetrieveFlags) {
        GSDKLOG("Error. Could not recover flags\n");
    }
    BOOL isReachable = ((ana_connectionFlags & kSCNetworkFlagsReachable) != 0);
    BOOL needConnection = ((ana_connectionFlags & kSCNetworkFlagsConnectionRequired) != 0);
    return (isReachable && !needConnection) ? YES : NO;
#endif
}

+ (BOOL) activeWWAN {
#ifdef ANA_UNIT_TEST
    return YES;
#else
    if (![self networkAvaliable]) return NO;
    return ((ana_connectionFlags & kSCNetworkReachabilityFlagsIsWWAN) != 0) ? YES : NO;
#endif
}

+ (BOOL) activeWLAN {
    if (![GSDKInfoTool networkAvaliable]) return NO;
    return ([GSDKInfoTool localWiFiIPAddress] != nil) ? YES : NO;
}

+ (NSString *) localWiFiIPAddress {
    BOOL success;
    struct ifaddrs * addrs;
    const struct ifaddrs * cursor;
    NSString * waddr = nil;
    
    success = (getifaddrs(&addrs) == 0);
    if (success) {
        cursor = addrs;
        while (cursor != NULL) {
            if (cursor->ifa_addr->sa_family == AF_INET && (cursor->ifa_flags & IFF_LOOPBACK) == 0) {
                NSString * name = [NSString stringWithUTF8String:cursor->ifa_name];
                if ([name isEqualToString:@"en0"]) {//Wifi adapter
                    char addrNamev4[INET_ADDRSTRLEN];
                    const struct sockaddr_in * ipv4 = (const struct sockaddr_in *)cursor->ifa_addr;
                    waddr = [NSString stringWithUTF8String:inet_ntop(ipv4->sin_family, &(ipv4->sin_addr), addrNamev4, INET_ADDRSTRLEN)];
                    GSDKLOG(@"local本机地址ipv4-----%@",waddr);
                    break;
                }
            }
            else if (cursor->ifa_addr->sa_family == AF_INET6 && (cursor->ifa_flags & IFF_LOOPBACK) == 0) {
                NSString * name = [NSString stringWithUTF8String:cursor->ifa_name];
                if ([name isEqualToString:@"en0"]) {//Wifi adapter
                    char addrNamev6[INET6_ADDRSTRLEN];
                    const struct sockaddr_in6 * ipv6 = (const struct sockaddr_in6*)cursor->ifa_addr;
                    waddr = [NSString stringWithUTF8String:inet_ntop(ipv6->sin6_family, &(ipv6->sin6_addr), addrNamev6, INET6_ADDRSTRLEN)];
                    GSDKLOG(@"local本机地址ipv6-----%@",waddr);
                }
            }
            cursor = cursor->ifa_next;
        }
        freeifaddrs(addrs);
    }
    GSDKLOG(@"return %@",waddr);
    return waddr;
}

+ (NSString *) routerIPAddress {
    if ([[self netType] isEqualToString:@"wifi"]) {
        return [self wiFiRouterAddress];
    }
    return nil;
}

+ (NSString *) wiFiRouterAddress {
    // Get the WiFi Router Address
    @try {
        // Set the ip address variable
        NSString * routerIP = nil;
        // Set the router array variable with the routing information
        NSMutableArray *routerArray = [GSDK_Route_Info getRoutes];
        // Run through the array
        for(int i = 0; i < (int)[routerArray count]; i++) {
            // Set the router info
            GSDK_Route_Info * router = (GSDK_Route_Info *)[routerArray objectAtIndex:i];
            routerIP = [router getGateway];
        }
        // Return Successful
        return routerIP;
    }
    @catch (NSException * exception) {
        // Error
        return nil;
    }
}

+ (NSString *) netMask {
    BOOL success;
    struct ifaddrs * addrs;
    const struct ifaddrs * cursor;
    NSString * netMask = nil;
    
    success = (getifaddrs(&addrs) == 0);
    if (success) {
        cursor = addrs;
        while (cursor != NULL) {
            if (cursor->ifa_addr->sa_family == AF_INET && (cursor->ifa_flags & IFF_LOOPBACK) == 0) {
                NSString * name = [NSString stringWithUTF8String:cursor->ifa_name];
                if ([name isEqualToString:@"en0"]) {//Wifi adapter
                    char addrNamev4[INET_ADDRSTRLEN];
                    const struct sockaddr_in * ipv4 = (const struct sockaddr_in *)cursor->ifa_netmask;
                    netMask = [NSString stringWithUTF8String:inet_ntop(ipv4->sin_family, &(ipv4->sin_addr), addrNamev4, INET_ADDRSTRLEN)];
                    GSDKLOG(@"local子网掩码地址ipv4-----%@",netMask);
                    break;
                }
            }
            else if (cursor->ifa_addr->sa_family == AF_INET6 && (cursor->ifa_flags & IFF_LOOPBACK) == 0) {
                NSString * name = [NSString stringWithUTF8String:cursor->ifa_name];
                if ([name isEqualToString:@"en0"]) {//Wifi adapter
                    char addrNamev6[INET6_ADDRSTRLEN];
                    const struct sockaddr_in6 * ipv6 = (const struct sockaddr_in6*)cursor->ifa_netmask;
                    netMask = [NSString stringWithUTF8String:inet_ntop(ipv6->sin6_family, &(ipv6->sin6_addr), addrNamev6, INET6_ADDRSTRLEN)];
                    GSDKLOG(@"local子网掩码地址ipv6-----%@",netMask);
                }
            }
            cursor = cursor->ifa_next;
        }
        freeifaddrs(addrs);
    }
    GSDKLOG(@"return %@",netMask);
    return netMask;
}

+ (BOOL) is2G {
    if (![GSDKInfoTool networkAvaliable]) {
        return NO;
    }
    if ((ana_connectionFlags & kSCNetworkReachabilityFlagsIsWWAN) == 0) {
        return NO;
    }
    if((ana_connectionFlags & kSCNetworkReachabilityFlagsTransientConnection) == kSCNetworkReachabilityFlagsTransientConnection)  {
        return YES;
    }
    return NO;
}

+ (BOOL) isIPLegal:(NSString *)ip errorInfo:(NSString **)errorInfo {
    BOOL isIPLegal = YES;
    NSArray *tempArray = [ip componentsSeparatedByString:@"."];
    if (tempArray.count == 4){
        for (NSString *unitStr in tempArray){
            int unitIntValue = unitStr.intValue;
            if (unitIntValue < 0 || unitIntValue > 255) {
                isIPLegal = NO;
                *errorInfo = [NSString stringWithFormat:@"IP illegal:%@",ip];
                break;
            }
        }
    } else {
        isIPLegal = NO;
        *errorInfo = [NSString stringWithFormat:@"IP illegal:%@",ip];
    }
    return isIPLegal;
}

unsigned char * getdefaultgateway(in_addr_t * addr) {
    unsigned char * octet=(unsigned char *)malloc(4);
#if 0
    /* net.route.0.inet.dump.0.0 ? */
    int mib[] = {CTL_NET, PF_ROUTE, 0, AF_INET,
        NET_RT_DUMP, 0, 0/*tableid*/};
#endif
    /* net.route.0.inet.flags.gateway */
    int mib[] = {CTL_NET, PF_ROUTE, 0, AF_INET,
        NET_RT_FLAGS, RTF_GATEWAY};
    size_t l;
    char * buf, * p;
    struct rt_msghdr * rt;
    struct sockaddr * sa;
    struct sockaddr * sa_tab[RTAX_MAX];
    int i;
    if (sysctl(mib, sizeof(mib)/sizeof(int), 0, &l, 0, 0) < 0) {
        return octet;
    }
    if (l>0) {
        buf = (char *)malloc(l);
        if (sysctl(mib, sizeof(mib)/sizeof(int), buf, &l, 0, 0) < 0) {
            return octet;
        }
        for (p=buf; p<buf+l; p+=rt->rtm_msglen) {
            rt = (struct rt_msghdr *)p;
            sa = (struct sockaddr *)(rt + 1);
            for (i=0; i<RTAX_MAX; i++) {
                if (rt->rtm_addrs & (1 << i)) {
                    sa_tab[i] = sa;
                    sa = (struct sockaddr *)((char *)sa + ROUNDUP(sa->sa_len));
                } else {
                    sa_tab[i] = NULL;
                }
            }
            if (((rt->rtm_addrs & (RTA_DST|RTA_GATEWAY)) == (RTA_DST|RTA_GATEWAY))
               && sa_tab[RTAX_DST]->sa_family == AF_INET
               && sa_tab[RTAX_GATEWAY]->sa_family == AF_INET) {
                for (int i=0; i<4; i++){
                    octet[i] = ( ((struct sockaddr_in *)(sa_tab[RTAX_GATEWAY]))->sin_addr.s_addr >> (i*8) ) & 0xFF;
                }
            }
        }
        free(buf);
    }
    return octet;
}

//手机剩余空间
+ (NSString *) freeDiskSpaceInBytes {
    
    NSURL *fileUrl = [NSURL fileURLWithPath:NSHomeDirectory()];
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 11.0) {
        NSDictionary *spaceDict = [fileUrl resourceValuesForKeys:@[NSURLVolumeAvailableCapacityForImportantUsageKey] error:nil];
        if (spaceDict && spaceDict[NSURLVolumeAvailableCapacityForImportantUsageKey] && [spaceDict[NSURLVolumeAvailableCapacityForImportantUsageKey] longLongValue] > 0) {
            return [self humanReadableStringFromBytes:[spaceDict[NSURLVolumeAvailableCapacityForImportantUsageKey] longLongValue]];
        }
    } else {
        NSDictionary * fattributes = [[NSFileManager defaultManager] attributesOfFileSystemForPath:NSHomeDirectory() error:nil];
        if (fattributes && [fattributes objectForKey:NSFileSystemFreeSize] && ([[fattributes objectForKey:NSFileSystemFreeSize] longLongValue] > 0)) {
            long long freespace = [[fattributes objectForKey:NSFileSystemFreeSize] longLongValue];
            return [self humanReadableStringFromBytes:freespace];
        }
    }
    return @"-1";
}

//手机总空间
+ (NSString *) totalDiskSpaceInBytes {
    // TODO: 确认TDM静态数据采集单位
    // NOTE(三合一): 优先使用TDM静态数据采集
    return [NSString stringWithFormat:@"%d", DeviceInfo::DeviceInfoHelper::getDeviceTotalSpace()];
}

//计算文件大小
+ (NSString *) humanReadableStringFromBytes:(unsigned long long)byteCount {
    float numberOfBytes = byteCount;
    return [NSString stringWithFormat:@"%.0f",numberOfBytes/1024.0 /1024.0];
}

+ (BOOL) addressesForHostname:(NSString *)hostname ConvertString:(NSString **)convertString {
    if (!hostname) {
        if (convertString) {
            *convertString = nil;
        }
        return NO;
    }
    const char * hostnameC = [hostname UTF8String];
    
    struct addrinfo hints, *res, *res0;
    struct sockaddr_in *s4;
    struct sockaddr_in6 *s6;
    int retval;
    char buf[64];
    
    memset (&hints, 0, sizeof (struct addrinfo));
    hints.ai_family = PF_UNSPEC;//AF_INET6;
    hints.ai_flags = AI_CANONNAME;
    //AI_ADDRCONFIG, AI_ALL, AI_CANONNAME,  AI_NUMERICHOST
    //AI_NUMERICSERV, AI_PASSIVE, OR AI_V4MAPPED
    
    retval = getaddrinfo(hostnameC, NULL, &hints, &res0);
    if (retval == 0) {
        for (res = res0; res; res = res->ai_next) {
            switch (res->ai_family){
                case AF_INET6:
                    s6 = (struct sockaddr_in6 *)res->ai_addr;
                    if (inet_ntop(res->ai_family, (void *)&(s6->sin6_addr), buf, sizeof(buf)) == NULL) {
                        NSLog(@"inet_ntop failed for v6!\n");
                    } else {
                        if (convertString) {
                            *convertString = [NSString stringWithUTF8String:buf];
                        }
                        freeaddrinfo(res0);
                        return YES;
                    }
                    break;
                case AF_INET:
                    s4 = (struct sockaddr_in *)res->ai_addr;
                    if (inet_ntop(res->ai_family, (void *)&(s4->sin_addr), buf, sizeof(buf)) == NULL) {
                        NSLog(@"inet_ntop failed for v4!\n");
                    } else {
                        if (convertString) {
                            *convertString = [NSString stringWithUTF8String:buf];
                        }
                        freeaddrinfo(res0);
                        return NO;
                    }
                    break;
                default:
                    NSLog(@"Neither IPv4 nor IPv6!");
            }
        }
        freeaddrinfo(res0);
    }
    if (convertString) {
        *convertString = nil;
    }
    return NO;
}

+ (NSString *) platApi {
    return [UIDevice currentDevice].systemVersion;
}

+ (NSString *) phoneModel {
    // NOTE(三合一): 优先使用TDM静态数据采集
    NSString * platform = DeviceInfo::DeviceInfoHelper::getDeviceModelFromTDM();
    if (!platform) {
        struct utsname systemInfo;
        uname(&systemInfo);
        platform = [NSString stringWithCString:systemInfo.machine encoding:NSASCIIStringEncoding];
    }
    return platform;
}

+ (NSString *) carrierName {
    CTTelephonyNetworkInfo * info = [[CTTelephonyNetworkInfo alloc] init];
    CTCarrier * carrier = [info subscriberCellularProvider];
    //当前手机所属运营商名称
    NSString * mobile = @"UNKNOWN";
    //先判断有没有SIM卡，如果没有则不获取本机运营商
    if (!carrier.isoCountryCode) {
        GSDKLOG(@"没有SIM卡");
        mobile = @"无运营商";
    } else {
        if (carrier.carrierName) {
            mobile = carrier.carrierName;
        }
    }
    return mobile;
}

+ (struct in6_addr) convertIP2V6:(NSString *) ipv6 {
    struct in6_addr ipv6_addr = {0};
    int v6_r = inet_pton(AF_INET6, [ipv6 UTF8String], &ipv6_addr);
    if (v6_r == 0) {
        GSDKLOG(@"[MNA]inet_pton error, return 0");
    }
    return ipv6_addr;
}

+ (in_addr_t) convertIPAddressToBinary:(NSString *)ipAddress {
    struct in_addr resultAddr;
    const char * ipUtf8String = [ipAddress UTF8String];
    size_t len = strlen(ipUtf8String) + 1;
    char ipArrary [len];
    memcpy(ipArrary, ipUtf8String, len);
    int ret = inet_pton(AF_INET, ipArrary, (void *)&resultAddr);
    if (ret == 0) {
        GSDKLOG(@"[MNA]inet_pton error, return 0");
    } else {
        GSDKLOG(@"inet_pton ip: %u", resultAddr.s_addr);
    }
    return resultAddr.s_addr;
}

// 全局队列
+ (dispatch_queue_t) gsdk_queue {
    static dispatch_queue_t gsdk_queue;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        gsdk_queue = dispatch_queue_create("com.tencent.gsdk", DISPATCH_QUEUE_SERIAL);
    });
    return gsdk_queue;
}

+ (dispatch_queue_t) gsdk_event_queue {
    static dispatch_queue_t gsdk_event_queue;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        gsdk_event_queue = dispatch_queue_create("com.tencent.gsdk.event", DISPATCH_QUEUE_SERIAL);
    });
    return gsdk_event_queue;
}

+ (dispatch_queue_t) gsdk_quality_queue {
    static dispatch_queue_t gsdk_quality_queue;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        gsdk_quality_queue = dispatch_queue_create("com.tencent.gsdk.quality", DISPATCH_QUEUE_SERIAL);
    });
    return gsdk_quality_queue;
}

+ (dispatch_queue_t) gsdk_udpArray_queue {
    static dispatch_queue_t gsdk_udpArray_queue;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        gsdk_udpArray_queue = dispatch_queue_create("com.tencent.gsdk.udpArray", DISPATCH_QUEUE_SERIAL);
    });
    return gsdk_udpArray_queue;
}

// NOTE(三合一): GCloud云控实现注入
+ (void) setGemCCStrategy:(GemCCStrategy *)gemCCStrategy {
    gGemCCStrategy = gemCCStrategy;
}

+ (GemCCStrategy *) getGemCCStrategy {
    return gGemCCStrategy;
}

@end
