//
//  GSDKLog.h
//  GSDK
//
//  Created by 曹爽 on 16/3/24.
//  Copyright © 2016年 fu chunhui. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GSDKPrivate.h"

#ifndef GSDKLOG
#define GSDKLOG(xx, ...) [[GSDKLogger sharedInstance] gsdkLog:[NSString stringWithFormat:@"%s*** " xx, __PRETTY_FUNCTION__, ##__VA_ARGS__]]
#endif

@interface GSDKLogger : NSObject

@property (nonatomic,assign) BOOL enableLog;

+ (GSDKLogger *) sharedInstance;
- (void) gsdkLog:(NSString *)logMsg;

@end
