//
//  GSDKReporter.h
//  GSDK
//
//  Created by fu chunhui on 2018/8/8.
//  Copyright © 2018年 fu chunhui. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GSDKReporter : NSObject

+ (void) gsdkReport:(NSString *)eventName Params:(NSDictionary *)params;

@end
