//
//  AESTool.h
//  GSDK
//
//  Created by 曹爽 on 16/4/12.
//  Copyright © 2016年 fu chunhui. All rights reserved.
//

@interface GSDKAESEncrypt : NSObject

+ (NSString *) GSDKAES128Encrypt:(NSString *)plainText;

+ (NSString *) GSDKAES128Decrypt:(NSString *)encryptText;

+ (BOOL) validGSDKKey:(NSString *)key;

@end
