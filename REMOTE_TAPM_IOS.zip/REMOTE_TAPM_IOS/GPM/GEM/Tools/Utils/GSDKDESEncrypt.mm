//
//  GSDKDESEncrypt.m
//  GSDK
//
//  Created by 曹爽 on 2016/10/12.
//  Copyright © 2016年 fu chunhui. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GSDKDESEncrypt.h"
#import "GSDKLogger.h"
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonCrypto.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <err.h>

@implementation GSDKDESEncrypt

char GSDKDnsByteToHexByte(char byte) {
    if (byte < 10) {
        return byte + '0';
    }
    return byte - 10 + 'a';
}

void GSDKDnsByteToHexChar(char byte, char *hex) {
    hex[0] = GSDKDnsByteToHexByte((byte >> 4) & 0x0F);
    hex[1] = GSDKDnsByteToHexByte(byte & 0x0F);
}

NSString *GSDKDnsDataToHexString(NSData *data) {
    char hex[data.length * 2 + 1];
    const char *bytes = (const char *)data.bytes;
    for (NSUInteger i = 0; i < data.length; ++i) {
        GSDKDnsByteToHexChar(bytes[i], &hex[i * 2]);
    }
    hex[data.length * 2] = 0;
    return [NSString stringWithUTF8String:hex];
}

char GSDKDnsHexByteToChar(char hex) {
    if (hex >= '0' && hex <= '9') {
        return hex - '0';
    }
    if (hex >= 'a' && hex <= 'f') {
        return hex - 'a' + 10;
    }
    if (hex >= 'A' && hex <= 'F') {
        return hex - 'A' + 10;
    }
    return 0;
}

char GSDKDnsHexCharToChar(char high, char low) {
    high = GSDKDnsHexByteToChar(high);
    low = GSDKDnsHexByteToChar(low);
    return (high << 4) | low;
}

+ (NSString *) GSDKDES128Encrypt:(NSString *)plainText key:(NSString *)key {
    NSData *srcData = [plainText dataUsingEncoding:NSUTF8StringEncoding];
    size_t dataOutAvilable = ([srcData length] + kCCBlockSizeDES) & ~(kCCBlockSizeDES - 1);
    unsigned char dataOut[dataOutAvilable];
    memset(dataOut, 0x0, dataOutAvilable);
    size_t dataOutMoved = 0;
    
    char encryptKey[kCCKeySizeDES] = {0};
    strncpy(encryptKey, [key UTF8String], kCCKeySizeDES);//???: 有风险
    
    CCCryptorStatus ccStatus = CCCrypt(kCCEncrypt,
                                       kCCAlgorithmDES,
                                       kCCOptionPKCS7Padding | kCCOptionECBMode,
                                       encryptKey,
                                       kCCKeySizeDES,
                                       NULL,
                                       srcData.bytes,
                                       srcData.length,
                                       dataOut,
                                       dataOutAvilable,
                                       &dataOutMoved);
    if (ccStatus == kCCSuccess) {
        NSData *resultData = [NSData dataWithBytes:dataOut length:(NSUInteger)dataOutMoved];
        return GSDKDnsDataToHexString(resultData);
    }
    return nil;
}

+ (NSString *) GSDKDES128Decrypt:(NSString *)cipherString key:(NSString *)key {
    if (cipherString && key) {
        const char *tempBytes = [cipherString UTF8String];
        NSUInteger tempLength = [cipherString length];
        if (tempLength > 0) {
            NSUInteger dataLength = tempLength / 2;
            char textBytes[dataLength];
            for (int i  = 0; i < tempLength - 1; i = i + 2) {
                char high = tempBytes[i];
                char low = tempBytes[i + 1];
                char hex = GSDKDnsHexCharToChar(high, low);
                textBytes[i / 2] = hex;
            }
            
            size_t dataOutAvilable = (dataLength + kCCBlockSizeDES) & ~(kCCBlockSizeDES - 1);
            unsigned char dataOut[dataOutAvilable];
            memset(dataOut, 0x0, dataOutAvilable);
            size_t dataOutMoved = 0;
            
            char decryptKey[kCCKeySizeDES] = {0};
            strncpy(decryptKey, [key UTF8String], kCCKeySizeDES);//???: 有风险
            CCCryptorStatus ccStatus = CCCrypt(kCCDecrypt,
                                               kCCAlgorithmDES,
                                               kCCOptionPKCS7Padding | kCCOptionECBMode,
                                               decryptKey,
                                               kCCKeySizeDES,
                                               NULL,
                                               textBytes,
                                               dataLength,
                                               dataOut,
                                               dataOutAvilable,
                                               &dataOutMoved);
            
            NSString *plainText = nil;
            if (ccStatus == kCCSuccess) {
                NSData *data = [NSData dataWithBytes:dataOut length:(NSUInteger)dataOutMoved];
                if (data) {
                    plainText = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                }
            }
            return plainText;
        }
    }
    return nil;
}

+ (NSURL *) httpDnsUrlWithDomain:(NSString *)domain {
    if (!domain || domain.length == 0) {
        GSDKLOG(@"HttpDns Domain is must needed!");
        return nil;
    }
    
    //域名需DES加密，内外部加密秘钥以及url字段需要区分
    NSString *domainEncrypStr = [self GSDKDES128Encrypt:domain key:HTTP_DNS_DOMAIN_ENCRYPT_KEY];
    
    if (domainEncrypStr && domainEncrypStr.length > 0) {
        NSString *httpServer = [self getIPv6:[HTTP_DNS_HTTP_SERVER UTF8String]];
        NSString *urlStr = [NSString stringWithFormat:@"https://%@/d?dn=%@&clientip=1&ttl=1&id=1",httpServer, domainEncrypStr];
        NSURL *url = [NSURL URLWithString:urlStr];
        GSDKLOG(@"%@",url);
        return url;
    } else {
        GSDKLOG(@"HttpDns Domain Crypt Error!");
    }
    
    return nil;
}

+ (NSString *) getIPv6: (const char *)mHost {
    if (NULL == mHost)
        return nil;
    const char * newChar = "No";
    struct addrinfo * res0;
    struct addrinfo hints;
    struct addrinfo * res;
    int n, s;
    
    memset(&hints, 0, sizeof(hints));
    
    hints.ai_flags = AI_DEFAULT;
    hints.ai_family = PF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    
    n = getaddrinfo(mHost, "http", &hints, &res0);
    if (n != 0) {
        printf("getaddrinfo error: %s\n",gai_strerror(n));
        return nil;
    }
    
    struct sockaddr_in6 * addr6;
    struct sockaddr_in * addr;
    NSString * NewStr = nil;
    char ipbuf[32];
    s = -1;
    for (res = res0; res; res = res->ai_next) {
        if (res->ai_family == AF_INET6) {
            addr6 = (struct sockaddr_in6 *)res->ai_addr;
            newChar = inet_ntop(AF_INET6, &addr6->sin6_addr, ipbuf, sizeof(ipbuf));
            if (newChar != NULL) {
                NSString * TempA = [[NSString alloc] initWithCString:(const char *)newChar encoding:NSASCIIStringEncoding];
                if (TempA) {
                    NewStr = [NSString stringWithFormat:@"[%@]", TempA];
                    break;
                }
            }
        } else if (res->ai_family == AF_INET) {
            addr = (struct sockaddr_in *)res->ai_addr;
            newChar = inet_ntop(AF_INET, &addr->sin_addr, ipbuf, sizeof(ipbuf));
            if (newChar != NULL) {
                NSString * TempA = [[NSString alloc] initWithCString:(const char *)newChar encoding:NSASCIIStringEncoding];
                if (TempA) {
                    NewStr = TempA;
                    break;
                }
            }
        } else {
            GSDKLOG(@"Neither IPv4 nor IPv6!");
        }
    }
    freeaddrinfo(res0);
    return NewStr;
}

@end
