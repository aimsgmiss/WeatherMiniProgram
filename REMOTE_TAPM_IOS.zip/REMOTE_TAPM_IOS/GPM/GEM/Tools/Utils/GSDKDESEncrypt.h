//
//  GSDKDESEncrypt.h
//  GSDK
//
//  Created by 曹爽 on 2016/10/12.
//  Copyright © 2016年 fu chunhui. All rights reserved.
//

#ifndef GSDKDESEncrypt_h
#define GSDKDESEncrypt_h

@interface GSDKDESEncrypt : NSObject

+ (NSURL *) httpDnsUrlWithDomain:(NSString *)domain;
+ (NSString *)GSDKDES128Decrypt:(NSString *)cipherString key:(NSString *)key;

@end

#endif /* GSDKDESEncrypt_h */
