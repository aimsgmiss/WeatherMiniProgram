//
//  GSDKLoginPayDetect.h
//  GSDK
//
//  Created by fu chunhui on 2017/3/2.
//  Copyright © 2017年 fu chunhui. All rights reserved.
//

#ifndef GSDKLoginPayDetect_h
#define GSDKLoginPayDetect_h

@interface GSDKLoginPayDetect : NSObject

- (void) detectPort:(NSString *) domain1 Port1:(NSString *)port1 Domain2:(NSString *)domain2 Port2:(NSString *)port2 Domain3:(NSString *)domain3 Port3:(NSString *)port3 Domain4:(NSString *)domain4 Port4:(NSString *)port4 Domain5:(NSString *)domain5 Port5:(NSString *)port5 Domain6:(NSString *)domain6 Port6:(NSString *)port6;
- (void) detectPayPort;

@end

#endif /* GSDKLoginPayDetect_h */
