//
//  GSDKInitManager.m
//  GSDK
//
//  Created by fu chunhui on 2017/3/2.
//  Copyright © 2017年 fu chunhui. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GSDKLoginPayDetect.h"
#import "GSDKUDPPingDetect.h"
#import "GSDKInitManager.h"
#import "GSDKPingDetect.h"
#import "GSDKDetectPort.h"
#import "GSDKUdpDetect.h"
#import "GSDKReporter.h"
#import "GSDKInfoTool.h"
#import "GSDKReporter.h"
#import "GSDKCallRecorder.h"
#import <UIKit/UIKit.h>
#import "TApmApiSingleInstance.h"
// 登录
static NSString * const kGSDKLogin = @"login";
static NSString * const kGSDKPay = @"pay";
static NSString * const kGSDKDomain = @"domain";
static NSString * const kGSDKDomain1 = @"domain1";
static NSString * const kGSDKDomain2 = @"domain2";
static NSString * const kGSDKDomain3 = @"domain3";
static NSString * const kGSDKDomain4 = @"domain4";
static NSString * const kGSDKDomain5 = @"domain5";
static NSString * const kGSDKDomain6 = @"domain6";
static NSString * const kGSDKPort1 = @"port1";
static NSString * const kGSDKPort2 = @"port2";
static NSString * const kGSDKPort3 = @"port3";
static NSString * const kGSDKPort4 = @"port4";
static NSString * const kGSDKPort5 = @"port5";
static NSString * const kGSDKPort6 = @"port6";

// NOTE(三合一): 常量定义
static NSString * const TCP_DETECT_TARGETS_NAME = @"tcp";
static NSString * const UDP_DETECT_TARGETS_NAME = @"udp";

// 登录云控json字段: 启动测试协议
static NSString * const START_DETECT_CHANNEL_NAME = @"up_protocol";
static NSString * const TCP_DETECT_CHANNEL_NAME = @"tcp";
static NSString * const UDP_DETECT_CHANNEL_NAME = @"udp";
static NSString * const NONE_DETECT_CHANNEL_NAME = @"down";

// 登录云控json字段: 模块调用上报频率
static NSString * const CALL_REPORT_INTERVAL_SEC_NAME = @"mode_freq";

// 开关记忆功能存储键值
static NSString * const kGSDKLoginSwitch = @"GSDKLoginSwitch";

static const int Detect_PING_TIME_OUT = 1;
static const int Detect_TCP_TIME_OUT = 1;// todo
static const float Detect_Buffer = 0.5;

@interface GSDKInitManager()

@property (nonatomic, readwrite, assign) BOOL login_flag;
@property (nonatomic, readwrite, assign) BOOL pay_flag;
@property (nonatomic, readwrite, assign) BOOL domain_flag;

@property (nonatomic, readwrite, strong) NSArray * udpArray;
@property (nonatomic, readwrite, strong) NSArray * tcpArray;

@end

@implementation GSDKInitManager

static GSDKInitManager * _sharedInstance = nil;
//方法实现
+ (id) sharedInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[GSDKInitManager alloc] init];
    });
    return _sharedInstance;
}

- (void) GSDKInit:(BOOL)debug {
    if (![[NSUserDefaults standardUserDefaults] stringForKey:kGSDKCreateTime]) {
        NSTimeInterval create_Time = [[NSDate date] timeIntervalSince1970];
        [[NSUserDefaults standardUserDefaults] setValue:[NSString stringWithFormat:@"%.0f", create_Time] forKey:kGSDKCreateTime];
    }
    self.login_flag = YES;
    self.pay_flag = YES;
    self.domain_flag = NO;
    [[GSDKLogger sharedInstance] setEnableLog:debug];
    // TODO: NOTE(三合一): 版本号确认
    NSLog(@"[Info] GSDKInit Version:%@", GSDK_VERSION);
    NSString * createTime = [[NSUserDefaults standardUserDefaults] stringForKey:kGSDKCreateTime];
    if (!createTime) {
        createTime = @"UNKNOWN";
    }
    NSDictionary * initDict = @{kGSDKCreateTime: createTime, kGSDKDebug: debug? @"true" : @"false", kGSDKOpenid: [GSDKInfoTool openID]};
    [GSDKReporter gsdkReport:@"gsdk_init" Params:initDict];
    //请求登陆云控接口挪过来
    [self GSDKRequestLoginControl];
}

- (void) GSDKRequestLoginControl {
    // NOTE(三合一): 直接从GCloud云控实现上获取值
    dispatch_async([GSDKInfoTool gsdk_event_queue], ^{
        GemCCStrategy* gemStrategy = [GSDKInfoTool getGemCCStrategy];
        if (!gemStrategy) {
            return;
        }
        NSMutableDictionary* loginControlDict = [NSMutableDictionary dictionary];
        
        BOOL loginSwitch = [gemStrategy getBool:kGSDKLogin defaultValue:true];
        loginControlDict[kGSDKLogin] = @(loginSwitch);
        BOOL paySwitch = [gemStrategy getBool:kGSDKPay defaultValue:true];
        loginControlDict[kGSDKPay] = @(paySwitch);
        BOOL domainSwitch = [gemStrategy getBool:kGSDKDomain defaultValue:false];
        loginControlDict[kGSDKDomain] = @(domainSwitch);
        
        loginControlDict[kGSDKDomain1] = [gemStrategy getString:kGSDKDomain1 value:@"" defaultValue:@""];
        loginControlDict[kGSDKPort1] = [NSString stringWithFormat:@"%d", [gemStrategy getInt:kGSDKPort1 defaultValue:0]];
        loginControlDict[kGSDKDomain2] = [gemStrategy getString:kGSDKDomain2 value:@"" defaultValue:@""];
        loginControlDict[kGSDKPort2] = [NSString stringWithFormat:@"%d", [gemStrategy getInt:kGSDKPort2 defaultValue:0]];
        loginControlDict[kGSDKDomain3] = [gemStrategy getString:kGSDKDomain3 value:@"" defaultValue:@""];
        loginControlDict[kGSDKPort3] = [NSString stringWithFormat:@"%d", [gemStrategy getInt:kGSDKPort3 defaultValue:0]];
        loginControlDict[kGSDKDomain4] = [gemStrategy getString:kGSDKDomain4 value:@"" defaultValue:@""];
        loginControlDict[kGSDKPort4] = [NSString stringWithFormat:@"%d", [gemStrategy getInt:kGSDKPort4 defaultValue:0]];
        loginControlDict[kGSDKDomain5] = [gemStrategy getString:kGSDKDomain5 value:@"" defaultValue:@""];
        loginControlDict[kGSDKPort5] = [NSString stringWithFormat:@"%d", [gemStrategy getInt:kGSDKPort5 defaultValue:0]];
        loginControlDict[kGSDKDomain6] = [gemStrategy getString:kGSDKDomain6 value:@"" defaultValue:@""];
        loginControlDict[kGSDKPort6] = [NSString stringWithFormat:@"%d", [gemStrategy getInt:kGSDKPort6 defaultValue:0]];
        
        loginControlDict[TCP_DETECT_TARGETS_NAME] = [gemStrategy getString:TCP_DETECT_TARGETS_NAME value:@"" defaultValue:@""];
        loginControlDict[UDP_DETECT_TARGETS_NAME] = [gemStrategy getString:UDP_DETECT_TARGETS_NAME value:@"" defaultValue:@""];
        loginControlDict[START_DETECT_CHANNEL_NAME] = [gemStrategy getString:START_DETECT_CHANNEL_NAME value:@"" defaultValue:@""];
        loginControlDict[CALL_REPORT_INTERVAL_SEC_NAME] = [NSString stringWithFormat:@"%d", [gemStrategy getInt:CALL_REPORT_INTERVAL_SEC_NAME defaultValue:0]];
        
        [self gotLoginControl:loginControlDict];
    });
}

- (void)gotLoginControl:(NSDictionary *)resultsDictionary {
    dispatch_async(gsdk_realtime_queue(), ^{
        NSString * tcpString = resultsDictionary[@"tcp"];
        if (tcpString && tcpString.length > 0) {
            self.tcpArray = [tcpString componentsSeparatedByString:@";"];
        }
    });
    dispatch_async(gsdk_udpDetect_queue(), ^{
        NSString * udpString = resultsDictionary[@"udp"];
        if (udpString && udpString.length > 0) {
            self.udpArray = [udpString componentsSeparatedByString:@";"];
        }
    });
    [self detectOperation:resultsDictionary];
    
    // 设置模块调用频率
    int callIntervalMills = [[resultsDictionary objectForKey:CALL_REPORT_INTERVAL_SEC_NAME] intValue];
    if (callIntervalMills > 0) {
        int callReportIntervalMills = callIntervalMills * 1000;
        [[GSDKCallRecorder sharedInstance] setReportIntervalMillsValue: callReportIntervalMills];
    }
    
    // 启动测速
    NSString * channelName = [resultsDictionary objectForKey:START_DETECT_CHANNEL_NAME];
    if (channelName && channelName.length > 0) {
        [self mayStartSpeedTestWhenInit:channelName];
    }
}

- (void) mayStartSpeedTestWhenInit:(NSString *) detectChannelName {
    GSDKDetectChannel detectChannel = [self getDetectChannel:detectChannelName];
    switch (detectChannel) {
        case TCP:
            [self GSDKRealTimeTCPDetectWhenInit:YES];
            break;
        case UDP:
            [self GSDKRealTimeUDPDetectWhenInit:YES];
            break;
        default:
            break;
    }
}

- (GSDKDetectChannel) getDetectChannel:(NSString *) detectChannelName {
    if (NSOrderedSame == [TCP_DETECT_CHANNEL_NAME caseInsensitiveCompare:detectChannelName]) {
        return TCP;
    }
    if (NSOrderedSame == [UDP_DETECT_CHANNEL_NAME caseInsensitiveCompare:detectChannelName]) {
        return UDP;
    }
    return NONE;
}

- (void) detectOperation:(NSDictionary *)dict {
    self.login_flag = [dict[kGSDKLogin] boolValue];
    self.pay_flag = [dict[kGSDKPay] boolValue];
    self.domain_flag = [dict[kGSDKDomain] boolValue];
    if (_domain_flag) {
        GSDKLOG(@"开启域名探测");
        GSDKLoginPayDetect * detect = [[GSDKLoginPayDetect alloc] init];
        [detect detectPort:dict[kGSDKDomain1] Port1:dict[kGSDKPort1]
                   Domain2:dict[kGSDKDomain2] Port2:dict[kGSDKPort2]
                   Domain3:dict[kGSDKDomain3] Port3:dict[kGSDKPort3]
                   Domain4:dict[kGSDKDomain4] Port4:dict[kGSDKPort4]
                   Domain5:dict[kGSDKDomain5] Port5:dict[kGSDKPort5]
                   Domain6:dict[kGSDKDomain6] Port6:dict[kGSDKPort6]];
    } else {
        GSDKLOG(@"不开启域名探测");
    }
}

- (void) GSDKSetUserName:(NSString *)openID {
    if (openID && [openID length] > 0) {
        [[NSUserDefaults standardUserDefaults] setValue:openID forKey:kGSDKOpenID];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
}

- (void) GSDKRealTimeTCPDetectWhenInit:(BOOL) initing {
    dispatch_async(gsdk_realtime_queue(), ^{
        NSLog(@"[Info] GSDKRealTimeTCPDetect");
        if (!_tcpArray || [_tcpArray count] < 1) {
            GSDKLOG(@"tcpArray is null, return!!!");
//            [[GSDKInitManager sharedInstance] OnGSDKLogNotify:-1 ErrMsg:@"tcpArray is null" ExtMsg:@"GSDKTimeOutDetect"];
            return;
        }
        NSString * netType = [GSDKInfoTool netType];
        NSString * signalStrength = @"-1";
        NSString * openID = [GSDKInfoTool openID];
        dispatch_queue_t queue = dispatch_queue_create("realTimeQueue", DISPATCH_QUEUE_SERIAL);
        GSDKDetectPort * tcpDetect = [[GSDKDetectPort alloc] init];
        NSMutableDictionary * dict = @{kGSDK_RealTime_NetType: netType,
                                       kGSDK_RealTime_RSSI: signalStrength,
                                       kGSDKOpenid: openID}.mutableCopy;
        for (int i = 0; i < [_tcpArray count]; i++) {
            if (!_tcpArray[i] || [_tcpArray[i] length] <= 0) {
                continue;
            }
            NSArray * array = [_tcpArray[i] componentsSeparatedByString:@":"];
            if (!array || [array count] != 2 || !array[0] || !array[1]) {
                continue;
            }
            __block NSString * cost = [NSString stringWithFormat:@"%@_1000", array[0]];
            dispatch_semaphore_t sema = dispatch_semaphore_create(0);
            dispatch_async(queue, ^{
                cost = [tcpDetect connectionTime:array[0] Port:[array[1] intValue]];
                dispatch_semaphore_signal(sema);
            });
            dispatch_semaphore_wait(sema, dispatch_time(DISPATCH_TIME_NOW, (int64_t)((Detect_TCP_TIME_OUT + Detect_Buffer) * NSEC_PER_SEC)));
            [dict setValue:cost forKey:[NSString stringWithFormat:@"d%d", (i + 1)]];
        }
        NSString * gateDelay = @"1000,1000,1000";
        NSString * routerIp = [GSDKInfoTool routerIPAddress];
        GSDKLOG(@"The router's ip is: %@", routerIp);
        if (routerIp) {
            [[GSDKPingDetect sharedInstance] isPingConnect:routerIp];
            dispatch_semaphore_t sema = dispatch_semaphore_create(0);
            dispatch_semaphore_wait(sema, dispatch_time(DISPATCH_TIME_NOW, (int64_t)(Detect_PING_TIME_OUT * NSEC_PER_SEC)));
            NSArray * timeConsumingList = [[GSDKPingDetect sharedInstance] Completation];
            NSMutableString * timeStr = [NSMutableString stringWithString:@""];
            if (timeConsumingList && timeConsumingList.count == 3) {
                NSString * time = timeConsumingList[0];
                [timeStr appendFormat:@"%@", time];
                for (int i = 1; i < timeConsumingList.count; i++) {
                    NSString * time = timeConsumingList[i];
                    [timeStr appendFormat:@",%@",time];
                }
            } else {
                [timeStr appendString:@"-1,-1,-1"];
            }
            GSDKLOG(@"%@", timeStr);
            gateDelay = timeStr;
        }
        [dict setValue:gateDelay forKey:kGSDK_RealTime_GateDelay];
        if (initing) {
            [dict setValue:TCP_DETECT_CHANNEL_NAME forKey:START_DETECT_CHANNEL_NAME];
        } else {
            [dict setValue:NONE_DETECT_CHANNEL_NAME forKey:START_DETECT_CHANNEL_NAME];
        }
        [GSDKReporter gsdkReport:TCPDetectReportName Params:dict];
        [[TApmApiSingleInstance sharedInstance] postDetectTimeOut:dict];
//        [[GSDKInitManager sharedInstance] OnGSDKLogNotify:0 ErrMsg:@"success" ExtMsg:@"GSDKTimeOutDetect"];
    });
}

- (void) GSDKRealTimeUDPDetectWhenInit:(BOOL) initing {
//    __block NSMutableDictionary * udpDict = nil;
//    dispatch_semaphore_t sema = dispatch_semaphore_create(0);
    dispatch_async(gsdk_udpDetect_queue(), ^{
        NSLog(@"[Info] GSDKRealTimeUDPDetect");
        if (!_udpArray || [_udpArray count] < 1) {
            GSDKLOG(@"udpArray is null, return!!!");
//            dispatch_semaphore_signal(sema);
            return;
        }
        NSString * netType = [GSDKInfoTool netType];
        NSString * signalStrength = @"-1";
        NSString * openID = [GSDKInfoTool openID];
        NSString * gateDelay = @"1000,1000,1000";
        NSString * routerIp = [GSDKInfoTool routerIPAddress];
        GSDKLOG(@"The router's ip is: %@", routerIp);
        if (routerIp) {
            [[GSDKUDPPingDetect sharedInstance] isUDPPingConnect:routerIp];
            dispatch_semaphore_t sema = dispatch_semaphore_create(0);
            dispatch_semaphore_wait(sema, dispatch_time(DISPATCH_TIME_NOW, (int64_t)(Detect_PING_TIME_OUT * NSEC_PER_SEC)));
            NSArray * timeConsumingList = [[GSDKUDPPingDetect sharedInstance] UDPCompletation];
            NSMutableString * timeStr = [NSMutableString stringWithString:@""];
            if (timeConsumingList && timeConsumingList.count == 3) {
                NSString * time = timeConsumingList[0];
                [timeStr appendFormat:@"%@", time];
                for (int i = 1; i < timeConsumingList.count; i++) {
                    NSString * time = timeConsumingList[i];
                    [timeStr appendFormat:@",%@",time];
                }
            } else {
                [timeStr appendString:@"-1,-1,-1"];
            }
            GSDKLOG(@"%@", timeStr);
            gateDelay = timeStr;
        }
        GSDKUdpDetect * udpDetect = [[GSDKUdpDetect alloc] init];
        NSMutableDictionary * dict = @{kGSDK_RealTime_NetType: netType,
                                       kGSDK_RealTime_RSSI: signalStrength,
                                       kGSDK_RealTime_GateDelay: gateDelay,
                                       kGSDKOpenid: openID}.mutableCopy;
        NSMutableDictionary * udpDict = [NSMutableDictionary dictionary];
        for (int i = 0; i < [_udpArray count]; i++) {
            if (!_udpArray[i] || [_udpArray[i] length] <= 0) {
                continue;
            }
            NSArray * array = [_udpArray[i] componentsSeparatedByString:@":"];
            if (!array || [array count] != 2 || !array[0] || !array[1]) {
                continue;
            }
            NSString * cost = [udpDetect udpConnectTime:array[0] Port:[array[1] intValue]];
            [udpDict setValue:cost forKey:[NSString stringWithFormat:@"d%d", (i + 1)]];
        }
        [dict addEntriesFromDictionary:udpDict];
        if (initing) {
            [dict setValue:UDP_DETECT_CHANNEL_NAME forKey:START_DETECT_CHANNEL_NAME];
        } else {
            [dict setValue:NONE_DETECT_CHANNEL_NAME forKey:START_DETECT_CHANNEL_NAME];
        }
        [GSDKReporter gsdkReport:UDPDetectReportName Params:dict];
//        dispatch_semaphore_signal(sema);
    });
//    dispatch_semaphore_wait(sema, DISPATCH_TIME_FOREVER);
//    return udpDict;
}

- (void) GSDKRealTimeTCPDetect {
    [self GSDKRealTimeTCPDetectWhenInit:NO];
}

//- (NSDictionary *) GSDKRealTimeUDPDetect {
//    [self GSDKRealTimeUDPDetectWhenInit:NO];
//}

static dispatch_queue_t gsdk_realtime_queue() {
    static dispatch_queue_t gsdk_realtime_queue;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        gsdk_realtime_queue = dispatch_queue_create("com.tencent.gsdk.realTimeDetect", DISPATCH_QUEUE_SERIAL);
    });
    return gsdk_realtime_queue;
}

static dispatch_queue_t gsdk_udpDetect_queue() {
    static dispatch_queue_t gsdk_udpDetect_queue;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        gsdk_udpDetect_queue = dispatch_queue_create("com.tencent.gsdk.udpDetect", DISPATCH_QUEUE_SERIAL);
    });
    return gsdk_udpDetect_queue;
}

@end
