//
//  GSDKLoginPayDetect.m
//  GSDK
//
//  Created by fu chunhui on 2017/3/2.
//  Copyright © 2017年 fu chunhui. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GSDKLoginPayDetect.h"
#import "GSDKInitManager.h"
#import "GSDKDetectPort.h"
#import "GSDKInfoTool.h"
#import "GSDKReporter.h"

//域名联通性探测结果上报事件名
static NSString * const ConnectionReportName = @"gsdk_report_con";
static NSString * const PayConnectionReportName = @"gsdk_report_pay_con";

//域名联通性探测上报key值
static NSString * const kDomain1 = @"d1";
static NSString * const kDomain2 = @"d2";
static NSString * const kDomain3 = @"d3";
static NSString * const kDomain4 = @"d4";
static NSString * const kDomain5 = @"d5";
static NSString * const kDomain6 = @"d6";

@implementation GSDKLoginPayDetect

- (void) detectPort:(NSString *) domain1 Port1:(NSString *)port1 Domain2:(NSString *)domain2 Port2:(NSString *)port2 Domain3:(NSString *)domain3 Port3:(NSString *)port3 Domain4:(NSString *)domain4 Port4:(NSString *)port4 Domain5:(NSString *)domain5 Port5:(NSString *)port5 Domain6:(NSString *)domain6 Port6:(NSString *)port6 {
    dispatch_queue_t queue = dispatch_queue_create("com.tencent.gsdk.port", DISPATCH_QUEUE_CONCURRENT);
    dispatch_async(queue, ^{
        //结果上报
        NSMutableDictionary * dic = [NSMutableDictionary dictionaryWithCapacity:6];
        GSDKDetectPort * dect = [[GSDKDetectPort alloc] init];
        dic[kDomain1] = [dect isConnection:domain1 Port:[port1 intValue]];
        dic[kDomain2] = [dect isConnection:domain2 Port:[port2 intValue]];
        dic[kDomain3] = [dect isConnection:domain3 Port:[port3 intValue]];
        dic[kDomain4] = [dect isConnection:domain4 Port:[port4 intValue]];
        dic[kDomain5] = [dect isConnection:domain5 Port:[port5 intValue]];
        dic[kDomain6] = [dect isConnection:domain6 Port:[port6 intValue]];
        dic[kGSDKOpenid] = [GSDKInfoTool openID];
        GSDKLOG(@"探测结果：%@", dic);
        [GSDKReporter gsdkReport:ConnectionReportName Params:dic];
    });
}
//www.qq.com
//www.sohu.com
//www.sina.com.cn
- (void)detectPayPort {
    dispatch_queue_t queue = dispatch_queue_create("com.tencent.gsdk.payport", DISPATCH_QUEUE_CONCURRENT);
    dispatch_async(queue, ^{
        //结果上报
        NSMutableDictionary * dic = [NSMutableDictionary dictionaryWithCapacity:6];
        GSDKDetectPort * dect = [[GSDKDetectPort alloc] init];
        dic[kDomain1] = [dect isConnection:@"www.qq.com" Port:80];
        dic[kDomain2] = [dect isConnection:@"www.sohu.com" Port:80];
        dic[kDomain3] = [dect isConnection:@"www.sina.com.cn" Port:80];
        dic[kGSDKOpenid] = [GSDKInfoTool openID];
        [GSDKReporter gsdkReport:PayConnectionReportName Params:dic];
    });
}

@end
