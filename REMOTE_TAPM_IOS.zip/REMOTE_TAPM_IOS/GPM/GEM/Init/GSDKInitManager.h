//
//  GSDKInitManager.h
//  GSDK
//
//  Created by fu chunhui on 2017/3/2.
//  Copyright © 2017年 fu chunhui. All rights reserved.
//

#ifndef GSDKInitManager_h
#define GSDKInitManager_h

#import "GSDKLogger.h"
#import "GSDKStructs.h"

@interface GSDKInitManager : NSObject

+ (id) sharedInstance;

- (void) GSDKInit:(BOOL)debug;
- (void) GSDKSetUserName:(NSString *)openID;

- (void) GSDKRealTimeTCPDetect;
//- (NSDictionary *) GSDKRealTimeUDPDetect;

@property (nonatomic, readonly, assign) BOOL login_flag;
@property (nonatomic, readonly, assign) BOOL pay_flag;
@property (nonatomic, readonly, assign) BOOL domain_flag;

@end
#endif /* GSDKInitManager_h */
