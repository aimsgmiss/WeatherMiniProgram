//
//  GSDKStructs.h
//  GSDK
//
//  Created by Mike on 4/11/16.
//  Copyright © 2016 Tencent. All rights reserved.
//

typedef enum _gsdkpay{
    /**
     * 必接，此步骤为购买过程第一步，对应场景可灵活调整
     * 示例：如第一步为”选择商品（道具/点券）“，则此步骤为”选择商品（道具/点券）“；
     * 如第一步为”点击购买“，则此步骤为”点击购买“
     **/
    gsdkPayStart = 0,
    
    /**
     * 点击购买，分两种情况：游戏内道具/点券
     * 游戏内道具：如余额足，直接扣除，购买成功，跳转至gsdkPayDone；如余额不足，购买失败，跳转至gsdkPayDone；
     * 点券：拉起支付界面
     * 安卓平台支付成功或失败均会有回调，跳转至gsdkPayDone
     * ios平台额外多两步
     **/
    gsdkClickBuy = 1,
    
    /**
     * ios平台回调
     **/
    gsdkOrder = 2,
    
    /**
     * 下单结果回调
     **/
    gsdkPay = 3,
    
    /**
     * 必接，支付过程结束
     * 游戏内道具购买：成功或失败
     * 点券购买：安卓平台收到支付成功或失败回调；ios平台收到发货结果回调
     **/
    gsdkPayDone = 4 // 必接
    
} GSDKPayItem;

typedef enum _gsdkenvironment{

    gsdkTest = 0,     // 测试环境
    gsdkDomestic = 1, // 国内环境
    gsdkOverseas = 2, // 海外环境
    gsdkNA = 3        // 北美CODM环境
    
} GSDKEnvironment;

typedef enum _gsdkreportplatform{
    
    gsdkBeacon = 1,    // 数据仅上报灯塔
    gsdkTdm = 2,       // 数据仅上报tdm
    gsdkBeaconTdm = 3, // 数据同时上报灯塔和tdm
    
} GSDKReportPlatform;

typedef enum GSDKDetectChannel {
    
    TCP = 0,
    UDP = 1,
    NONE = 2
} GSDKDetectChannel;

typedef enum GSDKCloudConfigSource {
    
    FROM_MEMORY_CACHE = 0,
    FROM_NETWORK = 1,
    FROM_DISK_CACHE = 2,
    FROM_DEFAULT_VALUE = 3,
} GSDKCloudConfigSource;
