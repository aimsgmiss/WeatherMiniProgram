//
//  GSDKCallRecorder.h
//  GSDK
//
//  Created by 王泽锋 on 2019/6/4.
//  Copyright © 2019 fu chunhui. All rights reserved.
//

@interface GSDKCallRecorder : NSObject

+ (id) sharedInstance;
- (void) setReportIntervalMillsValue:(int) reportIntervalMillsValue;
- (void) recordCall:(NSString *) call;

@end
