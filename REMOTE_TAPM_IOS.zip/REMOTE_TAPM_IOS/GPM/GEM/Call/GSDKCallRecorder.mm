//
//  GSDKCallRecorder.m
//  GSDK
//
//  Created by 王泽锋 on 2019/6/4.
//  Copyright © 2019 fu chunhui. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#include "GSDKCallRecorder.h"
#import "GSDKInfoTool.h"
#import "GSDKReporter.h"
#import "GSDKLogger.h"

static const int DEFAULT_REPORT_INTERVAL_MILLS = 60 * 1000;
static const int EACH_CALL_MIN_CAPACITY = 4;

static NSString * const CALL_STAT_EVENT_NAME = @"gsdk_model_call_stat";
static NSString * const CALL_STAT_KEY = @"mode";
static NSString * const OPEN_ID_KEY = @"openid";

static GSDKCallRecorder * gCallRecorder = nil;

@interface GSDKCallRecorder()

@property (nonatomic, readwrite, assign) int reportIntervalMills;

// NOTE: use in [[GSDKInfoTool] gsdk_queue]
@property (nonatomic, readwrite, strong) NSMutableDictionary * call2CountDict;

@property (nonatomic, readonly, strong) dispatch_block_t reportTask;
@property (nonatomic, readwrite, strong) dispatch_source_t reportTimer;

@end

@implementation GSDKCallRecorder

+ (id) sharedInstance {
    static dispatch_once_t token;
    dispatch_once(&token, ^{
        gCallRecorder = [[GSDKCallRecorder alloc] init];
    });
    return gCallRecorder;
}

- (instancetype) init {
    self = [super init];
    
    if (self) {
        _reportIntervalMills = DEFAULT_REPORT_INTERVAL_MILLS;
        
        __weak __typeof(self) weakSelf = self;
        _reportTask = ^{
            __strong __typeof(self) strongSelf = weakSelf;
            if (!strongSelf) {
                return;
            }
            if (!strongSelf.call2CountDict || 0 == [strongSelf.call2CountDict count]) {
                return;
            }

            NSString * callStatValue = [strongSelf callStatInfo];
            NSDictionary * reportInfos = [[NSDictionary alloc] initWithObjectsAndKeys:callStatValue, CALL_STAT_KEY, [GSDKInfoTool openID], kGSDKOpenid, nil];
            [GSDKReporter gsdkReport:CALL_STAT_EVENT_NAME Params:reportInfos];
        };
        [self cancelReportTimerIfNecessary];
        _reportTimer = [self getReportTimerWithIntervalMills:_reportIntervalMills ReportTask:_reportTask Queue:[GSDKInfoTool gsdk_queue]];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reportWhenAppEnterBackground) name:UIApplicationDidEnterBackgroundNotification object:nil];
    }
    
    return self;
}

- (void) setReportIntervalMillsValue:(int) reportIntervalMillsValue {
    _reportIntervalMills = reportIntervalMillsValue;
    
    [self cancelReportTimerIfNecessary];
    _reportTimer = [self getReportTimerWithIntervalMills:_reportIntervalMills ReportTask:_reportTask Queue:[GSDKInfoTool gsdk_queue]];
}

- (void) recordCall:(NSString *) call {
    if (!call) {
        return;
    }
    
    __weak __typeof(self) weakSelf = self;
    dispatch_async([GSDKInfoTool gsdk_queue], ^{
        __strong __typeof(self) strongSelf = weakSelf;
        if (!strongSelf) {
            return;
        }
        
        // TODO: for DEBUG
        GSDKLOG(@"GSDKCallRecorder recordCall:%@", call);
        if (!strongSelf.call2CountDict) {
            strongSelf.call2CountDict = [NSMutableDictionary new];
        }
        id countValue = [strongSelf.call2CountDict objectForKey:call];
        int count;
        if (countValue) {
            count = [countValue intValue] + 1;
        } else {
            count = 1;
        }
        [strongSelf.call2CountDict setValue:[NSNumber numberWithInt:count] forKey:call];
    });
}

- (void) reportWhenAppEnterBackground {
    dispatch_async([GSDKInfoTool gsdk_queue], _reportTask);
}

- (dispatch_source_t) getReportTimerWithIntervalMills:(int) intervalMills ReportTask:(dispatch_block_t) reportTask Queue:(dispatch_queue_t) queue {
    dispatch_source_t reportTimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
    
    if (reportTimer) {
        uint64_t intervalNanos = intervalMills / 1000ull * NSEC_PER_SEC;
        dispatch_source_set_timer(reportTimer, dispatch_walltime(NULL, 0), intervalNanos, intervalNanos);
        dispatch_source_set_event_handler(reportTimer, reportTask);
        dispatch_resume(reportTimer);
    }
    
    return reportTimer;
}

- (void) cancelReportTimerIfNecessary {
    if (_reportTimer) {
        dispatch_source_cancel(_reportTimer);
        _reportTimer = nil;
    }
}

// NOTE: call when call2CountDict is not empty
// NOTE: use in [[GSDKInfoTool] gsdk_queue]
- (NSString *) callStatInfo {
    NSMutableString * callStatInfoValue = [NSMutableString stringWithCapacity:EACH_CALL_MIN_CAPACITY *  [_call2CountDict count]];
    
    for (NSString * call in _call2CountDict) {
        int count = [_call2CountDict[call] intValue];
        [callStatInfoValue appendString:call];
        [callStatInfoValue appendString:@":"];
        [callStatInfoValue appendString:[NSString stringWithFormat:@"%d", count]];
        [callStatInfoValue appendString:@","];
    }
    [callStatInfoValue deleteCharactersInRange:NSMakeRange([callStatInfoValue length] - 1, 1)];
    [_call2CountDict removeAllObjects];
    
    return callStatInfoValue;
};

@end
