#!/bin/bash

#xcodebuild build BITCODE_GENERATION_MODE=bitcode OTHER_CFLAGS="-fembed-bitcode" -configuration "Release" -sdk iphoneos clean build
#xcodebuild -configuration "Debug" -sdk iphonesimulator clean build
#lipo -create ./build/Release-iphoneos/libAPM.a ./build/Debug-iphonesimulator/libAPM.a  -output ./APM.a

declare -i revisedVersionNum=$1+20
revisedVersion=1.0.00.00$revisedVersionNum
cat revisedVersion

sed -i '' -e "s/\"1.0.00..*\"/\"${revisedVersion}\"/g" APM/APM/GCloud/PluginGPM.h
cat APM/APM/GCloud/PluginGPM.h


xcodebuild  -configuration "Release" -sdk iphoneos clean build
cp ./build/Release-iphoneos/libGPM.a ./
mv libGPM.a GPM.a

