//#if defined(_WIN32) || defined(_WIN64)
#ifndef _INI_FILE_IMP_
#define _INI_FILE_IMP_
#include "IniFile.h"
#include<vector>
#include<string>

#include "AMutex.h"

using namespace std;

namespace ABase
{
    
    class CIniFileImpl : public IniFile
    {
    public:
        explicit CIniFileImpl(const char*fileName);
        virtual ~CIniFileImpl();
        
    public:
        virtual bool Load();
        virtual bool Save();
        AString ReadString( const char*section, const char*key, const char*value);
        int ReadInt( const char*section, const char*key, int value);
        long long ReadLongLong( const char*section, const char*key, long long value);
        AString ReadString( const char*section, const char*key, const char*value , bool& hasValue);
        int    ReadInt( const char*section, const char*key, int value , bool& hasValue);
        long long ReadLongLong( const char*section, const char*key, long long value , bool& hasValue);
        bool WriteString( const char*section, const char*key, const char*value );
        bool WriteInt( const char*section, const char*key, int value );
        bool WriteLongLong( const char*section, const char*key, long long value );
        bool RemoveSection( const char*section );
        bool RemoveKey( const char*section, const char*key );
        //void GetAllSections( AArray* sections);
        void GetAllKeys( const char* section, AArray* keys);
        bool IsContainKey(const char* section, const char*key);
        bool RemoveAll();

    private:
        static string Trim( const string& str );
        static string LTrim( const string& str );
        static string RTrim( const string& str );

    protected:
        string m_fileName;
        vector<string> m_vctLine;
        CMutex m_mutex;
    };
}


#endif

//#endif
