//#if defined(_WIN32) || defined(_WIN64)
#ifndef _FISH_INI_FILE_IMP_
#define _FISH_INI_FILE_IMP_

#include<vector>
#include<string>

#include "AMutex.h"
#include "IniFile.h"
#include "IniFileImp.h"

#define KEY_LEN 16
#define MD5_LEN 16
#define PUB_KEY_LEN 64

namespace ABase
{
    
    class InitFileHeadBase
    {
    public:
        uint16_t Magic;
        uint16_t Version;
        uint32_t HeadLen; //base + ext
        uint32_t BodyLen;
    };
    
    class InitFileHeadExt
    {
    public:
        uint16_t Encyption;
        uint16_t PubKeyLen;
        uint8_t PubKey[PUB_KEY_LEN];
        uint16_t Md5Len;
        uint8_t Md5[MD5_LEN];
    };
    
    class EncryptedIniFileImpl : public CIniFileImpl
    {
    public:
        explicit EncryptedIniFileImpl(const char*fileName);
        virtual ~EncryptedIniFileImpl();
        
    public:
        virtual bool Load(void);
        virtual bool Save(void);

    private:
        void _MakeTeaKey(uint8_t *teaKey, int keyLen, uint8_t * pubKey);
        void _GetTeaKey(uint8_t *teaKey, int keyLen);
        void _SaveTeaKey(uint8_t *teaKey, int keyLen);
    };
    

}


#endif

//#endif
