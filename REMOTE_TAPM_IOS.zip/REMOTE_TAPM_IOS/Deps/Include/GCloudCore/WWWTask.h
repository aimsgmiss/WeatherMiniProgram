//
//  WWWTask.hpp
//  WWW
//
//  Created by vforkk on 11/17/16.
//  Copyright © 2016 vforkk. All rights reserved.
//

#ifndef WWWTask_hpp
#define WWWTask_hpp

#include <map>
#include <string>
#if defined(_WIN32) || defined(_WIN64)
#include<windows.h>
#endif

#include "AMutex.h"
#include "IniFile.h"
#include "OperationQueue.h"

#include "UrlRequest.h"
#include "WWW.h"

#ifdef ANDROID
#undef __APPLE__
#endif

#ifdef __ORBIS__
#include "AThreadBase.h"
#include <scetypes.h>
#endif

//ms
#define DEFAULT_TIME_OUT 20000

namespace ABase
{
    class WWWTaskBase : virtual public WWWTask
    {
    public:
        WWWTaskBase(const char* url);
        virtual ~WWWTaskBase();
        
    public:
        void SetHttpHeader(const char* name, const char* value);
        std::map<std::string, std::string> GetHeaders(){return _headers;};
        void SetUrl(const char* url);
        const char* GetUrl();
        
    protected:
        std::string _url;
        std::map<std::string, std::string> _headers;
    };
    
    
    
    
    
    class DataTaskImpl
    : public WWWTaskBase
    , public DataTask
#ifdef ANDROID
    , UrlRequest::Listener
#elif defined(__ORBIS__)
	, CThreadBase
#endif
    {
    public:
        DataTaskImpl(const char* url);
        ~DataTaskImpl();
        
    public:
        void SetListener(DataTask::Listener* listener);
        void RemoveListener(DataTask::Listener* listener);
		DataTask::Listener*  GetListener(){return _listener;}
        
    public:
        void Get();
        void Post(const char* postData, int postLength);
        void Cancel();
        
    private:
        void _init();
        void _uninit();

    public:
        void Finish();
        void Destroy();
        
    private:
#ifdef ANDROID
        void onUrlRequestResponse(int status, UrlResponse *response);
#endif
        void FinishedCallback( WWWErrorCode errorCode, int httpStatus , const char* data, long long totalSize);
    private:
        DataTask::Listener* _listener;
        bool _isCancel;
#if defined(_WIN32) || defined(_WIN64)
	public:
		HANDLE	_hThread;
		void OnThreadProc(const char* postData, int postLength);
#endif

#if defined(__ORBIS__)
		void OnThreadProc();
		void OnThreadStart(){}
		void OnThreadExit(){}
		void OnThreadPause(){}
		void OnThreadResume(){}
		void OnThreadError(int Error){}
		int32_t http_get(int libhttpCtxId, const char *targetUrl);
#endif

        
    private:
		CMutex _mutex;
        volatile bool _isRequesting;
        volatile bool _isFinished;
#ifdef ANDROID
        UrlRequest* _impl;
#else
        void* _impl;
#endif
    };
    
    
    class DownloadFileTaskImpl
    : public WWWTaskBase
    , public DownloadFileTask
#ifdef ANDROID
    , UrlRequest::TaskListener
#endif
    {
    public:
        DownloadFileTaskImpl(const char* url, const char* saveFilePath);
        ~DownloadFileTaskImpl();
        
    public:
        void Get(){}
        void Post(const char* postData, int postLength){}
 
    public:
        void Pause();
        void Resume();
        void Cancel();
    
    public:
        void SetListener(DownloadFileTask::Listener* listener);
        void RemoveListener(DownloadFileTask::Listener* listener);
        DownloadFileTask::Listener* GetListener(){return _listener;}
        
    public:
        const char* GetLocalFilePath(){return _saveFilePath.c_str();}
       
    private:
        void _init();
        void _uninit();

    public:
        void Finish();
        void Destroy();

#ifdef ANDROID
    private:
        void onTaskBegan(long totalSize);
        void onTaskProgress(long currentSize, long totalSize);
        void onTaskFinished(int error, long totalSize);

#endif

        
    public:
        CMutex _mutex;
        
    private:
        std::string _saveFilePath;
        DownloadFileTask::Listener* _listener;
        volatile bool _isRequesting;
        volatile bool _isFinished;
#ifdef ANDROID
        UrlRequest* _impl;
#else
        void* _impl;
#endif
        
    };
    
    class UploadTaskImpl
    :public ABase::OperationTargetBase,
    public WWWTaskBase,
    public UploadTask
#ifdef ANDROID
    , UrlRequest::UploadTaskListener
#endif
    {
    public:
        UploadTaskImpl(const char* url, const char* fileName);
        ~UploadTaskImpl();
    
    public:
        void Get(){}
        void Post(const char* postData, int postLength){}
        
    private:
        void _init();
        void _uninit();
        void Upload(int size,int part_count, int count, const char* md5);
        void onWorkingThread(ObjectOperation* op, void* param);

    public:
        void Finish();
        void Destroy();

        
    public:
        void Pause();
        void Resume();
        void Cancel();
        
    public:
        void SetListener(UploadTask::Listener* listener);
        void RemoveListener(UploadTask::Listener* listener);
        UploadTask::Listener* GetListener(){return _listener;}
        
    public:
        const char* GetLocalFilePath(){return _fileName.c_str();}
    
    private:
        IniFile* _iniFile;
        std::string _fileName;
        std::string _fileMD5;
        UploadTask::Listener* _listener;
        volatile bool _isRequesting;
        volatile bool _isFinished;
        
    public:
        CMutex _mutex;

#ifdef ANDROID
        UrlRequest* _impl;
#else
        void* _impl;
#endif
    
    public:
        void SaveUploadingPart(int part);
        void RemoveCacheData();
        
#ifdef ANDROID
    private:
        void onTaskBegan(long totalSize);
        void onTaskProgress(long currentSize, long totalSize);
        void onTaskFinished(int error, long totalSize);

#endif
        
#if defined(_WIN32) || defined(_WIN64)
	public:
		HANDLE	_hThread;
		void OnThreadProc();
		bool isCancel;
#endif
  };






}

#endif /* WWWTask_hpp */
