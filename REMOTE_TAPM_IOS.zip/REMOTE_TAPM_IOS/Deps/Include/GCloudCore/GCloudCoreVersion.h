#ifndef GCLOUDCORE_VERSION__H
#define GCLOUDCORE_VERSION__H

#define GCLOUDCORE_VERSION_S "1.1.00.1670"
#define GCLOUDCORE_VERSION_HASH "9e11b28d3d3d294506cc7ca8d3a0b659fdc29535"

const char *gcloudcore_get_version();
const char *gcloudcore_get_version_hash();

#endif
