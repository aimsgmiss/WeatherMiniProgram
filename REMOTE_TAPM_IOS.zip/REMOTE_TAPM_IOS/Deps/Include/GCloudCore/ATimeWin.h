#ifndef __ATIMEWIN_H__
#define __ATIMEWIN_H__
#if defined(_WIN32) || defined(_WIN64)
#include <winsock2.h>
#include <Windows.h>

namespace ABase
{
    int gettimeofday(struct timeval *a_pstTv, struct timezone *a_pstTz);
}
#endif

#endif /*__ATIMEWIN_H__*/
